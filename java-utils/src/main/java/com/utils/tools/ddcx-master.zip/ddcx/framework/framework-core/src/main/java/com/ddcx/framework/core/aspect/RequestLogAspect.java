package com.ddcx.framework.core.aspect;

import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.base.dto.RequestLogDto;
import com.ddcx.framework.core.annotation.RequestLog;
import com.ddcx.framework.util.JacksonUtil;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.framework.util.RequestUtil;
import com.ddcx.framework.util.wrapper.Wrapper;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;

@Slf4j
@Aspect
@Component
public class RequestLogAspect {

    private ThreadLocal<Long> threadLocal = new ThreadLocal<>();

    private static final int MAX_SIZE = 2000;

    /**
     * Log annotation.
     */
    @Pointcut("@annotation(com.ddcx.framework.core.annotation.RequestLog)")
    public void RequestLog() {
    }

    /**
     * Do before.
     */
    @Before("RequestLog()")
    public void doBefore() {
        this.threadLocal.set(System.currentTimeMillis());

    }

    @AfterReturning(pointcut = "RequestLog()", returning = "returnValue")
    public void doAfter(final JoinPoint joinPoint, final Object returnValue) {
        if (returnValue instanceof Wrapper) {
            Wrapper result = (Wrapper) returnValue;
            if (PublicUtil.isNotEmpty(result) && result.getCode() == Wrapper.SUCCESS_CODE) {
                this.handleLog(joinPoint, result);
            }

        }
    }

    private void handleLog(final JoinPoint joinPoint, final Object result) {
        final Long startTime = this.threadLocal.get();
        final Long endTime = System.currentTimeMillis();
        HttpServletRequest request = RequestUtil.getRequest();
        String requestURI = request.getRequestURI();

        try {
            RequestLog requestLog = giveController(joinPoint);
            if (requestLog == null) {
                return;
            }
            LoginAuthDto loginUser = RequestUtil.getLoginUser();
            final String ipAddress = RequestUtil.getRemoteAddr(request);

            RequestLogDto requestLogDto = new RequestLogDto();
            requestLogDto.setClassName(joinPoint.getTarget().getClass().getName());
            requestLogDto.setMethodName(joinPoint.getSignature().getName());
            requestLogDto.setExcuteTime(endTime - startTime);
            requestLogDto.setStartTime(startTime);
            requestLogDto.setEndTime(endTime);
            requestLogDto.setIp(ipAddress);
            requestLogDto.setRequestUrl(requestURI);
            requestLogDto.setLogType(requestLog.logType().getType());
            requestLogDto.setLogName(requestLog.logType().getName());
            requestLogDto.setCreatedTime(System.currentTimeMillis() / 1000L);
            if (PublicUtil.isNotEmpty(loginUser)) {
                requestLogDto.setCreator(loginUser.getUserName());
                requestLogDto.setCreatedId(loginUser.getUserId());
            }

            getControllerMethodDescription(requestLog, requestLogDto, result, joinPoint);
            threadLocal.remove();
            log.info("requestLog--->>> " + requestLogDto);
            //  taskExecutor.execute(() -> this.restTemplate.postForObject("http://xxx/saveLog", requestLogDto, Integer.class));
        } catch (Exception ex) {
            log.error("获取注解类出现异常={}", ex.getMessage(), ex);
        }
    }


    private void getControllerMethodDescription(RequestLog relog, RequestLogDto requestLogDto, Object result, JoinPoint joinPoint) {
        if (relog.isSaveRequestData()) {
            setRequestData(requestLogDto, joinPoint);
        }
        if (relog.isSaveResponseData()) {
            setResponseData(requestLogDto, result);
        }
    }

    private void setResponseData(RequestLogDto requestLogDto, Object result) {
        try {
            requestLogDto.setResponseData(String.valueOf(result));
        } catch (Exception e) {
            log.error("获取响应数据,出现错误={}", e.getMessage(), e);
        }
    }

    private void setRequestData(RequestLogDto requestLogDto, JoinPoint joinPoint) {
        try {
            Object[] args = joinPoint.getArgs();
            if (args.length == 0) {
                return;
            }
            Object[] parameter = new Object[args.length];
            int index = 0;
            for (Object object : parameter) {
                if (object instanceof HttpServletRequest) {
                    continue;
                }
                parameter[index] = object;
                index++;
            }

            String requestData = JacksonUtil.toJsonWithFormat(parameter);

            if (requestData.length() > MAX_SIZE) {
                requestData = requestData.substring(MAX_SIZE);
            }

            requestLogDto.setRequestData(requestData);
        } catch (Exception e) {
            log.error("获取响应数据,出现错误={}", e.getMessage(), e);
        }
    }

    /**
     * 是否存在注解, 如果存在就记录日志
     */
    private static RequestLog giveController(JoinPoint joinPoint) {
        Method[] methods = joinPoint.getTarget().getClass().getDeclaredMethods();
        String methodName = joinPoint.getSignature().getName();
        if (null != methods && 0 < methods.length) {
            for (Method met : methods) {
                RequestLog relog = met.getAnnotation(RequestLog.class);
                if (null != relog && methodName.equals(met.getName())) {
                    return relog;
                }
            }
        }
        return null;
    }

}
