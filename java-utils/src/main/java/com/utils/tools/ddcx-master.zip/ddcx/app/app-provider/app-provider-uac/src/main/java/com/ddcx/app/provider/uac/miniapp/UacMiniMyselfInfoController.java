package com.ddcx.app.provider.uac.miniapp;


import com.ddcx.app.provider.api.uac.model.dto.MyselfInfoDto;
import com.ddcx.app.provider.api.uac.model.dto.UacUserDiffInfoDto;
import com.ddcx.app.provider.api.uac.model.vo.DeepMyselfInfoVo;
import com.ddcx.app.provider.api.uac.model.vo.MyselfInfoVo;
import com.ddcx.app.provider.api.uac.model.vo.UacUserDiffInfoVo;
import com.ddcx.app.provider.uac.service.UacSourceLogService;
import com.ddcx.app.provider.uac.service.UacUserService;
import com.ddcx.framework.base.dto.BaseQueryDto;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.UacSourceLog;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/myself")
@Api(value = "登录---小程序", tags = {"登录---小程序"})
public class UacMiniMyselfInfoController extends BaseController {


    @Autowired
    private UacUserService userService;


    /**
     * 个人中心
     */
    @ApiOperation(value = "获取个人中心", notes = "个人中心")
    @GetMapping(value = "/deep/info")
    public Wrapper<DeepMyselfInfoVo> getDeepMyselfInfo() {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        return userService.getDeepMyselfInfo(loginAuthDto.getUserId());
    }


    /**
     * 修改个人中心
     */
    @ApiOperation(value = "修改个人中心", notes = "修改个人中心")
    @PutMapping(value = "/deep/edit")
    public Wrapper editMyselfInfo(@RequestBody MyselfInfoDto dto) {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        return userService.editDeepMyselfInfo(loginAuthDto, dto);
    }


    /**
     * 个人中心
     */
    @ApiOperation(value = "个人中心", notes = "个人中心")
    @GetMapping(value = "/info")
    public Wrapper<MyselfInfoVo> getMyselfInfo() {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        return userService.getMyselfInfo(loginAuthDto);
    }


    /**
     * 个人中心
     */
    @ApiOperation(value = "个人中心", notes = "个人中心")
    @GetMapping(value = "/diff/info")
    public Wrapper<UacUserDiffInfoVo> getMyselfDiffInfo(@ApiParam(" 1:驾驶证 2:从业资格证 3:身份证 4:银行卡") @RequestParam("type") Integer type) {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        return userService.getMyselfDiffInfo(loginAuthDto, type);
    }


    /**
     * 个人中心
     */
    @ApiOperation(value = "个人中心", notes = "个人中心")
    @PutMapping(value = "/edit/diff/info")
    public Wrapper editMyselfDiffInfo(@ApiParam(" 1:驾驶证 2:从业资格证 3:身份证") @RequestParam("type") Integer type, @RequestBody UacUserDiffInfoDto dto) {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        return userService.editMyselfDiffInfo(loginAuthDto, type, dto);
    }

    /**
     * 积分记录
     */
    @ApiOperation(value = "积分记录", notes = "积分记录")
    @GetMapping(value = "/log")
    public Wrapper<PageInfo<UacSourceLog>> getLog(BaseQueryDto baseQueryDto) {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        return userService.getLog(loginAuthDto,baseQueryDto);
    }

}
