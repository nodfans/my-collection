package com.ddcx.app.provider.api.friend.service.hystrix;


import com.ddcx.app.provider.api.friend.service.FriendServiceFeignApi;
import org.springframework.stereotype.Component;

@Component
public class FriendServiceFeignApiHystrix implements FriendServiceFeignApi {
    @Override
    public void updateUserHeadImgAndUserName(Long userId, String imgPath, String userName) {

    }
}
