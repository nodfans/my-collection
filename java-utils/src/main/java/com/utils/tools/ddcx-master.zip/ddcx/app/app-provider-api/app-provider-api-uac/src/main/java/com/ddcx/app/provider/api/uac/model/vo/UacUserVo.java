package com.ddcx.app.provider.api.uac.model.vo;

import com.ddcx.model.uac.UacBank;
import com.ddcx.model.uac.UacUserAuth;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
@ApiModel(value = "UacUserVo", description = "用户信息")
public class UacUserVo implements java.io.Serializable {
    private static final long serialVersionUID = -8921738417733826881L;

    @ApiModelProperty(value = "用户ID", name = "userId")
    private Long userId;

    @ApiModelProperty(value = "用户编码", name = "userNo")
    private String userNo;

    @ApiModelProperty(value = "手机号码", name = "phone")
    private String phone;

    @ApiModelProperty(value = "身份证", name = "idCard")
    private String idCard;

    @ApiModelProperty(value = "状态 0：禁用，1：正常", name = "state")
    private Integer state;

    @ApiModelProperty(value = "类型 1：自营，2：挂靠", name = "userType")
    private Integer userType;

    @ApiModelProperty(value = "姓名", name = "realName")
    private String realName;

    @ApiModelProperty(value = "生日", name = "birthday")
    private Long birthday;

    @ApiModelProperty(value = "头像", name = "headImg")
    private String headImg;

    @ApiModelProperty(value = "地址码", name = "address")
    private String addressCode;
    @ApiModelProperty(value = "地址信息", name = "address")
    private String addressMsg;

    @ApiModelProperty("昵称")
    private String nickName;

    @ApiModelProperty("积分")
    private Integer source;

    @ApiModelProperty("挂靠公司")
    private String comName;

    @ApiModelProperty("所属车队")
    private String motorcadeName;

    @ApiModelProperty("紧急联系人")
    private String emergency;

    @ApiModelProperty("认证信息对象")
    private UacUserAuth uacUserAuth;

    @ApiModelProperty("银行卡列表")
    private List<UacBank> banks;


}
