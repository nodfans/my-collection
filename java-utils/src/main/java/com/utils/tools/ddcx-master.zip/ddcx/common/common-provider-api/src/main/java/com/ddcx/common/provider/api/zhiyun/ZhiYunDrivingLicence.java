package com.ddcx.common.provider.api.zhiyun;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("行驶证认证信息")
public class ZhiYunDrivingLicence {

    @ApiModelProperty("地址")
    private String address;
    @ApiModelProperty("用途")
    private String natureOfUsage;
    @ApiModelProperty("引擎号")
    private String engineNumber;
    @ApiModelProperty("到期日")
    private String dateOfissue;
    @ApiModelProperty("车牌号")
    private String vehicleNo;
    @ApiModelProperty("品牌号")
    private String brandModel;
    @ApiModelProperty("所有者")
    private String ownerName;
    @ApiModelProperty("注册日期")
    private String regTime;
    @ApiModelProperty("车辆类型")
    private String vehicleType;
    @ApiModelProperty("车辆编码")
    private String vehicleCode;

}
