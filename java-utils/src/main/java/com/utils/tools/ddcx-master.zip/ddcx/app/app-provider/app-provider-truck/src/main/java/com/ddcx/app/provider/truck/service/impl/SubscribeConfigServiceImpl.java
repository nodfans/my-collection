package com.ddcx.app.provider.truck.service.impl;


import com.alibaba.fastjson.JSON;
import com.ddcx.app.provider.truck.mapper.SubscribeConfigMapper;
import com.ddcx.app.provider.truck.mapper.SubscribeMapper;
import com.ddcx.app.provider.truck.service.SubscribeConfigService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.OverallSubscribeDto;
import com.ddcx.model.truck.SubscribeConfig;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/11.
 */
@Service
@Transactional
public class SubscribeConfigServiceImpl  implements SubscribeConfigService {
    @Resource
    private SubscribeConfigMapper subscribeConfigMapper;

    @Resource
    private SubscribeMapper subscribeMapper;

    @Override
    public Wrapper<List<OverallSubscribeDto>> getCurrentConfig(LoginAuthDto dto) {
        List<OverallSubscribeDto> list=new ArrayList<>(3);
        LocalDate localDate=LocalDate.now();
        list.add(getByYearAndMonth(localDate.getYear(),localDate.getMonthValue(),dto.getMotorcadeId()));
        localDate=localDate.plusMonths(1);
        list.add(getByYearAndMonth(localDate.getYear(),localDate.getMonthValue(),dto.getMotorcadeId()));
        localDate=localDate.plusMonths(1);
        list.add(getByYearAndMonth(localDate.getYear(),localDate.getMonthValue(),dto.getMotorcadeId()));
        return  WrapMapper.ok(list);
    }

    public OverallSubscribeDto getByYearAndMonth(int year,int month,Long motorcadeId){
        LocalDate localDate=LocalDate.now();
        int minMonth=localDate.getMonthValue();
        int minDay=localDate.getDayOfMonth();
        //获取本月生效的检查站
        SubscribeConfig config=subscribeConfigMapper.selectByDate(motorcadeId,year+"",month+"");
        if(config==null){
            return new OverallSubscribeDto(motorcadeId,year,month);
        }
        //当月年检配置信息
        int temp;
        OverallSubscribeDto dto=new OverallSubscribeDto(motorcadeId,year,month);
        List<Integer> list=JSON.parseArray(config.getDetail(),Integer.class);
        for (int i = 0; i < list.size(); i++) {
            temp=subscribeMapper.selectSubscribeCountOfDate(config.getId(),i+1);
            list.set(i,list.get(i)-temp);
            if(month==minMonth&&i<minDay){
                list.set(i,0);
            }
        }
        dto.setConfigId(config.getId());
        dto.setDays(list);
        dto.setYear(year);
        dto.setMonth(month);
        dto.setMotorcadeId(motorcadeId);
        return dto;
    }
}
