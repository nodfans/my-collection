package com.ddcx.app.provider.uac.service;

import com.ddcx.app.provider.api.uac.model.dto.*;
import com.ddcx.app.provider.api.uac.model.vo.*;
import com.ddcx.framework.base.dto.BaseQueryDto;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.service.IService;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.CardAuth;
import com.ddcx.model.uac.IdAuth;
import com.ddcx.model.uac.UacSourceLog;
import com.ddcx.model.uac.UacUser;
import com.github.pagehelper.PageInfo;
import lombok.Data;

public interface UacUserService extends IService<UacUser> {

    String VERIFY_CODE = "VERIFY_CODE";

    UacUser getById(Long id);

    UacUser getByPhone(String phone);

    UacLoginTokenVo register(UacUserRegisterDto userRegisterDto);

    Wrapper updatePWD(UacLoginDto dto);

    UacUser checkId(Long id);

    UacUserVo getUser(LoginAuthDto loginAuthDto);

    Boolean update(LoginAuthDto loginAuthDto, UacUpdateUserDto uacUpdateUserDto);

    Wrapper idAuth(IdAuth idAuth,LoginAuthDto dto);

    Wrapper cardAuth(CardAuth cardAuth,LoginAuthDto dto,Integer type);

    Wrapper getOwnMotorcadeDrivers(LoginAuthDto dto);

    Boolean updateOpenId(String openId,String phone);

    Wrapper<DeepMyselfInfoVo> getDeepMyselfInfo(Long userId);

    Wrapper editDeepMyselfInfo(LoginAuthDto loginAuthDto, MyselfInfoDto dto);

    Wrapper<MyselfInfoVo> getMyselfInfo(LoginAuthDto loginAuthDto);

    Wrapper<UacUserDiffInfoVo> getMyselfDiffInfo(LoginAuthDto loginAuthDto, Integer type);

    Wrapper editMyselfDiffInfo(LoginAuthDto loginAuthDto, Integer type, UacUserDiffInfoDto dto);

    Wrapper<PageInfo<UacSourceLog>> getLog(LoginAuthDto loginAuthDto, BaseQueryDto baseQueryDto);

    UacUser getUacUser(Long id);


    @Data
    class Address {
        private String province;
        private String city;
    }
}
