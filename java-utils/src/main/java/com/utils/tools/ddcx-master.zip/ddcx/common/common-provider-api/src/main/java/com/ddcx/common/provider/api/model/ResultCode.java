package com.ddcx.common.provider.api.model;

/**
 * 响应码枚举，参考HTTP状态码的语义
 */
public enum ResultCode {
    SUCCESS(200),//成功
    LOGIN_FAIL(1000),//登陸失败
    FAIL(400),//失败
    UNAUTHORIZED(401),//未认证（签名错误）
    NOT_FOUND(404),//接口不存在
    INTERNAL_SERVER_ERROR(500),//服务器内部错误
    SUCCESSI(2001),  // 订单生成成功，没有推荐码
    BALANCE_FAY_FAILED(2101),//订单支付失败
    USER_NOT_EXTENSION(3000);//没有代理方

    private final int code;

    ResultCode(int code) {
        this.code = code;
    }

    public int code() {
        return code;
    }
}
