package com.ddcx.common.provider.service.impl;


import com.alibaba.fastjson.JSON;
import com.ddcx.common.provider.api.model.vo.MessageVo;
import com.ddcx.common.provider.mapper.MessageMapper;
import com.ddcx.common.provider.mapper.MessageConfigMapper;
import com.ddcx.common.provider.service.MessageService;
import com.ddcx.framework.base.dto.BaseQueryDto;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.framework.util.page.PageUtil;
import com.ddcx.framework.util.wrapper.PageWrapMapper;
import com.ddcx.framework.util.wrapper.PageWrapper;
import com.ddcx.common.provider.util.JpushService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.common.Message;
import com.ddcx.model.common.MessageConfig;
import com.ddcx.model.common.Rescue;
import com.ddcx.model.uac.IdAuth;
import com.ddcx.model.uac.UacUser;
import com.ddcx.model.uac.UacUserAuth;
import com.ddcx.web.provider.api.uac.model.dto.MessageDto;
import com.ddcx.web.provider.api.uac.model.service.AdminUserServiceFeignApi;
import com.ddcx.web.provider.api.uac.model.vo.UacRescueListVo;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by CodeGenerator on 2020/03/02.
 */
@Service
@Transactional
public class MessageServiceImpl extends BaseService<MessageConfig> implements MessageService {
    @Resource
    private MessageMapper messageMapper;

    @Resource
    private MessageConfigMapper configMapper;
    @Resource
    private JpushService jpushService;

    @Autowired
    private AdminUserServiceFeignApi adminUserServiceFeignApi;

//    @Autowired
//    private UacUserMapper uacUserMapper;
//
//    @Autowired
//    private RescueMapper rescueMapper;
//
//    @Autowired
//    private UacUserAuthMapper uacUserAuthMapper;


    @Override
    public Wrapper<MessageVo> getUserNoReadNum(Long userId) {
        int[] resu = new int[5];
        for (int i = 1; i < 5; i++) {
            resu[i] = messageMapper.getUserNoReadNumOfType(userId, i);
        }
        MessageVo messageVo = new MessageVo();
        messageVo.setNoReadNum(resu);
        return WrapMapper.ok(messageVo);
    }

    @Override
    public Wrapper<PageInfo<MessageVo>> getMessageListByType(Integer page, Integer size, Long userId, Integer type) {
        PageHelper.startPage(page, size);
        List<Message> list = messageMapper.getMessageListByType(userId, type);
        List<MessageVo> vos = new ArrayList<>(list.size());
        MessageVo vo;
        MessageConfig config;
        for (Message message : list) {
            vo = new MessageVo();
            config = configMapper.selectByPrimaryKey(message.getConfigId());
            vo.setContent(config.getContent());
            vo.setImgUrl(config.getImgUrl());
            vo.setRequestUrl(config.getRequestUrl());
            vo.setState(message.getState());
            vo.setTopic(config.getTopic());
            vo.setType(type);
            vo.setCreateTime(config.getCreateTime());
            vo.setId(message.getId());
            vos.add(vo);
        }

        return WrapMapper.ok(new PageInfo(vos));
    }

    @Override
    public Wrapper alreadyReadTag(Long id, Long userId) {
        int i = messageMapper.alreadyReadTag(id, userId);
        if (i > 0) {
            return WrapMapper.ok("标记成功");
        }
        return WrapMapper.error("标记失败");
    }


    @Override
    public Wrapper<PageInfo<MessageConfig>> list(BaseQueryDto baseQueryDto, String title, Long createBy, Long date) {
        PageHelper.startPage(baseQueryDto.getPageNum(), baseQueryDto.getPageSize());
        PageHelper.orderBy("create_time desc");
        Long startDate = null;
        Long endDate = null;
        if (date != null) {
            LocalDate localDate = LocalDate.ofEpochDay(date / 1000 / 60 / 60 / 24);
            startDate = localDate.toEpochDay() * 24 * 60 * 60;
            localDate.plusDays(1L);
            endDate = localDate.toEpochDay() * 24 * 60 * 60;
        }
        List<MessageConfig> messages = configMapper.getNoDeleteList(title, createBy, startDate, endDate);
        return WrapMapper.ok(new PageInfo<>(messages));
    }

    @Override
    public Wrapper publishSystemMessage(MessageDto messageDto, Long AdminUserId) {
        if (PublicUtil.isEmpty(messageDto)) {
            return WrapMapper.error("消息内容不能为空");
        }
        MessageConfig messageConfig = new MessageConfig();
        messageConfig.setId(generateId());
        messageConfig.setTopic(messageDto.getTopic());
        messageConfig.setContent(messageDto.getContent());
        messageConfig.setType(1);
        messageConfig.setCreateUser(AdminUserId);
        messageConfig.setCreateTime(currentTime());
        messageConfig.setIsDelete(0);
        configMapper.insert(messageConfig);
        // 给每个用户插一条
        // List<UacUser> uacUsers = uacUserMapper.selectAll();
        List<UacUser> uacUsers = adminUserServiceFeignApi.getAllUsers();
        List<Long> collect = uacUsers.stream().map(uacUser -> uacUser.getId()).collect(Collectors.toList());
        collect.forEach(id -> {
            Message message = new Message();
            message.setId(generateId());
            message.setConfigId(messageConfig.getId());
            message.setState((byte) 0);
            message.setUserId(id);
            message.setDeleteTag((byte) 0);
            messageMapper.insert(message);
        });
        return WrapMapper.ok();
    }

    @Override
    public Wrapper update(MessageConfig config, Long adminUserId) {
        configMapper.update(config.getId());
        MessageDto dto = new MessageDto();
        dto.setTopic(config.getTopic());
        dto.setContent(config.getContent());
        publishSystemMessage(dto, adminUserId);
        return WrapMapper.ok();
    }


    @Override
    public PageWrapper<List<UacRescueListVo>> getRescueList(BaseQueryDto baseQueryDto) {
        Page page = PageHelper.startPage(baseQueryDto.getPageNum(), baseQueryDto.getPageSize());
        //  List<Rescue> rescues = rescueMapper.selectAll();
        List<Rescue> rescues = adminUserServiceFeignApi.getAllRescues();
        Long total = page.getTotal();
        List<UacRescueListVo> vos = new ArrayList<>();
        rescues.forEach(rescue -> {
            UacRescueListVo vo = new UacRescueListVo();
            vo.setId(rescue.getId());
            vo.setAddress(rescue.getAddress());
            vo.setContactPhone(rescue.getContactPhone());
            vo.setCreateTime(rescue.getCreateTime());
            vo.setState(rescue.getState());
            // UacUser user = uacUserMapper.selectByPrimaryKey(rescue.getUserId());
            UacUser user = adminUserServiceFeignApi.getSingleUser(rescue.getUserId());
            vo.setUserName(user.getNickName());
            vo.setPhone(user.getPhone());
            // UacUserAuth uacUserAuth = uacUserAuthMapper.selectByUserId(user.getId());
            UacUserAuth uacUserAuth = adminUserServiceFeignApi.getSingleAuthUser(user.getId());
            IdAuth idAuth = new Gson().fromJson(uacUserAuth.getIdAuth(), IdAuth.class);
            vo.setSex(idAuth.getSex());
            vos.add(vo);
        });
        return PageWrapMapper.wrap(vos, new PageUtil(total.intValue(), baseQueryDto.getPageNum(), baseQueryDto.getPageSize()));
    }

    @Override
    public Wrapper deleteRescueList(List<Long> ids) {
        ids.forEach(id -> {
            //  rescueMapper.deleteByPrimaryKey(id);
            adminUserServiceFeignApi.deleteRescueById(id);
        });
        return WrapMapper.ok("删除成功");
    }

    @Override
    public Wrapper deleteSystemMessage(List<Long> ids) {
        ids.forEach(id -> {
            configMapper.update(id);
        });
        return WrapMapper.ok("删除成功");
    }

    @Override
    public Wrapper testJpush(String title, String content, LoginAuthDto dto) {
        Map<String,String> map1=new HashMap();
        Map<String,String> map=new HashMap<>();
        map.put("contactPhone","18573626921");
        map.put("address","广东省深圳市南山区海天一路7号靠近深圳市软件产业基地1栋B座");
        map.put("lng","113.940725");
        map.put("lat","22.523609");
        map.put("userName","张三");
        map.put("reason","jjj");
        map.put("headImg","http://112.74.217.123/dd/images/23506bed6ea64d49870d7f9cab747c39.png");
        map1.put("type","3");
        map1.put("obj", JSON.toJSONString(map));
        jpushService.sendPush(title,content,map1,dto.getUserId().toString());
        return WrapMapper.ok();
    }
}
