package com.ddcx.app.provider.loan.web;


import com.ddcx.app.provider.api.loan.model.vo.LoanOrderVo;
import com.ddcx.app.provider.loan.service.LoanOrderService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.loan.LoanOrder;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
* Created by CodeGenerator on 2020/03/17.
*/
@RestController
@RequestMapping("/loan/order")
@Api(value = "用户借款表",tags = "用户借款表")
public class   LoanOrderController extends BaseController {
    @Resource
    private LoanOrderService loanOrderService;


    @ApiOperation("借款")
    @PostMapping("/saveLoan")
    public Wrapper saveLoan(@RequestBody @Valid LoanOrder order){
        return loanOrderService.saveLoan(order,getLoginAuthDto());
    }




    @ApiOperation("还款列表查询")
    @GetMapping("/getLoanApproveListOfPage")
    public Wrapper<PageInfo<LoanOrder>> getLoanApproveListOfPage(
                                            @ApiParam(value = "页数", defaultValue = "1") @RequestParam(defaultValue = "1") Integer page,
                                            @ApiParam(value = "每页记录数", defaultValue = "10") @RequestParam(defaultValue = "10") Integer size){
        return loanOrderService.getLoanApproveListOfPage(page,size,getLoginAuthDto());
    }

    @ApiOperation("贷款申请撤销")
    @GetMapping("/cancelLoan")
    public Wrapper cancelLoan(@ApiParam("oId")Long oId){
        return loanOrderService.cancelLoan(oId,getLoginAuthDto());
    }




}
