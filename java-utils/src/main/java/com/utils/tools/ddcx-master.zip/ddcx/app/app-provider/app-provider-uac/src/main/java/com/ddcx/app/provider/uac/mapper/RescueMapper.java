package com.ddcx.app.provider.uac.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.uac.Rescue;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface RescueMapper extends MyMapper<Rescue> {


    @Select("select r.*,u.real_name userName from rescue r left join uac_user u on r.user_id=u.id where r.state=1  order by r.create_time desc")
    List<Rescue> selectValidInfo();

    @Select("select r.*,u.real_name userName from rescue r left join uac_user u on r.user_id=u.id where r.state=1 and r.user_id=#{userId}  order by r.create_time desc limit 1")
    Rescue selectByUserIdOfState(@Param("userId")Long userId);

    @Update("update rescue set state=0 where #{now}-create_time>1800 and state=1")
    int updateOverdueInfo(Long now);

    @Select("select r.*,u.real_name userName from rescue r left join uac_user u on r.user_id=u.id where r.id=#{id}")
    Rescue getRescueInfoById(@Param("id")Long id);
}