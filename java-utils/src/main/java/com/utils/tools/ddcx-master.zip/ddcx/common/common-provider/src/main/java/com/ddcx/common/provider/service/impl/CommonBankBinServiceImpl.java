package com.ddcx.common.provider.service.impl;

import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.common.provider.service.CommonBankBinService;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.model.common.CommonBankBin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommonBankBinServiceImpl extends BaseService<CommonBankBin> implements CommonBankBinService {

    @Autowired
    private RedisUtil redisUtil;

    @Override
    public CommonBankBin getBankBin(String cardNo) {
        int cardSize = cardNo.length();
        String cardBin = cardNo.substring(0, 6);
        String key = RedisKey.BANK_BIN + cardBin + ":" + cardSize;
        CommonBankBin commonBankBin = (CommonBankBin) redisUtil.get(key);
        if (PublicUtil.isEmpty(commonBankBin)) {
            cardBin = cardNo.substring(0, 7);
            key = RedisKey.BANK_BIN + cardBin + ":" + cardSize;
            commonBankBin = (CommonBankBin) redisUtil.get(key);
        }
        return commonBankBin;
    }
}
