package com.ddcx.common.provider.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.common.Message;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface MessageMapper extends MyMapper<Message> {

    @Select("select count(*) from message m left join message_config c on m.config_id=c.id where m.user_id=#{userId} and c.type=#{type} and m.state=0 and c.is_delete=0")
    int getUserNoReadNumOfType(@Param("userId") Long userId, @Param("type") Integer type);

    @Select("select m.* from message m left join message_config c on m.config_id=c.id where m.user_id=#{userId} and c.type=#{type} and c.is_delete=0 order by create_time desc")
    List<Message> getMessageListByType(@Param("userId") Long userId, @Param("type") Integer type);

    @Update("update message set state=1 where   id=#{id} and user_id=#{userId}")
    int alreadyReadTag(@Param("id") Long id, @Param("userId") Long userId);

    @Update("update state=1 from message where  config_id in (select id from message_config where type = 3 and create_time<#{limitTime})")
    int readRescueMessage(@Param("limitTime") Long limitTime);
}