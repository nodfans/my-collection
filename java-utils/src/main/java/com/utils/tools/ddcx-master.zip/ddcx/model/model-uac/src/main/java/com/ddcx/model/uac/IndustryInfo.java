package com.ddcx.model.uac;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Table(name = "industry_info")
@ApiModel("行业信息")
public class IndustryInfo {
    /**
     * 主键
     */
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    @Id
    private Long id;

    /**
     * 标题
     */
    @ApiModelProperty("标题")
    @NotBlank
    private String title;

    /**
     * 内容
     */
    @ApiModelProperty("内容")
    @NotBlank
    private String content;

    /**
     * 状态 （1.可用 0.禁用）
     */
    @ApiModelProperty("状态 （1.可用 0.禁用）")
    @NotNull
    private Byte state;

    /**
     * H5
     */
    @ApiModelProperty("H5")
    @Column(name = "h5_url")
    @NotBlank
    private String h5Url;

    /**
     * 封面
     */
    @ApiModelProperty("封面")
    @Column(name = "head_img")
    @NotBlank
    private String headImg;

    /**
     * 排序
     */
    @ApiModelProperty("排序")
    @NotBlank
    private Integer sort;

    /**
     * 创建人
     */
    @ApiModelProperty("创建人")
    @Column(name = "create_by")
    private Long createBy;

    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    @Column(name = "create_time")
    private Long createTime;

    /**
     * 创建时间
     */
    @ApiModelProperty("浏览量")
    @Column(name = "view_num")
    private Integer viewNum;


    public Integer getViewNum() {
        return viewNum;
    }

    public void setViewNum(Integer viewNum) {
        this.viewNum = viewNum;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取标题
     *
     * @return title - 标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置标题
     *
     * @param title 标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取内容
     *
     * @return content - 内容
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置内容
     *
     * @param content 内容
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取状态 （1.可用 2.禁用）
     *
     * @return state - 状态 （1.可用 2.禁用）
     */
    public Byte getState() {
        return state;
    }

    /**
     * 设置状态 （1.可用 2.禁用）
     *
     * @param state 状态 （1.可用 2.禁用）
     */
    public void setState(Byte state) {
        this.state = state;
    }

    /**
     * 获取H5
     *
     * @return h5_url - H5
     */
    public String getH5Url() {
        return h5Url;
    }

    /**
     * 设置H5
     *
     * @param h5Url H5
     */
    public void setH5Url(String h5Url) {
        this.h5Url = h5Url;
    }

    /**
     * 获取封面
     *
     * @return head_img - 封面
     */
    public String getHeadImg() {
        return headImg;
    }

    /**
     * 设置封面
     *
     * @param headImg 封面
     */
    public void setHeadImg(String headImg) {
        this.headImg = headImg;
    }

    /**
     * 获取排序
     *
     * @return sort - 排序
     */
    public Integer getSort() {
        return sort;
    }

    /**
     * 设置排序
     *
     * @param sort 排序
     */
    public void setSort(Integer sort) {
        this.sort = sort;
    }

    /**
     * 获取创建人
     *
     * @return create_by - 创建人
     */
    public Long getCreateBy() {
        return createBy;
    }

    /**
     * 设置创建人
     *
     * @param createBy 创建人
     */
    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
}