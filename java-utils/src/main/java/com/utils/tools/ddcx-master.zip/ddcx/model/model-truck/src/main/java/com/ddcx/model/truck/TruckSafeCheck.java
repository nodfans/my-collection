package com.ddcx.model.truck;

import com.ddcx.framework.base.annotation.ExcelName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Table(name = "truck_safe_check")
@ApiModel("安全生产检查台账表")
public class TruckSafeCheck {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    @ApiModelProperty("序号")
    @Column(name = "serial_num")
    @ExcelName("序号")
    private String serialNum;

    /**
     * 检查日期
     */
    @Column(name = "check_date")
    @ApiModelProperty("检查日期")
    @ExcelName(value = "检查日期",isTimestamp = true)
    private Long checkDate;

    /**
     * 检查项目
     */
    @Column(name = "check_project")
    @ApiModelProperty("检查项目")
    @ExcelName("检查项目")
    private String checkProject;

    /**
     * 检查情况摘要
     */
    @Column(name = "main_info")
    @ApiModelProperty("检查情况摘要")
    @ExcelName("检查情况摘要")
    private String mainInfo;

    /**
     * 处理意见
     */
    @ApiModelProperty("处理意见")
    @ExcelName("处理意见")
    private String opinion;

    /**
     * 检查员姓名
     */
    @ApiModelProperty("检查员姓名")
    @Column(name = "check_name")
    @ExcelName("检查员姓名")
    private String checkName;

    @ApiModelProperty("车辆主键")
    @Column(name = "truck_id")
    private Long truckId;



    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }

    public Long getTruckId() {
        return truckId;
    }

    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取检查日期
     *
     * @return check_date - 检查日期
     */
    public Long getCheckDate() {
        return checkDate;
    }

    /**
     * 设置检查日期
     *
     * @param checkDate 检查日期
     */
    public void setCheckDate(Long checkDate) {
        this.checkDate = checkDate;
    }

    /**
     * 获取检查项目
     *
     * @return check_project - 检查项目
     */
    public String getCheckProject() {
        return checkProject;
    }

    /**
     * 设置检查项目
     *
     * @param checkProject 检查项目
     */
    public void setCheckProject(String checkProject) {
        this.checkProject = checkProject;
    }

    /**
     * 获取检查情况摘要
     *
     * @return main_info - 检查情况摘要
     */
    public String getMainInfo() {
        return mainInfo;
    }

    /**
     * 设置检查情况摘要
     *
     * @param mainInfo 检查情况摘要
     */
    public void setMainInfo(String mainInfo) {
        this.mainInfo = mainInfo;
    }

    /**
     * 获取处理意见
     *
     * @return opinion - 处理意见
     */
    public String getOpinion() {
        return opinion;
    }

    /**
     * 设置处理意见
     *
     * @param opinion 处理意见
     */
    public void setOpinion(String opinion) {
        this.opinion = opinion;
    }

    /**
     * 获取检查员姓名
     *
     * @return check_name - 检查员姓名
     */
    public String getCheckName() {
        return checkName;
    }

    /**
     * 设置检查员姓名
     *
     * @param checkName 检查员姓名
     */
    public void setCheckName(String checkName) {
        this.checkName = checkName;
    }
}