package com.ddcx.app.provider.truck.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.truck.Brand;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface BrandMapper extends MyMapper<Brand> {

    @Select(value = "select * from brand order by convert(first_letter using gbk) asc , convert(name using gbk) asc  ")
    List<Brand> selectAllOrdered();
}