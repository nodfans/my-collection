package com.ddcx.model.exam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.HashMap;
import java.util.List;

@ApiModel("试题显示类")
@Data
public class QuestionVo {


    @ApiModelProperty("考题id")
    private Long id;
    @ApiModelProperty("试题编号")
    private Integer num;

    @ApiModelProperty("试题类型 1.单选 2.多选 3.判断")
    private Byte type;

    @ApiModelProperty("试题题目")
    private String title;

    @ApiModelProperty("试题选项字符串")
    private String content;

    @ApiModelProperty("选项列表")
    private List<HashMap<String,String>> contentList;

    @ApiModelProperty("试题答案")
    private String answer;

}
