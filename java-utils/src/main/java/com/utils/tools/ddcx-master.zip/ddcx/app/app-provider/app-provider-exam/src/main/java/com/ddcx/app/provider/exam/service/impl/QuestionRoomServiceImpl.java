package com.ddcx.app.provider.exam.service.impl;


import com.ddcx.app.provider.exam.mapper.QuestionRoomMapper;
import com.ddcx.app.provider.exam.service.QuestionRoomService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/03/11.
 */
@Service
@Transactional
public class QuestionRoomServiceImpl  implements QuestionRoomService {
    @Resource
    private QuestionRoomMapper questionRoomMapper;

}
