package com.ddcx.framework.base.dto;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class AdminLoginAutoDto implements Serializable {

    /**
     * 序列化id
     */
    private static final long serialVersionUID = 412656865686654309L;

    /**
     * 主键
     */
    private Long id;

    /**
     * 用户名
     */
    @ApiModelProperty(value = "用户名", required = true)
    private String userName;

//    /**
//     * 密码
//     */
//    @ApiModelProperty(value = "密码", required = true)
//    private String password;
//
//    /**
//     * 盐值
//     */
//    @ApiModelProperty("盐值")
//    private String passwordSale;

    /**
     * 手机号
     */
    @ApiModelProperty(value = "手机号", required = true)
    private String phone;

    /**
     * 状态 1.正常 2.锁定
     */
    @ApiModelProperty("状态 1.正常 2.锁定")
    private Byte state;

    /**
     * 登录次数
     */
    @ApiModelProperty("最后一次登录时间")
    private Integer loginCount;

    /**
     * 创建时间
     */
    @ApiModelProperty("最后一次登录时间")
    private Long createTime;

    /**
     * 最后一次登录时间
     */
    @ApiModelProperty("最后一次登录时间")
    private Long lastLoginTime;


    /**
     * 账号级别（一级：大道出行公司，二级：运输公司，三级：车队）
     */
    @ApiModelProperty(value = "账号级别（一级：大道出行公司，二级：运输公司，三级：车队）", required = true)
    private Byte userLevel;


    @ApiModelProperty(value = "创建人id")
    private Long createBy;

    @ApiModelProperty(value = "附属账户：1.为附属账户 0.主账号")
    private Byte auxiliary;

    @ApiModelProperty(value = "token")
    private String token;

    @ApiModelProperty("所属车队主键")
    private Long motorcadeId;

    @ApiModelProperty("车队名称")
    private String motorcadeName;

    @ApiModelProperty("企业名称")
    private String comName;

    @ApiModelProperty("企业名称")
    private Long comId;

    @ApiModelProperty("用户权限主键")
    private Long mainId;

    public Long getMainId() {
        return mainId;
    }

    public void setMainId(Long mainId) {
        this.mainId = mainId;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Byte getState() {
        return state;
    }

    public void setState(Byte state) {
        this.state = state;
    }

    public Integer getLoginCount() {
        return loginCount;
    }

    public void setLoginCount(Integer loginCount) {
        this.loginCount = loginCount;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public Long getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(Long lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public Byte getUserLevel() {
        return userLevel;
    }

    public void setUserLevel(Byte userLevel) {
        this.userLevel = userLevel;
    }

    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    public Byte getAuxiliary() {
        return auxiliary;
    }

    public void setAuxiliary(Byte auxiliary) {
        this.auxiliary = auxiliary;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Long getMotorcadeId() {
        return motorcadeId;
    }

    public void setMotorcadeId(Long motorcadeId) {
        this.motorcadeId = motorcadeId;
    }

    public String getMotorcadeName() {
        return motorcadeName;
    }

    public void setMotorcadeName(String motorcadeName) {
        this.motorcadeName = motorcadeName;
    }

    public String getComName() {
        return comName;
    }

    public void setComName(String comName) {
        this.comName = comName;
    }

    public Long getComId() {
        return comId;
    }

    public void setComId(Long comId) {
        this.comId = comId;
    }
}
