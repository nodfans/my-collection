package com.ddcx.model.loan;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

@Table(name = "loan_config")
@ApiModel("贷款配置")
public class LoanConfig implements Serializable {
    /**
     * 主键
     */
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    @Id
    private Long id;

    /**
     * 车队主键
     */
    @Column(name = "motorcade_id")
    @ApiModelProperty("车队主键")
    private Long motorcadeId;

    /**
     * 借款类型
     */
    @Column(name = "loan_type")
    @ApiModelProperty("借款类型")
    private String loanType;
    @Transient
    @ApiModelProperty("借款类型")
    @NotNull(message = "借款类型不能为空")
    private List<String> loanTypeMsgs;

    /**
     * 借款期限
     */
    @Column(name = "loan_deadline")
    @ApiModelProperty("借款期限(期)")
    private String loanDeadline;
    @Transient
    @ApiModelProperty("借款期限")
    @NotNull(message = "借款期限不能为空")
    private List<Integer> loanDeadlineMsgs;

    /**
     * 还借款方式
     */
    @Column(name = "loan_way")
    @ApiModelProperty("还借款方式")
    private String loanWay;
    @Transient
    @ApiModelProperty("还借款方式")
    @NotNull(message = "还借款方式不能为空")
    private List<String> loanWayMsgs;

    /**
     * 月利率
     */
    @Column(name = "month_rate")
    @ApiModelProperty("月利率")
    @NotNull(message = "月利率不能为空")
    private BigDecimal monthRate;

    /**
     * 逾期利率
     */
    @Column(name = "overdue_rate")
    @ApiModelProperty("逾期利率")
    @NotNull(message = "逾期利率不能为空")
    private BigDecimal overdueRate;

    /**
     * 提醒时间
     */
    @Column(name = "remind_date")
    @ApiModelProperty("提醒时间（天）")
    private String remindDate;
    @Transient
    @ApiModelProperty("提醒时间（天）")
    @NotNull(message = "提醒时间不能为空")
    private List<Integer> remindDateMsgs;

    /**
     * 到期文案
     */
    @Column(name = "expire_text")
    @ApiModelProperty("到期文案")
    @NotNull(message = "到期文案不能为空")
    private String expireText;

    /**
     * 逾期文案
     */
    @Column(name = "overdue_text")
    @ApiModelProperty("逾期文案")
    @NotNull(message = "逾期文案不能为空")
    private String overdueText;

    /**
     * 创建人
     */
    @Column(name = "create_by")
    @ApiModelProperty("创建人")
    private Long createBy;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    @ApiModelProperty("创建时间")
    private Long createTime;

    /**
     * 修改人
     */
    @Column(name = "update_by")
    @ApiModelProperty("修改人")
    private Long updateBy;

    /**
     * 修改时间
     */
    @Column(name = "update_time")
    @ApiModelProperty("修改时间")
    private Long updateTime;


    /**
     * 提醒时间
     */
    @Column(name = "remind_select")
    @ApiModelProperty("提醒时间（已选中的）")
    private Integer remindSelect;

    public Integer getRemindSelect() {
        return remindSelect;
    }

    public void setRemindSelect(Integer remindSelect) {
        this.remindSelect = remindSelect;
    }

    public List<String> getLoanTypeMsgs() {
        return loanTypeMsgs;
    }

    public void setLoanTypeMsgs(List<String> loanTypeMsgs) {
        this.loanTypeMsgs = loanTypeMsgs;
    }

    public List<Integer> getLoanDeadlineMsgs() {
        return loanDeadlineMsgs;
    }

    public void setLoanDeadlineMsgs(List<Integer> loanDeadlineMsgs) {
        this.loanDeadlineMsgs = loanDeadlineMsgs;
    }

    public List<String> getLoanWayMsgs() {
        return loanWayMsgs;
    }

    public void setLoanWayMsgs(List<String> loanWayMsgs) {
        this.loanWayMsgs = loanWayMsgs;
    }

    public List<Integer> getRemindDateMsgs() {
        return remindDateMsgs;
    }

    public void setRemindDateMsgs(List<Integer> remindDateMsgs) {
        this.remindDateMsgs = remindDateMsgs;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取车队主键
     *
     * @return motorcade_id - 车队主键
     */
    public Long getMotorcadeId() {
        return motorcadeId;
    }

    /**
     * 设置车队主键
     *
     * @param motorcadeId 车队主键
     */
    public void setMotorcadeId(Long motorcadeId) {
        this.motorcadeId = motorcadeId;
    }

    /**
     * 获取借款类型
     *
     * @return loan_type - 借款类型
     */
    public String getLoanType() {
        return loanType;
    }

    /**
     * 设置借款类型
     *
     * @param loanType 借款类型
     */
    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    /**
     * 获取借款期限
     *
     * @return loan_deadline - 借款期限
     */
    public String getLoanDeadline() {
        return loanDeadline;
    }

    /**
     * 设置借款期限
     *
     * @param loanDeadline 借款期限
     */
    public void setLoanDeadline(String loanDeadline) {
        this.loanDeadline = loanDeadline;
    }

    /**
     * 获取还借款方式
     *
     * @return loan_way - 还借款方式
     */
    public String getLoanWay() {
        return loanWay;
    }

    /**
     * 设置还借款方式
     *
     * @param loanWay 还借款方式
     */
    public void setLoanWay(String loanWay) {
        this.loanWay = loanWay;
    }

    /**
     * 获取月利率
     *
     * @return month_rate - 月利率
     */
    public BigDecimal getMonthRate() {
        return monthRate;
    }

    /**
     * 设置月利率
     *
     * @param monthRate 月利率
     */
    public void setMonthRate(BigDecimal monthRate) {
        this.monthRate = monthRate;
    }

    /**
     * 获取逾期利率
     *
     * @return overdue_rate - 逾期利率
     */
    public BigDecimal getOverdueRate() {
        return overdueRate;
    }

    /**
     * 设置逾期利率
     *
     * @param overdueRate 逾期利率
     */
    public void setOverdueRate(BigDecimal overdueRate) {
        this.overdueRate = overdueRate;
    }

    /**
     * 获取提醒时间
     *
     * @return remind_date - 提醒时间
     */
    public String getRemindDate() {
        return remindDate;
    }

    /**
     * 设置提醒时间
     *
     * @param remindDate 提醒时间
     */
    public void setRemindDate(String remindDate) {
        this.remindDate = remindDate;
    }

    /**
     * 获取到期文案
     *
     * @return expire_text - 到期文案
     */
    public String getExpireText() {
        return expireText;
    }

    /**
     * 设置到期文案
     *
     * @param expireText 到期文案
     */
    public void setExpireText(String expireText) {
        this.expireText = expireText;
    }

    /**
     * 获取逾期文案
     *
     * @return overdue_text - 逾期文案
     */
    public String getOverdueText() {
        return overdueText;
    }

    /**
     * 设置逾期文案
     *
     * @param overdueText 逾期文案
     */
    public void setOverdueText(String overdueText) {
        this.overdueText = overdueText;
    }

    /**
     * 获取创建人
     *
     * @return create_by - 创建人
     */
    public Long getCreateBy() {
        return createBy;
    }

    /**
     * 设置创建人
     *
     * @param createBy 创建人
     */
    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取修改人
     *
     * @return update_by - 修改人
     */
    public Long getUpdateBy() {
        return updateBy;
    }

    /**
     * 设置修改人
     *
     * @param updateBy 修改人
     */
    public void setUpdateBy(Long updateBy) {
        this.updateBy = updateBy;
    }

    /**
     * 获取修改时间
     *
     * @return update_time - 修改时间
     */
    public Long getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置修改时间
     *
     * @param updateTime 修改时间
     */
    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }
}