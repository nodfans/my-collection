package com.ddcx.app.provider.uac.service.impl;


import com.ddcx.app.provider.uac.mapper.IndustryInfoMapper;
import com.ddcx.app.provider.uac.service.IndustryInfoService;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.IndustryInfo;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/16.
 */
@Service
@Transactional
public class IndustryInfoServiceImpl implements IndustryInfoService {
    @Resource
    private IndustryInfoMapper industryInfoMapper;

    @Override
    public Wrapper listOfPage( Integer page, Integer size) {
        PageHelper.startPage(page,size);
        PageHelper.orderBy("sort");
        IndustryInfo industryInfo=new IndustryInfo();
        industryInfo.setState((byte) 1);
        List<IndustryInfo> list=industryInfoMapper.select(industryInfo);
        return WrapMapper.ok(new PageInfo<>(list));
    }


    @Override
    public Wrapper detail(Long id) {
        IndustryInfo industryInfo=industryInfoMapper.selectByPrimaryKey(id);
        if(industryInfo!=null){
            industryInfoMapper.updateViewNum(id);
        }
        return WrapMapper.ok(industryInfo);
    }
}
