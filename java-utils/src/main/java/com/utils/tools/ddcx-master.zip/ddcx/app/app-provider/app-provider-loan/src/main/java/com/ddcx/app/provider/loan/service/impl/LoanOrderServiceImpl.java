package com.ddcx.app.provider.loan.service.impl;


import com.ddcx.app.provider.api.uac.service.UacUserServiceFeignApi;
import com.ddcx.app.provider.loan.mapper.LoanOrderMapper;
import com.ddcx.app.provider.loan.mapper.LoanRepaymentItemMapper;
import com.ddcx.app.provider.loan.service.LoanConfigService;
import com.ddcx.app.provider.loan.service.LoanOrderService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.LoanIssueUtil;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.loan.LoanConfig;
import com.ddcx.model.loan.LoanOrder;
import com.ddcx.model.loan.LoanRepaymentItem;
import com.ddcx.model.uac.IdAuth;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/17.
 */
@Service
@Transactional
public class LoanOrderServiceImpl implements LoanOrderService {
    @Resource
    private LoanOrderMapper loanOrderMapper;
    @Resource
    private LoanConfigService loanConfigService;
    @Resource
    private LoanRepaymentItemMapper itemMapper;
    @Resource
    private UacUserServiceFeignApi uacUserServiceFeignApi;


    @Override
    public Wrapper saveLoan(LoanOrder order, LoginAuthDto dto) {
        order.setState((byte) 0);
        order.setCreateTime(System.currentTimeMillis()/1000);
        order.setMotorcadeId(dto.getMotorcadeId());
        order.setMotorcadeName(dto.getMotorcadeName());
        order.setComId(dto.getComId());
        order.setUserName(dto.getUserName());
        order.setUserPhone(dto.getPhone());
        order.setSex(dto.getSex());
        order.setUserId(dto.getUserId());
        order.setTruckLicense("暂未确认拿哪个车牌");
        IdAuth idAuth=uacUserServiceFeignApi.getAuthInfo(dto.getUserId());
        if(idAuth==null){
            return WrapMapper.error("请先进行身份认证");
        }
        order.setIdCard(idAuth.getIdCard());
        loanOrderMapper.insert(order);
        return WrapMapper.ok();
    }

    @Override
    public Wrapper getLoanApproveListOfPage(Integer page, Integer size, LoginAuthDto dto) {
        PageHelper.startPage(page,size);
        List<LoanOrder> loanOrders=loanOrderMapper.getLoanApproveListOfPage(dto.getUserId());
        List<LoanRepaymentItem> items;
        LoanConfig config=loanConfigService.getLoanConfigByMotorcadeId(dto).getResult();
        for (LoanOrder order : loanOrders) {
            if(order.getState().intValue()==0){
                if(config!=null){
                    order.setRate(config.getMonthRate());
                }
            }
            //用于逾期标记
            boolean temp=true;
            items=itemMapper.getByOrderId(order.getId());
            //用于完成标记
            int finish=items.size();
            int currentMonth=LocalDate.now().getMonthValue();
            int currentYear=LocalDate.now().getYear();
            LocalDate issueDate;
            int issue=1;
            //用于标记当前应还期数
            boolean currentIssue=true;
            for (LoanRepaymentItem item : items) {
                if(currentIssue&&item.getState().intValue()==2){
                    item.setCurrent((byte) 1);
                    currentIssue=false;
                }
                if(currentIssue&&item.getState().intValue()==0){
                    item.setCurrent((byte) 1);
                    currentIssue=false;
                }
                if(currentIssue&&item.getState().intValue()==3){
                    item.setCurrent((byte) 1);
                    currentIssue=false;
                    order.setState((byte) 5);
                }
                item.setIssueMsg(LoanIssueUtil.getChinaIssueMsg(item.getIssue()));
                issueDate=LocalDate.ofEpochDay(item.getRepaymentTime()/60/60/24);
                //定位当月
                if(issueDate.getYear()==currentYear&&issueDate.getMonthValue()==currentMonth){
                    issue=item.getIssue();
                }
                //定位还款
                if(item.getState().intValue()==2&&temp){
                    order.setState((byte) 3);
                    temp=false;
                    order.setOverdueDays(item.getExpireDay());
                    order.setLocalIssueMoney(item.getRepaymentAmount());
                }
                if(item.getState().intValue()==1){
                    finish--;
                }
            }
            if(finish==0&&items.size()>0){
                order.setState((byte) 4);
            }
            if(order.getState().intValue()==1){
                order.setLocalIssueMoney(items.get(issue-1).getRepaymentAmount());
            }
            order.setItems(items);
        }
        return WrapMapper.ok(new PageInfo<>(loanOrders));
    }

    @Override
    public Wrapper cancelLoan(Long oId, LoginAuthDto dto) {
        LoanOrder param=new LoanOrder();
        param.setId(oId);
        param.setUserId(dto.getUserId());
        LoanOrder order=loanOrderMapper.selectOne(param);
        if(order==null){
            WrapMapper.error("贷款申请不存在");
        }
        if(Byte.valueOf((byte) 0).equals(order.getState())){
//            param.setState((byte) -1);
//            param.setUserId(null);
//            loanOrderMapper.updateByPrimaryKeySelective(param);
            loanOrderMapper.deleteByPrimaryKey(oId);
            return WrapMapper.ok();
        }
        return WrapMapper.error("订单无法撤销");
    }

}
