package com.ddcx.app.provider.uac.service.impl;


import com.alibaba.fastjson.JSON;
import com.ddcx.app.provider.api.truck.model.service.TruckFeignClientApi;
import com.ddcx.app.provider.uac.mapper.RelatedRemindersMapper;
import com.ddcx.app.provider.uac.mapper.RescueMapper;
import com.ddcx.app.provider.uac.service.RescueService;
import com.ddcx.common.provider.api.model.dto.MessageDto;
import com.ddcx.common.provider.api.service.CommonServiceFeignApi;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.DistanceUtil;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.common.Message;
import com.ddcx.model.common.MessageConfig;
import com.ddcx.model.common.RelatedReminders;
import com.ddcx.model.uac.Rescue;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by CodeGenerator on 2020/03/26.
 */
@Service
@Transactional
public class RescueServiceImpl extends BaseService<Rescue> implements RescueService {
    @Resource
    private RescueMapper rescueMapper;
    @Resource
    private RelatedRemindersMapper remindersMapper;
    @Resource
    private TruckFeignClientApi truckFeignClientApi;
    @Resource
    private CommonServiceFeignApi commonServiceFeignApi;

    @Override
    public Wrapper saveRescue(Rescue rescue, LoginAuthDto dto) {
        Rescue param=new Rescue();
        param.setState((byte) 1);
        param.setUserId(dto.getUserId());
        Rescue rescue2=rescueMapper.selectOne(param);
        if(rescue2!=null){
            if(System.currentTimeMillis()/1000-rescue2.getCreateTime()>30*60){
                Rescue rescue1=new Rescue();
                rescue1.setId(rescue.getId());
                rescue1.setState((byte) 0);
                rescueMapper.updateByPrimaryKeySelective(rescue1);
            }else {
                return WrapMapper.error("请先撤销上一条救援记录");
            }
        }
        rescue.setId(generateId());
        rescue.setUserId(dto.getUserId());
        rescue.setState((byte) 1);
        rescue.setCreateTime(System.currentTimeMillis()/1000);
        rescueMapper.insert(rescue);
        //发送救援消息
        RelatedReminders relatedReminders=remindersMapper.selectOne(new RelatedReminders());
        Integer ascHelpKm;
        if(relatedReminders==null||relatedReminders.getAskHelpKm()==null){
            ascHelpKm=50;
        }else {
            ascHelpKm=relatedReminders.getAskHelpKm();
        }
        Set<Long> driverIds=truckFeignClientApi.getAllValidUserId(rescue.getLng(),rescue.getLat(),ascHelpKm);
        Map<String,Object> map=new HashMap<>(2);
        MessageDto messageDto=new MessageDto();
        MessageConfig config=new MessageConfig();
        config.setType(3);
        config.setCreateUser(dto.getUserId());
        config.setTopic("求援");
        config.setContent(rescue.getReason());
        config.setRequestUrl(rescue.getId()+"");
        messageDto.setMessageConfig(config);
        messageDto.setMessage(new Message());
        driverIds.remove(null);
        driverIds.remove(dto.getUserId());
        // TODO: 2020/5/22 测试用 start
        driverIds.clear();
        driverIds.add(8020415504000L);
        driverIds.add(8636016306944L);
        driverIds.add(7740978798272L);
        // TODO: 2020/5/22 测试用 end
        map.put("1",messageDto);
        map.put("2",new LinkedList<>(driverIds));
        map.put("3",true);
        Map<String,String> map2=new HashMap();
        Map<String,String> map3=new HashMap<>();
        map3.put("contactPhone",rescue.getContactPhone());
        map3.put("address",rescue.getAddress());
        map3.put("lng",rescue.getLng());
        map3.put("lat",rescue.getLat());
        map3.put("userName",dto.getUserName());
        map3.put("reason",rescue.getReason());
        map3.put("headImg",dto.getHeadImg());
        map3.put("sendTime",System.currentTimeMillis()/1000+"");
        map3.put("id",rescue.getId()+"");
        map2.put("type","3");//type   1.系统消息 2.优惠消息 3.救援消息 4.学习消息
        map2.put("obj", JSON.toJSONString(map3));
        map2.put("title","救援消息");
        map2.put("content",dto.getUserName()+"发起了救援消息。");
        map.put("4",JSON.toJSONString(map2));
        commonServiceFeignApi.addMessageOfAllByUserIds(JSON.toJSONString(map));
        return WrapMapper.ok(rescue.getId());
    }

    @Override
    public Wrapper rescueList(String lng,String lat, LoginAuthDto dto) {
        if(lng==null){
            Rescue param=new Rescue();
            param.setState((byte) 1);
            param.setUserId(dto.getUserId());
            Rescue rescue=rescueMapper.selectByUserIdOfState(dto.getUserId());
            if(rescue!=null&&System.currentTimeMillis()/1000-rescue.getCreateTime()>30*60){
                Rescue rescue1=new Rescue();
                rescue1.setId(rescue.getId());
                rescue1.setState((byte) 0);
                rescueMapper.updateByPrimaryKeySelective(rescue1);
                rescue=null;
            }
            List<Rescue> rescues = new ArrayList<>();
            if(rescue!=null){
                rescues.add(rescue);
            }
            return WrapMapper.ok(rescues);
        }
        RelatedReminders relatedReminders=remindersMapper.selectOne(new RelatedReminders());
        List<Rescue> list=rescueMapper.selectValidInfo();
        List<Rescue> rescues = list.stream().filter(rescue1 -> (DistanceUtil.getDistance1(Double.valueOf(lat), Double.valueOf(lng), Double.valueOf(rescue1.getLat()), Double.valueOf(rescue1.getLng())) < relatedReminders.getAskHelpKm() * 1000)).collect(Collectors.toList());
        return WrapMapper.ok(rescues);
    }

    @Override
    public Wrapper currentRescue(LoginAuthDto dto) {
        Rescue param=new Rescue();
        param.setState((byte) 1);
        param.setUserId(dto.getUserId());
        Rescue rescue=rescueMapper.selectOne(param);
        if(rescue!=null&&System.currentTimeMillis()/1000-rescue.getCreateTime()>30*60){
            Rescue rescue1=new Rescue();
            rescue1.setId(rescue.getId());
            rescue1.setState((byte) 0);
            rescueMapper.updateByPrimaryKeySelective(rescue1);
            rescue=null;
        }
        return WrapMapper.ok(rescue);
    }

    @Override
    public Wrapper cancelRescue(Long id, LoginAuthDto dto) {
        Rescue rescue=new Rescue();
        rescue.setId(id);
        rescue.setUserId(dto.getUserId());
        rescue.setState((byte) 0);
        rescueMapper.updateByPrimaryKeySelective(rescue);
        commonServiceFeignApi.deleteRescueMessage(rescue.getId());
        return WrapMapper.ok();
    }

    @Override
    public Wrapper getRescueInfo(String lng, String lat, LoginAuthDto dto) {
        Wrapper<List<Rescue>> wrapper=rescueList(lng,lat,dto);
        List<Rescue> list=  wrapper.getResult();
        String result="";
        for (Rescue rescue : list) {
            result+=rescue.getUserName()+"在"+rescue.getAddress()+"："+rescue.getReason()+"。     ";
        }
        return WrapMapper.ok(result);
    }

    @Override
    public Wrapper getRescueInfoById(Long id) {
        return WrapMapper.ok(rescueMapper.getRescueInfoById(id));
    }
}
