package com.ddcx.common.provider.api.zhiyun;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("身份证认证信息")
public class ZhiYunIdAuth {

    @ApiModelProperty("姓名")
    private String idCardName;
    @ApiModelProperty("性别")
    private String sex;
    @ApiModelProperty("民族")
    private String ethnicity;
    @ApiModelProperty("出生")
    private String dateOfBbirth;
    @ApiModelProperty("住址")
    private String address;
    @ApiModelProperty("公民身份号码")
    private String idCardNum;
    @ApiModelProperty("签发机关")
    private String authority;
    @ApiModelProperty("签发日期")
    private String dateOfissue;
    @ApiModelProperty("失效日期")
    private String dateOfExpiry;
}
