package com.ddcx.app.provider.uac.service;

import com.ddcx.app.provider.api.uac.model.dto.LoginDto;
import com.ddcx.app.provider.api.uac.model.dto.UacLoginDto;
import com.ddcx.app.provider.api.uac.model.vo.UacLoginTokenVo;
import com.ddcx.model.uac.UacUser;

public interface UacLoginTokenService {

    UacLoginTokenVo token(UacLoginDto uacLoginDto);

    UacLoginTokenVo refreshToken(Long userId);

    void deleteToken(Long userId);

    UacLoginTokenVo generateToken(UacUser uacUser);

    void refreshRedis(Long userId,String token);

    UacLoginTokenVo getToken(LoginDto loginDto);

}
