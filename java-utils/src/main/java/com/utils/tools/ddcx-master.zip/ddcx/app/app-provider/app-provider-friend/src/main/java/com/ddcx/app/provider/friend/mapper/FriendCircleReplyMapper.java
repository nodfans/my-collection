package com.ddcx.app.provider.friend.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.friend.FriendCircleReply;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface FriendCircleReplyMapper extends MyMapper<FriendCircleReply> {

    @Select("select * from friend_circle_reply where friend_circle_id=#{id} order by create_time asc")
    List<FriendCircleReply> selectByFriendCircleId(@Param("id") Long id);


    @Delete("delete from friend_circle_reply where  friend_circle_id=#{id}")
    int deleteByFriendCircleId(@Param("id") Long id);

    @Select("select count(*) from friend_circle_reply where friend_circle_id=#{id}")
    int selectCountByFriendCircleId(@Param("id") Long id);

    @Update("update friend_circle_reply set user_nick_name=#{userName} where user_id=#{userId}")
    int updateUserNameByUserId(@Param("userId") Long userId,@Param("userName") String userName);

    @Update("update friend_circle_reply set to_user_nick_name=#{userName} where to_user_id=#{userId}")
    int updateUserNameByUserId1(@Param("userId") Long userId,@Param("userName") String userName);
}