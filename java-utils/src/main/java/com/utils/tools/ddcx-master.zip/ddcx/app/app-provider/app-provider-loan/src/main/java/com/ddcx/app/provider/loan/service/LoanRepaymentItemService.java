package com.ddcx.app.provider.loan.service;


import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.loan.LoanOrder;
import com.ddcx.model.loan.LoanRepaymentItem;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * Created by CodeGenerator on 2020/03/17.
 */
public interface LoanRepaymentItemService {

    Wrapper getLoanRepayMentItems(LoanOrder order, LoginAuthDto dto);


    Wrapper repayment(LoanRepaymentItem item,LoginAuthDto dto) throws Exception;

    Wrapper aliAttestation(String mapSource);

    String aliPayReturn(Map<String,String> map);

    String payReturn(String notifyData);

    void notify(HttpServletResponse response, HttpServletRequest request);


}
