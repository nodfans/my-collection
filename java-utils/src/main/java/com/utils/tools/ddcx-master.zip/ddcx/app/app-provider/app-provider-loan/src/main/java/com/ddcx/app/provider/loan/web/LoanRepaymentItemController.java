package com.ddcx.app.provider.loan.web;


import com.ddcx.app.provider.loan.service.LoanRepaymentItemService;
import com.ddcx.framework.core.annotation.NoNeedAccessAuthentication;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.loan.LoanOrder;
import com.ddcx.model.loan.LoanRepaymentItem;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
* Created by CodeGenerator on 2020/03/17.
*/
@RestController
@RequestMapping("/loan/repayment/item")
@Api(value = "用户还款计划表",tags = "用户还款计划表")
@Slf4j
public class LoanRepaymentItemController extends BaseController {
    @Resource
    private LoanRepaymentItemService loanRepaymentItemService;

    @ApiOperation("根据贷款参数获取分期信息")
    @GetMapping("/getLoanRepayMentItems")
    public Wrapper<List<LoanRepaymentItem>> getLoanRepayMentItems(@ApiParam("必填参数：借款本金，还款方式，借款期限") LoanOrder order){
        return loanRepaymentItemService.getLoanRepayMentItems(order,getLoginAuthDto());
    }


    @ApiOperation("请求支付")
    @PostMapping("/repayment")
    public Wrapper repayment(@RequestBody @Validated LoanRepaymentItem item) throws Exception {
        return loanRepaymentItemService.repayment(item,getLoginAuthDto());
    }


    @ApiOperation("支付宝验签")
    @PostMapping("/aliAttestation")
    public Wrapper aliAttestation(@RequestBody String map){
        return loanRepaymentItemService.aliAttestation(map);
    }

//    @ApiOperation("微信验签")
//    @PostMapping("/wxAttestation")
//    public Wrapper wxAttestation(HttpServletRequest request, HttpServletResponse response){
//        return loanRepaymentItemService.wxAttestation(map);
//    }

    @ApiOperation("银联验签")
    @PostMapping("/yinLianAttestation")
    public Wrapper yinLianAttestation(@RequestBody @Validated LoanRepaymentItem item){
        return null;
    }

//    @ApiOperation("支付宝还款回调")
    @PostMapping("/aliPayReturn")
    @NoNeedAccessAuthentication
    public String aliPayReturn(HttpServletRequest request){
        Map<String, String> param = convertRequestParamsToMap(request); // 将异步通知中收到的待验证所有参数都存放到map中
        logger.info("支付宝回调信息："+param.toString());
        return loanRepaymentItemService.aliPayReturn(param);
    }

    // 将request中的参数转换成Map
    private static Map<String, String> convertRequestParamsToMap(HttpServletRequest request) {
        Map<String,String> params = new HashMap<String,String>();
        Map requestParams = request.getParameterMap();
        log.info("requestParams---->>>> "+requestParams);
        for (Iterator iter = requestParams.keySet().iterator(); iter.hasNext();) {
            String name = (String) iter.next();
            String[] values = (String[]) requestParams.get(name);
            String valueStr = "";
            for (int i = 0; i < values.length; i++) {
                valueStr = (i == values.length - 1) ? valueStr + values[i]
                        : valueStr + values[i] + ",";
            }
            //乱码解决，这段代码在出现乱码时使用。
            //valueStr = new String(valueStr.getBytes("ISO-8859-1"), "utf-8");
            params.put(name, valueStr);
        }
        return params;
    }

//    @ApiOperation("微信还款回调")
    @PostMapping("/wxPayReturn")
    @NoNeedAccessAuthentication
    public String wxPayReturn(HttpServletRequest request, HttpServletResponse response) {
        String resXml = "";
        try {
            InputStream inputStream = request.getInputStream();
            //将InputStream转换成xmlString
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder sb = new StringBuilder();
            String line = null;
            try {
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
            } catch (IOException e) {
                System.out.println(e.getMessage());
            } finally {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            resXml = sb.toString();
            String result = loanRepaymentItemService.payReturn(resXml);
            return result;
        } catch (Exception e) {
            System.out.println("微信手机支付失败:" + e.getMessage());
            String result = "<xml>" + "<return_code><![CDATA[FAIL]]></return_code>" + "<return_msg><![CDATA[报文为空]]></return_msg>" + "</xml> ";
            return result;
        }
    }

//    @ApiOperation("银联还款回调")
    @PostMapping("/yinLianPayReturn")
    public Wrapper yinLianPayReturn(String aaa){
        return null;
    }


    @ApiOperation("小程序支付回调")
    @PostMapping("/notify")
    public void xcxNotify(HttpServletResponse response, HttpServletRequest request) {
        loanRepaymentItemService.notify(response, request);
    }

}
