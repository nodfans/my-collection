package com.ddcx.common.provider.service.impl;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.common.provider.mapper.SysConfigMapper;
import com.ddcx.common.provider.service.SysConfigService;
import com.ddcx.framework.base.dto.AdminLoginAutoDto;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.common.SysConfig;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by CodeGenerator on 2020/03/17.
 */
@Service
@Transactional
public class SysConfigServiceImpl implements SysConfigService {
    @Resource
    private SysConfigMapper sysConfigMapper;
    @Resource
    private RedisUtil redisUtil;

    @PostConstruct
    public JSONObject initExamScoreConfig1(){
        String value=sysConfigMapper.selectByKey(RedisKey.EXAM_SCORE_CONFIG);
        redisUtil.hset(RedisKey.SYS_CONFIG,RedisKey.EXAM_SCORE_CONFIG,value);
        return JSONObject.parseObject(value);
    }
    public JSONObject initExamScoreConfig(Long motorcadeId){
        String value=sysConfigMapper.selectByKey(RedisKey.EXAM_SCORE_CONFIG+motorcadeId);
        redisUtil.hset(RedisKey.SYS_CONFIG,RedisKey.EXAM_SCORE_CONFIG,value);
        return JSONObject.parseObject(value);
    }
    @Override
    public Wrapper getExamScoreConfig(Long motorcadeId) {
        String value= (String) redisUtil.hget(RedisKey.SYS_CONFIG,RedisKey.EXAM_SCORE_CONFIG+motorcadeId);
        if(value==null){
            initExamScoreConfig(motorcadeId);
            value= (String) redisUtil.hget(RedisKey.SYS_CONFIG,RedisKey.EXAM_SCORE_CONFIG+motorcadeId);
        }
        return WrapMapper.ok(value);
    }

    @Override
    public Wrapper initExamScoreConfig(Byte qType, Integer score, AdminLoginAutoDto dto) {
        if(qType.intValue()==1){
            JSONObject jsonObject=initExamScoreConfig(dto.getMotorcadeId());
            int jScore=jsonObject.getInteger("judge");
            Map<String,Integer> map=new HashMap<>();
            map.put("select",score);
            map.put("judge",jScore);
            String value=sysConfigMapper.selectByKey(RedisKey.EXAM_SCORE_CONFIG+dto.getMotorcadeId());
            if(value==null){
                SysConfig sysConfig=new SysConfig();
                sysConfig.setUpdateBy(dto.getId());
                sysConfig.setUpdateTime(System.currentTimeMillis()/1000);
                sysConfig.setConfigKey(RedisKey.EXAM_SCORE_CONFIG+dto.getMotorcadeId());
                sysConfig.setConfigInfo("考试配合");
                sysConfig.setConfigValue(JSON.toJSONString(map));
                sysConfigMapper.insert(sysConfig);
            }else {
                sysConfigMapper.updateByKey(RedisKey.EXAM_SCORE_CONFIG+dto.getMotorcadeId(),JSON.toJSONString(map),dto.getId(),System.currentTimeMillis()/1000);
            }
        }else{
            JSONObject jsonObject=initExamScoreConfig(dto.getMotorcadeId());
            int sScore=jsonObject.getInteger("select");
            Map<String,Integer> map=new HashMap<>();
            map.put("select",sScore);
            map.put("judge",score);
            String value=sysConfigMapper.selectByKey(RedisKey.EXAM_SCORE_CONFIG+dto.getMotorcadeId());
            if(value==null){
                SysConfig sysConfig=new SysConfig();
                sysConfig.setUpdateBy(dto.getId());
                sysConfig.setUpdateTime(System.currentTimeMillis()/1000);
                sysConfig.setConfigKey(RedisKey.EXAM_SCORE_CONFIG+dto.getMotorcadeId());
                sysConfig.setConfigInfo("考试配合");
                sysConfig.setConfigValue(JSON.toJSONString(map));
                sysConfigMapper.insert(sysConfig);
            }else {
                sysConfigMapper.updateByKey(RedisKey.EXAM_SCORE_CONFIG+dto.getMotorcadeId(),JSON.toJSONString(map),dto.getId(),System.currentTimeMillis()/1000);
            }
        }
        initExamScoreConfig(dto.getMotorcadeId());
        return WrapMapper.ok();
    }
}
