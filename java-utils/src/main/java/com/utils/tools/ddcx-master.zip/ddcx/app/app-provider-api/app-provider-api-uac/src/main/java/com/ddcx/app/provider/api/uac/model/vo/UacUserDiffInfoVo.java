package com.ddcx.app.provider.api.uac.model.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class UacUserDiffInfoVo {


    private idInfo idInfo;
    private licenceInfo licenceInfo;
    private jobInfo jobInfo;
    private List<bankInfo> bankInfos;


    @Data
    public static class idInfo {
        @ApiModelProperty("名称")
        private String name;
        @ApiModelProperty("身份证号码")
        private String idCard;
        @ApiModelProperty("身份证正面照")
        private String frontImg;
        @ApiModelProperty("身份证反面照")
        private String reverseImg;
    }

    @Data
    public static class licenceInfo {
        @ApiModelProperty("行驶证")
        private String licenseImg;
        @ApiModelProperty("驾驶证")
        private String drivingImg;
        @ApiModelProperty("行驶证过期时间")
        private Long licenceExpireTime;
        @ApiModelProperty("驾驶证过期时间")
        private Long drivingExpireTime;
    }

    @Data
    public static class jobInfo {
        @ApiModelProperty("从业资格证照片")
        private String jobImg;
        @ApiModelProperty("过期时间")
        private Long expireTime;
    }

    @Data
    public static class bankInfo {
        private Long id;
        @ApiModelProperty("银行名称")
        private String bankName;
        @ApiModelProperty("卡号")
        private String cardNo;
        @ApiModelProperty("持卡人")
        private String cardVest;

    }
}
