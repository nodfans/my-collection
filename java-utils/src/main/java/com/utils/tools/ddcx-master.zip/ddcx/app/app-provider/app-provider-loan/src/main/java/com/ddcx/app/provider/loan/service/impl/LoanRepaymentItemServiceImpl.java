package com.ddcx.app.provider.loan.service.impl;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alipay.api.response.AlipayTradeAppPayResponse;
import com.ddcx.app.provider.api.loan.model.enums.RepaymentStateEnum;
import com.ddcx.app.provider.api.uac.service.UacUserServiceFeignApi;
import com.ddcx.app.provider.loan.mapper.LoanPayRecordMapper;
import com.ddcx.app.provider.loan.mapper.LoanRepaymentItemMapper;
import com.ddcx.app.provider.loan.service.LoanRepaymentItemService;
import com.ddcx.app.provider.loan.util.*;
import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.*;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.loan.LoanConfig;
import com.ddcx.model.loan.LoanOrder;
import com.ddcx.model.loan.LoanPayRecord;
import com.ddcx.model.loan.LoanRepaymentItem;
import com.ddcx.model.uac.UacUser;
import com.github.wxpay.sdk.WXPay;
import com.github.wxpay.sdk.WXPayUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;

import static com.ddcx.framework.util.StringUtils.getRandomString;

/**
 * Created by CodeGenerator on 2020/03/17.
 */
@Service
@Transactional
public class LoanRepaymentItemServiceImpl extends BaseService<LoanRepaymentItem> implements LoanRepaymentItemService {
    @Resource
    private LoanRepaymentItemMapper loanRepaymentItemMapper;
    @Resource
    private RedisUtil redisUtil;
    @Resource
    private AliUtils aliUtils;
    @Resource
    private UacUserServiceFeignApi userServiceFeignApi;
    @Resource
    private LoanPayRecordMapper recordMapper;
    public static final String SPBILL_CREATE_IP = "112.74.217.123";
    public static final String NOTIFY_URL = "http://112.74.217.123/ddcx/loan/loan/repayment/item/wxPayReturn";
    public static final String TRADE_TYPE_APP = "APP";

    @Override
    public Wrapper getLoanRepayMentItems(LoanOrder order, LoginAuthDto dto) {
        if (order.getRepaymentWay() == null ||
                order.getTimeLimit() == null ||
                order.getAmount() == null) {
            return WrapMapper.error("参数不足<借款本金，借款期限，借款方式>");
        }

        LoanConfig config = (LoanConfig) redisUtil.hget(RedisKey.LOAN_CONFIG, dto.getMotorcadeId() + "");
        Double monthRate = config.getMonthRate().doubleValue();
        List<LoanRepaymentItem> items = new ArrayList<>(order.getTimeLimit());
        //期次
        int issue = 1;
        //总利息
        BigDecimal totalInterest = BigDecimal.ZERO;
        //总额
        BigDecimal totalRepaymentAmount = BigDecimal.ZERO;
        //首月的日期
        int firstPeriodDate = LocalDate.now().getDayOfMonth();
        LoanRepaymentItem item;
        Calendar calendar = Calendar.getInstance();
        Calendar nextCalendar = Calendar.getInstance();
        if (order.getRepaymentWay().equals(Byte.valueOf("1"))) {
            //等额本金计算
            //每月本金
            BigDecimal perMonthPrincipal = BigDecimal.valueOf(LoanUtilsOfCapital.getPerMonthPrincipal(order.getAmount().doubleValue(), order.getTimeLimit()));
            //每月利息
            Map<Integer, Double> map = LoanUtilsOfCapital.getPerMonthInterest(order.getAmount().doubleValue(), monthRate, order.getTimeLimit());
            for (Double iter : map.values()) {
                item = new LoanRepaymentItem();
                getNextPeriodCalendar(calendar, nextCalendar, firstPeriodDate);
                item.setRepaymentTime(nextCalendar.getTimeInMillis() / 1000 / 24 / 3600 * 24 * 3600);
                item.setIssueMsg(LoanIssueUtil.getChinaIssueMsg(issue));
                item.setIssue(issue++);
                item.setAmount(perMonthPrincipal.setScale(2, RoundingMode.HALF_UP));
                item.setInterest(BigDecimal.valueOf(iter).setScale(2, RoundingMode.HALF_UP));
                item.setRepaymentAmount(item.getAmount().add(item.getInterest()).setScale(2, RoundingMode.HALF_UP));
                item.setExpireDay(0);
                item.setState(RepaymentStateEnum.WAIT.getCode());
                calendar.setTime(nextCalendar.getTime());
                items.add(item);
                totalInterest = totalInterest.add(BigDecimal.valueOf(iter));
                totalRepaymentAmount = totalRepaymentAmount.add(item.getRepaymentAmount());
            }
        } else if(order.getRepaymentWay().equals(Byte.valueOf("2"))){
            //等额本息计算
            //每月偿还本金
            Map<Integer, BigDecimal> perMonthPrincipal = LoanUtilsOfInterest.getPerMonthPrincipal(order.getAmount().doubleValue(), monthRate, order.getTimeLimit());
            //每月偿还利息
            Map<Integer, BigDecimal> perMonthInterest = LoanUtilsOfInterest.getPerMonthInterest(order.getAmount().doubleValue(), monthRate, order.getTimeLimit());
            Iterator<BigDecimal> perPI = perMonthPrincipal.values().iterator();
            Iterator<BigDecimal> perII = perMonthInterest.values().iterator();
            while (perPI.hasNext() && perII.hasNext()) {
                item = new LoanRepaymentItem();
                getNextPeriodCalendar(calendar, nextCalendar, firstPeriodDate);
                item.setRepaymentTime(nextCalendar.getTimeInMillis() / 1000 / 24 / 3600 * 24 * 3600);
                item.setIssueMsg(LoanIssueUtil.getChinaIssueMsg(issue));
                item.setIssue(issue++);
                item.setAmount(perPI.next().setScale(2, RoundingMode.HALF_UP));
                item.setInterest(perII.next().setScale(2, RoundingMode.HALF_UP));
                item.setRepaymentAmount(item.getAmount().add(item.getInterest()).setScale(2, RoundingMode.HALF_UP));
                item.setExpireDay(0);
                item.setState(RepaymentStateEnum.WAIT.getCode());
                calendar.setTime(nextCalendar.getTime());
                items.add(item);
                totalInterest = totalInterest.add(item.getInterest());
                totalRepaymentAmount = totalRepaymentAmount.add(item.getRepaymentAmount());
            }
        }else {
            item=new LoanRepaymentItem();
            item.setAmount(order.getAmount().setScale(2,BigDecimal.ROUND_HALF_UP));
            item.setInterest(order.getAmount().multiply(config.getMonthRate()).multiply(BigDecimal.valueOf(order.getTimeLimit())).setScale(2,BigDecimal.ROUND_HALF_UP));
            item.setIssue(1);
            item.setIssueMsg(LoanIssueUtil.getChinaIssueMsg(1));
            item.setOverdueMoney(BigDecimal.ZERO);
            item.setExpireDay(0);
            item.setRepaymentAmount(item.getAmount().add(item.getInterest()).setScale(2,BigDecimal.ROUND_HALF_UP));
            item.setRepaymentTime(LocalDate.now().plusMonths(order.getTimeLimit()).toEpochDay()*24*60*60);
            items.add(item);
            totalRepaymentAmount = totalRepaymentAmount.add(item.getRepaymentAmount());
        }
        Wrapper wrapper = WrapMapper.ok(items);
        wrapper.setMessage(totalRepaymentAmount.setScale(2, RoundingMode.HALF_UP).toString());
        return wrapper;
    }

    @Override
    public Wrapper repayment(LoanRepaymentItem item, LoginAuthDto dto) throws Exception {
        Integer issue = loanRepaymentItemMapper.selectCurrentIssue(item.getoId());
        item.setIssue(issue);
        LoanRepaymentItem item1 = loanRepaymentItemMapper.selectByCondition(item.getoId(), item.getIssue(), dto.getUserId());
        String orderNumber = null;
        if (item1 == null) {
            return WrapMapper.error("订单不存在");
        }
        if (item.getPayType().intValue() == 1) {
            WxMd5Util md5Util = new WxMd5Util();
            String total_fee = item1.getRepaymentAmount().setScale(2, BigDecimal.ROUND_HALF_UP).toString();
            //微信支付
            String attach = "{\"user_id\":\"" + dto.getUserId() + "\"}";
            //请求预支付订单
            Map<String, String> returnMap = new HashMap<>();
            WxUtils config = new WxUtils();
            WXPay wxpay = new WXPay(config);
            Map<String, String> data = new HashMap<>();
            //生成商户订单号，不可重复
            String out_trade_no = "WX" + generateId();
            data.put("appid", config.getAppID());
            data.put("mch_id", config.getMchID());
            data.put("nonce_str", WXPayUtil.generateNonceStr());
            String body = "还款";
            data.put("body", body);
            data.put("out_trade_no", out_trade_no);
            data.put("total_fee", total_fee);
            //自己的服务器IP地址
            data.put("spbill_create_ip", SPBILL_CREATE_IP);
            //异步通知地址（请注意必须是外网）
            data.put("notify_url", NOTIFY_URL);
            //交易类型
            data.put("trade_type", TRADE_TYPE_APP);
            //附加数据，在查询API和支付通知中原样返回，该字段主要用于商户携带订单的自定义数据
            data.put("attach", attach);
            String sign1 = md5Util.getSign(data);
            data.put("sign", sign1);

            try {
                //使用官方API请求预付订单
                Map<String, String> response = wxpay.unifiedOrder(data);
                System.out.println(response);
                String returnCode = response.get("return_code");    //获取返回码
                //若返回码为SUCCESS，则会返回一个result_code,再对该result_code进行判断
                if (returnCode.equals("SUCCESS")) {//主要返回以下5个参数
                    String resultCode = response.get("result_code");
                    returnMap.put("appid", response.get("appid"));
                    returnMap.put("mch_id", response.get("mch_id"));
                    returnMap.put("nonce_str", response.get("nonce_str"));
                    returnMap.put("sign", response.get("sign"));
                    if ("SUCCESS".equals(resultCode)) {//resultCode 为SUCCESS，才会返回prepay_id和trade_type
                        //获取预支付交易回话标志
                        returnMap.put("trade_type", response.get("trade_type"));
                        returnMap.put("prepay_id", response.get("prepay_id"));
                    } else {
                        //此时返回没有预付订单的数据
                    }
                } else {
                }
            } catch (Exception e) {
                System.out.println(e);
                //系统等其他错误的时候
            }
            Map<String, String> map = new HashMap<>();
            //返回APP端的数据
            //参加调起支付的签名字段有且只能是6个，分别为appid、partnerid、prepayid、package、noncestr和timestamp，而且都必须是小写
            //参加调起支付的签名字段有且只能是6个，分别为appid、partnerid、prepayid、package、noncestr和timestamp，而且都必须是小写
            //参加调起支付的签名字段有且只能是6个，分别为appid、partnerid、prepayid、package、noncestr和timestamp，而且都必须是小写
            map.put("appid", returnMap.get("appid"));
            map.put("partnerid", returnMap.get("mch_id"));
            map.put("prepayid", returnMap.get("prepay_id"));
            map.put("package", "Sign=WXPay");
            map.put("noncestr", returnMap.get("nonce_str"));
            map.put("timestamp", String.valueOf(System.currentTimeMillis() / 1000));//单位为秒
            //      这里不要使用请求预支付订单时返回的签名
            //      这里不要使用请求预支付订单时返回的签名
            //      这里不要使用请求预支付订单时返回的签名
            map.put("sign", md5Util.getSign(map));
            map.put("extdata", attach);
            return WrapMapper.ok(map);
        } else if (item.getPayType().intValue() == 2) {
            //支付宝支付
            orderNumber = "ALI" + generateId();
            AlipayTradeAppPayResponse response = aliUtils.pay(item1.getRepaymentAmount(), orderNumber);
            if (response == null) {
                return WrapMapper.error("支付宝支付调用失败！");
            }
            redisUtil.hset(RedisKey.ALI_ORDER_NUMBER, orderNumber, item1.getId(), 60 * 25);
            return WrapMapper.ok(response);
        } else if (item.getPayType().intValue() == 3) {
            //银联支付
        } else if (4 == item.getPayType().intValue()) {
            // 小程序微信支付
            //生成的随机字符串
            try {
                String nonce_str = getRandomString(32);
                //商品名称
                String body = "还款";
                //获取客户端的ip地址
                String spbill_create_ip = SPBILL_CREATE_IP;
                UacUser user = userServiceFeignApi.getUser(dto.getUserId());
                String openid = null;
                if (PublicUtil.isNotEmpty(user)) {
                    openid = user.getOpenId();
                } else {
                    logger.info("openId为空");
                }
                System.out.println("openid--->>>" + openid);
                String out_trade_no = String.valueOf(generateId());
                String total_fee = item1.getRepaymentAmount().setScale(2, BigDecimal.ROUND_HALF_UP).toString();
                //组装参数，用户生成统一下单接口的签名
                Map<String, String> packageParams = new HashMap<String, String>();
                packageParams.put("appid", WechatConfig.APPID);
                packageParams.put("mch_id", WxPayConfig.mch_id);
                packageParams.put("nonce_str", nonce_str);
                packageParams.put("body", body);
                packageParams.put("out_trade_no", out_trade_no);//商户订单号
                packageParams.put("total_fee", total_fee);//支付金额，这边需要转成字符串类型，否则后面的签名会失败
                packageParams.put("spbill_create_ip", spbill_create_ip);
                packageParams.put("notify_url", WxPayConfig.notify_url);//支付成功后的回调地址
                packageParams.put("trade_type", WxPayConfig.TRADETYPE);//支付方式
                packageParams.put("openid", openid);
                String prestr = PayUtil.createLinkString(packageParams); // 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
                //MD5运算生成签名，这里是第一次签名，用于调用统一下单接口
                String mysign = PayUtil.sign(prestr, WxPayConfig.key, "utf-8").toUpperCase();
                //拼接统一下单接口使用的xml数据，要将上一步生成的签名一起拼接进去
                String xml = "<xml>" + "<appid>" + WechatConfig.APPID + "</appid>"
                        + "<body><![CDATA[" + body + "]]></body>"
                        + "<mch_id>" + WxPayConfig.mch_id + "</mch_id>"
                        + "<nonce_str>" + nonce_str + "</nonce_str>"
                        + "<notify_url>" + WxPayConfig.notify_url + "</notify_url>"
                        + "<openid>" + openid + "</openid>"
                        + "<out_trade_no>" + out_trade_no + "</out_trade_no>"
                        + "<spbill_create_ip>" + spbill_create_ip + "</spbill_create_ip>"
                        + "<total_fee>" + total_fee + "</total_fee>"
                        + "<trade_type>" + WxPayConfig.TRADETYPE + "</trade_type>"
                        + "<sign>" + mysign + "</sign>"
                        + "</xml>";
                System.out.println("调试模式_统一下单接口 请求XML数据：" + xml);
                //调用统一下单接口，并接受返回的结果
                String result = PayUtil.httpRequest(WxPayConfig.pay_url, "POST", xml);
                System.out.println("调试模式_统一下单接口 返回XML数据：" + result);
                // 将解析结果存储在HashMap中
                Map map = PayUtil.doXMLParse(result);
                String return_code = (String) map.get("return_code");//返回状态码
                Map<String, Object> response = new HashMap<>();//返回给小程序端需要的参数
                if (return_code.equals("SUCCESS")) {
                    String prepay_id = (String) map.get("prepay_id");//返回的预付单信息
                    response.put("nonceStr", nonce_str);
                    response.put("package", "prepay_id=" + prepay_id);
                    Long timeStamp = System.currentTimeMillis() / 1000;
                    response.put("timeStamp", timeStamp + "");//这边要将返回的时间戳转化成字符串，不然小程序端调用wx.requestPayment方法会报签名错误
                    //拼接签名需要的参数
                    String stringSignTemp = "appId=" + WechatConfig.APPID + "&nonceStr=" + nonce_str + "&package=prepay_id=" + prepay_id + "&signType=" + WxPayConfig.SIGNTYPE + "&timeStamp=" + timeStamp;
                    //再次签名，这个签名用于小程序端调用wx.requesetPayment方法
                    String paySign = PayUtil.sign(stringSignTemp, WxPayConfig.key, "utf-8").toUpperCase();
                    response.put("paySign", paySign);
                    response.put("signType", WxPayConfig.SIGNTYPE);
                    LoanPayRecord record = new LoanPayRecord();
                    record.setId(Long.valueOf(out_trade_no));
                    record.setItemId(item.getId());
                    record.setPayDateTime(System.currentTimeMillis() / 1000);
                    record.setPayMoney(item.getRepaymentAmount());
                    record.setSourceData(JSON.toJSONString(map));
                    record.setOrderNumber(orderNumber); // 目前是空
                    record.setType((byte) 4);
                    recordMapper.insert(record);
                }
                response.put("appid", WechatConfig.APPID);
                response.put("state", 1);
                return WrapMapper.ok(response);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        } else if(5 == item.getPayType().intValue()) {
            LoanRepaymentItem loanRepaymentItem = new LoanRepaymentItem();
            loanRepaymentItem.setId(item1.getId());
            if(StringUtils.isBlank(item.getRemarkFile())){
                return WrapMapper.error("请上传支付凭证");
            }
            loanRepaymentItem.setRemarkFile(item.getRemarkFile());
            loanRepaymentItem.setState((byte) 3);
            loanRepaymentItemMapper.updateByPrimaryKeySelective(loanRepaymentItem);
            return WrapMapper.ok("已提交线下支付审核");
        }else {
            return WrapMapper.error("支付类型非法");
        }
        return null;
    }

    @Override
    public Wrapper aliAttestation(String mapSource) {
        JSONObject jsonObject = JSONObject.parseObject(mapSource);
        JSONObject jsonObject1 = JSONObject.parseObject(jsonObject.get("map").toString());
        JSONObject jsonObject2 = JSONObject.parseObject(jsonObject1.get("result").toString());
//        JSONObject jsonObject3=JSONObject.parseObject(jsonObject2.get("alipay_trade_app_pay_response").toString());
        Map<String, Object> map2 = jsonObject2.getInnerMap();
//        Map<String,Object> map3=jsonObject3.getInnerMap();
//        String result1=JSONObject.parseObject(map2).getString("result");
//        Map<String,Object> map1=JSONObject.parseObject(result1).getInnerMap();
        Map<String, String> map = new LinkedHashMap<>();
        for (String s : map2.keySet()) {
            if (s.equals("sign_type")) {
                continue;
            }
            map.put(s, map2.get(s).toString());
        }
        String content = jsonObject1.get("result").toString();
        content = content.substring(content.indexOf(":{") + 1, content.lastIndexOf("sign\":") - 2);
        boolean result = aliUtils.aliAttestation(map, content);
        if (result) {
            switch (jsonObject1.getString("resultStatus")) {
                case "9000":
                case "6004":
                case "8000":
                    return WrapMapper.ok("支付成功");
                case "4000":
                    return WrapMapper.error("订单支付失败");
                case "5000":
                    return WrapMapper.error("重复请求");
                case "6001":
                    return WrapMapper.error("用户中途取消");
                case "6002": {
                    return WrapMapper.error("网络连接出错");
                }
                default:
                    return WrapMapper.error("其它支付错误");
            }
        }
        return WrapMapper.error("支付宝验签失败！");
    }

    @Override
    public String aliPayReturn(Map<String, String> map) {
        boolean result = aliUtils.aliReturnAttestation(map);
        if (!result) {
            return "failure";
        }
        String orderNumber = map.get("out_trade_no");
        //用户支付金额
        String payMoney = map.get("total_amount");
        Long id = null;
        try {
            id = (Long) redisUtil.hget(RedisKey.ALI_ORDER_NUMBER, orderNumber);
        } catch (Exception e) {
            return "failure";
        }
        if (!map.get("trade_status").equals("TRADE_SUCCESS")) {
            return "success";
        }
        LoanRepaymentItem item = loanRepaymentItemMapper.selectByPrimaryKey(id);
        if (!item.getRepaymentAmount().setScale(2, BigDecimal.ROUND_HALF_UP).toString().equals(payMoney)) {
            return "failure";
        }
        if (!map.get("app_id").equals(AliUtils.APP_ID)) {
            return "failure";
        }
        return successOpration(orderNumber, item, map, (byte) 2);
    }

    @Override
    public String payReturn(String notifyData) {
        WxUtils config = null;
        try {
            config = new WxUtils();
        } catch (Exception e) {
            e.printStackTrace();
        }
        WXPay wxpay = new WXPay(config);
        String xmlBack = "";
        Map<String, String> notifyMap = null;
        try {
            notifyMap = WXPayUtil.xmlToMap(notifyData);         // 调用官方SDK转换成map类型数据
            if (wxpay.isPayResultNotifySignatureValid(notifyMap)) {//验证签名是否有效，有效则进一步处理
                String return_code = notifyMap.get("return_code");//状态
                String out_trade_no = notifyMap.get("out_trade_no");//商户订单号
                if (return_code.equals("SUCCESS")) {
                    if (out_trade_no != null) {
                        // 注意特殊情况：订单已经退款，但收到了支付结果成功的通知，不应把商户的订单状态从退款改成支付成功
                        // 注意特殊情况：微信服务端同样的通知可能会多次发送给商户系统，所以数据持久化之前需要检查是否已经处理过了，处理了直接返回成功标志
                        //业务数据持久化
                        System.err.println("支付成功");
                        logger.info("微信手机支付回调成功订单号:{}", out_trade_no);
                        Long id = null;
                        try {
                            id = (Long) redisUtil.hget(RedisKey.WX_ORDER_NUMBER, out_trade_no);
                        } catch (Exception e) {
                            logger.info("微信手机支付回调失败订单号:{}", out_trade_no);
                            xmlBack = "<xml>" + "<return_code><![CDATA[FAIL]]></return_code>" + "<return_msg><![CDATA[报文为空]]></return_msg>" + "</xml> ";
                            return xmlBack;
                        }
                        LoanRepaymentItem item = loanRepaymentItemMapper.selectByPrimaryKey(id);
                        String r = successOpration(out_trade_no, item, notifyMap, (byte) 1);
                        if ("failure".equals(r)) {
                            xmlBack = "<xml>" + "<return_code><![CDATA[FAIL]]></return_code>" + "<return_msg><![CDATA[报文为空]]></return_msg>" + "</xml> ";
                            return xmlBack;
                        }
                        xmlBack = "<xml>" + "<return_code><![CDATA[SUCCESS]]></return_code>" + "<return_msg><![CDATA[OK]]></return_msg>" + "</xml> ";
                    } else {
                        logger.info("微信手机支付回调失败订单号:{}", out_trade_no);
                        xmlBack = "<xml>" + "<return_code><![CDATA[FAIL]]></return_code>" + "<return_msg><![CDATA[报文为空]]></return_msg>" + "</xml> ";
                    }
                }
                return xmlBack;
            } else {
                // 签名错误，如果数据里没有sign字段，也认为是签名错误
                //失败的数据要不要存储？
                logger.error("手机支付回调通知签名错误");
                xmlBack = "<xml>" + "<return_code><![CDATA[FAIL]]></return_code>" + "<return_msg><![CDATA[报文为空]]></return_msg>" + "</xml> ";
                return xmlBack;
            }
        } catch (Exception e) {
            logger.error("手机支付回调通知失败", e);
            xmlBack = "<xml>" + "<return_code><![CDATA[FAIL]]></return_code>" + "<return_msg><![CDATA[报文为空]]></return_msg>" + "</xml> ";
        }
        return xmlBack;
    }

    @Override
    public void notify(HttpServletResponse response, HttpServletRequest request) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader((ServletInputStream) request.getInputStream()));
            String line = null;
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
            //sb为微信返回的xml
            String notityXml = sb.toString();
            String resXml = "";
            System.out.println("接收到的报文：" + notityXml);
            Map map = PayUtil.doXMLParse(notityXml);
            System.out.println("Notify Map--->>>" + map.toString());
            String returnCode = (String) map.get("return_code");
            String out_trade_no = (String) map.get("out_trade_no");
            if ("SUCCESS".equals(returnCode)) {
                //验证签名是否正确
                Map<String, String> validParams = PayUtil.paraFilter(map);  //回调验签时需要去除sign和空值参数
                String validStr = PayUtil.createLinkString(validParams);//把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
                String sign = PayUtil.sign(validStr, WxPayConfig.key, "utf-8").toUpperCase();//拼装生成服务器端验证的签名
                //根据微信官网的介绍，此处不仅对回调的参数进行验签，还需要对返回的金额与系统订单的金额进行比对等
                if (sign.equals(map.get("sign"))) {
                    Example example = new Example(LoanPayRecord.class);
                    Example.Criteria criteria = example.createCriteria();
                    criteria.andEqualTo("id", out_trade_no);
                    LoanPayRecord record = recordMapper.selectOneByExample(example);
                    if (PublicUtil.isNotEmpty(record)) {
                        // 订单业务

                        //通知微信服务器已经支付成功
                        resXml = "<xml>" + "<return_code><![CDATA[SUCCESS]]></return_code>"
                                + "<return_msg><![CDATA[OK]]></return_msg>" + "</xml> ";
                    }
                }
            } else {
                resXml = "<xml>" + "<return_code><![CDATA[FAIL]]></return_code>"
                        + "<return_msg><![CDATA[报文为空]]></return_msg>" + "</xml> ";
            }
            System.out.println(resXml);
            System.out.println("微信支付回调数据结束");
            BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream());
            out.write(resXml.getBytes());
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String successOpration(String orderNumber, LoanRepaymentItem item, Map<String, String> map, Byte type) {
        LoanPayRecord record = new LoanPayRecord();
        record.setId(generateId());
        record.setType((byte) 2);
        record.setItemId(item.getId());
        record.setPayDateTime(System.currentTimeMillis() / 1000);
        record.setPayMoney(item.getRepaymentAmount());
        record.setSourceData(JSON.toJSONString(map));
        record.setOrderNumber(orderNumber);
        int i = recordMapper.insert(record);
        String repaymentType;
        switch (type) {
            case 1:
                repaymentType = "微信还款";
                break;
            case 2:
                repaymentType = "支付宝还款";
                break;
            case 3:
                repaymentType = "银联还款";
                break;
            case 4:
                repaymentType = "小程序还款";
                break;
            default:
                repaymentType = "其他途径";
        }
        int j = loanRepaymentItemMapper.finish(item.getId(), repaymentType);
        if (i > 0 && j > 0) {
            if (type.intValue() == 1) {
                redisUtil.hdel(RedisKey.WX_ORDER_NUMBER, orderNumber);
            }
            if (type.intValue() == 2) {
                redisUtil.hdel(RedisKey.ALI_ORDER_NUMBER, orderNumber);
            }
            if (type.intValue() == 3) {
                redisUtil.hdel(RedisKey.YL_ORDER_NUMBER, orderNumber);
            }
            return "success";
        }
        return "failure";
    }


    /**
     * 获得下一期还款日
     */
    private void getNextPeriodCalendar(Calendar calendar, Calendar nextPeriodCalendar, int firstPeriodDate) {
        int currentPeriodMonth = calendar.get(Calendar.MONTH);
        int currentPeriodYear = calendar.get(Calendar.YEAR);
        int nextPeriodMonth = currentPeriodMonth + 1;
        if (nextPeriodMonth > 11) {
            nextPeriodMonth = nextPeriodMonth % 12;
            nextPeriodCalendar.set(Calendar.DATE, 1);
            nextPeriodCalendar.set(Calendar.YEAR, currentPeriodYear + 1);
            nextPeriodCalendar.set(Calendar.MONTH, nextPeriodMonth);
        } else {
            nextPeriodCalendar.set(Calendar.DATE, 1);
            nextPeriodCalendar.set(Calendar.MONTH, nextPeriodMonth);
        }
        int nextPeriodMaxDate = nextPeriodCalendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        if (firstPeriodDate > nextPeriodMaxDate) {
            nextPeriodCalendar.set(Calendar.DATE, nextPeriodMaxDate);
        } else {
            nextPeriodCalendar.set(Calendar.DATE, firstPeriodDate);
        }
    }
}
