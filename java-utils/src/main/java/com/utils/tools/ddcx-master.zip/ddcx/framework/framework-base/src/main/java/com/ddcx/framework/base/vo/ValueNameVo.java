package com.ddcx.framework.base.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ValueNameVo implements java.io.Serializable {
    private static final long serialVersionUID = 4586393943305280618L;

    @ApiModelProperty(value = "值", name = "v")
    private Object v;

    @ApiModelProperty(value = "名称", name = "n")
    private String n;

    public ValueNameVo(Object v, String n) {
        this.v = v;
        this.n = n;
    }
}
