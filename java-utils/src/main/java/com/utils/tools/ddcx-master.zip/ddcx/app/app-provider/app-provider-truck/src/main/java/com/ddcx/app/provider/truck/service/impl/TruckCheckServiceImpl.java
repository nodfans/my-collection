package com.ddcx.app.provider.truck.service.impl;


import com.ddcx.app.provider.api.uac.service.UacUserServiceFeignApi;
import com.ddcx.app.provider.truck.mapper.TruckCheckMapper;
import com.ddcx.app.provider.truck.mapper.TruckMapper;
import com.ddcx.app.provider.truck.mapper.TruckSafeInformMapper;
import com.ddcx.app.provider.truck.service.TruckCheckService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.StringUtils;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.Truck;
import com.ddcx.model.truck.TruckCheck;
import com.ddcx.model.truck.TruckSafeInform;
import com.ddcx.model.uac.UserBacklog;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/04/17.
 */
@Service
@Transactional
public class TruckCheckServiceImpl extends BaseService<TruckCheck> implements TruckCheckService {
    @Resource
    private TruckCheckMapper truckCheckMapper;
    @Resource
    private TruckMapper truckMapper;
    @Resource
    private UacUserServiceFeignApi uacUserServiceFeignApi;
    @Resource
    private TruckSafeInformMapper truckSafeInformMapper;
    @Override
    public Wrapper addTruckCheck(TruckCheck check, LoginAuthDto dto) {
        Truck truck=truckMapper.selectByPrimaryKey(check.getTruckId());
        if(truck==null){
            return WrapMapper.error("汽车不存在");
        }
        check.setTruckNum(truck.getTruckNum());
        check.setDriverName(truck.getDriverName());
        check.setCheckName(dto.getUserName());
        check.setDriverName(dto.getUserName());
        check.setId(generateId());
        List<String> needCheck=new LinkedList<>();
        if(check.getCertificate().intValue()==1){
            needCheck.add("行车证件");
        }
        if(check.getSafetyBelt().intValue()==1){
            needCheck.add("安全带");
        }
        if(check.getShiftOp().intValue()==1){
            needCheck.add("离合及换挡操作情况");
        }
        if(check.getSteering().intValue()==1){
            needCheck.add("转向系统");
        }
        if(check.getBrakeOp().intValue()==1){
            needCheck.add("刹车系统");
        }
        if(check.getTire().intValue()==1){
            needCheck.add("轮胎");
        }
        if(check.getUnderpan().intValue()==1){
            needCheck.add("底盘、钢板总成");
        }
        if(check.getEngine().intValue()==1){
            needCheck.add("引擎");
        }
        if(check.getOilCircuit().intValue()==1){
            needCheck.add("油电路");
        }
        if(check.getTrumpet().intValue()==1){
            needCheck.add("喇叭");
        }
        if(check.getWiper().intValue()==1){
            needCheck.add("雨刮");
        }
        if(check.getDoorLock().intValue()==1){
            needCheck.add("车门锁");
        }
        if(check.getMirror().intValue()==1){
            needCheck.add("左右及车内后视镜");
        }
        if(check.getLamplight().intValue()==1){
            needCheck.add("车灯");
        }
        if(check.getLicensePlate().intValue()==1){
            needCheck.add("车牌照");
        }
        if(check.getDashBoard().intValue()==1){
            needCheck.add("仪表指示");
        }
        if(check.getAppearance().intValue()==1){
            needCheck.add("车辆外观");
        }
        if(check.getRepertory().intValue()==1){
            needCheck.add("车辆常备工具");
        }
        if(check.getTireChain().intValue()==1){
            needCheck.add("防滑链");
        }
        if(check.getBumper().intValue()==1){
            needCheck.add("前后保险杠");
        }
        if(check.getGps().intValue()==1){
            needCheck.add("GPS");
        }

        if(needCheck.size()>0){
            //添加隐患整改通知
            TruckSafeInform inform=new TruckSafeInform();
            inform.setId(generateId());
            inform.setAbarbeitungLimit(7);
            inform.setCreateTime(System.currentTimeMillis()/1000);
            inform.setTruckId(truck.getId());
            inform.setTruckNum(truck.getTruckNum());
            inform.setInformNum(StringUtils.generatorCheckNum());
            inform.setCheckId(check.getId());
            inform.setState((byte) 0);
            //添加待办事项
            UserBacklog userBacklog=new UserBacklog();
            userBacklog.setDriverId(truck.getDriverId());
            userBacklog.setInitiateDate(System.currentTimeMillis()/1000);
            userBacklog.setLimitDate(System.currentTimeMillis()/1000+7*24*60*60);
            userBacklog.setOverdueState((byte) 1);
            userBacklog.setTitle("安全隐患整改");
            userBacklog.setType((byte) 1);
            userBacklog.setState((byte) 0);
            check.setRectification((byte) 2);
            for (String s : needCheck) {
                inform.setId(generateId());
                inform.setCheckPart(s);
                truckSafeInformMapper.insert(inform);
                userBacklog.setObjId(inform.getId());
                userBacklog.setDetails("车牌号为："+truck.getTruckNum()+",部件"+s+"需要整改。");
                uacUserServiceFeignApi.addUserBackLog(userBacklog);
            }
        }
        int i=truckCheckMapper.insert(check);
        if(i>0){
         return WrapMapper.ok();
        }
        return WrapMapper.error("添加失败");
    }



}
