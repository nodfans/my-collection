package com.ddcx.model.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Id;

@Data
@ApiModel("救援配置")
public class Rescue implements java.io.Serializable {

    @Id
    @ApiModelProperty("主键")
    private Long id;
    @ApiModelProperty("发布人用户ID")
    private Long userId;
    @ApiModelProperty("救援原因")
    private String reason;
    @ApiModelProperty("紧急联系人电话")
    private Long contactPhone;
    @ApiModelProperty("状态")
    private Integer state;
    @ApiModelProperty("救援地址")
    private String address;
    @ApiModelProperty("创建时间")
    private Long createTime;

}
