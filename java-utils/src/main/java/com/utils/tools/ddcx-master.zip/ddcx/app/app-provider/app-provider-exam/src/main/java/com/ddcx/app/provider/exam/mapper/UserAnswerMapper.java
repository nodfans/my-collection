package com.ddcx.app.provider.exam.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.exam.UserAnswer;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

@Component
@Mapper
public interface UserAnswerMapper extends MyMapper<UserAnswer> {
}