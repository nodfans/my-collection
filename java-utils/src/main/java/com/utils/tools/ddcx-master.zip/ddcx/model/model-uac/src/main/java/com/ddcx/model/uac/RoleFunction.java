package com.ddcx.model.uac;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Table(name = "role_function")
@ApiModel("角色权限关系")
public class RoleFunction {
    /**
     * 角色主键
     */
    @Id
    @ApiModelProperty("角色主键")
    @Column(name = "role_id")
    private Long roleId;

    /**
     * 权限主键
     */
    @Id
    @ApiModelProperty("权限主键")
    @Column(name = "function_id")
    private Long functionId;


    public RoleFunction() {
    }

    public RoleFunction(Long roleId, Long functionId) {
        this.roleId = roleId;
        this.functionId = functionId;
    }

    /**
     * 获取角色主键
     *
     * @return role_id - 角色主键
     */
    public Long getRoleId() {
        return roleId;
    }

    /**
     * 设置角色主键
     *
     * @param roleId 角色主键
     */
    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    /**
     * 获取权限主键
     *
     * @return function_id - 权限主键
     */
    public Long getFunctionId() {
        return functionId;
    }

    /**
     * 设置权限主键
     *
     * @param functionId 权限主键
     */
    public void setFunctionId(Long functionId) {
        this.functionId = functionId;
    }

}