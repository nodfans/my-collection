package com.ddcx.common.provider.service;


import com.ddcx.framework.base.dto.AdminLoginAutoDto;
import com.ddcx.framework.util.wrapper.Wrapper;

/**
 * Created by CodeGenerator on 2020/03/17.
 */
public interface SysConfigService {

    Wrapper getExamScoreConfig(Long motorcadeId);

    Wrapper initExamScoreConfig(Byte qType, Integer score, AdminLoginAutoDto dto);
}
