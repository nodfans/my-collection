package com.ddcx.app.provider.uac.web;

import com.ddcx.app.provider.api.uac.model.dto.UacLoginDto;
import com.ddcx.app.provider.api.uac.model.vo.UacLoginTokenVo;
import com.ddcx.app.provider.uac.service.UacLoginTokenService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.base.enums.LogTypeEnum;
import com.ddcx.framework.core.annotation.RequestLog;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.google.common.base.Preconditions;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/token")
@Api(value = "登录", tags = {"登录"})
public class UacLoginTokenController extends BaseController {

    @Autowired
    private UacLoginTokenService loginTokenService;

    /**
     * 登录获取token
     */
    @ApiOperation(value = "获取token", notes = "获取token")
    @PostMapping(value = "/get")
    @RequestLog(logType = LogTypeEnum.LOGIN_LOG, isSaveRequestData = true, isSaveResponseData = true)
    public synchronized Wrapper<UacLoginTokenVo> login(@RequestBody @Validated UacLoginDto uacLoginDto) {
        if (1 == uacLoginDto.getLoginType()) {
            Preconditions.checkArgument(PublicUtil.isNotEmpty(uacLoginDto.getCode()), "请输入验证码");
        } else if (2 == uacLoginDto.getLoginType()) {
            Preconditions.checkArgument(PublicUtil.isNotEmpty(uacLoginDto.getPassword()), "请输入密码");
        }
        Preconditions.checkArgument(PublicUtil.isNotEmpty(uacLoginDto.getFromType()) && (1 == uacLoginDto.getFromType() || 2 == uacLoginDto.getFromType()), "请选择登来源");
        final UacLoginTokenVo uacLoginTokenVo = loginTokenService.token(uacLoginDto);
        return WrapMapper.ok(uacLoginTokenVo);
    }

    /**
     * 刷新token
     */
    @ApiOperation(value = "刷新token", notes = "刷新token")
    @GetMapping(value = "/refresh")
    @RequestLog(logType = LogTypeEnum.REQUEST_LOG, isSaveRequestData = true, isSaveResponseData = true)
    public Wrapper<UacLoginTokenVo> refreshToken() {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        final UacLoginTokenVo uacLoginTokenVo = loginTokenService.refreshToken(loginAuthDto.getUserId());
        return WrapMapper.ok(uacLoginTokenVo);
    }

    /**
     * 退出清除token
     */
    @ApiOperation(value = "清除token", notes = "清除token")
    @RequestLog(logType = LogTypeEnum.REQUEST_LOG)
    @DeleteMapping(value = "/delete")
    public Wrapper logout() {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        loginTokenService.deleteToken(loginAuthDto.getUserId());
        return WrapMapper.ok();
    }
}
