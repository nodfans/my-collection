package com.ddcx.common.provider.service.impl;


import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.common.provider.mapper.BsAreaMapper;
import com.ddcx.common.provider.service.BsAreaService;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.model.common.BsArea;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/23.
 */
@Service
@Transactional
public class BsAreaServiceImpl extends BaseService<BsArea> implements BsAreaService {
    @Resource
    private BsAreaMapper bsAreaMapper;

    @Resource
    private RedisUtil redisUtil;


    /**
     * redis初始化信息
     */
    @PostConstruct
    public  void InitInfo(){
        Long area=redisUtil.hgetSize(RedisKey.BS_AREA);
        if(area>0){
            return;
        }
        List<BsArea> list=bsAreaMapper.selectAll();
        for (BsArea bsArea : list) {
            redisUtil.hset(RedisKey.BS_AREA,bsArea.getAreaCode()+"",bsArea);
        }
    }


}
