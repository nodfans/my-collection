package com.ddcx.app.provider.friend.client;


import com.ddcx.app.provider.api.friend.service.FriendServiceFeignApi;
import com.ddcx.app.provider.friend.mapper.FriendCircleMapper;
import com.ddcx.app.provider.friend.mapper.FriendCircleReplyMapper;
import com.ddcx.app.provider.friend.mapper.FriendLikeMapper;
import com.ddcx.framework.util.StringUtils;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RefreshScope
@RestController
public class FriendFeignClient implements FriendServiceFeignApi {

    @Resource
    private FriendCircleMapper friendCircleMapper;
    @Resource
    private FriendCircleReplyMapper friendCircleReplyMapper;
    @Resource
    private FriendLikeMapper friendLikeMapper;

    @Override
    public void updateUserHeadImgAndUserName(Long userId, String imgPath, String userName) {
        friendCircleMapper.updateUserHeadImgAndUserName(userId,imgPath,userName);
        if(StringUtils.isNotBlank(userName)){
            friendCircleReplyMapper.updateUserNameByUserId(userId,userName);
            friendCircleReplyMapper.updateUserNameByUserId1(userId,userName);
            friendLikeMapper.updateUserNameByUserId(userId,userName);
        }
    }
}
