package com.ddcx.common.provider.service.impl;


import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.model.common.Dictionary;
import com.ddcx.common.provider.mapper.DictionaryMapper;
import com.ddcx.common.provider.service.DictionaryService;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/02/27.
 */
@Service
@Transactional
@Log4j2
public class DictionaryServiceImpl implements DictionaryService {
    @Resource
    private DictionaryMapper dictionaryMapper;

    @Resource
    private RedisUtil redisUtil;


    /**
     * 初始化数据字典到redis
     */
    @PostConstruct
    public void initDictionary(){

        redisUtil.lTrim(RedisKey.DICTIONARY_LIST,0,0);
        redisUtil.lPop(RedisKey.DICTIONARY_LIST);

        List<Dictionary> list=dictionaryMapper.selectAllOrder();

        List<Dictionary> dictionaries=new LinkedList<>();
        Integer type=list.get(0).getType();
        Dictionary dictionary;
        for (int i = 0; i < list.size(); i++) {
            dictionary=list.get(i);
            if(type.equals(dictionary.getType())&&i!=(list.size()-1)){
                dictionaries.add(dictionary);
            }else{
                if(i==list.size()-1){
                    if(type.equals(dictionary.getType())){
                        dictionaries.add(dictionary);
                    }else {
                        redisUtil.lSet(RedisKey.DICTIONARY_LIST,dictionaries);
                        dictionaries=new LinkedList<>();
                        type=dictionary.getType();
                        dictionaries.add(dictionary);
                    }
                }
                redisUtil.lSet(RedisKey.DICTIONARY_LIST,dictionaries);
                if(i!=list.size()-1){
                    dictionaries=new LinkedList<>();
                    type=dictionary.getType();
                    dictionaries.add(dictionary);
                }
            }
        }
        log.info("数据字典，加载完成-------------------------");
        return;
    }


    @Override
    public Wrapper<List<Dictionary>> getDictionaryByType(Integer type) {
        if (type == null || type > redisUtil.lGetListSize(RedisKey.DICTIONARY_LIST)) {
            return WrapMapper.error("数据字典类型非法");
        }
        List<Dictionary> list = (List<Dictionary>) redisUtil.lGetIndex(RedisKey.DICTIONARY_LIST, type - 1);
        return WrapMapper.ok(list);
    }

    @Override
    public Wrapper addDictionary(String data, Integer type) {
        Dictionary dictionary=new Dictionary();
        dictionary.setName(data);
        dictionary.setType(type);
        dictionaryMapper.insert(dictionary);
        initDictionary();
        return WrapMapper.ok();
    }

    @Override
    public Wrapper deleteDictionary(Long id) {
        dictionaryMapper.deleteByPrimaryKey(id);
        initDictionary();
        return WrapMapper.ok();
    }
}
