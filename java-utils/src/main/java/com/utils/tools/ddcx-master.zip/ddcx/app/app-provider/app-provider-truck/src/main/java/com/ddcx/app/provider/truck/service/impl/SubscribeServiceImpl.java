package com.ddcx.app.provider.truck.service.impl;


import com.ddcx.app.provider.api.truck.model.vo.SubscribeParam;
import com.ddcx.app.provider.api.truck.model.vo.SubscribeVo;
import com.ddcx.app.provider.truck.mapper.SubscribeConfigMapper;
import com.ddcx.app.provider.truck.mapper.SubscribeMapper;
import com.ddcx.app.provider.truck.service.SubscribeConfigService;
import com.ddcx.app.provider.truck.service.SubscribeService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.OverallSubscribeDto;
import com.ddcx.model.truck.Subscribe;
import com.ddcx.model.truck.SubscribeConfig;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/11.
 */
@Service
@Transactional
public class SubscribeServiceImpl  extends BaseService<Subscribe> implements SubscribeService {
    @Resource
    private SubscribeMapper subscribeMapper;
    @Resource
    private SubscribeConfigMapper  subscribeConfigMapper;
    @Resource
    private SubscribeConfigService configService;
    @Resource
    private RedisUtil redisUtil;

    @Override
    public synchronized Wrapper subscribe(SubscribeParam param, LoginAuthDto dto) {
        OverallSubscribeDto config=configService.getByYearAndMonth(param.getYear(),param.getMonth(),dto.getMotorcadeId());
        if(config==null){
            return WrapMapper.error("无检查站信息，预约失败");
        }
        if(config.getDays().get(param.getDay()-1)<=0){
            return WrapMapper.error("已无名额，预约失败");
        }
        Subscribe subscribe=new Subscribe();
        subscribe.setDate(LocalDate.of(param.getYear(),param.getMonth(),param.getDay()).toEpochDay()*24*3600);
        subscribe.setDriverId(dto.getUserId());
        int count=subscribeMapper.selectCount(subscribe);
        if(count>0){
            return WrapMapper.error("当天已经预约无法重复预约");
        }
        subscribe.setSubscribeId(config.getConfigId());
        subscribe.setDriverName(dto.getUserName());
        subscribe.setMotorcadeId(dto.getMotorcadeId());
        subscribe.setMotorcadeName(dto.getMotorcadeName());
        subscribe.setDriverPhone(dto.getPhone());
        subscribe.setIsFinish((byte) 0);
        subscribe.setId(generateId());
        subscribeMapper.insert(subscribe);
        return WrapMapper.ok();
    }

    @Override
    public Wrapper getMySubscribes(Integer page, Integer size, LoginAuthDto dto) {
        PageHelper.startPage(page,size);
        PageHelper.orderBy("date desc");
        Subscribe param=new Subscribe();
        param.setDriverId(dto.getUserId());
        List<Subscribe> list=subscribeMapper.select(param);
        List<SubscribeVo> vos=new ArrayList<>(list.size());
        SubscribeVo vo;
        SubscribeConfig config;
        for (Subscribe subscribe : list) {
            vo=new SubscribeVo();
            config=subscribeConfigMapper.selectByPrimaryKey(subscribe.getSubscribeId());
            BeanUtils.copyProperties(subscribe,vo);
            vo.setCheckpointAddress(config.getAddress());
            vo.setCheckpointName(config.getCheckpointName());
            vo.setLat(Double.valueOf(config.getLat()));
            vo.setLng(Double.valueOf(config.getLng()));
            vos.add(vo);
        }
        return WrapMapper.ok(new PageInfo(vos));
    }

    @Override
    public Wrapper cancelSubscribe(Long id, LoginAuthDto dto) {
        Subscribe subscribe=subscribeMapper.selectByPrimaryKey(id);
        if(subscribe==null||!subscribe.getDriverId().equals(dto.getUserId())){
            return WrapMapper.error("取消失败");
        }
        if(subscribe.getIsFinish().intValue()!=0){
            return WrapMapper.error("非法状态，取消失败");
        }
        subscribeMapper.deleteByPrimaryKey(id);
        return WrapMapper.ok();
    }
}
