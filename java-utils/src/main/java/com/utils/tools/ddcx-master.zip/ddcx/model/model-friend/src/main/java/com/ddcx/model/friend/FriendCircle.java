package com.ddcx.model.friend;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

@Table(name = "friend_circle")
@ApiModel("卡友圈")
public class FriendCircle {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 标题
     */
//    @NotBlank(message = "标题不能为空")
    @ApiModelProperty("标题<暂时废弃>")
    private String title;

    /**
     * 文字内容
     */
    @NotBlank(message = "文字内容不能为空")
    @ApiModelProperty("文字内容")
    @Column(name = "text_content")
    private String textContent;

    /**
     * 图片内容
     */
    @NotBlank(message = "图片内容不能为空")
    @ApiModelProperty("图片内容")
    @Column(name = "img_content")
    private String imgContent;

    /**
     * 创建者id
     */
    @Column(name = "user_id")
    private Long userId;

    /**
     * 创建者昵称
     */
    @ApiModelProperty("创建者昵称")
    @Column(name = "nick_name")
    private String nickName;

    /**
     * 创建者头像
     */
    @ApiModelProperty("创建者定位")
    @Column(name = "head_img")
    private String headImg;

    /**
     * 创建者定位
     */
    @ApiModelProperty("创建者定位")
    @Column(name = "user_location")
    private String userLocation;

    @ApiModelProperty("创建者纬度")
    @Column(name = "lat")
    private String lat;

    @ApiModelProperty("创建者经度")
    @Column(name = "lng")
    private String lng;

    @ApiModelProperty("几分钟前，几小时前，几天前....")
    @Transient
    private String dateStr;

    public String getDateStr() {
        return dateStr;
    }

    public void setDateStr(String dateStr) {
        this.dateStr = dateStr;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    @Column(name = "create_time")
    private Long createTime;

    /**
     * 点赞数
     */
    @ApiModelProperty("点赞数")
    @Column(name = "like_count")
    private Integer likeCount;

    /**
     * 回复数
     */
    @ApiModelProperty("回复数")
    @Column(name = "reply_count")
    private Integer replyCount;

    @ApiModelProperty("是否是自己的 true 是 false 否")
    @Transient
    private Boolean isOwn;

    @ApiModelProperty("是否已经点赞 大于0 已经点赞 0 否")
    @Transient
    private Byte isLike;

    public Byte getIsLike() {
        return isLike;
    }

    public void setIsLike(Byte isLike) {
        this.isLike = isLike;
    }

    public Boolean getOwn() {
        return isOwn;
    }

    public void setOwn(Boolean own) {
        isOwn = own;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取标题
     *
     * @return title - 标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置标题
     *
     * @param title 标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取文字内容
     *
     * @return text_content - 文字内容
     */
    public String getTextContent() {
        return textContent;
    }

    /**
     * 设置文字内容
     *
     * @param textContent 文字内容
     */
    public void setTextContent(String textContent) {
        this.textContent = textContent;
    }

    /**
     * 获取图片内容
     *
     * @return img_content - 图片内容
     */
    public String getImgContent() {
        return imgContent;
    }

    /**
     * 设置图片内容
     *
     * @param imgContent 图片内容
     */
    public void setImgContent(String imgContent) {
        this.imgContent = imgContent;
    }

    /**
     * 获取创建者id
     *
     * @return user_id - 创建者id
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置创建者id
     *
     * @param userId 创建者id
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 获取创建者昵称
     *
     * @return nick_name - 创建者昵称
     */
    public String getNickName() {
        return nickName;
    }

    /**
     * 设置创建者昵称
     *
     * @param nickName 创建者昵称
     */
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    /**
     * 获取创建者头像
     *
     * @return head_img - 创建者头像
     */
    public String getHeadImg() {
        return headImg;
    }

    /**
     * 设置创建者头像
     *
     * @param headImg 创建者头像
     */
    public void setHeadImg(String headImg) {
        this.headImg = headImg;
    }

    /**
     * 获取创建者定位
     *
     * @return user_location - 创建者定位
     */
    public String getUserLocation() {
        return userLocation;
    }

    /**
     * 设置创建者定位
     *
     * @param userLocation 创建者定位
     */
    public void setUserLocation(String userLocation) {
        this.userLocation = userLocation;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
        if(createTime!=null){
            long curr=System.currentTimeMillis()/1000;
            long tag=curr-createTime;
            if(tag/(60*60*24*365)>0){
                dateStr=tag/(60*60*24*365)+"年前";
            }else if(tag/(60*60*24*30)>0){
                dateStr=tag/(60*60*24*30)+"月前";
            }else if(tag/(60*60*24*7)>0){
                dateStr=tag/(60*60*24*7)+"周前";
            }else if(tag/(60*60*24)>0){
                dateStr=tag/(60*60*24)+"天前";
            }else if(tag/(60*60)>0){
                dateStr=tag/(60*60)+"小时前";
            }else if(tag/(60)>0){
                dateStr=tag/(60)+"分钟前";
            }else {
                dateStr=tag+"秒前";
            }
        }
    }

    /**
     * 获取点赞数
     *
     * @return like_count - 点赞数
     */
    public Integer getLikeCount() {
        return likeCount;
    }

    /**
     * 设置点赞数
     *
     * @param likeCount 点赞数
     */
    public void setLikeCount(Integer likeCount) {
        this.likeCount = likeCount;
    }

    /**
     * 获取回复数
     *
     * @return reply_count - 回复数
     */
    public Integer getReplyCount() {
        return replyCount;
    }

    /**
     * 设置回复数
     *
     * @param replyCount 回复数
     */
    public void setReplyCount(Integer replyCount) {
        this.replyCount = replyCount;
    }
}