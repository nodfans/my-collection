package com.ddcx.app.provider.uac.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.uac.UserBacklog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface UserBacklogMapper extends MyMapper<UserBacklog> {


    @Select("select * from user_backlog where driver_id=#{userId} and state=0 and overdue_state=#{type}")
    List<UserBacklog> getUserBackLog(@Param("userId") Long userId,@Param("type") Integer type);

}