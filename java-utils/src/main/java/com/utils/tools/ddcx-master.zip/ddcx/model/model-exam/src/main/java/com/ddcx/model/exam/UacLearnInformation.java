package com.ddcx.model.exam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Table(name = "uac_learn_information")
@ApiModel("学习资料")
public class UacLearnInformation {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    /**
     * 类型 1：文字，2：视频
     */
    @ApiModelProperty("类型 1：文字，2：视频")
    private Byte type;

    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    @Column(name = "create_time")
    private Long createTime;

    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    @Column(name = "title")
    private String title;

    /**
     * 内容
     */
    @ApiModelProperty("内容")
    private String content;

    /**
     * 排序
     */
    @ApiModelProperty("排序")
    private Integer sort;
    /**
     * 封面
     */
    @ApiModelProperty("封面")
    private String cover;

    /**
     * 0、禁用 1、启用
     */
    @ApiModelProperty("0、禁用 1、启用")
    private Byte state;

    /**
     * 发布人
     */
    @ApiModelProperty("发布人")
    private Long createBy;


    /**
     * 数据来源 1.平台
     */
    @ApiModelProperty("数据来源 1.平台")
    private Byte source;

    @ApiModelProperty("学习时长（秒）<如果为null则未学习，否则已学习>")
    @Transient
    private Long duration;

    @ApiModelProperty("H5链接")
    @Transient
    private String h5;

    @ApiModelProperty("视频观看时长")
    @Transient
    private Long viewDuration;

    @ApiModelProperty("是否完成: 0.未完成 1.已完成")
    @Transient
    private Byte finish;


    public Long getViewDuration() {
        return viewDuration;
    }

    public void setViewDuration(Long viewDuration) {
        this.viewDuration = viewDuration;
    }

    public Byte getFinish() {
        return finish;
    }

    public void setFinish(Byte finish) {
        this.finish = finish;
    }

    public String getH5() {
        return h5;
    }

    public void setH5(String h5) {
        this.h5 = h5;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取类型 1：文字，2：视频
     *
     * @return type - 类型 1：文字，2：视频
     */
    public Byte getType() {
        return type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 设置类型 1：文字，2：视频
     *
     * @param type 类型 1：文字，2：视频
     */
    public void setType(Byte type) {
        this.type = type;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取内容
     *
     * @return content - 内容
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置内容
     *
     * @param content 内容
     */
    public void setContent(String content) {
        this.content = content;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public Byte getState() {
        return state;
    }

    public void setState(Byte state) {
        this.state = state;
    }

    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    public Byte getSource() {
        return source;
    }

    public void setSource(Byte source) {
        this.source = source;
    }
}