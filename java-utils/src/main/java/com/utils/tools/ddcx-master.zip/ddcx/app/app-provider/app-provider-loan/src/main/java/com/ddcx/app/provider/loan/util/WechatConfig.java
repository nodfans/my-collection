package com.ddcx.app.provider.loan.util;

public class WechatConfig {

    public final static String APPID = "wx8df2b3f5678d825f";
    public final static String APPSECRET = "7272178fc835fd769f2e2fa135480d36";
    public final static String ACCESSTOKENURL = "https://api.weixin.qq.com/sns/jscode2session";
    public final static String WXINFOURL = "https://api.weixin.qq.com/sns/userinfo";
}
