package com.ddcx.common.provider.service.impl;


import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.common.provider.mapper.*;
import com.ddcx.common.provider.service.CnRegionInfoService;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.common.BsCity;
import com.ddcx.model.common.BsProvince;
import com.ddcx.model.common.CnRegionInfo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/23.
 */
@Service
@Transactional
public class CnRegionInfoServiceImpl extends BaseService<CnRegionInfo> implements CnRegionInfoService {
    @Resource
    private CnRegionInfoMapper cnRegionInfoMapper;

    @Resource
    private BsProvinceMapper bsProvinceMapper;

    @Resource
    private BsCityMapper bsCityMapper;

    @Resource
    private BsAreaMapper bsAreaMapper;

    @Resource
    private BsStreetMapper bsStreetMapper;

    @Resource
    private RedisUtil redisUtil;


    @Override
    public Wrapper getProvinceInfo() {
        Wrapper ok = WrapMapper.ok(bsProvinceMapper.selectAll());
        return ok;
    }

    @Override
    public Wrapper getCityInfo() {
        Wrapper ok = WrapMapper.ok(bsCityMapper.selectAll());
        return ok;
    }

    @Override
    public Wrapper getAreaInfo() {
        Wrapper ok = WrapMapper.ok(bsAreaMapper.selectAll());
        return ok;
    }

    @Override
    public Wrapper getStreetInfo() {
        Wrapper ok = WrapMapper.ok(bsStreetMapper.selectAllOfFewColumn());
        return ok;
    }

    @Override
    public Wrapper getBcRegionInfo() {
        List<Object> provincs=redisUtil.lGet(RedisKey.CN_REGION_INFO,0,34);
        return WrapMapper.ok(provincs);
    }

    @PostConstruct
    public void initChRegionInfo(){
        List<BsProvince> provincs=bsProvinceMapper.selectAll();
        for (BsProvince province : provincs) {
            province.setCities(bsCityMapper.selectByProviceCode(province.getProvinceCode()));
            for (BsCity city : province.getCities()) {
                city.setList(bsAreaMapper.selectByCityCode(city.getCityCode()));
            }
        }
        redisUtil.del(RedisKey.CN_REGION_INFO);
        redisUtil.lSet(RedisKey.CN_REGION_INFO, provincs);
    }
}
