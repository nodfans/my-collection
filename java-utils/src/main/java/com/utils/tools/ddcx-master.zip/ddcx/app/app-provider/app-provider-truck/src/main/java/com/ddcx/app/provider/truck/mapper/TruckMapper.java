package com.ddcx.app.provider.truck.mapper;


import com.ddcx.app.provider.api.truck.model.param.ARUParam;
import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.truck.Truck;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface TruckMapper extends MyMapper<Truck> {


    @Select("select * from truck where  truck_owner_id=#{userId} order by create_time asc")
    List<Truck> getOwnTrucksOfOwner(@Param("userId") Long userId);

    @Select("select * from truck where driver_id=#{userId}  order by create_time asc")
    List<Truck> getOwnTrucksOfDriver(@Param("userId") Long userId);

    @Update("update truck set driver_id=#{newDriverId},driver_name=#{newDriverName} where id=#{truckId} and truck_owner_id=#{userId}")
    int updateTruckDriver(@Param("truckId") Long truckId, @Param("newDriverId") Long newDriverId, @Param("userId") Long userId,@Param("newDriverName")String newDriverName);

    @Update("update truck set driver_id=truck_owner_id,driver_name=owner_name where id=#{truckId} and (truck_owner_id=#{userId} or driver_id=#{userId})")
    int clearTruckBinding(@Param("truckId") Long truckId, @Param("userId") Long userId);

    int updateTruckARU(ARUParam param);

    @Select("select id , truck_num from truck where driver_id=#{userId} or truck_owner_id=#{userId}")
    List<Truck> getTruckSelects(@Param("userId") Long userId);

    @Select("select truck_num,lng,lat,driver_id,truck_owner_id from truck where truck_num is not null and lng is not null and lat is not null")
    List<Truck> selectAllLocation();
    @Select("select driver_id  from truck where annual_inspection_limit_time=#{limitDate}")
    List<Long> listByAnLimitDate(@Param("limitDate") Long limitDate);
    @Select("select driver_id  from truck where renewal_insurance_limit_time=#{limitDate}")
    List<Long> listByReLimitDate(@Param("limitDate") Long limitDate);
    @Select("select driver_id  from truck where upkeep_limit_time=#{limitDate}")
    List<Long> listByUpLimitDate(@Param("limitDate") Long limitDate);
    @Select("select truck_num,insurance_company,insurance_type,renewal_insurance_time,renewal_insurance_limit_time from truck where (driver_id=#{userId} or truck_owner_id=#{userId}) and insurance_company is not null")
    List<Truck> getOwnTruckInsurances(@Param("userId") Long userId);
}