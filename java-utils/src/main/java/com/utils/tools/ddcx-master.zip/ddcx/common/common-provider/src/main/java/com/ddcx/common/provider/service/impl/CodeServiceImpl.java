package com.ddcx.common.provider.service.impl;

import com.ddcx.app.provider.api.uac.enums.UacErrorCodeEnum;
import com.ddcx.app.provider.api.uac.exception.UacBizException;
import com.ddcx.app.provider.api.uac.model.dto.UacCheckAccountDto;
import com.ddcx.app.provider.api.uac.model.vo.UacUserVo;
import com.ddcx.app.provider.api.uac.service.UacUserServiceFeignApi;
import com.ddcx.common.provider.api.enums.CommonErrorCodeEnum;
import com.ddcx.common.provider.api.exception.CommonBizException;
import com.ddcx.common.provider.api.model.dto.SendCodeDto;
import com.ddcx.common.provider.api.model.dto.VerifyCodeDto;
import com.ddcx.common.provider.api.model.vo.VerifyCodeResultVo;
import com.ddcx.common.provider.service.CodeService;
import com.ddcx.framework.base.constant.GlobalConstant;
import com.ddcx.framework.base.dto.ActionTokenDto;
import com.ddcx.framework.base.dto.VerifyCode;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.framework.util.StringUtils;
import com.ddcx.framework.util.date.DateUtil;
import com.ddcx.web.provider.api.uac.model.service.AdminUserServiceFeignApi;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class CodeServiceImpl implements CodeService {

    private static final Logger log = LoggerFactory.getLogger(CodeServiceImpl.class);

    @Value(value = "${verifyCode.smsTtl}")
    private Integer verifyCode_smsTtl;

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private UacUserServiceFeignApi uacUserServiceFeignApi;

    @Autowired
    private AdminUserServiceFeignApi adminUserServiceFeignApi;

    @Override
    public Boolean send(SendCodeDto sendCodeDto) {
        //如果是1,2 则账号不存在,不处理
        //如果是3,4 则账号存在,不处理
        //如果是5 恒处理
        if(sendCodeDto.getBizType().intValue()<3){
            checkPhone(sendCodeDto.getAccount());
        }else if(sendCodeDto.getBizType().intValue()<5){
            if(sendCodeDto.getPlatform().intValue()==1){
                UacUserVo uacUserVo = uacUserServiceFeignApi.getUserByPhone(new UacCheckAccountDto(sendCodeDto.getAccount()));
                if(uacUserVo!=null){
                    throw new UacBizException(UacErrorCodeEnum.UAC20000004);
                }
            }else {
                Integer i=adminUserServiceFeignApi.getByPhone(sendCodeDto.getAccount());
                if(i==null||i.intValue()>0){
                    throw new UacBizException(UacErrorCodeEnum.UAC20000004);
                }
            }

        }
//        String code = NumberUtils.getRandomNumber(6);
        String code = "123456";
        Integer ttl = verifyCode_smsTtl;
        log.info("code--->>> " + code);
        VerifyCode verifyCode = new VerifyCode();
        verifyCode.setAccount(sendCodeDto.getAccount());
        verifyCode.setCode(code);
        verifyCode.setExpireTime(DateUtil.addMinute(new Date(), ttl).getTime() / 1000L);
        redisUtil.set(VERIFY_CODE + ":" + verifyCode.getAccount(), verifyCode, ttl * 60);
//        SmsUtil.send(sendCodeDto.getAccount(),code);
        return true;
    }

    @Override
    public VerifyCodeResultVo verify(VerifyCodeDto verifyCodeDto) {
        VerifyCode verifyCode = (VerifyCode) redisUtil.get(VERIFY_CODE + ":" + verifyCodeDto.getAccount());
        if (PublicUtil.isEmpty(verifyCode)) {
            throw new CommonBizException(CommonErrorCodeEnum.COMMON10000004);
        }
        if (!verifyCodeDto.getCode().toLowerCase().equals(verifyCode.getCode())) {
            throw new CommonBizException(CommonErrorCodeEnum.COMMON10000004);
        }
        redisUtil.del(VERIFY_CODE + ":" + verifyCode.getAccount());
        VerifyCodeResultVo verifyCodeResultVo = new VerifyCodeResultVo();
        verifyCodeResultVo.setAccount(verifyCode.getAccount());
        verifyCodeResultVo.setActionToken(Base64.encodeBase64URLSafeString((StringUtils.getRandomString(50) + ":" + System.currentTimeMillis() + ":" + verifyCode.getAccount()).getBytes()));

        ActionTokenDto actionTokenDto = new ActionTokenDto();
        actionTokenDto.setAccount(verifyCodeResultVo.getAccount());
        actionTokenDto.setToken(verifyCodeResultVo.getActionToken());
        actionTokenDto.setExpireTime(DateUtil.addMinute(new Date(), 10).getTime() / 1000L);
        redisUtil.set(GlobalConstant.Sys.ACTION_TOKEN + ":" + verifyCodeResultVo.getAccount(), actionTokenDto, 10 * 60);
        return verifyCodeResultVo;
    }


    private void checkPhone(String phone) {
        UacUserVo uacUserVo = uacUserServiceFeignApi.getUserByPhone(new UacCheckAccountDto(phone));
        if (PublicUtil.isEmpty(uacUserVo)) {
            throw new UacBizException(UacErrorCodeEnum.UAC20000005);
        }
    }
}
