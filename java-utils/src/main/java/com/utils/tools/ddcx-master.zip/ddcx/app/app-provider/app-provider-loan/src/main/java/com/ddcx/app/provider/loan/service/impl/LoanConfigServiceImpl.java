package com.ddcx.app.provider.loan.service.impl;


import com.ddcx.app.provider.loan.mapper.LoanConfigMapper;
import com.ddcx.app.provider.loan.service.LoanConfigService;
import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.base.enums.ErrorCodeEnum;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.loan.LoanConfig;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/03/23.
 */
@Service
@Transactional
public class LoanConfigServiceImpl implements LoanConfigService {
    @Resource
    private LoanConfigMapper loanConfigMapper;
    @Resource
    private RedisUtil redisUtil;

    @Override
    public Wrapper getLoanConfigByMotorcadeId(LoginAuthDto dto) {
        Long motorcadeId = dto.getMotorcadeId();
        if(motorcadeId==null||!motorcadeId.equals(dto.getMotorcadeId())){
            return WrapMapper.error(ErrorCodeEnum.GL99990105.msg());
        }
        LoanConfig config=getByMotorcadeId(motorcadeId);
        if(config==null){
            return WrapMapper.error("该车队暂无配置");
        }
        return WrapMapper.ok(config);
    }




    //根据车队id初始化单个redis缓存
    private LoanConfig getByMotorcadeId(Long motorcadeId){
        LoanConfig config= (LoanConfig) redisUtil.hget(RedisKey.LOAN_CONFIG,motorcadeId+"");
        return config;
    }


}
