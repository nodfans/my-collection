package com.ddcx.model.truck;

import com.ddcx.framework.util.StringUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.util.Arrays;
import java.util.List;

@Table(name = "veh_accident_rep")
@ApiModel("事故信息")
public class VehAccidentRep {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long id;

    /**
     * 用户
     */
    @Column(name = "u_id")
    @ApiModelProperty(value = "用户主键")
    private Long uId;

    /**
     * 上报类型
     */
    @Column(name = "rep_type")
    @ApiModelProperty(value = "上报类型")
    @NotBlank
    private String repType;

    /**
     * 车头
     */
    @ApiModelProperty(value = "车头")
//    @NotBlank
    private String head;

    /**
     * 车身
     */
    @ApiModelProperty(value = "车身")
//    @NotBlank
    private String body;

    /**
     * 整车
     */
    @ApiModelProperty(value = "整车")
//    @NotBlank
    private String whole;

    /**
     * 事故原因及车辆损害情况
     */
    @ApiModelProperty(value = "事故原因及车辆损害情况")
    private String info;

    /**
     * 直接经济损失
     */
    @ApiModelProperty(value = "直接经济损失")
    @Column(name = "direct_economic_loss")
    private String directEconomicLoss;

    /**
     * 事发地点
     */
    @ApiModelProperty(value = "事发地点")
    private String address;

    /**
     * 事故性质
     */
    @ApiModelProperty(value = "事故性质<暂不填写>")
    private String nature;

    /**
     * 事故性质
     */
    @ApiModelProperty(value = "事故描述")
    private String description;

    /**
     * 事故责任
     */
    @ApiModelProperty(value = "事故责任")
    private String responsibility;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    @Column(name = "create_time")
    private Long createTime;

    /**
     * 图片
     */
    @ApiModelProperty(value = "图片")
    private String img;

    @Transient
    @ApiModelProperty(value = "图片列表")
    private List<String> imgList;

    @ApiModelProperty(value = "发布人姓名")
    private String uName;

    @ApiModelProperty("车队主键")
    private Long motorcadeId;
    @ApiModelProperty("公司主键")
    private Long comId;

    public Long getMotorcadeId() {
        return motorcadeId;
    }

    public void setMotorcadeId(Long motorcadeId) {
        this.motorcadeId = motorcadeId;
    }

    public Long getComId() {
        return comId;
    }

    public void setComId(Long comId) {
        this.comId = comId;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    public List<String> getImgList() {
        return imgList;
    }

    public void setImgList(List<String> imgList) {
        this.imgList = imgList;
        if(imgList!=null&&imgList.size()>0){
            img="";
            for (String s : imgList) {
                img+=s+";";
            }
            img=img.substring(0,img.length()-1);
        }
    }

    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取用户
     *
     * @return u_id - 用户
     */
    public Long getuId() {
        return uId;
    }

    /**
     * 设置用户
     *
     * @param uId 用户
     */
    public void setuId(Long uId) {
        this.uId = uId;
    }

    /**
     * 获取上报类型
     *
     * @return rep_type - 上报类型
     */
    public String getRepType() {
        return repType;
    }

    /**
     * 设置上报类型
     *
     * @param repType 上报类型
     */
    public void setRepType(String repType) {
        this.repType = repType;
    }

    /**
     * 获取车头
     *
     * @return head - 车头
     */
    public String getHead() {
        return head;
    }

    /**
     * 设置车头
     *
     * @param head 车头
     */
    public void setHead(String head) {
        this.head = head;
    }

    /**
     * 获取车身
     *
     * @return body - 车身
     */
    public String getBody() {
        return body;
    }

    /**
     * 设置车身
     *
     * @param body 车身
     */
    public void setBody(String body) {
        this.body = body;
    }

    /**
     * 获取整车
     *
     * @return whole - 整车
     */
    public String getWhole() {
        return whole;
    }

    /**
     * 设置整车
     *
     * @param whole 整车
     */
    public void setWhole(String whole) {
        this.whole = whole;
    }

    /**
     * 获取事故原因及车辆损害情况
     *
     * @return info - 事故原因及车辆损害情况
     */
    public String getInfo() {
        return info;
    }

    /**
     * 设置事故原因及车辆损害情况
     *
     * @param info 事故原因及车辆损害情况
     */
    public void setInfo(String info) {
        this.info = info;
    }

    /**
     * 获取直接经济损失
     *
     * @return direct_economic_loss - 直接经济损失
     */
    public String getDirectEconomicLoss() {
        return directEconomicLoss;
    }

    /**
     * 设置直接经济损失
     *
     * @param directEconomicLoss 直接经济损失
     */
    public void setDirectEconomicLoss(String directEconomicLoss) {
        this.directEconomicLoss = directEconomicLoss;
    }

    /**
     * 获取事发地点
     *
     * @return address - 事发地点
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置事发地点
     *
     * @param address 事发地点
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * 获取事故性质
     *
     * @return nature - 事故性质
     */
    public String getNature() {
        return nature;
    }

    /**
     * 设置事故性质
     *
     * @param nature 事故性质
     */
    public void setNature(String nature) {
        this.nature = nature;
    }

    /**
     * 获取事故责任
     *
     * @return responsibility - 事故责任
     */
    public String getResponsibility() {
        return responsibility;
    }

    /**
     * 设置事故责任
     *
     * @param responsibility 事故责任
     */
    public void setResponsibility(String responsibility) {
        this.responsibility = responsibility;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取图片
     *
     * @return img - 图片
     */
    public String getImg() {
        return img;
    }

    /**
     * 设置图片
     *
     * @param img 图片
     */
    public void setImg(String img) {
        this.img = img;
        if(StringUtils.isNotBlank(img)){
            imgList= Arrays.asList(img.split(";"));
        }
    }
}