package com.ddcx.model.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Table(name = "common_bank_bin")
@ApiModel("银行卡bin")
public class CommonBankBin implements java.io.Serializable {
    private static final long serialVersionUID = -1691056268198438205L;

    @Id
    @ApiModelProperty("主键")
    private Long id;
    /**
     * 银行名称
     */
    @ApiModelProperty("银行名称")
    private String bankName;
    /**
     * 机构代码
     */
    @ApiModelProperty("机构代码")
    private String bankCode;
    /**
     * 卡名称
     */
    @ApiModelProperty("卡名称")
    private String cardName;
    /**
     * 卡号长度
     */
    @ApiModelProperty("卡号长度")
    private Integer cardSize;
    /**
     * 主账号
     */
    @ApiModelProperty("主账号")
    private String cardNo;
    /**
     * 卡bin
     */
    @ApiModelProperty("卡bin")
    private String cardBin;
    /**
     * 卡类型 DC：储蓄卡，CC：信用卡(贷记卡)，SCC：准贷记卡，PC：预付费卡
     */
    @ApiModelProperty("卡类型 DC：储蓄卡，CC：信用卡(贷记卡)，SCC：准贷记卡，PC：预付费卡")
    private String cardType;
}
