package com.ddcx.app.provider.truck.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.truck.SubscribeConfig;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;


@Mapper
@Component
public interface SubscribeConfigMapper extends MyMapper<SubscribeConfig> {

    @Select("select * from subscribe_config where year=#{year} and month=#{month} and motorcade_id=#{motorcadeId} order by id desc limit 1")
    SubscribeConfig selectByDate(@Param("motorcadeId") Long motorcadeId,@Param("year") String year,@Param("month") String month);
}