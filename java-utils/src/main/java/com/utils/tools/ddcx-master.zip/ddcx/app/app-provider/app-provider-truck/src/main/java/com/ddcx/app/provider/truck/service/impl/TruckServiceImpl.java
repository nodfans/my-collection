package com.ddcx.app.provider.truck.service.impl;


import com.ddcx.app.provider.api.truck.model.enums.TruckUserLevel;
import com.ddcx.app.provider.api.truck.model.param.ARUParam;
import com.ddcx.app.provider.api.truck.model.vo.TruckInsurance;
import com.ddcx.app.provider.api.uac.model.vo.UacUserVo;
import com.ddcx.app.provider.api.uac.service.UacUserServiceFeignApi;
import com.ddcx.app.provider.truck.mapper.TruckMapper;
import com.ddcx.app.provider.truck.mapper.TruckTransactionMapper;
import com.ddcx.app.provider.truck.service.TruckService;
import com.ddcx.common.provider.api.model.dto.MessageDto;
import com.ddcx.common.provider.api.service.CommonServiceFeignApi;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.common.Message;
import com.ddcx.model.common.MessageConfig;
import com.ddcx.model.truck.Truck;
import com.ddcx.model.truck.TruckTransaction;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/02/28.
 */
@Service
@Transactional
public class TruckServiceImpl implements TruckService {
    @Resource
    private TruckMapper truckMapper;

    @Resource
    private UacUserServiceFeignApi uacUserServiceFeignApi;

    @Resource
    private TruckTransactionMapper transactionMapper;

    @Resource
    private CommonServiceFeignApi commonServiceFeignApi;

    @Override
    public Wrapper<List<Truck>> getOwnTrucks(Long userId) {
        List<Truck> list1 = truckMapper.getOwnTrucksOfOwner(userId);
        List<Truck> list2 = truckMapper.getOwnTrucksOfDriver(userId);
        list1.addAll(list2);
        for (Truck truck : list1) {
            if (userId.equals(truck.getDriverId())) {
                truck.setTruckUserLevel(TruckUserLevel.driver.getCode());
            }
            if (userId.equals(truck.getTruckOwnerId())) {
                truck.setTruckUserLevel(TruckUserLevel.owner.getCode());
            }
            if(truck.getSaleState().intValue()==1){
                truck.setSalePrice(transactionMapper.selectSalePriceByTruckId(truck.getId()));
            }
        }
        return WrapMapper.ok(list1);
    }

    @Override
    public Wrapper<Truck> getTruckDetail(Long id, Long userId) {
        Truck truck = truckMapper.selectByPrimaryKey(id);
        if (truck == null) {
            return WrapMapper.error("信息获取失败");
        }
        if (userId != null && userId.equals(truck.getDriverId())) {
            truck.setTruckUserLevel(TruckUserLevel.driver.getCode());
        }
        if (userId != null && userId.equals(truck.getTruckOwnerId())) {
            truck.setTruckUserLevel(TruckUserLevel.owner.getCode());
        }
        return WrapMapper.ok(truck);
    }

    @Override
    public Wrapper updateTruckDriver(Long truckId, Long newDriverId, Long oldDriverId, Long userId) {
        Truck truck=truckMapper.selectByPrimaryKey(truckId);
        UacUserVo uacUser=uacUserServiceFeignApi.getUserById(newDriverId);
        if(uacUser==null){
            return WrapMapper.error("司机不存在");
        }
        int i = truckMapper.updateTruckDriver(truckId, newDriverId, userId,uacUser.getRealName());
        if (i > 0) {
                MessageDto dto=new MessageDto();
                Message message=new Message();
                message.setDeleteTag((byte) 0);
                message.setState((byte) 0);
                message.setUserId(newDriverId);
                MessageConfig messageConfig=new MessageConfig();
                messageConfig.setContent("尊敬的"+uacUser.getRealName()+",车辆（"+truck.getTruckNum()+"）已和您绑定");
                messageConfig.setIsDelete(0);
                messageConfig.setCreateTime(System.currentTimeMillis()/1000);
                messageConfig.setTopic("车辆司机绑定");
                messageConfig.setCreateUser(userId);
                messageConfig.setType(1);
                dto.setMessage(message);
                dto.setMessageConfig(messageConfig);
                commonServiceFeignApi.addMessage(dto);
            if(truck.getDriverId()!=null) {
                MessageDto dto1 = new MessageDto();
                Message message1 = new Message();
                message1.setDeleteTag((byte) 0);
                message1.setState((byte) 0);
                message1.setUserId(newDriverId);
                MessageConfig messageConfig1 = new MessageConfig();
                messageConfig1.setContent("尊敬的" + truck.getDriverName() + ",车辆（" + truck.getTruckNum() + "）已和您解除绑定");
                messageConfig1.setIsDelete(0);
                messageConfig1.setCreateTime(System.currentTimeMillis() / 1000);
                messageConfig1.setTopic("车辆司机解除绑定");
                messageConfig1.setCreateUser(userId);
                messageConfig1.setType(1);
                dto1.setMessage(message);
                dto1.setMessageConfig(messageConfig);
                commonServiceFeignApi.addMessage(dto1);
            }
                return WrapMapper.ok("司机更换成功");
        }
        return WrapMapper.error("司机更换失败");
    }

    @Override
    public Wrapper clearTruckBinding(Long truckId, Long oldDriverId, Long userId) {
        Truck truck=truckMapper.selectByPrimaryKey(truckId);
        if(truck==null){
            return WrapMapper.error("车辆不存在");
        }
        if(truck.getTruckOwnerId().equals(truck.getDriverId())){
            return WrapMapper.error("暂无绑定司机");
        }
        int i = truckMapper.clearTruckBinding(truckId, userId);
        if (i > 0) {
            MessageDto dto=new MessageDto();
            Message message=new Message();
            message.setDeleteTag((byte) 0);
            message.setState((byte) 0);
            message.setUserId(truck.getDriverId());
            MessageConfig messageConfig=new MessageConfig();
            messageConfig.setContent("尊敬的"+truck.getDriverName()+",车辆（"+truck.getTruckNum()+"）已和您解除绑定");
            messageConfig.setIsDelete(0);
            messageConfig.setCreateTime(System.currentTimeMillis()/1000);
            messageConfig.setTopic("车辆解除绑定");
            messageConfig.setCreateUser(userId);
            messageConfig.setType(1);
            dto.setMessage(message);
            dto.setMessageConfig(messageConfig);
            commonServiceFeignApi.addMessage(dto);
            return WrapMapper.ok("司机绑定关系已经解除");
        }
        return WrapMapper.error("司机绑定关系解除失败");
    }

    @Override
    public Wrapper updateTruckARU(ARUParam param, Long userId) {
        Long truckId=param.getTruckId();
        Truck truck=truckMapper.selectByPrimaryKey(truckId);
        if(truck==null){
            WrapMapper.error("车辆不存在");
        }
        Long annualInspectionTime=param.getAnnualInspectionTime();
        Integer months1=param.getAnnualInspectionValid();
        Long renewalInsuranceTime=param.getRenewalInsuranceTime();
        Integer months2=param.getRenewalInsuranceValid();
        Long upkeepTime=param.getUpkeepTime();
        Integer months3=param.getUpkeepValid();
        Long annualInspectionLimitTime; //  年检到期时间
        Long renewalInsuranceLimitTime; //  续保到期时间
        Long upkeepLimitTime;           //  保养到期时间
        //命名受不鸟了太长了还记不住。。。
        if(annualInspectionTime!=null||months1!=null){
            if(annualInspectionTime==null){
                annualInspectionTime=truck.getAnnualInspectionTime();
                param.setAnnualInspectionTime(annualInspectionTime);
            }
            if(months1==null){
                months1=truck.getAnnualInspectionValid();
                param.setAnnualInspectionValid(months1);
            }
            LocalDate localDate1 = LocalDate.ofEpochDay(annualInspectionTime  / 24 / 3600);
            annualInspectionLimitTime = localDate1.plusMonths(months1).toEpochDay() * 3600 * 24;
            param.setAnnualInspectionLimitTime(annualInspectionLimitTime);
        }
        if(renewalInsuranceTime!=null||months2!=null){
            if(renewalInsuranceTime==null){
                renewalInsuranceTime=truck.getRenewalInsuranceTime();
                param.setRenewalInsuranceTime(renewalInsuranceTime);
            }
            if(months2==null){
                months2=truck.getRenewalInsuranceValid();
                param.setRenewalInsuranceValid(months2);
            }
            LocalDate localDate2 = LocalDate.ofEpochDay(renewalInsuranceTime / 24 / 3600);
            renewalInsuranceLimitTime = localDate2.plusMonths(months2).toEpochDay() * 3600 * 24;
            param.setRenewalInsuranceLimitTime(renewalInsuranceLimitTime);
        }
        if(upkeepTime!=null||months3!=null){
            if(upkeepTime==null){
                upkeepTime=truck.getUpkeepTime();
                param.setUpkeepTime(upkeepTime);
            }
            if(months3==null){
                months3=truck.getUpkeepValid();
                param.setUpkeepValid(months3);
            }
            LocalDate localDate3 = LocalDate.ofEpochDay(upkeepTime  / 24 / 3600);
            upkeepLimitTime = localDate3.plusMonths(months3).toEpochDay() * 3600 * 24;
            param.setUpkeepLimitTime(upkeepLimitTime);
        }
        param.setUserId(userId);
        int i = truckMapper.updateTruckARU(param);
        if (i > 0) {
            return WrapMapper.ok("时间更新成功");
        }
        return WrapMapper.error("时间更新失败");
    }

    @Override
    public Wrapper cancelSale(Long truckId, Long userId) {
        TruckTransaction truckTransaction=new TruckTransaction();
        truckTransaction.setTruckId(truckId);
        truckTransaction.setUserId(userId);
        transactionMapper.cancelSale(truckId,userId);
        return WrapMapper.ok();
    }

    @Override
    public Wrapper<List<Truck>> getTruckSelects(LoginAuthDto dto) {
        return WrapMapper.ok(truckMapper.getTruckSelects(dto.getUserId()));
    }

    @Override
    public Wrapper getOwnTruckInsurances(Integer page, Integer size, LoginAuthDto dto) {
        PageHelper.startPage(page,size);
        List<Truck> trucks=truckMapper.getOwnTruckInsurances(dto.getUserId());
        List<TruckInsurance> insurances=new ArrayList<>(trucks.size());
        for (Truck truck : trucks) {
            insurances.add(new TruckInsurance(truck.getTruckNum(),truck.getInsuranceCompany(),truck.getInsuranceType(),truck.getRenewalInsuranceTime(),truck.getRenewalInsuranceLimitTime()));
        }
        return WrapMapper.ok(new PageInfo<>(insurances));
    }
}
