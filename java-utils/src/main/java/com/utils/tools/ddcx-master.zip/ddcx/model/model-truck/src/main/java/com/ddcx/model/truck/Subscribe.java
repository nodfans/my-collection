package com.ddcx.model.truck;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@ApiModel("预约表")
public class Subscribe {
    /**
     * 主键
     */
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    @Id
    private Long id;

    /**
     * 司机主键
     */
    @Column(name = "driver_id")
    @ApiModelProperty("司机主键")
    private Long driverId;

    /**
     * 车辆主键
     */
    @Column(name = "truck_id")
    @ApiModelProperty("车辆主键")
    private Long truckId;

    /**
     * 预约配置主键
     */
    @Column(name = "subscribe_id")
    @ApiModelProperty("预约配置主键")
    private Long subscribeId;

    /**
     * 预约时间
     */
    @ApiModelProperty("预约时间")
    private Long date;

    /**
     * 检测空缺
     */
    @Column(name = "is_finish")
    @ApiModelProperty("检测空缺(0,待年检 1.已年检 2.未年检)")
    private Byte isFinish;


    /**
     * 车队主键
     */
    @Column(name = "motorcade_id")
    @ApiModelProperty("车队主键")
    private Long motorcadeId;

    /**
     * 车队名称
     */
    @Column(name = "motorcade_name")
    @ApiModelProperty("车队名称")
    private String motorcadeName;


    /**
     * 司机名称
     */
    @Column(name = "driver_name")
    @ApiModelProperty("司机名称")
    private String driverName;

    /**
     * 司机手机号码
     */
    @Column(name = "driver_phone")
    @ApiModelProperty("司机手机号码")
    private String driverPhone;

    @Transient
    @ApiModelProperty("检查站名称")
    private String checkpointName;

    @Transient
    @ApiModelProperty("检查站地址")
    private String address;


    public String getCheckpointName() {
        return checkpointName;
    }

    public void setCheckpointName(String checkpointName) {
        this.checkpointName = checkpointName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDriverPhone() {
        return driverPhone;
    }

    public void setDriverPhone(String driverPhone) {
        this.driverPhone = driverPhone;
    }

    public Long getMotorcadeId() {
        return motorcadeId;
    }

    public void setMotorcadeId(Long motorcadeId) {
        this.motorcadeId = motorcadeId;
    }

    public String getMotorcadeName() {
        return motorcadeName;
    }

    public void setMotorcadeName(String motorcadeName) {
        this.motorcadeName = motorcadeName;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取司机主键
     *
     * @return driver_id - 司机主键
     */
    public Long getDriverId() {
        return driverId;
    }

    /**
     * 设置司机主键
     *
     * @param driverId 司机主键
     */
    public void setDriverId(Long driverId) {
        this.driverId = driverId;
    }

    /**
     * 获取车辆主键
     *
     * @return truck_id - 车辆主键
     */
    public Long getTruckId() {
        return truckId;
    }

    /**
     * 设置车辆主键
     *
     * @param truckId 车辆主键
     */
    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    /**
     * 获取预约配置主键
     *
     * @return subscribe_id - 预约配置主键
     */
    public Long getSubscribeId() {
        return subscribeId;
    }

    /**
     * 设置预约配置主键
     *
     * @param subscribeId 预约配置主键
     */
    public void setSubscribeId(Long subscribeId) {
        this.subscribeId = subscribeId;
    }

    /**
     * 获取预约时间
     *
     * @return date - 预约时间
     */
    public Long getDate() {
        return date;
    }

    /**
     * 设置预约时间
     *
     * @param date 预约时间
     */
    public void setDate(Long date) {
        this.date = date;
    }

    /**
     * 获取检测空缺
     *
     * @return is_finish - 检测空缺
     */
    public Byte getIsFinish() {
        return isFinish;
    }

    /**
     * 设置检测空缺
     *
     * @param isFinish 检测空缺
     */
    public void setIsFinish(Byte isFinish) {
        this.isFinish = isFinish;
    }
}