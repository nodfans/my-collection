package com.ddcx.model.exam;

import javax.persistence.*;

@Table(name = "user_answer")
public class UserAnswer {
    /**
     * 考试记录表主键
     */
    @Column(name = "record_id")
    private Long recordId;

    /**
     * 正确答案
     */
    @Column(name = "true_answer")
    private String trueAnswer;

    /**
     * 用户答案
     */
    @Column(name = "user_answer")
    private String userAnswer;

    /**
     * 题目主键
     */
    @Column(name = "question_id")
    private Long questionId;

    /**
     * 题目编号
     */
    @Column(name = "question_num")
    private Integer questionNum;

    /**
     * 获取考试记录表主键
     *
     * @return record_id - 考试记录表主键
     */
    public Long getRecordId() {
        return recordId;
    }

    /**
     * 设置考试记录表主键
     *
     * @param recordId 考试记录表主键
     */
    public void setRecordId(Long recordId) {
        this.recordId = recordId;
    }

    /**
     * 获取正确答案
     *
     * @return true_answer - 正确答案
     */
    public String getTrueAnswer() {
        return trueAnswer;
    }

    /**
     * 设置正确答案
     *
     * @param trueAnswer 正确答案
     */
    public void setTrueAnswer(String trueAnswer) {
        this.trueAnswer = trueAnswer;
    }

    /**
     * 获取用户答案
     *
     * @return user_answer - 用户答案
     */
    public String getUserAnswer() {
        return userAnswer;
    }

    /**
     * 设置用户答案
     *
     * @param userAnswer 用户答案
     */
    public void setUserAnswer(String userAnswer) {
        this.userAnswer = userAnswer;
    }

    /**
     * 获取题目主键
     *
     * @return question_id - 题目主键
     */
    public Long getQuestionId() {
        return questionId;
    }

    /**
     * 设置题目主键
     *
     * @param questionId 题目主键
     */
    public void setQuestionId(Long questionId) {
        this.questionId = questionId;
    }

    /**
     * 获取题目编号
     *
     * @return question_num - 题目编号
     */
    public Integer getQuestionNum() {
        return questionNum;
    }

    /**
     * 设置题目编号
     *
     * @param questionNum 题目编号
     */
    public void setQuestionNum(Integer questionNum) {
        this.questionNum = questionNum;
    }
}