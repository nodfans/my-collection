package com.ddcx.app.provider.exam.service;


/**
 * Created by CodeGenerator on 2020/03/11.
 */
public interface QuestionService {

}
