package com.ddcx.common.provider.api.zhiyun;

import lombok.Data;

/**
 * 车辆定位信息
 */
@Data
public class TruckLocation {


    //车牌号
    private String truckNum;
    //纬度
    private String  lat;
    //经度
    private String  lon;
    //地址
    private String  adr;
    //车辆定位时间
    private String  utc;
    //速度
    private String  spd;
    //方向
    private String  drc;
    //省
    private String  province;
    //市
    private String  city;
    //县
    private String  country;
    //里程
    private String  mil;




}
