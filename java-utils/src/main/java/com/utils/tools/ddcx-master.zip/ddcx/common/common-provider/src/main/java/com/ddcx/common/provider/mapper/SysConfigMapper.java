package com.ddcx.common.provider.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.common.SysConfig;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;


@Mapper
@Component
public interface SysConfigMapper extends MyMapper<SysConfig> {

    @Select("select config_value from sys_config where config_key=#{key}")
    String selectByKey(@Param("key") String key);

    @Update("update sys_config set config_value=#{value},update_by=#{updateBy},update_time=#{updateTime} where  config_key=#{key}")
    int updateByKey(@Param("key")String key,@Param("value")String value,@Param("updateBy") Long updateBy,@Param("updateTime") Long updateTime);

}