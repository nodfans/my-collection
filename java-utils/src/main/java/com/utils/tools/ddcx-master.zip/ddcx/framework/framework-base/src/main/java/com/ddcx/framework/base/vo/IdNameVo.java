package com.ddcx.framework.base.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class IdNameVo implements java.io.Serializable {
    private static final long serialVersionUID = -7586214355485848051L;

    @ApiModelProperty(value = "id", name = "id")
    private Long id;

    @ApiModelProperty(value = "名称", name = "name")
    private String name;

    public IdNameVo(Long id, String name) {
        this.id = id;
        this.name = name;
    }
}
