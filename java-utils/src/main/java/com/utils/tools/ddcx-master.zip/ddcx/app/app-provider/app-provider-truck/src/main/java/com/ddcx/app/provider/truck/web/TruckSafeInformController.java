package com.ddcx.app.provider.truck.web;


import com.ddcx.app.provider.truck.service.TruckSafeInformService;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.TruckSafeInform;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/04/17.
*/
@RestController
@RequestMapping("/truck/safe/inform")
@Api(value = "安全隐患整改模块",tags = "安全隐患整改模块")
public class TruckSafeInformController {
    @Resource
    private TruckSafeInformService truckSafeInformService;


    @ApiOperation("获取安全隐患整改详情")
    @GetMapping("/getById")
    public Wrapper<TruckSafeInform> getById(@ApiParam("主键")@RequestParam Long id){
        return truckSafeInformService.getById(id);
    }

    @ApiOperation("获取安全隐患整改详情")
    @GetMapping("/getByTruckId")
    public Wrapper<TruckSafeInform> getByTruckId(@ApiParam("车辆主键")@RequestParam Long id){
        return truckSafeInformService.getByTruckId(id);
    }

    @ApiOperation("安全隐患整改提交")
    @PostMapping("/submitTruckSafeInfo")
    public Wrapper submitTruckSafeInfo(@RequestBody @Validated TruckSafeInform truckSafeInform){
        return truckSafeInformService.submitTruckSafeInfo(truckSafeInform);
    }



}
