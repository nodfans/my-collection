package com.ddcx.app.provider.api.friend.service;


import com.ddcx.app.provider.api.friend.service.hystrix.FriendServiceFeignApiHystrix;
import com.ddcx.framework.core.annotation.NoNeedAccessAuthentication;
import com.ddcx.framework.core.feign.FeignAutoConfiguration;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Component
@FeignClient(value = "ddcx-app-provider-friend", configuration = FeignAutoConfiguration.class, fallback = FriendServiceFeignApiHystrix.class)
public interface FriendServiceFeignApi {



    @NoNeedAccessAuthentication
    @GetMapping(value = "/api/friend/updateUserHeadImgAndUserName")
    void updateUserHeadImgAndUserName(@RequestParam Long userId,@RequestParam(required = false) String imgPath,@RequestParam(required = false) String userName);


}
