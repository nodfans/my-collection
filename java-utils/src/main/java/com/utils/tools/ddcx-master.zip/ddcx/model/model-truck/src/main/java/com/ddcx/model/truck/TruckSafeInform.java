package com.ddcx.model.truck;

import com.ddcx.framework.base.annotation.ExcelName;
import com.ddcx.framework.util.StringUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Table(name = "truck_safe_inform")
@ApiModel("安全隐患整改通知表")
public class TruckSafeInform {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    @NotNull(message = "主键不能为空")
    private Long id;

    /**
     * 车辆主键
     */
    @Column(name = "truck_id")
    @ApiModelProperty("车辆主键")
    private Long truckId;

    /**
     * 车牌号
     */
    @Column(name = "truck_num")
    @ApiModelProperty("车牌号")
    private String truckNum;

    /**
     * 检查部位
     */
    @Column(name = "check_part")
    @ApiModelProperty("检查部位")
    @NotBlank(message = "检查部位不能为空")
    @ExcelName("检查部位不能为空")
    private String checkPart;

    /**
     * 通知编号
     */
    @Column(name = "inform_num")
    @ApiModelProperty("通知编号")
    @ExcelName("通知编号")
    private String informNum;

    /**
     * 隐患内容
     */
    @Column(name = "hidden_danger_content")
    @ApiModelProperty("隐患内容")
    @ExcelName("隐患内容")
    private String hiddenDangerContent;

    /**
     * 整改措施
     */
    @ApiModelProperty("整改措施")
    @NotBlank(message = "整改措施不能为空")
    @ExcelName("整改措施")
    private String abarbeitung;

    /**
     * 备注
     */
    @ApiModelProperty("备注")
    @ExcelName("备注")
    private String remark;

    /**
     * 整改期限
     */
    @Column(name = "abarbeitung_limit")
    @ApiModelProperty("整改期限")
    @ExcelName("整改期限")
    private Integer abarbeitungLimit;

    /**
     * 图片
     */
    @ApiModelProperty("图片")
    @NotBlank(message = "图片不能为空")
    @ExcelName("图片")
    private String img;

    @ApiModelProperty("图片列表")
    @Transient
    private List<String> imgList;

    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    @Column(name = "create_time")
    @ExcelName(value = "创建时间",isTimestamp = true)
    private Long createTime;

    @ApiModelProperty("检查台账id")
    @Column(name = "check_id")
    private Long checkId;

    @ApiModelProperty("整改状态：1.司机端已填写整改 0.司机端未填写整改 2.已消除待办")
    @Column(name = "state")
    @ExcelName(value = "整改状态",replaceNumber = {"司机端未填写整改","司机端已填写整改","已消除待办"})
    private Byte state;


    @ApiModelProperty("菜单")
    @Transient
    private Map<String,List<String>> list;


    public Map<String, List<String>> getList() {
        return list;
    }

    public void setList(Map<String, List<String>> list) {
        this.list = list;
    }

    public Byte getState() {
        return state;
    }

    public void setState(Byte state) {
        this.state = state;
    }

    public Long getCheckId() {
        return checkId;
    }

    public void setCheckId(Long checkId) {
        this.checkId = checkId;
    }

    public List<String> getImgList() {
        return imgList;
    }

    public void setImgList(List<String> imgList) {
        this.imgList = imgList;
        if(imgList!=null&&imgList.size()>0){
            img="";
            for (String s : imgList) {
                img+=s+";";
            }
            img=img.substring(0,img.length()-1);
        }
    }

    /**
     * 获取车辆主键
     *
     * @return id - 车辆主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置车辆主键
     *
     * @param id 车辆主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取车辆主键
     *
     * @return truck_id - 车辆主键
     */
    public Long getTruckId() {
        return truckId;
    }

    /**
     * 设置车辆主键
     *
     * @param truckId 车辆主键
     */
    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    /**
     * 获取车牌号
     *
     * @return truck_num - 车牌号
     */
    public String getTruckNum() {
        return truckNum;
    }

    /**
     * 设置车牌号
     *
     * @param truckNum 车牌号
     */
    public void setTruckNum(String truckNum) {
        this.truckNum = truckNum;
    }

    /**
     * 获取检查部位
     *
     * @return check_part - 检查部位
     */
    public String getCheckPart() {
        return checkPart;
    }

    /**
     * 设置检查部位
     *
     * @param checkPart 检查部位
     */
    public void setCheckPart(String checkPart) {
        this.checkPart = checkPart;
    }

    /**
     * 获取通知编号
     *
     * @return inform_num - 通知编号
     */
    public String getInformNum() {
        return informNum;
    }

    /**
     * 设置通知编号
     *
     * @param informNum 通知编号
     */
    public void setInformNum(String informNum) {
        this.informNum = informNum;
    }

    /**
     * 获取隐患内容
     *
     * @return hidden_danger_content - 隐患内容
     */
    public String getHiddenDangerContent() {
        return hiddenDangerContent;
    }

    /**
     * 设置隐患内容
     *
     * @param hiddenDangerContent 隐患内容
     */
    public void setHiddenDangerContent(String hiddenDangerContent) {
        this.hiddenDangerContent = hiddenDangerContent;
    }

    /**
     * 获取整改措施
     *
     * @return abarbeitung - 整改措施
     */
    public String getAbarbeitung() {
        return abarbeitung;
    }

    /**
     * 设置整改措施
     *
     * @param abarbeitung 整改措施
     */
    public void setAbarbeitung(String abarbeitung) {
        this.abarbeitung = abarbeitung;
    }

    /**
     * 获取备注
     *
     * @return remark - 备注
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 设置备注
     *
     * @param remark 备注
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * 获取整改期限
     *
     * @return abarbeitung_limit - 整改期限
     */
    public Integer getAbarbeitungLimit() {
        return abarbeitungLimit;
    }

    /**
     * 设置整改期限
     *
     * @param abarbeitungLimit 整改期限
     */
    public void setAbarbeitungLimit(Integer abarbeitungLimit) {
        this.abarbeitungLimit = abarbeitungLimit;
    }

    /**
     * 获取图片
     *
     * @return img - 图片
     */
    public String getImg() {
        return img;
    }

    /**
     * 设置图片
     *
     * @param img 图片
     */
    public void setImg(String img) {
        this.img = img;
        if(StringUtils.isNotBlank(img)){
            imgList= Arrays.asList(img.split(";"));
        }
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
}