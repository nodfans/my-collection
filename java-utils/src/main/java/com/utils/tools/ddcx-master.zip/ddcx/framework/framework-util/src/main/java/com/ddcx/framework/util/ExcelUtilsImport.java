package com.ddcx.framework.util;


import org.apache.poi.POIXMLDocumentPart;
import org.apache.poi.ss.usermodel.PictureData;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.*;
import org.openxmlformats.schemas.drawingml.x2006.spreadsheetDrawing.CTMarker;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * excel解析<导入>
 */
public class ExcelUtilsImport {




    public static  List<List<String>>  parseFile(MultipartFile file) throws Exception {
        return null;
    }


    public static void getDataFromExcel(MultipartFile file) throws IOException
    {

        FileInputStream fis =null;
        Workbook wookbook = null;
        Sheet sheet =null;
        try
        {
             //获取一个绝对地址的流
             fis = (FileInputStream) file.getInputStream();
        }
        catch(Exception e)
        {
             e.printStackTrace();
        }

        try
        {
           //2007版本的excel，用.xlsx结尾
           wookbook = new XSSFWorkbook(fis);//得到工作簿
        } catch (IOException e)
        {
            e.printStackTrace();
        }


        Map<String, PictureData> maplist=null;

        sheet = wookbook.getSheetAt(0);
            // 判断用07还是03的方法获取图片
        maplist = getPictures2((XSSFSheet) sheet);

    }
    /**
      * 获取图片和位置	(xlsx)
      * @param	sheet
      * @return
      * @throws IOException
      */
      public static Map<String,	PictureData> getPictures2 (XSSFSheet sheet) throws IOException {
        Map<String, PictureData> map = new HashMap<String, PictureData>();
        List<POIXMLDocumentPart> list	= sheet.getRelations();
        for (POIXMLDocumentPart part : list) {
            if (part instanceof XSSFDrawing) {
                XSSFDrawing drawing =	(XSSFDrawing) part;
                List<XSSFShape> shapes = drawing.getShapes();
                for (XSSFShape shape : shapes) {
                    XSSFPicture picture = (XSSFPicture) shape;
                    XSSFClientAnchor anchor =	picture.getPreferredSize();
                    CTMarker marker =	anchor.getFrom();
                    String key = marker.getRow() + "-" + marker.getCol();
                    map.put(key, picture.getPictureData());
                }
            }
        }
        return map;
    }



}
