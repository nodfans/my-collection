package com.ddcx.model.uac;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Table(name = "uac_feedback")
@ApiModel("用户反馈")
public class UacFeedback implements java.io.Serializable {
    private static final long serialVersionUID = 879872959058196658L;
   
    @Id
    @ApiModelProperty("主键")
    private Long id;
    /**
     * 用户ID
     */
    @ApiModelProperty("用户ID")
    private Long userId;
    /**
     * 内容
     */
    @ApiModelProperty("内容")
    private String content;
    /**
     * 图片
     */
    @ApiModelProperty("图片")
    private String imgs;
    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    private Long createTime;
}
