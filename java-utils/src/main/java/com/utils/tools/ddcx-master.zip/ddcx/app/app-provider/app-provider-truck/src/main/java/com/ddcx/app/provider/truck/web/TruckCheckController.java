package com.ddcx.app.provider.truck.web;


import com.ddcx.app.provider.truck.service.TruckCheckService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.TruckCheck;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/04/17.
*/
@RestController
@RequestMapping("/truck/check")
@Api(value = "车辆检测模块",tags = "车辆检查模块")
public class TruckCheckController extends BaseController {
    @Resource
    private TruckCheckService truckCheckService;

    @ApiOperation("用户添加日常检查登记台账")
    @PostMapping("/addTruckCheck")
    public Wrapper addTruckCheck(@RequestBody@ApiParam("所有参数都已0.表示正常 1.表示异常") TruckCheck truckCheck){
        return truckCheckService.addTruckCheck(truckCheck,getLoginAuthDto());
    }









}
