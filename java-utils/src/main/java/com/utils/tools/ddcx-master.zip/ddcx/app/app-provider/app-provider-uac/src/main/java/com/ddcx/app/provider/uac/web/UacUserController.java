package com.ddcx.app.provider.uac.web;

import com.ddcx.app.provider.api.uac.model.dto.CardAuthDto;
import com.ddcx.app.provider.api.uac.model.dto.UacLoginDto;
import com.ddcx.app.provider.api.uac.model.dto.UacUpdateUserDto;
import com.ddcx.app.provider.api.uac.model.dto.UacUserRegisterDto;
import com.ddcx.app.provider.api.uac.model.vo.UacLoginTokenVo;
import com.ddcx.app.provider.api.uac.model.vo.UacUserVo;
import com.ddcx.app.provider.uac.service.UacUserService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.base.enums.LogTypeEnum;
import com.ddcx.framework.core.annotation.RequestLog;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.StringUtils;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.IdAuth;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/user")
@Api(value = "用户", tags = {"用户"})
public class UacUserController extends BaseController {

    @Autowired
    private UacUserService userService;

    @ApiOperation(value = "注册", notes = "注册")
    @PostMapping(value = "/register")
    @RequestLog(logType = LogTypeEnum.REQUEST_LOG, isSaveRequestData = true, isSaveResponseData = true)
    public synchronized Wrapper<UacLoginTokenVo> register(@RequestBody @Validated UacUserRegisterDto uacUserRegisterDto) {
        final UacLoginTokenVo uacLoginTokenVo = userService.register(uacUserRegisterDto);
        return WrapMapper.ok(uacLoginTokenVo);
    }

    @ApiOperation(value = "用户信息", notes = "用户信息")
    @GetMapping(value = "/get")
    @RequestLog(logType = LogTypeEnum.REQUEST_LOG, isSaveRequestData = true, isSaveResponseData = true)
    public Wrapper<UacUserVo> getUser() {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        final UacUserVo uacUserVo = userService.getUser(loginAuthDto);
        return WrapMapper.ok(uacUserVo);
    }

    @ApiOperation(value = "修改", notes = "修改")
    @PutMapping(value = "/update")
    @RequestLog(logType = LogTypeEnum.REQUEST_LOG, isSaveRequestData = true, isSaveResponseData = true)
    public Wrapper update(@RequestBody @Validated UacUpdateUserDto uacUpdateUserDto) {
        if(StringUtils.isNotBlank(uacUpdateUserDto.getEmergency())&&StringUtils.isNotPhone(uacUpdateUserDto.getEmergency())){
           return WrapMapper.error("紧急联系人手机号码格式不正确");
        }
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        final Boolean flag = userService.update(loginAuthDto, uacUpdateUserDto);
        if (flag) {
            return WrapMapper.ok("操作成功");
        }
        return WrapMapper.error("操作失败");
    }



    @ApiOperation(value = "修改密码", notes = "修改密码")
    @PutMapping(value = "/updatePWD")
    @RequestLog(logType = LogTypeEnum.REQUEST_LOG, isSaveRequestData = true, isSaveResponseData = true)
    public Wrapper updatePWD(@RequestBody  UacLoginDto dto) {
        if(StringUtils.isBlank(dto.getAccount())){
            return WrapMapper.error("手机号不能为空");
        }
        if(StringUtils.isBlank(dto.getPassword())){
            return WrapMapper.error("密码不能为空");
        }
        if(StringUtils.isBlank(dto.getCode())){
            return WrapMapper.error("验证码不能为空");
        }
        return userService.updatePWD(dto);
    }




    @ApiOperation("身份证认证")
    @PostMapping("/idAuth")
    public Wrapper idAuth(@RequestBody IdAuth idAuth){
        return userService.idAuth(idAuth,getLoginAuthDto());
    }

    @ApiOperation("证件认证（1.行驶证 2.驾驶证 3.从业资格证）")
    @PostMapping("/cardAuth")
    public Wrapper cardAuth(@RequestBody @Validated CardAuthDto cardAuthDto){
        return userService.cardAuth(cardAuthDto.getCardAuth(),getLoginAuthDto(),cardAuthDto.getType());
    }


    @ApiOperation("获取本车队司机列表<id:主键,name:司机名>")
    @GetMapping("/getOwnMotorcadeDrivers")
    public Wrapper  getOwnMotorcadeDrivers(){
        return userService.getOwnMotorcadeDrivers(getLoginAuthDto());
    }


}
