package com.ddcx.app.provider.truck.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.truck.TruckTransaction;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Mapper
@Component
public interface TruckTransactionMapper extends MyMapper<TruckTransaction> {

    /**
     * 获取车辆（交易）信息
     *
     * @param truckTransaction
     * @return
     */
    @Select({"<script>",
            "select  id,user_id,truck_length,load_weight,login_date,brand,buy_date,type,sale_price,new_level,picture,create_time from truck_transaction ",
            "<where>",
            "<if test='brand!=null'>",
            "and brand = #{brand}",
            "</if>",
            "<if test='type!=null'>",
            "and type like concat('%',#{type},'%')",
            "</if>",
            "<if test='engineType!=null'>",
            "and engine_type = #{engineType}",
            "</if>",
            "<if test='newLevel!=null'>",
            "and new_level= #{newLevel}",
            "</if>",
            "</where>",
            "order by create_time",
            "</script>"})
    List<TruckTransaction> getTrucksPage(TruckTransaction truckTransaction);

    /**
     * 参数查询交易车辆
     *
     * @param truckTransaction
     * @return
     */
    List<TruckTransaction> getTrucksOwnerPage(TruckTransaction truckTransaction);



    @Select("select count(*) from truck_transaction where truck_id=#{truckId}")
    int selectCountByTruckId(@Param("truckId") Long truckId);


    @Select("select sale_price from truck_transaction where  truck_id=#{truckId}")
    BigDecimal selectSalePriceByTruckId(@Param("truckId")Long truckId);


    @Delete("delete from truck_transaction where   truck_id=#{truckId} and user_id=#{userId}")
    int cancelSale(@Param("truckId") Long truckId,@Param("userId") Long userId);
}