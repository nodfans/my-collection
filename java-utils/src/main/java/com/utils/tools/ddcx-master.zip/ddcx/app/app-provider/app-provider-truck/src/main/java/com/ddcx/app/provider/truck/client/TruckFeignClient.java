package com.ddcx.app.provider.truck.client;


import com.ddcx.app.provider.api.truck.model.service.TruckFeignClientApi;
import com.ddcx.app.provider.truck.mapper.TruckMapper;
import com.ddcx.framework.util.DistanceUtil;
import com.ddcx.model.truck.Truck;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RefreshScope
@RestController
public class TruckFeignClient implements TruckFeignClientApi {

    @Resource
    private TruckMapper truckMapper;

    @Override
    public Set<Long> getAllValidUserId(String lng, String lat, Integer askHelpKm) {
        List<Truck> trucks=truckMapper.selectAllLocation();
        Set<Long> driverId=trucks.stream().filter(rescue1 -> (DistanceUtil.getDistance1(Double.valueOf(lat), Double.valueOf(lng), Double.valueOf(rescue1.getLat()), Double.valueOf(rescue1.getLng())) < askHelpKm * 1000)).map(Truck::getDriverId).collect(Collectors.toSet());
        return driverId;
    }
}
