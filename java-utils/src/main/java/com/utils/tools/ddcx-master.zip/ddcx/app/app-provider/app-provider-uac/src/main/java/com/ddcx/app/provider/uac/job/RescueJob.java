package com.ddcx.app.provider.uac.job;


import com.ddcx.app.provider.uac.mapper.RescueMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@Log4j2
@EnableScheduling
public class RescueJob {

    @Resource
    private RescueMapper rescueMapper;

    /**
     * 每2分钟执行一次 更改掉过期时间
     */
    @Scheduled(cron = "0 0/2 * * * ? ")
    public void updateRescueJob(){
        int i=rescueMapper.updateOverdueInfo(System.currentTimeMillis()/1000);

        log.info(i+"条求援信息过期被处理。。。");
    }
}
