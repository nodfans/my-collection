package com.ddcx.app.provider.exam.service.impl;


import com.ddcx.app.provider.exam.mapper.UacLearnInformationMapper;
import com.ddcx.app.provider.exam.mapper.UacLearnRecordMapper;
import com.ddcx.app.provider.exam.service.UacLearnInformationService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.exam.UacLearnInformation;
import com.ddcx.model.exam.UacLearnRecord;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/11.
 */
@Service
@Transactional
public class UacLearnInformationServiceImpl implements UacLearnInformationService {
    @Resource
    private UacLearnInformationMapper uacLearnInformationMapper;
    @Resource
    private UacLearnRecordMapper recordMapper;

    @Override
    public Wrapper getInfoByType(Byte type, LoginAuthDto dto) {
        UacLearnInformation information=new UacLearnInformation();
        information.setState((byte) 1);
        information.setType(type);
        List<UacLearnInformation> list=uacLearnInformationMapper.select(information);
        UacLearnRecord record=null;
        for (UacLearnInformation info : list) {
            record=recordMapper.selectByOwn(info.getId(),dto.getUserId());
            info.setDuration(record==null?null:record.getDuration());
            info.setFinish(record==null?null:record.getFinish());
            info.setViewDuration(record==null?null:record.getViewDuration());
            info.setH5("http://www.baidu.com");
        }
        return WrapMapper.ok(list);
    }

    @Override
    public Wrapper detail(Long id, LoginAuthDto dto) {
        UacLearnInformation information=new UacLearnInformation();
        information.setState((byte) 1);
        information.setId(id);
        UacLearnInformation information1=uacLearnInformationMapper.selectOne(information);
        UacLearnRecord record=recordMapper.selectByOwn(id,dto.getUserId());
        information1.setH5("http://www.baidu.com");
        information1.setDuration(record==null?null:record.getDuration());
        information1.setFinish(record==null?(byte)0:record.getFinish());
        if(information1.getType().intValue()==2){
            information1.setViewDuration(record==null?0L:record.getViewDuration());
        }
        return WrapMapper.ok(information1);
    }
}
