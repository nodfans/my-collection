package com.ddcx.common.provider.client;

import com.alibaba.fastjson.JSONObject;
import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.common.provider.api.model.dto.MessageDto;
import com.ddcx.common.provider.api.model.vo.CommonBankBinVo;
import com.ddcx.common.provider.api.service.CommonServiceFeignApi;
import com.ddcx.common.provider.api.zhiyun.ZhiYunDrivingLicence;
import com.ddcx.common.provider.api.zhiyun.ZhiYunIdAuth;
import com.ddcx.common.provider.controller.PicUploadController;
import com.ddcx.common.provider.mapper.MessageConfigMapper;
import com.ddcx.common.provider.mapper.MessageMapper;
import com.ddcx.common.provider.mapper.ReminderDaysMapper;
import com.ddcx.common.provider.service.CommonBankBinService;
import com.ddcx.common.provider.service.ZhiYunService;
import com.ddcx.common.provider.util.JpushService;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.framework.util.StringUtils;
import com.ddcx.framework.util.id.IdWorker;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.common.*;
import com.ddcx.web.provider.api.uac.model.service.AdminUserServiceFeignApi;
import lombok.SneakyThrows;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RestController;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.*;

@RefreshScope
@RestController
public class CommonServiceFeignClient extends BaseController implements CommonServiceFeignApi {

    @Autowired
    private CommonBankBinService commonBankbinService;

    @Resource
    private MessageMapper messageMapper;

    @Resource
    private MessageConfigMapper messageConfigMapper;

    @Resource
    private AdminUserServiceFeignApi userServiceFeignApi;

    @Resource
    private RedisUtil redisUtil;

    @Resource
    private PicUploadController uploadController;

    @Resource
    private ReminderDaysMapper reminderDaysMapper;

    @Resource
    private JpushService jpushService;

    @Resource
    private ZhiYunService zhiYunService;

    @Override
    public String upload(byte[] imgData) {
        return uploadController.uploadImg(imgData);
    }

    @Override
    public String deleteFile(String filePath) {
        logger.info(filePath);
        if (StringUtils.isEmpty(filePath)) {
            return null;
        }
        String[] strings = filePath.split(",");
        logger.info(strings.length + "");
        for (String string : strings) {
            logger.info(string);
            uploadController.publicDeleteFile(string);
        }
        return null;
    }

    @Override
    public String deleteAdminFile(String filePath) {
        logger.info(filePath);
        if (StringUtils.isEmpty(filePath)) {
            return null;
        }
        String[] strings = filePath.split(",");
        logger.info(strings.length + "");
        for (String string : strings) {
            logger.info(string);
            uploadController.publicDeleteFile(string);
        }
        return null;
    }

    @Override
    public CommonBankBinVo getBankBin(String cardNo) {
        CommonBankBinVo commonBankBinVo = null;
        CommonBankBin commonBankBin = commonBankbinService.getBankBin(cardNo);
        if (PublicUtil.isNotEmpty(commonBankBin)) {
            commonBankBinVo = new ModelMapper().map(commonBankBin, CommonBankBinVo.class);
        }
        return commonBankBinVo;
    }

    @Override
    public JSONObject getSysConfigByKey(String key) {
        Object obj=redisUtil.hget(RedisKey.SYS_CONFIG, key);
        String str = obj==null?"{\"select\":2,\"judge\":2}":obj.toString();
        return JSONObject.parseObject(str);
    }

    @Override
    public int addMessage(MessageDto dto) {
        MessageConfig messageConfig = dto.getMessageConfig();
        messageConfig.setCreateTime(System.currentTimeMillis() / 1000);
        messageConfig.setIsDelete(0);
        int i = messageConfigMapper.insert(messageConfig);
        Message message = dto.getMessage();
        message.setConfigId((long) i);
        message.setDeleteTag((byte) 0);
        message.setState((byte) 0);
        messageMapper.insert(message);
        return 1;
    }

    @Override
    public int addAdminMessage(MessageDto dto) {
        return addMessage(dto);
    }

    @Override
    public int addMessageOfAll(MessageDto dto) {
        MessageConfig messageConfig = dto.getMessageConfig();
        messageConfig.setCreateTime(System.currentTimeMillis() / 1000);
        messageConfig.setIsDelete(0);
        int i = messageConfigMapper.insert(messageConfig);
        List<Long> list = userServiceFeignApi.getAllUserId();
        Set<Long> set = new HashSet<>(list);
        set.forEach((Long a) -> {
            Message message = new Message();
            message.setConfigId((long) i);
            message.setDeleteTag((byte) 0);
            message.setState((byte) 0);
            message.setUserId(a);
            messageMapper.insert(message);
        });
        return 1;
    }

    @Override
    public int addMessageOfAllByUserIds(String map1) {
        Map<String, Object> map = JSONObject.parseObject(map1, new HashMap<String, Object>().getClass());
        MessageDto dto = JSONObject.parseObject(map.get("1").toString(), MessageDto.class);
        List<Long> list = JSONObject.parseArray(map.get("2").toString(), Long.class);
        Boolean tag=JSONObject.parseObject(map.get("3").toString(), Boolean.class);;
        MessageConfig messageConfig = dto.getMessageConfig();
        messageConfig.setCreateTime(System.currentTimeMillis() / 1000);
        messageConfig.setIsDelete(0);
        try {
            messageConfig.setId(new IdWorker().nextId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        messageConfigMapper.insert(messageConfig);
        for (Long aLong : list) {
            Message message = new Message();
            message.setConfigId(messageConfig.getId());
            message.setDeleteTag((byte) 0);
            message.setState((byte) 0);
            message.setUserId(aLong);
            messageMapper.insert(message);
        }
        if(tag!=null&&tag&&list.size()>0){
            Map<String,String> map2=JSONObject.parseObject(map.get("4").toString(),new HashMap<String,String>().getClass());
            String[] strings=new String[list.size()];
            for (int i = 0; i < strings.length; i++) {
                strings[i]=list.get(i).toString();
            }
            jpushService.sendPush(map2.get("title"),map2.get("content"),map2,strings);
            jpushService.sendCustomPush(map2.get("title"),map2.get("content"),map2,strings);
        }
        return 1;
    }

    @SneakyThrows
    @Override
    public CnRegionInfo getRegionMsgByCode(String code) {
        CnRegionInfo info = new CnRegionInfo();
        if (code.length() == 6) {
            //获取省市区即可
            BsArea bsArea = (BsArea) redisUtil.hget(RedisKey.BS_AREA, code);
            BsCity bsCity = (BsCity) redisUtil.hget(RedisKey.BS_CITY, code.substring(0, 4) + "00");
            BsProvince bsProvince = (BsProvince) redisUtil.hget(RedisKey.BS_PROVINCE, code.substring(0, 2) + "0000");
            info.setCriShortName(bsProvince.getProvinceName() + bsCity.getCityName() + bsArea.getAreaName());
            return info;
        } else if (code.length() == 9) {
            //获取省市区街道
            BsStreet bsStreet = (BsStreet) redisUtil.hget(RedisKey.BS_STREET, code);
            BsArea bsArea = (BsArea) redisUtil.hget(RedisKey.BS_AREA, code.substring(0, 6));
            BsCity bsCity = (BsCity) redisUtil.hget(RedisKey.BS_CITY, code.substring(0, 4) + "00");
            BsProvince bsProvince = (BsProvince) redisUtil.hget(RedisKey.BS_PROVINCE, code.substring(0, 2) + "0000");
            info.setCriShortName(bsProvince.getProvinceName() + bsCity.getCityName() + bsArea.getAreaName() + bsStreet.getStreetName());
            return info;
        }
        return null;
    }

//    @Override
//    public BsStreet getBsStreetByCode(String code) {
//        return (BsStreet) redisUtil.hget(RedisKey.BS_STREET,code);
//    }

    @Override
    public BsArea getBsAreaByCode(String code) {
        return (BsArea) redisUtil.hget(RedisKey.BS_AREA, code);
    }

    @Override
    public RelatedReminders selectRelatedReminders() {
        return reminderDaysMapper.selectOne(new RelatedReminders());
    }

    @Override
    public Integer getHelpMessageTotal() {
        Example example = new Example(MessageConfig.class);
        example.createCriteria().andEqualTo("type", 3);
        return messageConfigMapper.selectCountByExample(example);
    }

    @Override
    public int deleteRescueMessage(Long rescueId) {
        return messageConfigMapper.updateRescueMessage(rescueId+"");
    }

    @Override
    public ZhiYunIdAuth idCardLicense(String frontPath, String reversePath) throws Exception {
        Wrapper<ZhiYunIdAuth> wrapper=zhiYunService.idCardLicense(frontPath,reversePath);
        return wrapper.getResult();
    }

    @Override
    public ZhiYunDrivingLicence drivingLicense(String drivingPath) throws Exception {
        Wrapper<ZhiYunDrivingLicence> wrapper=zhiYunService.drivingLicense(drivingPath);
        return wrapper.getResult();
    }


}
