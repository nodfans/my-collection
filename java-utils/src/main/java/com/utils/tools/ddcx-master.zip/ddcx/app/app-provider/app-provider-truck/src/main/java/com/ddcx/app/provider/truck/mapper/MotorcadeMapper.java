package com.ddcx.app.provider.truck.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.truck.Motorcade;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface MotorcadeMapper extends MyMapper<Motorcade> {

    @Select("select id ,com_name,motorcade_name from motorcade where state=1 and com_name=#{comName}")
    List<Motorcade> getMotorcadeByComName(@Param("comName")String comName);
}