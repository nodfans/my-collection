package com.ddcx.app.provider.loan.service;


import com.ddcx.framework.base.dto.AdminLoginAutoDto;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.loan.LoanOrder;

import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/17.
 */
public interface LoanOrderService  {


    Wrapper saveLoan(LoanOrder order, LoginAuthDto dto);

    Wrapper getLoanApproveListOfPage( Integer page, Integer size, LoginAuthDto dto);

    Wrapper cancelLoan(Long oId,LoginAuthDto dto);


}
