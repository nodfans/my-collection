package com.ddcx.app.provider.api.truck.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("预约显示类")
@Data
public class SubscribeVo {

    /**
     * 主键
     */
    @ApiModelProperty("主键")
    private Long id;

    /**
     * 司机主键
     */
    @ApiModelProperty("司机主键")
    private Long driverId;

    /**
     * 车辆主键
     */
    @ApiModelProperty("车辆主键")
    private Long truckId;

    /**
     * 预约配置主键
     */
    @ApiModelProperty("预约配置主键")
    private Long subscribeId;

    /**
     * 预约时间
     */
    @ApiModelProperty("预约时间")
    private Long date;

    /**
     * 检测空缺(0,待年检 1.已年检 2.未年检)
     */
    @ApiModelProperty("检测空缺(0,待年检 1.已年检 2.未年检)")
    private Byte isFinish;


    /**
     * 车队主键
     */
    @ApiModelProperty("车队主键")
    private Long motorcadeId;

    /**
     * 车队名称
     */
    @ApiModelProperty("车队名称")
    private String motorcadeName;


    /**
     * 司机名称
     */
    @ApiModelProperty("司机名称")
    private String driverName;

    /**
     * 司机手机号码
     */
    @ApiModelProperty("司机手机号码")
    private String driverPhone;

    @ApiModelProperty("检查站名称")
    private String checkpointName;

    @ApiModelProperty("检查站地址")
    private String checkpointAddress;

    @ApiModelProperty("检查站纬度")
    private Double lat;

    @ApiModelProperty("检查站经度")
    private Double lng;



}
