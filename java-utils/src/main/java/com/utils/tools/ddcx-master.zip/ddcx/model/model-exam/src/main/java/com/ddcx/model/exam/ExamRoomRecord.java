package com.ddcx.model.exam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Table(name = "exam_room_record")
@ApiModel("考场记录表")
public class ExamRoomRecord {
    /**
     * 主键
     */
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    @Id
    private Long id;

    /**
     * 考场主键
     */
    @Column(name = "room_id")
    @ApiModelProperty("考场主键")
    private Long roomId;

    /**
     * 考场名
     */
    @ApiModelProperty("考场名")
    private String name;

    /**
     * 地址
     */
    @ApiModelProperty("地址")
    private String address;

    /**
     * 时长
     */
    @ApiModelProperty("时长")
    private Integer duration;

    /**
     * 时间
     */
    @ApiModelProperty("时间")
    @Column(name = "room_date")
    private Long roomDate;

    /**
     * 题目数
     */
    @ApiModelProperty("题目数")
    @Column(name = "question_count")
    private Integer questionCount;

    /**
     * 参与人数
     */
    @ApiModelProperty("参与人数")
    @Column(name = "person_count")
    private Integer personCount;


    @ApiModelProperty("车队主键")
    private Long motorcadeId;

    public Long getMotorcadeId() {
        return motorcadeId;
    }

    public void setMotorcadeId(Long motorcadeId) {
        this.motorcadeId = motorcadeId;
    }


    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取考场主键
     *
     * @return room_id - 考场主键
     */
    public Long getRoomId() {
        return roomId;
    }

    /**
     * 设置考场主键
     *
     * @param roomId 考场主键
     */
    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    /**
     * 获取考场名
     *
     * @return name - 考场名
     */
    public String getName() {
        return name;
    }

    /**
     * 设置考场名
     *
     * @param name 考场名
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取地址
     *
     * @return address - 地址
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置地址
     *
     * @param address 地址
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * 获取时长
     *
     * @return duration - 时长
     */
    public Integer getDuration() {
        return duration;
    }

    /**
     * 设置时长
     *
     * @param duration 时长
     */
    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    /**
     * 获取时间
     *
     * @return room_date - 时间
     */
    public Long getRoomDate() {
        return roomDate;
    }

    /**
     * 设置时间
     *
     * @param roomDate 时间
     */
    public void setRoomDate(Long roomDate) {
        this.roomDate = roomDate;
    }

    /**
     * 获取题目数
     *
     * @return question_count - 题目数
     */
    public Integer getQuestionCount() {
        return questionCount;
    }

    /**
     * 设置题目数
     *
     * @param questionCount 题目数
     */
    public void setQuestionCount(Integer questionCount) {
        this.questionCount = questionCount;
    }

    /**
     * 获取参与人数
     *
     * @return person_count - 参与人数
     */
    public Integer getPersonCount() {
        return personCount;
    }

    /**
     * 设置参与人数
     *
     * @param personCount 参与人数
     */
    public void setPersonCount(Integer personCount) {
        this.personCount = personCount;
    }
}