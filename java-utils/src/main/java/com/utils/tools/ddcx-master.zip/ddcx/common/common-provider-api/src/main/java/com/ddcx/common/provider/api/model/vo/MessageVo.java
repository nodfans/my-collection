package com.ddcx.common.provider.api.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("消息显示类")
public class MessageVo {

    @ApiModelProperty("消息id")
    private Long id;
    @ApiModelProperty("标题")
    private String topic;
    @ApiModelProperty("消息内容")
    private String content;
    @ApiModelProperty("请求路径：为学习消息时，1.表示跳转文字学习列表 2.表示跳转视频学习列表;为救援消息时为救援消息主键")
    private String requestUrl;
    @ApiModelProperty("图片url")
    private String imgUrl;
    @ApiModelProperty("发布时间")
    private Long createTime;

    private Integer type;
    /**
     * 消息状态（0.未读 1,.已读）
     */
    @ApiModelProperty("消息状态（0.未读 1,.已读）")
    private Byte state;
    @ApiModelProperty("各类未读消息数量：数组下标对应消息类型")
    private int[] noReadNum;
}
