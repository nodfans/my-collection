package com.ddcx.app.provider.loan.web;

import com.ddcx.app.provider.loan.service.LoanPayRecordService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/04/28.
*/
@RestController
@RequestMapping("/loan/pay/record")
public class LoanPayRecordController {
    @Resource
    private LoanPayRecordService loanPayRecordService;

}
