package com.ddcx.app.provider.uac.mapper;

import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.uac.UacBank;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface UacBankMapper extends MyMapper<UacBank> {

    @Select("select * from uac_bank where user_id=#{userId} order by create_time desc limit 1")
    List<UacBank>  selectBanksByUserId(@Param("userId") Long userId);



}
