package com.ddcx.app.provider.loan.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.loan.LoanOrder;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface LoanOrderMapper extends MyMapper<LoanOrder> {

    List<LoanOrder>  getLoanApproveListOfPage(Long userId);
}