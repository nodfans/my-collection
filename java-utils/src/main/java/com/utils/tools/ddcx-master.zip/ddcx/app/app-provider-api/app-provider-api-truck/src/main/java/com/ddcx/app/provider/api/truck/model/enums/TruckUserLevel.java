package com.ddcx.app.provider.api.truck.model.enums;

//汽车用户级别
public enum TruckUserLevel {

    none(0, "无关人员"), driver(1, "司机"), owner(2, "车主");

    private Integer code;
    private String des;

    TruckUserLevel(Integer code, String des) {
        this.code = code;
        this.des = des;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
