package com.ddcx.model.common;

import javax.persistence.*;

@Table(name = "total_img_path")
public class TotalImgPath {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 所有上传的图片
     */
    @Column(name = "srcPath")
    private String srcpath;

    public TotalImgPath() {
    }

    public TotalImgPath(String srcpath) {
        this.srcpath = srcpath;
    }

    /**
     * 获取id
     *
     * @return id - id
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取所有上传的图片
     *
     * @return srcPath - 所有上传的图片
     */
    public String getSrcpath() {
        return srcpath;
    }

    /**
     * 设置所有上传的图片
     *
     * @param srcpath 所有上传的图片
     */
    public void setSrcpath(String srcpath) {
        this.srcpath = srcpath;
    }
}