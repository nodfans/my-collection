package com.ddcx.app.provider.uac.mapper;

import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.uac.UacFeedback;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface UacFeedbackMapper extends MyMapper<UacFeedback> {

}
