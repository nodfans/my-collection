package com.ddcx.app.provider.api.uac.model.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class DeepMyselfInfoVo implements java.io.Serializable {
    
    @ApiModelProperty(value = "用户ID", name = "userId")
    private Long userId;

    @ApiModelProperty(value = "手机号码", name = "phone")
    private String phone;

    @ApiModelProperty(value = "生日", name = "birthday")
    private Long birthday;

    @ApiModelProperty(value = "头像", name = "headImg")
    private String headImg;

    @ApiModelProperty(value = "地址信息", name = "address")
    private String addressMsg;

    @ApiModelProperty(value = "名称", name = "name")
    private String name;
}
