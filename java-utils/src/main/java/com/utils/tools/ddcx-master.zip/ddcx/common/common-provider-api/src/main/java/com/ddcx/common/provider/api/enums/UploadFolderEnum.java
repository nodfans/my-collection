package com.ddcx.common.provider.api.enums;


import com.ddcx.common.provider.api.util.CommonUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public enum UploadFolderEnum {

    IMAGE("images", "jpg", "jpg,png,jpeg"),

    PDF("userPdf", "pdf", "pdf"),

    HTML("userHtml", "html", "html"),

    IMAGE_APP("imageApp", "jpg", "jpg,png,jpeg"),

    DOC("userDoc", "doc", "doc"),

    EXCEL("excel", "xlsx", "xlsx");

    UploadFolderEnum(String folderName, String suffix) {
        this.folderName = folderName;
        this.suffix = suffix;
    }

    UploadFolderEnum(String folderName, String suffix, String fileType) {
        this.folderName = folderName;  // 文件路径
        this.suffix = suffix;  // 默认后缀
        this.fileType = fileType;  // 文件 准许后缀类型
    }

    private String folderName;

    private String suffix;

    private String fileType;

    public String getFolderName() {
        return folderName;
    }

    public String doDateFilePath() {
        return "/" + this.folderName ; //DateUtil.getCurDate();
    }

    public String getNowDate() {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String time = df.format(new Date());
        return time;
    }

    public String getDefaultFileName(String suffix) {
        if (fileType.contains(suffix)) {
            return CommonUtil.retrieveUUID() + "." + suffix;
        }
        return getDefaultFileName();
    }

    public String getDefaultFileName() {
        return CommonUtil.retrieveUUID() + "." + suffix;
    }


}
