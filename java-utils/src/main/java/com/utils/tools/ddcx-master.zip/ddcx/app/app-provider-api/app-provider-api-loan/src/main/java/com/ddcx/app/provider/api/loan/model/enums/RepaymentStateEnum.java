package com.ddcx.app.provider.api.loan.model.enums;

public enum  RepaymentStateEnum {

    WAIT((byte)0,"待还款"),ALREADY((byte)1,"已还款"), OVERDUE((byte)2,"已逾期");

    private Byte code;

    private String msg;

    RepaymentStateEnum(Byte code, String msg) {
        this.code = code;
        this.msg = msg;
    }


    public Byte getCode() {
        return code;
    }

    public void setCode(Byte code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
