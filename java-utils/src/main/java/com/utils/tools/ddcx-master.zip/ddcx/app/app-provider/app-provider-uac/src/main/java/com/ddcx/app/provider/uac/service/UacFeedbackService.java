package com.ddcx.app.provider.uac.service;

import com.ddcx.app.provider.api.uac.model.dto.UacFeedbackDto;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.service.IService;
import com.ddcx.model.uac.UacFeedback;

public interface UacFeedbackService extends IService<UacFeedback> {

    Boolean create(LoginAuthDto loginAuthDto, UacFeedbackDto uacFeedbackDto);
}
