package com.ddcx.app.provider.api.uac.enums;

public enum UacErrorCodeEnum {

    UAC20000001(20000001, "账号不存在"),
    UAC20000002(20000002, "密码错误"),
    UAC20000003(20000003, "用户不存在"),
    UAC20000004(20000004, "账号已存在"),
    UAC20000005(20000005, "手机号未注册"),
    UAC20000006(20000006, "银行卡号错误"),
    UAC20000007(20000007, "银行卡号已存在"),
    UAC20000008(20000008, "账号被锁定，无法登录"),
    UAC20000009(20000009, "请进入APP端注册并提交信息");

    private int code;
    private String msg;

    /**
     * Msg string.
     *
     * @return the string
     */
    public String msg() {
        return msg;
    }

    /**
     * Code int.
     *
     * @return the int
     */
    public int code() {
        return code;
    }

    UacErrorCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    /**
     * Gets enum.
     *
     * @param code the code
     * @return the enum
     */
    public static UacErrorCodeEnum getEnum(int code) {
        for (UacErrorCodeEnum ele : UacErrorCodeEnum.values()) {
            if (ele.code() == code) {
                return ele;
            }
        }
        return null;
    }

}
