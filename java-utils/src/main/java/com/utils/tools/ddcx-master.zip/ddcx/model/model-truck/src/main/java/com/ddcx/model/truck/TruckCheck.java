package com.ddcx.model.truck;

import com.ddcx.framework.base.annotation.ExcelName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Table(name = "truck_check")
@ApiModel("检查台账存档表")
public class TruckCheck {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("")
    private Long id;

    /**
     * 车辆主键
     */
    @Column(name = "truck_id")
    @ApiModelProperty(value = "",required = true)
    @NotNull(message = "车辆主键不能为空")
    private Long truckId;

    /**
     * 车牌号
     */
    @Column(name = "truck_num")
    @ApiModelProperty("车牌号")
    private String truckNum;

    /**
     * 司机姓名
     */
    @Column(name = "driver_name")
    @ApiModelProperty("司机姓名")
    private String driverName;

    /**
     * 检查时间
     */
    @Column(name = "check_time")
    @ApiModelProperty("检查时间")
    @ExcelName(value = "检查时间",isTimestamp = true)
    private Long checkTime;

    /**
     * 行车证件
     */
    @ApiModelProperty("行车证件")
    @ExcelName(value = "行车证件",replaceNumber = {"正常","异常"})
    private Byte certificate=0;

    /**
     * 安全带
     */
    @Column(name = "safety_belt")
    @ApiModelProperty("安全带")
    @ExcelName(value = "安全带",replaceNumber = {"正常","异常"})
    private Byte safetyBelt=0;

    /**
     * 离合及换挡操作情况
     */
    @Column(name = "shift_op")
    @ApiModelProperty("离合及换挡操作情况")
    @ExcelName(value = "离合及换挡操作情况",replaceNumber = {"正常","异常"})
    private Byte shiftOp=0;

    /**
     * 转向系统
     */
    @ApiModelProperty("转向系统")
    @ExcelName(value = "转向系统",replaceNumber = {"正常","异常"})
    private Byte steering=0;

    /**
     * 刹车系统
     */
    @Column(name = "brake_op")
    @ApiModelProperty("刹车系统")
    @ExcelName(value = "刹车系统",replaceNumber = {"正常","异常"})
    private Byte brakeOp=0;

    /**
     * 轮胎
     */
    @ApiModelProperty("轮胎")
    @ExcelName(value = "轮胎",replaceNumber = {"正常","异常"})
    private Byte tire=0;

    /**
     * 底盘、钢板总成
     */
    @ApiModelProperty("底盘、钢板总成")
    @ExcelName(value = "底盘、钢板总成",replaceNumber = {"正常","异常"})
    private Byte underpan=0;

    /**
     * 引擎
     */
    @ApiModelProperty("引擎")
    @ExcelName(value = "引擎",replaceNumber = {"正常","异常"})
    private Byte engine=0;

    /**
     * 油电路
     */
    @Column(name = "oil_circuit")
    @ApiModelProperty("油电路")
    @ExcelName(value = "油电路",replaceNumber = {"正常","异常"})
    private Byte oilCircuit=0;

    /**
     * 喇叭
     */
    @ApiModelProperty("喇叭")
    @ExcelName(value = "喇叭",replaceNumber = {"正常","异常"})
    private Byte trumpet=0;

    /**
     * 雨刮
     */
    @ApiModelProperty("雨刮")
    @ExcelName(value = "雨刮",replaceNumber = {"正常","异常"})
    private Byte wiper=0;

    /**
     * 车门锁
     */
    @Column(name = "door_lock")
    @ApiModelProperty("车门锁")
    @ExcelName(value = "车门锁",replaceNumber = {"正常","异常"})
    private Byte doorLock=0;

    /**
     * 左右及车内后视镜
     */
    @ApiModelProperty("左右及车内后视镜")
    @ExcelName(value = "左右及车内后视镜",replaceNumber = {"正常","异常"})
    private Byte mirror=0;

    /**
     * 车灯
     */
    @ApiModelProperty("车灯")
    @ExcelName(value = "车灯",replaceNumber = {"正常","异常"})
    private Byte lamplight=0;

    /**
     * 车牌照
     */
    @Column(name = "license_plate")
    @ApiModelProperty("车牌照")
    @ExcelName(value = "车牌照",replaceNumber = {"正常","异常"})
    private Byte licensePlate=0;

    /**
     * 仪表指示
     */
    @Column(name = "dash_board")
    @ApiModelProperty("仪表指示")
    @ExcelName(value = "仪表指示",replaceNumber = {"正常","异常"})
    private Byte dashBoard=0;

    /**
     * 车辆外观
     */
    @ApiModelProperty("车辆外观")
    @ExcelName(value = "车辆外观",replaceNumber = {"正常","异常"})
    private Byte appearance=0;

    /**
     * 车辆常备工具
     */
    @ApiModelProperty("车辆常备工具")
    @ExcelName(value = "车辆常备工具",replaceNumber = {"正常","异常"})
    private Byte repertory=0;

    /**
     * 防滑链
     */
    @Column(name = "tire_chain")
    @ApiModelProperty("防滑链")
    @ExcelName(value = "防滑链",replaceNumber = {"正常","异常"})
    private Byte tireChain=0;

    /**
     * 前后保险杠
     */
    @ApiModelProperty("前后保险杠")
    @ExcelName(value = "前后保险杠",replaceNumber = {"正常","异常"})
    private Byte bumper=0;

    /**
     * GPS
     */
    @ApiModelProperty("GPS")
    @ExcelName(value = "GPS",replaceNumber = {"正常","异常"})
    private Byte gps=0;

    /**
     * 整改情况 0,无需整改 1.已整改 2.未整改
     */
    @ApiModelProperty("改情况 0,无需整改 1.已整改 2.未整改")
    @ExcelName(value = "整改情况",replaceNumber = {"无需整改","已整改","未整改"})
    private Byte rectification=0;

    /**
     * 检查员姓名（可不在本系统内）
     */
    @Column(name = "check_name")
    @ApiModelProperty("检查员姓名（可不在本系统内）")
    @ExcelName(value = "检查员姓名")
    private String checkName;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取车辆主键
     *
     * @return truck_id - 车辆主键
     */
    public Long getTruckId() {
        return truckId;
    }

    /**
     * 设置车辆主键
     *
     * @param truckId 车辆主键
     */
    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    /**
     * 获取车牌号
     *
     * @return truck_num - 车牌号
     */
    public String getTruckNum() {
        return truckNum;
    }

    /**
     * 设置车牌号
     *
     * @param truckNum 车牌号
     */
    public void setTruckNum(String truckNum) {
        this.truckNum = truckNum;
    }

    /**
     * 获取司机姓名
     *
     * @return driver_name - 司机姓名
     */
    public String getDriverName() {
        return driverName;
    }

    /**
     * 设置司机姓名
     *
     * @param driverName 司机姓名
     */
    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    /**
     * 获取检查时间
     *
     * @return check_time - 检查时间
     */
    public Long getCheckTime() {
        return checkTime;
    }

    /**
     * 设置检查时间
     *
     * @param checkTime 检查时间
     */
    public void setCheckTime(Long checkTime) {
        this.checkTime = checkTime;
    }

    /**
     * 获取行车证件
     *
     * @return certificate - 行车证件
     */
    public Byte getCertificate() {
        return certificate;
    }

    /**
     * 设置行车证件
     *
     * @param certificate 行车证件
     */
    public void setCertificate(Byte certificate) {
        this.certificate = certificate;
    }

    /**
     * 获取安全带
     *
     * @return safety_belt - 安全带
     */
    public Byte getSafetyBelt() {
        return safetyBelt;
    }

    /**
     * 设置安全带
     *
     * @param safetyBelt 安全带
     */
    public void setSafetyBelt(Byte safetyBelt) {
        this.safetyBelt = safetyBelt;
    }

    /**
     * 获取离合及换挡操作情况
     *
     * @return shift_op - 离合及换挡操作情况
     */
    public Byte getShiftOp() {
        return shiftOp;
    }

    /**
     * 设置离合及换挡操作情况
     *
     * @param shiftOp 离合及换挡操作情况
     */
    public void setShiftOp(Byte shiftOp) {
        this.shiftOp = shiftOp;
    }

    /**
     * 获取转向系统
     *
     * @return steering - 转向系统
     */
    public Byte getSteering() {
        return steering;
    }

    /**
     * 设置转向系统
     *
     * @param steering 转向系统
     */
    public void setSteering(Byte steering) {
        this.steering = steering;
    }

    /**
     * 获取刹车系统
     *
     * @return brake_op - 刹车系统
     */
    public Byte getBrakeOp() {
        return brakeOp;
    }

    /**
     * 设置刹车系统
     *
     * @param brakeOp 刹车系统
     */
    public void setBrakeOp(Byte brakeOp) {
        this.brakeOp = brakeOp;
    }

    /**
     * 获取轮胎
     *
     * @return tire - 轮胎
     */
    public Byte getTire() {
        return tire;
    }

    /**
     * 设置轮胎
     *
     * @param tire 轮胎
     */
    public void setTire(Byte tire) {
        this.tire = tire;
    }

    /**
     * 获取底盘、钢板总成
     *
     * @return underpan - 底盘、钢板总成
     */
    public Byte getUnderpan() {
        return underpan;
    }

    /**
     * 设置底盘、钢板总成
     *
     * @param underpan 底盘、钢板总成
     */
    public void setUnderpan(Byte underpan) {
        this.underpan = underpan;
    }

    /**
     * 获取引擎
     *
     * @return engine - 引擎
     */
    public Byte getEngine() {
        return engine;
    }

    /**
     * 设置引擎
     *
     * @param engine 引擎
     */
    public void setEngine(Byte engine) {
        this.engine = engine;
    }

    /**
     * 获取油电路
     *
     * @return oil_circuit - 油电路
     */
    public Byte getOilCircuit() {
        return oilCircuit;
    }

    /**
     * 设置油电路
     *
     * @param oilCircuit 油电路
     */
    public void setOilCircuit(Byte oilCircuit) {
        this.oilCircuit = oilCircuit;
    }

    /**
     * 获取喇叭
     *
     * @return trumpet - 喇叭
     */
    public Byte getTrumpet() {
        return trumpet;
    }

    /**
     * 设置喇叭
     *
     * @param trumpet 喇叭
     */
    public void setTrumpet(Byte trumpet) {
        this.trumpet = trumpet;
    }

    /**
     * 获取雨刮
     *
     * @return wiper - 雨刮
     */
    public Byte getWiper() {
        return wiper;
    }

    /**
     * 设置雨刮
     *
     * @param wiper 雨刮
     */
    public void setWiper(Byte wiper) {
        this.wiper = wiper;
    }

    /**
     * 获取车门锁
     *
     * @return door_lock - 车门锁
     */
    public Byte getDoorLock() {
        return doorLock;
    }

    /**
     * 设置车门锁
     *
     * @param doorLock 车门锁
     */
    public void setDoorLock(Byte doorLock) {
        this.doorLock = doorLock;
    }

    /**
     * 获取左右及车内后视镜
     *
     * @return mirror - 左右及车内后视镜
     */
    public Byte getMirror() {
        return mirror;
    }

    /**
     * 设置左右及车内后视镜
     *
     * @param mirror 左右及车内后视镜
     */
    public void setMirror(Byte mirror) {
        this.mirror = mirror;
    }

    /**
     * 获取车灯
     *
     * @return lamplight - 车灯
     */
    public Byte getLamplight() {
        return lamplight;
    }

    /**
     * 设置车灯
     *
     * @param lamplight 车灯
     */
    public void setLamplight(Byte lamplight) {
        this.lamplight = lamplight;
    }

    /**
     * 获取车牌照
     *
     * @return license_plate - 车牌照
     */
    public Byte getLicensePlate() {
        return licensePlate;
    }

    /**
     * 设置车牌照
     *
     * @param licensePlate 车牌照
     */
    public void setLicensePlate(Byte licensePlate) {
        this.licensePlate = licensePlate;
    }

    /**
     * 获取仪表指示
     *
     * @return dash_board - 仪表指示
     */
    public Byte getDashBoard() {
        return dashBoard;
    }

    /**
     * 设置仪表指示
     *
     * @param dashBoard 仪表指示
     */
    public void setDashBoard(Byte dashBoard) {
        this.dashBoard = dashBoard;
    }

    /**
     * 获取车辆外观
     *
     * @return appearance - 车辆外观
     */
    public Byte getAppearance() {
        return appearance;
    }

    /**
     * 设置车辆外观
     *
     * @param appearance 车辆外观
     */
    public void setAppearance(Byte appearance) {
        this.appearance = appearance;
    }

    /**
     * 获取车辆常备工具
     *
     * @return repertory - 车辆常备工具
     */
    public Byte getRepertory() {
        return repertory;
    }

    /**
     * 设置车辆常备工具
     *
     * @param repertory 车辆常备工具
     */
    public void setRepertory(Byte repertory) {
        this.repertory = repertory;
    }

    /**
     * 获取防滑链
     *
     * @return tire_chain - 防滑链
     */
    public Byte getTireChain() {
        return tireChain;
    }

    /**
     * 设置防滑链
     *
     * @param tireChain 防滑链
     */
    public void setTireChain(Byte tireChain) {
        this.tireChain = tireChain;
    }

    /**
     * 获取前后保险杠
     *
     * @return bumper - 前后保险杠
     */
    public Byte getBumper() {
        return bumper;
    }

    /**
     * 设置前后保险杠
     *
     * @param bumper 前后保险杠
     */
    public void setBumper(Byte bumper) {
        this.bumper = bumper;
    }

    /**
     * 获取GPS
     *
     * @return gps - GPS
     */
    public Byte getGps() {
        return gps;
    }

    /**
     * 设置GPS
     *
     * @param gps GPS
     */
    public void setGps(Byte gps) {
        this.gps = gps;
    }

    /**
     * 获取整改情况 0,无需整改 1.已整改 2.未整改
     *
     * @return rectification - 整改情况 0,无需整改 1.已整改 2.未整改
     */
    public Byte getRectification() {
        return rectification;
    }

    /**
     * 设置整改情况 0,无需整改 1.已整改 2.未整改
     *
     * @param rectification 整改情况 0,无需整改 1.已整改 2.未整改
     */
    public void setRectification(Byte rectification) {
        this.rectification = rectification;
    }

    /**
     * 获取检查员姓名（可不在本系统内）
     *
     * @return check_name - 检查员姓名（可不在本系统内）
     */
    public String getCheckName() {
        return checkName;
    }

    /**
     * 设置检查员姓名（可不在本系统内）
     *
     * @param checkName 检查员姓名（可不在本系统内）
     */
    public void setCheckName(String checkName) {
        this.checkName = checkName;
    }
}