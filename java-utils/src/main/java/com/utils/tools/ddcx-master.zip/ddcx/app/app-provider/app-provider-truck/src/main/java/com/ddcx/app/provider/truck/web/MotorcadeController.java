package com.ddcx.app.provider.truck.web;


import com.ddcx.app.provider.truck.service.MotorcadeService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.Motorcade;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/09.
 */
@RestController
@RequestMapping("/motorcade")
@Api(value = "车队模块",tags = "车队模块")
public class MotorcadeController extends BaseController {
    @Resource
    private MotorcadeService motorcadeService;


    @ApiOperation("根据公司名称查询出所有车队")
    @GetMapping("/getMotorcadeByComName")
    public Wrapper<List<Motorcade>> getMotorcadeByComName(@ApiParam(value = "企业名称")@RequestParam(required = false) String comName){
        return motorcadeService.getMotorcadeByComName(comName);
    }









}
