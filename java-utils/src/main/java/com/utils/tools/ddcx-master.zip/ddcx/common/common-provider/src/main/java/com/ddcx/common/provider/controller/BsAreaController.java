package com.ddcx.common.provider.controller;


import com.ddcx.common.provider.service.BsAreaService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/03/23.
*/
@RestController
@RequestMapping("/bs/area")
public class BsAreaController {
    @Resource
    private BsAreaService bsAreaService;

}
