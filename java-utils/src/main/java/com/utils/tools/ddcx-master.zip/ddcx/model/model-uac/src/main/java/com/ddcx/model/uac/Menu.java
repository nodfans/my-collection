package com.ddcx.model.uac;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@ApiModel("菜单")
public class Menu {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    /**
     * 菜单名称
     */
    @ApiModelProperty("菜单名称")
    @Column(name = "menu_name")
    private String menuName;

    /**
     * 菜单描述
     */
    @ApiModelProperty("菜单描述")
    @Column(name = "menu_description")
    private String menuDescription;

    /**
     * 父节点
     */
    @ApiModelProperty("父节点")
    @Column(name = "parent_menu_id")
    private Long parentMenuId;

    /**
     * 显示顺序
     */
    @ApiModelProperty("显示顺序")
    @Column(name = "display_order")
    private Byte displayOrder;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取菜单名称
     *
     * @return menu_name - 菜单名称
     */
    public String getMenuName() {
        return menuName;
    }

    /**
     * 设置菜单名称
     *
     * @param menuName 菜单名称
     */
    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    /**
     * 获取菜单描述
     *
     * @return menu_description - 菜单描述
     */
    public String getMenuDescription() {
        return menuDescription;
    }

    /**
     * 设置菜单描述
     *
     * @param menuDescription 菜单描述
     */
    public void setMenuDescription(String menuDescription) {
        this.menuDescription = menuDescription;
    }

    /**
     * 获取父节点
     *
     * @return parent_menu_id - 父节点
     */
    public Long getParentMenuId() {
        return parentMenuId;
    }

    /**
     * 设置父节点
     *
     * @param parentMenuId 父节点
     */
    public void setParentMenuId(Long parentMenuId) {
        this.parentMenuId = parentMenuId;
    }

    /**
     * 获取显示顺序
     *
     * @return display_order - 显示顺序
     */
    public Byte getDisplayOrder() {
        return displayOrder;
    }

    /**
     * 设置显示顺序
     *
     * @param displayOrder 显示顺序
     */
    public void setDisplayOrder(Byte displayOrder) {
        this.displayOrder = displayOrder;
    }
}