package com.ddcx.app.provider.truck.service.impl;


import com.ddcx.app.provider.truck.mapper.VehAccidentRepMapper;
import com.ddcx.app.provider.truck.service.VehAccidentRepService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.VehAccidentRep;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/03/10.
 */
@Service
@Transactional
public class VehAccidentRepServiceImpl extends BaseService<VehAccidentRep> implements VehAccidentRepService {
    @Resource
    private VehAccidentRepMapper vehAccidentRepMapper;

    @Override
    public Wrapper add(VehAccidentRep rep, LoginAuthDto dto) {
        rep.setuId(dto.getUserId());
        rep.setuName(dto.getUserName());
        rep.setId(generateId());
        rep.setCreateTime(System.currentTimeMillis()/1000);
        rep.setMotorcadeId(dto.getMotorcadeId());
        rep.setComId(dto.getComId());
        vehAccidentRepMapper.insert(rep);
        return WrapMapper.ok();
    }
}
