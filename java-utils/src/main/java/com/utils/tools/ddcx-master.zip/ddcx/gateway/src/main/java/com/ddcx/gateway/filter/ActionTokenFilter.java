//package com.ddcx.gateway.filter;
//
//import com.ddcx.framework.base.constant.GlobalConstant;
//import com.ddcx.framework.base.dto.ActionTokenDto;
//import com.ddcx.framework.base.enums.ErrorCodeEnum;
//import com.ddcx.framework.core.redis.RedisUtil;
//import com.ddcx.framework.util.PublicUtil;
//import com.netflix.zuul.ZuulFilter;
//import com.netflix.zuul.context.RequestContext;
//import com.netflix.zuul.exception.ZuulException;
//import lombok.Data;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.codec.binary.Base64;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.cloud.netflix.zuul.filters.support.FilterConstants;
//import org.springframework.stereotype.Component;
//
//import javax.servlet.http.HttpServletRequest;
//import java.util.List;
//
//@Data
//@Slf4j
//@Component
//@ConfigurationProperties(prefix = "action")
//public class ActionTokenFilter extends ZuulFilter {
//    private List<String> token;
//
//    @Autowired
//    private RedisUtil redisUtil;
//
//    @Override
//    public String filterType() {
//        //前置过滤器
//        return FilterConstants.PRE_TYPE;
//    }
//
//    @Override
//    public int filterOrder() {
//        //优先级，数字越大，优先级越低
//        return 1;
//    }
//
//    @Override
//    public boolean shouldFilter() {
//        //是否执行该过滤器，true代表需要过滤
//        return true;
//    }
//
//    @Override
//    public Object run() throws ZuulException {
//        log.info("AuthHeaderFilter - 开始鉴权...");
//        RequestContext requestContext = RequestContext.getCurrentContext();
//        doSomething(requestContext);
//        return null;
//    }
//
//    private void doSomething(RequestContext requestContext) throws ZuulException {
//        HttpServletRequest request = requestContext.getRequest();
//        String requestURI = request.getRequestURI();
//        log.info("The request url {}", requestURI);
//        if (PublicUtil.isNotEmpty(token)) {
//            for (String need : token) {
//                if (requestURI.contains(need)) {
//                    String actionToken = request.getHeader("actionToken");
//                    if (PublicUtil.isEmpty(actionToken)) {
//                        throw new ZuulException("刷新页面重试", ErrorCodeEnum.GL99990102.code(), ErrorCodeEnum.GL99990101.msg());
//                    }
//                    actionToken = new String(Base64.decodeBase64(actionToken));
//                    log.info("actionToken>>>>>> {}", actionToken);
//                    String[] strs = actionToken.split(":");
//                    String account = strs[2];
//                    ActionTokenDto actionTokenDto = (ActionTokenDto) redisUtil.get(GlobalConstant.Sys.ACTION_TOKEN + ":" + account);
//                    if (PublicUtil.isEmpty(actionTokenDto)) {
//                        throw new ZuulException("刷新页面重试", ErrorCodeEnum.GL99990102.code(), ErrorCodeEnum.GL99990101.msg());
//                    }
//                    redisUtil.del(GlobalConstant.Sys.ACTION_TOKEN + ":" + account);
//                    return;
//                }
//            }
//        }
//    }
//}
