package com.ddcx.framework.base.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

@Data
public class BaseDto implements java.io.Serializable {
    private static final long serialVersionUID = -1307910255489451653L;

    @JsonIgnore
    public boolean isNew() {
        if (ClassUtil.isNotEmptyBean(this)) {
            return true;
        }
        return false;
    }
}
