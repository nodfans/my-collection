package com.ddcx.model.exam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.Column;
import javax.persistence.Table;

@Table(name = "question_room")
@ApiModel("试题考场关系")
public class QuestionRoom {
    /**
     * 考场主键
     */
    @Column(name = "room_id")
    @ApiModelProperty("考场主键")
    private Long roomId;

    /**
     * 试题主键
     */
    @ApiModelProperty("试题主键")
    @Column(name = "question_id")
    private Long questionId;


    /**
     * 试题类型 ： 1.单选 2. 多选 3.判断
     */
    @ApiModelProperty(".单选 2. 多选 3.判断")
    private Byte type;

    @ApiModelProperty("考题编号")
    private Integer questionNum;


    public Integer getQuestionNum() {
        return questionNum;
    }

    public void setQuestionNum(Integer questionNum) {
        this.questionNum = questionNum;
    }

    /**
     * 获取考场主键
     *
     * @return room_id - 考场主键
     */
    public Long getRoomId() {
        return roomId;
    }

    /**
     * 设置考场主键
     *
     * @param roomId 考场主键
     */
    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    /**
     * 获取试题主键
     *
     * @return question_id - 试题主键
     */
    public Long getQuestionId() {
        return questionId;
    }

    /**
     * 设置试题主键
     *
     * @param questionId 试题主键
     */
    public void setQuestionId(Long questionId) {
        this.questionId = questionId;
    }


    public Byte getType() {
        return type;
    }

    public void setType(Byte type) {
        this.type = type;
    }
}