package com.ddcx.common.provider.util;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 极光推送配置信息
 *
 * @author 葫芦娃
 */
@Component("jpushConfig")
@Data
public class JpushConfig {

    // 读取极光配置信息中的用户名密码
    @Value("${jpush.appKey}")
    private String appkey;
    @Value("${jpush.masterSecret}")
    private String masterSecret;
    @Value("${jpush.liveTime}")
    private String liveTime;

}
