package com.ddcx.model.uac;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;


@ApiModel("角色对象")
public class Role implements Serializable {

    private static final long serialVersionUID=-5700854022428004580L;

    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long id;

    /**
     * 角色名称
     */
    @Column(name = "role_name")
    @NotBlank(message = "角色名称不能为空")
    @ApiModelProperty(value = "角色名称", required = true)
    private String roleName;

    /**
     * 角色描述
     */
    @Column(name = "role_desc")
//    @NotBlank(message = "角色描述不能为空")
    @ApiModelProperty(value = "角色描述")
    private String roleDesc;

    /**
     * 是否有效 1--有效 2--无效
     */
    @Column(name = "effect_tag")
    @ApiModelProperty(value = "是否有效 1--有效 0--无效 ")
    private Byte effectTag;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    @ApiModelProperty(value = "创建时间")
    private Long createDate;

    /**
     * 创建人
     */
    @Column(name = "create_by")
    @ApiModelProperty(value = "创建人主键")
    private Long createBy;

    /**
     * 修改时间
     */
    @Column(name = "update_date")
    @ApiModelProperty(value = "修改时间")
    private Long updateDate;

    /**
     * 修改人
     */
    @Column(name = "update_by")
    @ApiModelProperty(value = "修改人id")
    private Long updateBy;


    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取角色名称
     *
     * @return role_name - 角色名称
     */
    public String getRoleName() {
        return roleName;
    }

    /**
     * 设置角色名称
     *
     * @param roleName 角色名称
     */
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    /**
     * 获取角色描述
     *
     * @return role_desc - 角色描述
     */
    public String getRoleDesc() {
        return roleDesc;
    }

    /**
     * 设置角色描述
     *
     * @param roleDesc 角色描述
     */
    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    /**
     * 获取是否有效 1--有效 2--无效
     *
     * @return effect_tag - 是否有效 1--有效 2--无效
     */
    public Byte getEffectTag() {
        return effectTag;
    }

    /**
     * 设置是否有效 1--有效 2--无效
     *
     * @param effectTag 是否有效 1--有效 2--无效
     */
    public void setEffectTag(Byte effectTag) {
        this.effectTag = effectTag;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Long getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Long createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取创建人
     *
     * @return create_by - 创建人
     */
    public Long getCreateBy() {
        return createBy;
    }

    /**
     * 设置创建人
     *
     * @param createBy 创建人
     */
    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    /**
     * 获取修改时间
     *
     * @return update_date - 修改时间
     */
    public Long getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置修改时间
     *
     * @param updateDate 修改时间
     */
    public void setUpdateDate(Long updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 获取修改人
     *
     * @return update_by - 修改人
     */
    public Long getUpdateBy() {
        return updateBy;
    }

    /**
     * 设置修改人
     *
     * @param updateBy 修改人
     */
    public void setUpdateBy(Long updateBy) {
        this.updateBy = updateBy;
    }

}