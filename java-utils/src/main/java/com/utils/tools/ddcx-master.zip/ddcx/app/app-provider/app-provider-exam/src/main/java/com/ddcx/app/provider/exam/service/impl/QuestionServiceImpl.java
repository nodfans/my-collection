package com.ddcx.app.provider.exam.service.impl;


import com.ddcx.app.provider.exam.mapper.QuestionMapper;
import com.ddcx.app.provider.exam.service.QuestionService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/03/11.
 */
@Service
@Transactional
public class QuestionServiceImpl  implements QuestionService {
    @Resource
    private QuestionMapper questionMapper;

}
