package com.ddcx.app.provider.truck.service;


import com.ddcx.app.provider.api.truck.model.param.ARUParam;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.Truck;

import java.util.List;

/**
 * Created by CodeGenerator on 2020/02/28.
 */
public interface TruckService {

    /**
     * 获取用户汽车信息
     *
     * @param userId 用户id
     * @return
     */
    Wrapper<List<Truck>> getOwnTrucks(Long userId);

    /**
     * 获取汽车详情
     *
     * @param id     汽车主键
     * @param userId 用户主键
     * @return
     */
    Wrapper<Truck> getTruckDetail(Long id, Long userId);


    /**
     * 更换司机
     *
     * @param truckId     汽车主键
     * @param newDriverId 新司机主键
     * @param oldDriverId 旧司机主键
     * @param userId      当前用户主键
     * @return
     */
    Wrapper updateTruckDriver(Long truckId, Long newDriverId, Long oldDriverId, Long userId);

    /**
     * 解除汽车的司机绑定关系
     *
     * @param truckId     汽车主键
     * @param oldDriverId 就司机主键
     * @param userId      当前用户主键
     * @return
     */
    Wrapper clearTruckBinding(Long truckId, Long oldDriverId, Long userId);


    /**
     * 更新年检，续保，保养信息
     * @return
     */
    Wrapper updateTruckARU(ARUParam param, Long userId);

    Wrapper cancelSale(Long truckId,Long userId);

    Wrapper getTruckSelects(LoginAuthDto dto);

    Wrapper getOwnTruckInsurances(Integer page,Integer size,LoginAuthDto dto);
}
