package com.ddcx.common.provider.api.zhiyun;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("里程信息")
@Data
public class ZhiYunMileageStatistics {

    @ApiModelProperty("行驶总里程数")
    private String mileage;
    @ApiModelProperty("起点时间")
    private String startTime;
    @ApiModelProperty("终点时间")
    private String endTime;
    @ApiModelProperty("起点位置经纬度")
    private String startLonLat;
    @ApiModelProperty("起点位置描述")
    private String start;
    @ApiModelProperty("终点位置经纬度")
    private String endLonLat;
    @ApiModelProperty("终点位置描述")
    private String end;










}
