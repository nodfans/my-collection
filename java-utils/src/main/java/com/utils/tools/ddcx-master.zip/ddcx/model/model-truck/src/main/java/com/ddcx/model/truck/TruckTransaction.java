package com.ddcx.model.truck;

import com.ddcx.framework.util.StringUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

@Table(name = "truck_transaction")
@ApiModel(value = "汽车（交易）")
public class TruckTransaction {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long id;

    /**
     * 汽车品牌
     */
    @NotBlank(message = "汽车品牌不能为空")
    @ApiModelProperty(value = "汽车品牌", required = true)
    private String brand;

    /**
     * 车型
     */
    @NotBlank(message = "车型不能为空")
    @ApiModelProperty(value = "车型", required = true)
    private String type;

    @NotBlank(message = "发动机型号不能为空")
    @ApiModelProperty(value = "发动机型号", required = true)
    private String engineType;

    @NotNull(message = "马力不能为空")
    @ApiModelProperty(value = "马力（匹）", required = true)
    private Float horsepower;

    /**
     * 购买时间
     */
//    @NotNull(message = "购买时间不能为空")
    @ApiModelProperty(value = "购买时间<暂时不用>")
    @Column(name = "buy_date")
    private Long buyDate;

    /**
     * 表显里程(万公里)
     */
    @NotNull(message = "表显里程(万公里)不能为空")
    @ApiModelProperty(value = "表显里程(万公里)", required = true)
    private Float mileage;

    /**
     * 排量（升）<废弃不再使用>
     */
    @ApiModelProperty(value = "排量（升）<废弃不再使用>")
    private Float displacement;

    /**
     * 购买价格（元）
     */
    @NotNull(message = "购买价格（元）不能为空")
    @ApiModelProperty(value = "购买价格（元）", required = true)
    @Column(name = "buy_price")
    private BigDecimal buyPrice;

    /**
     * 出售价格（元）
     */
    @NotNull(message = "出售价格（元）不能为空")
    @ApiModelProperty(value = "出售价格（元）", required = true)
    @Column(name = "sale_price")
    private BigDecimal salePrice;

    /**
     * 车辆照片(用分号分开链接)
     */
//    @NotBlank(message = "车辆照片不能为空")
    @ApiModelProperty(value = "车辆照片(用分号分开链接)", required = true)
    private String picture;

    @ApiModelProperty(value = "车辆照片列表", required = true)
    private List<String> pictureList;


    /**
     * 几成新
     */
//    @NotNull(message = "成新不能为空")
    @ApiModelProperty(value = "几成新<废弃>")
    private Float newLevel;

    /**
     * 添加日期
     */
    @ApiModelProperty(value = "添加日期")
    @Column(name = "create_time")
    private Long createTime;

    @ApiModelProperty(value = "创建者id")
    @Column(name = "user_id")
    private Long userId;

    @NotNull
    @ApiModelProperty(value = "车辆归属地", required = true)
    @Column(name = "own_address")
    private String ownAddress;

    @NotNull(message = "行驶证登记日期不能为空")
    @Column(name = "login_date")
    @ApiModelProperty(value = "行驶证登记日期", required = true)
    private Long loginDate;

    @NotBlank(message = "驱动形式不能为空")
    @Column(name = "drive_type")
    @ApiModelProperty(value = "驱动形式", required = true)
    private String driveType;

    @NotBlank(message = "环保标准不能为空")
    @Column(name = "e_standard")
    @ApiModelProperty(value = "环保标准", required = true)
    private String eStandard;

    @Column(name = "truck_length")
    @ApiModelProperty(value = "车辆长度（米）")
    private Float truckLength;

    @Column(name = "load_weight")
    @ApiModelProperty(value = "车辆载重（吨）")
    private Float loadWeight;

    @Column(name = "user_name")
    @ApiModelProperty(value = "联系人姓名")
    private String userName;

    @Column(name = "user_phone")
    @ApiModelProperty(value = "联系人手机号码")
    private String userPhone;

    @ApiModelProperty(value = "出售类型：1.原有 2.新增")
    @Column(name = "sale_type")
    private Byte saleType;

    @ApiModelProperty(value = "模板车辆id（出售类型为原有时生效）")
    @Column(name = "truck_id")
    private Long truckId;

    @ApiModelProperty(value = "来源： 1. 平台 2.客户端")
    @Column(name = "from_type")
    private Byte fromType;


    public List<String> getPictureList() {
        return pictureList;
    }

    public void setPictureList(List<String> pictureList) {
        this.pictureList = pictureList;
        if(pictureList!=null&&pictureList.size()>0){
            picture="";
            for (String s : pictureList) {
                picture+=s+";";
            }
            picture=picture.substring(0,picture.length()-1);
        }
    }

    public Byte getFromType() {
        return fromType;
    }

    public void setFromType(Byte fromType) {
        this.fromType = fromType;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }


    public Byte getSaleType() {
        return saleType;
    }

    public void setSaleType(Byte saleType) {
        this.saleType = saleType;
    }

    public Long getTruckId() {
        return truckId;
    }

    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getOwnAddress() {
        return ownAddress;
    }

    public void setOwnAddress(String ownAddress) {
        this.ownAddress = ownAddress;
    }

    public Long getLoginDate() {
        return loginDate;
    }

    public void setLoginDate(Long loginDate) {
        this.loginDate = loginDate;
    }

    public String getDriveType() {
        return driveType;
    }

    public void setDriveType(String driveType) {
        this.driveType = driveType;
    }

    public String geteStandard() {
        return eStandard;
    }

    public void seteStandard(String eStandard) {
        this.eStandard = eStandard;
    }

    public Float getTruckLength() {
        return truckLength;
    }

    public void setTruckLength(Float truckLength) {
        this.truckLength = truckLength;
    }

    public Float getLoadWeight() {
        return loadWeight;
    }

    public void setLoadWeight(Float loadWeight) {
        this.loadWeight = loadWeight;
    }

    /**
     * 获取汽车品牌
     *
     * @return brand - 汽车品牌
     */
    public String getBrand() {
        return brand;
    }

    /**
     * 设置汽车品牌
     *
     * @param brand 汽车品牌
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * 获取车型
     *
     * @return type - 车型
     */
    public String getType() {
        return type;
    }

    /**
     * 设置车型
     *
     * @param type 车型
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 获取购买时间
     *
     * @return buy_date - 购买时间
     */
    public Long getBuyDate() {
        return buyDate;
    }

    /**
     * 设置购买时间
     *
     * @param buyDate 购买时间
     */
    public void setBuyDate(Long buyDate) {
        this.buyDate = buyDate;
    }

    /**
     * 获取表显里程(万公里)
     *
     * @return mileage - 表显里程(万公里)
     */
    public Float getMileage() {
        return mileage;
    }

    /**
     * 设置表显里程(万公里)
     *
     * @param mileage 表显里程(万公里)
     */
    public void setMileage(Float mileage) {
        this.mileage = mileage;
    }

    /**
     * 获取排量（升）
     *
     * @return displacement - 排量（升）
     */
    public Float getDisplacement() {
        return displacement;
    }

    /**
     * 设置排量（升）
     *
     * @param displacement 排量（升）
     */
    public void setDisplacement(Float displacement) {
        this.displacement = displacement;
    }

    /**
     * 获取购买价格（元）
     *
     * @return buy_price - 购买价格（元）
     */
    public BigDecimal getBuyPrice() {
        return buyPrice;
    }

    /**
     * 设置购买价格（元）
     *
     * @param buyPrice 购买价格（元）
     */
    public void setBuyPrice(BigDecimal buyPrice) {
        this.buyPrice = buyPrice;
    }

    /**
     * 获取出售价格（元）
     *
     * @return sale_price - 出售价格（元）
     */
    public BigDecimal getSalePrice() {
        return salePrice;
    }

    /**
     * 设置出售价格（元）
     *
     * @param salePrice 出售价格（元）
     */
    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

    public String getEngineType() {
        return engineType;
    }

    public void setEngineType(String engineType) {
        this.engineType = engineType;
    }

    public Float getHorsepower() {
        return horsepower;
    }

    public void setHorsepower(Float horsepower) {
        this.horsepower = horsepower;
    }

    /**
     * 获取车辆照片(用分号分开链接)
     *
     * @return picture - 车辆照片(用分号分开链接)
     */
    public String getPicture() {
        return picture;
    }

    /**
     * 设置车辆照片(用分号分开链接)
     *
     * @param picture 车辆照片(用分号分开链接)
     */
    public void setPicture(String picture) {
        this.picture = picture;
        if(StringUtils.isNotBlank(picture)){
            pictureList= Arrays.asList(picture.split(";"));
        }
    }

    /**
     * 获取几成新
     *
     * @return newLevel - 几成新
     */
    public Float getNewLevel() {
        return newLevel;
    }

    /**
     * 设置几成新
     *
     * @param newLevel 几成新
     */
    public void setNewLevel(Float newLevel) {
        this.newLevel = newLevel;
    }

    /**
     * 获取添加日期
     *
     * @return create_time - 添加日期
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置添加日期
     *
     * @param createTime 添加日期
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }


}