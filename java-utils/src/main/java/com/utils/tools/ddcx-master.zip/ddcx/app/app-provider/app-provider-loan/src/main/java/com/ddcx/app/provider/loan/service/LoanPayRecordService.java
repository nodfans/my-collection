package com.ddcx.app.provider.loan.service;
/**
 * Created by CodeGenerator on 2020/04/28.
 */
public interface LoanPayRecordService {

}
