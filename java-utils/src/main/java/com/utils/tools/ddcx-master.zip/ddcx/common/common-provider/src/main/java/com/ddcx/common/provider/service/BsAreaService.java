package com.ddcx.common.provider.service;



/**
 * Created by CodeGenerator on 2020/03/23.
 */
public interface BsAreaService {

}
