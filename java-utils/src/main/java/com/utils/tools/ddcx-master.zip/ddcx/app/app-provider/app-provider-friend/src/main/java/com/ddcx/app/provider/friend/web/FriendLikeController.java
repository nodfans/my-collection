package com.ddcx.app.provider.friend.web;


import com.ddcx.app.provider.friend.service.FriendLikeService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/03/02.
 */
@RestController
@RequestMapping("/friend/like")
@Api(value = "卡友圈点赞", tags = "卡友圈点赞")
public class FriendLikeController extends BaseController {
    @Resource
    private FriendLikeService friendLikeService;

    @ApiOperation("卡友圈点赞")
    @GetMapping("/putLike")
    public Wrapper putLike(@ApiParam(value = "卡友圈信息主键", required = true)@RequestParam Long id) {
        return friendLikeService.putLike(id,getLoginAuthDto());
    }

    @ApiOperation("取消卡友圈点赞")
    @GetMapping("/clearLike")
    public Wrapper clearLike(@ApiParam(value = "卡友圈信息主键", required = true) Long id) {
        return friendLikeService.clearLike(id, getLoginAuthDto());
    }

}
