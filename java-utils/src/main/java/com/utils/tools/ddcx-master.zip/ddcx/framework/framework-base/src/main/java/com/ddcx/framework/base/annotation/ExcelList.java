package com.ddcx.framework.base.annotation;

import java.lang.annotation.*;

/**
 * 该注解用于标识类中的集合对象
 */
@Target({ElementType.FIELD, ElementType.TYPE})
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface ExcelList {
    //集合中对象的类型
    Class value();
}
