package com.ddcx.app.provider.uac.service;


import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.SysBanner;

/**
 * Created by CodeGenerator on 2020/03/16.
 */
public interface SysBannerService {



    Wrapper listOfPage(SysBanner banner, Integer page, Integer sizes);


    Wrapper detail(Long id);



}
