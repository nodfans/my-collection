package com.ddcx.app.provider.truck.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.truck.TruckSafeInform;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;


@Component
@Mapper
public interface TruckSafeInformMapper extends MyMapper<TruckSafeInform> {

    @Select("select * from truck_safe_inform where truck_id=#{truckId} order by create_time desc limit 1")
    TruckSafeInform selectByTruckId(@Param("truckId") Long truckId);
}