package com.ddcx.common.provider.api.zhiyun;

import lombok.Data;

@Data
public class ZhiYunResult <T> {

    private T result;

    private Integer status;

}
