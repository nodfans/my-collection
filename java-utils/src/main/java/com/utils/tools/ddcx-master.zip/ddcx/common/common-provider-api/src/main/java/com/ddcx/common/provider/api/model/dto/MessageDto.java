package com.ddcx.common.provider.api.model.dto;

import com.ddcx.model.common.Message;
import com.ddcx.model.common.MessageConfig;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 消息传递
 */
@Data
@ApiModel("消息数据传递")
public class MessageDto {

    @ApiModelProperty("消息对象")
    private Message message;

    @ApiModelProperty("消息主体")
    private MessageConfig messageConfig;

    @ApiModelProperty("对象用户列表")
    private List<Long> userIds;

}
