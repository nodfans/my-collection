package com.ddcx.app.provider.uac.service;

import com.ddcx.app.provider.api.uac.model.dto.UacCreateBankDto;
import com.ddcx.app.provider.api.uac.model.vo.UacBankListVo;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.service.IService;
import com.ddcx.model.uac.UacBank;

import java.util.List;

public interface UacBankService extends IService<UacBank> {

    Boolean create(LoginAuthDto loginAuthDto, UacCreateBankDto uacCreateBankDto);

    Boolean delete(LoginAuthDto loginAuthDto, Long id);

    List<UacBank> getByUserId(Long UserId);

    List<UacBankListVo> list(LoginAuthDto loginAuthDto);

    UacBank getByCardNo(String cardNo);
}
