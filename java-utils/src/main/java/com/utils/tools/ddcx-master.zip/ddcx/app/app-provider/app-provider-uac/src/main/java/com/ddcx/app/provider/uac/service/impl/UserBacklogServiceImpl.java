package com.ddcx.app.provider.uac.service.impl;


import com.ddcx.app.provider.uac.mapper.UserBacklogMapper;
import com.ddcx.app.provider.uac.service.UserBacklogService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.UserBacklog;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/04/17.
 */
@Service
@Transactional
public class UserBacklogServiceImpl implements UserBacklogService {
    @Resource
    private UserBacklogMapper userBacklogMapper;

    @Override
    public Wrapper getUserBackLog(Integer page, Integer size,Integer type, LoginAuthDto dto) {
        PageHelper.startPage(page,size);
        PageHelper.orderBy("limit_date asc");
        List<UserBacklog> list;
        if(type.intValue()!=1){
            type=0;
        }
        list=userBacklogMapper.getUserBackLog(dto.getUserId(),type);
        return WrapMapper.ok(new PageInfo<>(list));
    }
}
