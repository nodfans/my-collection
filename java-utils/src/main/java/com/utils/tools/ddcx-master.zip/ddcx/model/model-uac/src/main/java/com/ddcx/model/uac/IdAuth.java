package com.ddcx.model.uac;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@ApiModel("身份证信息")
public class IdAuth {

    @NotBlank
    @ApiModelProperty("真实姓名")
    private String realName;
    @NotBlank
    @ApiModelProperty("身份证号")
    private String idCard;
    @NotBlank
    @ApiModelProperty("身份证正面照")
    private String cardFront;
    @NotBlank
    @ApiModelProperty("身份证背面照")
    private String cardBack;
    @NotBlank
    @ApiModelProperty("性别")
    private String sex;
    @ApiModelProperty("生日")
    private String birthDay;
    @ApiModelProperty("审核状态：-1：审核失败，0：审核中，1：身份通过")
    private String state;
}
