package com.ddcx.app.provider.truck.web;


import com.ddcx.app.provider.api.truck.model.vo.TruckTransactionVo;
import com.ddcx.app.provider.truck.service.TruckTransactionService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.TruckTransaction;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/02/25.
 */
@RestController
@RequestMapping("/truck/transaction")
@Api(value = "二手车交易模块", tags = {"二手车交易模块"})
public class TruckTransactionController extends BaseController {
    @Resource
    private TruckTransactionService truckTransactionService;

    @ApiOperation(value = "汽车交易-新增（发布）")
    @PostMapping("/save")
    public Wrapper saveTruckTransaction(@RequestBody @ApiParam(value = "汽车（交易）对象") @Validated TruckTransaction truckTransaction) {
        try {
            truckTransaction.setUserId(getLoginAuthDto().getUserId());
        } catch (NullPointerException e) {
            return WrapMapper.error("用户信息获取失败");
        }
        return truckTransactionService.save(truckTransaction,getLoginAuthDto());
    }

    @ApiOperation(value = "汽车交易-查询列表（分页）")
    @GetMapping("/getTrucksPage")
    public Wrapper<PageInfo<TruckTransaction>> getTrucksPage(@ApiParam(value = "参数") TruckTransaction truckTransaction
            , @ApiParam(value = "页数", defaultValue = "1") @RequestParam(defaultValue = "1") Integer page, @ApiParam(value = "每页记录数", defaultValue = "10") @RequestParam(defaultValue = "10") Integer size) {
        return truckTransactionService.getTrucksPage(page, size, truckTransaction);
    }


    @ApiOperation(value = "汽车交易-详情查询")
    @GetMapping("/getTruckDetail")
    public Wrapper<TruckTransactionVo> getTruckDetail(@ApiParam(value = "汽车主键", required = true) @RequestParam(required = true) Integer id) {
        return truckTransactionService.getTruckDetail(id);
    }

    @ApiOperation(value = "汽车交易-自己销售中的车辆列表查询")
    @GetMapping("/getTrucksOwnerPage")
    public Wrapper<PageInfo<TruckTransaction>> getTrucksOwnerPage(@ApiParam(value = "主参数") TruckTransaction truckTransaction,
                                                                    @ApiParam(value = "页数", defaultValue = "1") @RequestParam(defaultValue = "1") Integer page,
                                                                    @ApiParam(value = "每页记录数", defaultValue = "10") @RequestParam(defaultValue = "10") Integer size) {
        if (truckTransaction == null) {
            truckTransaction = new TruckTransaction();
        }
        truckTransaction.setUserId(getLoginAuthDto().getUserId());
        return truckTransactionService.getTrucksOwnerPage(truckTransaction, page, size);
    }

    @ApiOperation(value = "汽车交易-取消掉自己要交易的汽车")
    @GetMapping("/exitSaleState")
    public Wrapper exitSaleState(@ApiParam(value = "汽车主键", required = true) @RequestParam(required = true) Long id) {
        return truckTransactionService.exitSaleState(id, getLoginAuthDto().getUserId());
    }

}
