package com.ddcx.common.provider.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.common.BsCity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;


@Mapper
@Component
public interface BsCityMapper extends MyMapper<BsCity> {


    @Select("select * from bs_city where PROVINCE_CODE=#{code} order by SORT")
    List<BsCity> selectByProviceCode(@Param("code") String code);
}