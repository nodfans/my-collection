package com.ddcx.app.provider.api.truck.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@ApiModel("检查信息")
@Data
public class ARUParam {

    @ApiModelProperty(value = "车辆主键",required = true)
    @NotNull(message = "车辆主键必填")
    private Long truckId;
    @ApiModelProperty("年检时间")
    private Long annualInspectionTime;
    @ApiModelProperty("续保时间")
    private Long renewalInsuranceTime;
    @ApiModelProperty("保养时间")
    private Long upkeepTime;
    @ApiModelProperty("年检有效期")
    private Integer annualInspectionValid;
    @ApiModelProperty("续保有效期")
    private Integer renewalInsuranceValid;
    @ApiModelProperty("保养有效期")
    private Integer upkeepValid;
    @ApiModelProperty("年检到期时间")
    private Long annualInspectionLimitTime;
    @ApiModelProperty("续保到期时间")
    private Long renewalInsuranceLimitTime;
    @ApiModelProperty("保养到期时间")
    private Long upkeepLimitTime;
    @ApiModelProperty("当前用户id<不用传>")
    private Long userId;
}
