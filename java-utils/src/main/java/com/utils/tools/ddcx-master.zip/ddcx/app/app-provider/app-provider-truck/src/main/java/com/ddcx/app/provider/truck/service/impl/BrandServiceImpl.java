package com.ddcx.app.provider.truck.service.impl;

import com.ddcx.app.provider.truck.mapper.BrandMapper;
import com.ddcx.app.provider.truck.service.BrandService;
import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.model.truck.Brand;
import com.ddcx.model.truck.BrandVo;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


/**
 * Created by CodeGenerator on 2020/02/26.
 */
@Service
@Transactional
@Log4j2
public class BrandServiceImpl implements BrandService {
    @Resource
    private BrandMapper brandMapper;

    @Autowired
    private RedisUtil redisUtil;

    /**
     * 初始化汽车品牌车型信息
     */
    @PostConstruct
    public void initBrand(){
        redisUtil.lTrim(RedisKey.BRAND_LIST,0,0);
        redisUtil.lPop(RedisKey.BRAND_LIST);
        List<Brand> brands=brandMapper.selectAllOrdered();
        BrandVo brandVo;
        List<Brand> brands1=new LinkedList<>();
        String letter=brands.get(0).getFirstLetter();
        Brand brand;
        for (int i = 0; i < brands.size(); i++) {
            brand=brands.get(i);
            if(letter.equals(brand.getFirstLetter())&&i!=(brands.size()-1)){
                brands1.add(brand);
            }else{
                if(i==brands.size()-1){
                    if(letter.equals(brand.getFirstLetter())){
                        brands1.add(brand);
                    }else {
                        redisUtil.lSet(RedisKey.BRAND_LIST,brands1);
                        brands1=new LinkedList<>();
                        letter=brand.getFirstLetter();
                        brands1.add(brand);
                    }
                }
                brandVo=new BrandVo();
                brandVo.setFirstLetter(letter);
                brandVo.setBrand(brands1);
                redisUtil.lSet(RedisKey.BRAND_LIST,brandVo);
                if(i!=brands.size()-1){
                    brands1=new LinkedList<>();
                    letter=brand.getFirstLetter();
                    brands1.add(brand);
                }
            }
        }
        log.info("汽车品牌，加载完成-------------------------");
        return;
    }


    /**
     * 获取品牌-车型列表
     */
    @Override
    public List<BrandVo> getBrandVo() {
        List<Object> brandVos = redisUtil.lGet(RedisKey.BRAND_LIST, 0, -1);
        List<BrandVo> list = new ArrayList<>(brandVos.size());
        for (Object brandVo : brandVos) {
            list.add((BrandVo) brandVo);
        }
        return list;
    }


}
