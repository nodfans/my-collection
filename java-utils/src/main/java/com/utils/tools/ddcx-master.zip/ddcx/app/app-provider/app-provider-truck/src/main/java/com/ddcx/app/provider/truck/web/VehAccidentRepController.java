package com.ddcx.app.provider.truck.web;


import com.ddcx.app.provider.truck.service.VehAccidentRepService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.VehAccidentRep;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
* Created by CodeGenerator on 2020/03/10.
*/
@RestController
@RequestMapping("/veh/accident/rep")
@Api(value = "事故处理",tags = "事故处理")
public class VehAccidentRepController extends BaseController {
    @Resource
    private VehAccidentRepService vehAccidentRepService;



    @ApiOperation("事故上报")
    @PostMapping("/add")
    public Wrapper add(@RequestBody @Validated VehAccidentRep rep){
        return vehAccidentRepService.add(rep,getLoginAuthDto());
    }



}
