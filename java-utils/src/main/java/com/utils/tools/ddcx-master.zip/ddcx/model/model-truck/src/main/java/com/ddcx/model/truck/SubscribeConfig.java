package com.ddcx.model.truck;

import com.ddcx.framework.util.StringUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.List;

@Table(name = "subscribe_config")
@ApiModel("年检配置")
public class SubscribeConfig {
    /**
     * 主键
     */
    @ApiModelProperty("主键")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;

    /**
     * 检查站名称
     */
    @Column(name = "checkpoint_name")
    @ApiModelProperty("检查站名称")
    private String checkpointName;

    /**
     * 检查站地址
     */
    @ApiModelProperty("检查站地址")
    private String address;

    /**
     * 检查站地址码
     */
    @Column(name = "address_code")
    @ApiModelProperty("检查站地址码")
    private String addressCode;


    /**
     * 联系电话
     */
    @ApiModelProperty("联系电话")
    private String phone;

    /**
     * 本月可预约数
     */
    @ApiModelProperty("本月可预约数")
    @Transient
    private Integer subscribeNum;

    /**
     * 存数组字符串，下标表示单月几号，一一对应<JSON>
     */
    @ApiModelProperty("存数组字符串，下标表示单月几号，一一对应<JSON>")
    private String detail;

    /**
     * 存数组字符串，下标表示单月几号，一一对应<JSON>
     */
    @ApiModelProperty("数组，下标表示单月几号，前端传此参数")
    private List<Integer> detailArray;

    /**
     * 年份
     */
    @ApiModelProperty("年份")
    private String year;

    /**
     * 月份
     */
    @ApiModelProperty("月份")
    private String month;

    /**
     * 地址所在经度
     */
    @ApiModelProperty("地址所在经度")
    private String lng;

    /**
     * 地址所在纬度
     */
    @ApiModelProperty("地址所在纬度")
    private String lat;

    @ApiModelProperty("车队主键")
    private Long motorcadeId;

    @ApiModelProperty("已预约数")
    private Integer subscribeSum;

    public Integer getSubscribeSum() {
        return subscribeSum;
    }

    public void setSubscribeSum(Integer subscribeSum) {
        this.subscribeSum = subscribeSum;
    }

    public Long getMotorcadeId() {
        return motorcadeId;
    }

    public void setMotorcadeId(Long motorcadeId) {
        this.motorcadeId = motorcadeId;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public List<Integer> getDetailArray() {
        return detailArray;
    }

    public void setDetailArray(List<Integer> detailArray) {
        this.detailArray = detailArray;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取检查站名称
     *
     * @return checkpoint_name - 检查站名称
     */
    public String getCheckpointName() {
        return checkpointName;
    }

    /**
     * 设置检查站名称
     *
     * @param checkpointName 检查站名称
     */
    public void setCheckpointName(String checkpointName) {
        if(StringUtils.isNotBlank(checkpointName))
        this.checkpointName = checkpointName;
    }

    /**
     * 获取检查站地址
     *
     * @return address - 检查站地址
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置检查站地址
     *
     * @param address 检查站地址
     */
    public void setAddress(String address) {
        if(StringUtils.isNotBlank(address))
        this.address = address;
    }

    /**
     * 获取检查站地址码
     *
     * @return address_code - 检查站地址码
     */
    public String getAddressCode() {
        return addressCode;
    }

    /**
     * 设置检查站地址码
     *
     * @param addressCode 检查站地址码
     */
    public void setAddressCode(String addressCode) {
        this.addressCode = addressCode;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    /**
     * 获取联系电话
     *
     * @return phone - 联系电话
     */
    public String getPhone() {
        return phone;
    }

    /**
     * 设置联系电话
     *
     * @param phone 联系电话
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * 获取本月可预约数
     *
     * @return subscribe_num - 本月可预约数
     */
    public Integer getSubscribeNum() {
        return subscribeNum;
    }

    /**
     * 设置本月可预约数
     *
     * @param subscribeNum 本月可预约数
     */
    public void setSubscribeNum(Integer subscribeNum) {
        this.subscribeNum = subscribeNum;
    }

    /**
     * 获取存数组字符串，下标表示单月几号，一一对应
     *
     * @return detail - 存数组字符串，下标表示单月几号，一一对应
     */
    public String getDetail() {
        return detail;
    }

    /**
     * 设置存数组字符串，下标表示单月几号，一一对应
     *
     * @param detail 存数组字符串，下标表示单月几号，一一对应
     */
    public void setDetail(String detail) {
        this.detail = detail;
    }
}