package com.ddcx.app.provider.exam.web;

import com.ddcx.app.provider.exam.service.UserAnswerService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/04/14.
*/
@RestController
@RequestMapping("/user/answer")
public class UserAnswerController {
    @Resource
    private UserAnswerService userAnswerService;

}
