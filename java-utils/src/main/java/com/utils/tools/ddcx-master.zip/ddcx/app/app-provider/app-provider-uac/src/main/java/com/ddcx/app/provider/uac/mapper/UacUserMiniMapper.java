package com.ddcx.app.provider.uac.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.uac.UacUserMini;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

@Component
@Mapper
public interface UacUserMiniMapper extends MyMapper<UacUserMini> {

    @Select("select * from uac_user_mini where phone=#{phone} limit 1")
    UacUserMini selectByPhone(@Param("phone")String phone);
}