package com.ddcx.app.provider.loan.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.loan.LoanRepaymentItem;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface LoanRepaymentItemMapper extends MyMapper<LoanRepaymentItem> {


    @Select("select * from loan_repayment_item where o_id=#{id}")
    List<LoanRepaymentItem> getByOrderId(@Param("id") Long id);

    @Update("update loan_repayment_item set state=1,repayment_type=#{repaymentType} where id=#{id}")
    int finish(@Param("id") Long id,@Param("repaymentType")String repaymentType);

    @Select("select i.* from loan_repayment_item i left join loan_order o on i.o_id=o.id where o.id=#{oId} and i.issue=#{issue} and o.user_id=#{userId} limit 1")
    LoanRepaymentItem selectByCondition(@Param("oId")Long oId,@Param("issue")Integer issue,@Param("userId")Long userId);

    @Select("select issue from loan_repayment_item where o_id=#{oId} and state != 1 order by issue limit 1")
    Integer selectCurrentIssue(@Param("oId")Long oId);

    @Select("select l.o_id id,o.user_id oid from loan_repayment_item l left join loan_order o on o.id=l.o_id where state=0 and repayment_time=#{targetDate}")
    List<LoanRepaymentItem> listBacklogItems(@Param("targetDate")Long targetDate);
}