package com.ddcx.model.truck;

import com.ddcx.framework.base.annotation.ExcelName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.math.BigDecimal;

@Table(name = "truck_mileage_statistics")
@ApiModel("车辆行驶里程统计表")
public class TruckMileageStatistics {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    /**
     * 车辆主键
     */
    @Column(name = "truck_id")
    @ApiModelProperty("车辆主键")
    private Long truckId;

    /**
     * 上月统计日里程表示值
     */
    @Column(name = "last_month_value")
    @ApiModelProperty("上月统计日里程表示值")
    @ExcelName("上月统计日里程表示值")
    private BigDecimal lastMonthValue;

    /**
     * 本月统计日里程标示值
     */
    @Column(name = "current_month_value")
    @ApiModelProperty("本月统计日里程标示值")
    @ExcelName("本月统计日里程标示值")
    private BigDecimal currentMonthValue;

    /**
     * 本月行驶里程
     */
    @ApiModelProperty("本月行驶里程")
    @ExcelName("本月行驶里程")
    private BigDecimal period;

    /**
     * 累计行驶
     */
    @Column(name = "total_value")
    @ApiModelProperty("累计行驶")
    @ExcelName("累计行驶")
    private BigDecimal totalValue;

    @Column(name = "create_time")
    @ApiModelProperty("生成时间")
    @ExcelName(value = "生成时间",isTimestamp = true)
    private Long createTime;

    @Column(name = "remark")
    @ApiModelProperty("备注")
    @ExcelName("备注")
    private String remark;


    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取车辆主键
     *
     * @return truck_id - 车辆主键
     */
    public Long getTruckId() {
        return truckId;
    }

    /**
     * 设置车辆主键
     *
     * @param truckId 车辆主键
     */
    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    /**
     * 获取上月统计日里程表示值
     *
     * @return last_month_value - 上月统计日里程表示值
     */
    public BigDecimal getLastMonthValue() {
        return lastMonthValue;
    }

    /**
     * 设置上月统计日里程表示值
     *
     * @param lastMonthValue 上月统计日里程表示值
     */
    public void setLastMonthValue(BigDecimal lastMonthValue) {
        this.lastMonthValue = lastMonthValue;
    }

    /**
     * 获取本月统计日里程标示值
     *
     * @return current_month_value - 本月统计日里程标示值
     */
    public BigDecimal getCurrentMonthValue() {
        return currentMonthValue;
    }

    /**
     * 设置本月统计日里程标示值
     *
     * @param currentMonthValue 本月统计日里程标示值
     */
    public void setCurrentMonthValue(BigDecimal currentMonthValue) {
        this.currentMonthValue = currentMonthValue;
    }

    /**
     * 获取本月行驶里程
     *
     * @return period - 本月行驶里程
     */
    public BigDecimal getPeriod() {
        return period;
    }

    /**
     * 设置本月行驶里程
     *
     * @param period 本月行驶里程
     */
    public void setPeriod(BigDecimal period) {
        this.period = period;
    }

    /**
     * 获取累计行驶
     *
     * @return total_value - 累计行驶
     */
    public BigDecimal getTotalValue() {
        return totalValue;
    }

    /**
     * 设置累计行驶
     *
     * @param totalValue 累计行驶
     */
    public void setTotalValue(BigDecimal totalValue) {
        this.totalValue = totalValue;
    }
}