package com.ddcx.app.provider.truck.web;


import com.ddcx.app.provider.api.truck.model.vo.SubscribeParam;
import com.ddcx.app.provider.truck.service.SubscribeService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.OverallSubscribeDto;
import com.ddcx.model.truck.Subscribe;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
* Created by CodeGenerator on 2020/03/11.
*/
@RestController
@RequestMapping("/subscribe")
@Api(value = "年检预约",tags = "年检预约")
public class SubscribeController extends BaseController {
    @Resource
    private SubscribeService subscribeService;



    @ApiOperation("预约")
    @PostMapping("/subscribe")
    public Wrapper<List<OverallSubscribeDto>> getCurrentConfig(@RequestBody @Validated SubscribeParam param){
        return subscribeService.subscribe(param,getLoginAuthDto());
    }



    @ApiOperation("获取我的预约")
    @GetMapping("/getMySubscribes")
    public Wrapper<PageInfo<Subscribe>> getMySubscribes(@ApiParam(value = "当前页",defaultValue = "1")@RequestParam(defaultValue = "1") Integer page,
                                                        @ApiParam(value = "每页记录数",defaultValue = "10")@RequestParam(defaultValue = "10") Integer size){
        return subscribeService.getMySubscribes(page,size,getLoginAuthDto());
    }


    @ApiOperation("取消预约")
    @GetMapping("/cancelSubscribe")
    public Wrapper cancelSubscribe(@RequestParam @ApiParam("预约主键<id>") Long  id){
        return subscribeService.cancelSubscribe(id,getLoginAuthDto());
    }

}








