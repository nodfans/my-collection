package com.ddcx.app.provider.api.truck.model.vo;

import com.ddcx.model.truck.Truck;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
@ApiModel(value = "汽车显示类")
public class TruckVo {

    @ApiModelProperty(value = "汽车主对象")
    private Truck truck;

    @ApiModelProperty(value = "车主名字")
    private String ownerName;
    @ApiModelProperty(value = "司机名字")
    private String driverName;
    @ApiModelProperty(value = "用户级别: 0.无关人员 1.司机 2.车主")
    private Integer truckUserLevel = 0;

    public TruckVo(Truck truck, String ownerName, String driverName) {
        this.truck = truck;
        this.ownerName = ownerName;
        this.driverName = driverName;
    }

    public TruckVo() {
    }
}
