package com.ddcx.common.provider.api.enums;

public enum CommonErrorCodeEnum {

    COMMON10000001(10000001, "文件上传失败"),
    COMMON10000002(10000002, "文件上传失败"),
    COMMON10000003(10000003, "验证码发送失败"),
    COMMON10000004(10000004, "验证码错误"),
    COMMON10000005(10000005, "验证token错误"),
    COMMON10000006(10000006, "账号已存在");

    private int code;
    private String msg;

    /**
     * Msg string.
     *
     * @return the string
     */
    public String msg() {
        return msg;
    }

    /**
     * Code int.
     *
     * @return the int
     */
    public int code() {
        return code;
    }

    CommonErrorCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    /**
     * Gets enum.
     *
     * @param code the code
     * @return the enum
     */
    public static CommonErrorCodeEnum getEnum(int code) {
        for (CommonErrorCodeEnum ele : CommonErrorCodeEnum.values()) {
            if (ele.code() == code) {
                return ele;
            }
        }
        return null;
    }
}
