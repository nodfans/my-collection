package com.ddcx.app.provider.uac.web;


import com.ddcx.app.provider.uac.service.RescueService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.Rescue;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
* Created by CodeGenerator on 2020/03/26.
*/
@RestController
@RequestMapping("/rescue")
@Api(value = "救援模块",tags = "救援模块")
public class RescueController extends BaseController {
    @Resource
    private RescueService  rescueService;


    @ApiOperation("一键救援<会返回求援信息id，可用于撤回求援>")
    @PostMapping("/saveRescue")
    public Wrapper saveRescue(@RequestBody @Validated Rescue rescue){
        return rescueService.saveRescue(rescue,getLoginAuthDto());
    }


    @ApiOperation("救援列表查询")
    @GetMapping("/rescueList")
    public Wrapper<List<Rescue>> rescueList(@ApiParam("经度") String lng, @ApiParam("纬度") String lat){
        return rescueService.rescueList(lng,lat,getLoginAuthDto());
    }

    @ApiOperation("获取当前用户的救援信息")
    @GetMapping("/currentRescue")
    public Wrapper<Rescue> currentRescue(){
        return rescueService.currentRescue(getLoginAuthDto());
    }

    @ApiOperation("撤销求援")
    @GetMapping("/cancelRescue")
    public Wrapper<Rescue> cancelRescue(@RequestParam Long id){
        return rescueService.cancelRescue(id,getLoginAuthDto());
    }


    @ApiOperation("小喇叭，消息")
    @GetMapping("/getRescueInfo")
    public Wrapper<String> getRescueInfo(@ApiParam("经度") String lng, @ApiParam("纬度") String lat){
        return rescueService.getRescueInfo(lng,lat,getLoginAuthDto());
    }

    @ApiOperation("根据id获取救援详情")
    @GetMapping("/getRescueInfoById")
    public Wrapper<Rescue> getRescueInfoById(@ApiParam("主键") Long id){
        return rescueService.getRescueInfoById(id);
    }



}
