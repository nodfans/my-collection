package com.ddcx.app.provider.api.uac.model.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UacCheckAccountDto implements java.io.Serializable {
    private static final long serialVersionUID = 5960946024065858894L;

    @ApiModelProperty(value = "账号", name = "account", required = true)
    private String account;

    public UacCheckAccountDto(String account) {
        this.account = account;
    }
}
