package com.ddcx.framework.base.enums;

public enum ErrorCodeEnum {

    /**
     * Gl 99990100 error code enum.
     */
    GL99990100(9999100, "参数异常"),
    /**
     * Gl 99990401 error code enum.
     */
    GL99990401(9999401, "无访问权限"),

    GL401(401, "无访问权限"),

    GL404(404, "访问路径不存在"),
    /**
     * Gl 000500 error code enum.
     */
    GL500(500, "未知异常"),

    GL99990101(9999101, "token is invalid"),

    GL99990102(9999102, "action token is invalid"),

    GL99990103(9999103, "服务异常，请联系系统管理员"),

    GL99990104(9999104, "权限不足，无法操作"),

    GL99990105(9999105, "权限不足，获取失败");

    private int code;
    private String msg;

    /**
     * Msg string.
     *
     * @return the string
     */
    public String msg() {
        return msg;
    }

    /**
     * Code int.
     *
     * @return the int
     */
    public int code() {
        return code;
    }

    ErrorCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    /**
     * Gets enum.
     *
     * @param code the code
     * @return the enum
     */
    public static ErrorCodeEnum getEnum(int code) {
        for (ErrorCodeEnum ele : ErrorCodeEnum.values()) {
            if (ele.code() == code) {
                return ele;
            }
        }
        return null;
    }

}
