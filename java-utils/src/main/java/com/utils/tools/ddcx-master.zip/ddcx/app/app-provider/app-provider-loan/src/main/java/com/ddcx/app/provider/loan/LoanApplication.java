package com.ddcx.app.provider.loan;

import com.ddcx.framework.core.config.SwaggerConfiguration;
import com.ddcx.framework.core.support.GlobalExceptionHandler;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication(scanBasePackages = {"com.ddcx"})
@EnableDiscoveryClient
@EnableHystrix
@EnableFeignClients(basePackages = {"com.ddcx.app.provider.api.loan.service","com.ddcx.app.provider.api.uac.service","com.ddcx.common.provider.api.service"})
@Import({SwaggerConfiguration.class, GlobalExceptionHandler.class})
@EnableTransactionManagement
public class LoanApplication {
    public static void main(String[] args) {
        SpringApplication.run(LoanApplication.class, args);
    }
}
