package com.ddcx.app.provider.loan.service;


import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.loan.LoanConfig;

/**
 * Created by CodeGenerator on 2020/03/23.
 */
public interface LoanConfigService  {


    Wrapper<LoanConfig> getLoanConfigByMotorcadeId(LoginAuthDto dto);
}
