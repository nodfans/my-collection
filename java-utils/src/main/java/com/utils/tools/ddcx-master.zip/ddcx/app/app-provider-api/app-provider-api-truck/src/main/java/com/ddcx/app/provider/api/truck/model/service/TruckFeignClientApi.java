package com.ddcx.app.provider.api.truck.model.service;


import com.ddcx.app.provider.api.truck.model.service.hystrix.TruckServiceFeignApiHystrix;
import com.ddcx.framework.core.annotation.NoNeedAccessAuthentication;
import org.springframework.cloud.openfeign.FeignAutoConfiguration;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Set;

@Component
@FeignClient(value = "ddcx-app-provider-truck", configuration = FeignAutoConfiguration.class, fallback = TruckServiceFeignApiHystrix.class)
public interface TruckFeignClientApi {


    /**
     * 获取需要通知的司机主键列表
     * @param lng           经度
     * @param lat           纬度
     * @param askHelpKm     有效范围（km）
     * @return
     */
    @NoNeedAccessAuthentication
    @GetMapping("/api/truck/getAllValidUserId/{lng}/{lat}/{askHelpKm}")
    Set<Long> getAllValidUserId(@PathVariable String lng, @PathVariable String lat, @PathVariable Integer askHelpKm );

}
