package com.ddcx.common.provider.mapper;

import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.common.RelatedReminders;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface ReminderDaysMapper extends MyMapper<RelatedReminders> {
}
