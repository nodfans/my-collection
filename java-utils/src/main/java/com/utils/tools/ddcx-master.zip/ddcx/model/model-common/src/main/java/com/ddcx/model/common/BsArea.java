package com.ddcx.model.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Table(name = "bs_area")
@ApiModel("区对象")
public class BsArea implements Serializable {
    /**
     * 自增列
     */
    @Id
    @Column(name = "AREA_ID")
    @ApiModelProperty("自增列")
    private Integer areaId;

    /**
     * 区代码
     */
    @ApiModelProperty("区代码")
    @Column(name = "AREA_CODE")
    private String areaCode;

    /**
     * 父级市代码
     */
    @ApiModelProperty("父级市代码")
    @Column(name = "CITY_CODE")
    private String cityCode;

    /**
     * 市名称
     */
    @ApiModelProperty("市名称")
    @Column(name = "AREA_NAME")
    private String areaName;

    /**
     * 简称
     */
    @ApiModelProperty("简称")
    @Column(name = "SHORT_NAME")
    private String shortName;

    /**
     * 经度
     */
    @ApiModelProperty("经度")
    @Column(name = "LNG")
    private String lng;

    /**
     * 纬度
     */
    @ApiModelProperty("纬度")
    @Column(name = "LAT")
    private String lat;

    /**
     * 排序
     */
    @ApiModelProperty("排序")
    @Column(name = "SORT")
    private Integer sort;

    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    @Column(name = "GMT_CREATE")
    private Date gmtCreate;

    /**
     * 修改时间
     */
    @ApiModelProperty("修改时间")
    @Column(name = "GMT_MODIFIED")
    private Date gmtModified;

    /**
     * 备注
     */
    @ApiModelProperty("备注")
    @Column(name = "MEMO")
    private String memo;

    /**
     * 状态
     */
    @ApiModelProperty("状态<无用>")
    @Column(name = "DATA_STATE")
    private Integer dataState;

    /**
     * 租户ID
     */
    @ApiModelProperty("租户ID<无用>")
    @Column(name = "TENANT_CODE")
    private String tenantCode;

    /**
     * 获取自增列
     *
     * @return AREA_ID - 自增列
     */
    public Integer getAreaId() {
        return areaId;
    }

    /**
     * 设置自增列
     *
     * @param areaId 自增列
     */
    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    /**
     * 获取区代码
     *
     * @return AREA_CODE - 区代码
     */
    public String getAreaCode() {
        return areaCode;
    }

    /**
     * 设置区代码
     *
     * @param areaCode 区代码
     */
    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    /**
     * 获取父级市代码
     *
     * @return CITY_CODE - 父级市代码
     */
    public String getCityCode() {
        return cityCode;
    }

    /**
     * 设置父级市代码
     *
     * @param cityCode 父级市代码
     */
    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    /**
     * 获取市名称
     *
     * @return AREA_NAME - 市名称
     */
    public String getAreaName() {
        return areaName;
    }

    /**
     * 设置市名称
     *
     * @param areaName 市名称
     */
    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    /**
     * 获取简称
     *
     * @return SHORT_NAME - 简称
     */
    public String getShortName() {
        return shortName;
    }

    /**
     * 设置简称
     *
     * @param shortName 简称
     */
    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    /**
     * 获取经度
     *
     * @return LNG - 经度
     */
    public String getLng() {
        return lng;
    }

    /**
     * 设置经度
     *
     * @param lng 经度
     */
    public void setLng(String lng) {
        this.lng = lng;
    }

    /**
     * 获取纬度
     *
     * @return LAT - 纬度
     */
    public String getLat() {
        return lat;
    }

    /**
     * 设置纬度
     *
     * @param lat 纬度
     */
    public void setLat(String lat) {
        this.lat = lat;
    }

    /**
     * 获取排序
     *
     * @return SORT - 排序
     */
    public Integer getSort() {
        return sort;
    }

    /**
     * 设置排序
     *
     * @param sort 排序
     */
    public void setSort(Integer sort) {
        this.sort = sort;
    }

    /**
     * 获取创建时间
     *
     * @return GMT_CREATE - 创建时间
     */
    public Date getGmtCreate() {
        return gmtCreate;
    }

    /**
     * 设置创建时间
     *
     * @param gmtCreate 创建时间
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * 获取修改时间
     *
     * @return GMT_MODIFIED - 修改时间
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * 设置修改时间
     *
     * @param gmtModified 修改时间
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * 获取备注
     *
     * @return MEMO - 备注
     */
    public String getMemo() {
        return memo;
    }

    /**
     * 设置备注
     *
     * @param memo 备注
     */
    public void setMemo(String memo) {
        this.memo = memo;
    }

    /**
     * 获取状态
     *
     * @return DATA_STATE - 状态
     */
    public Integer getDataState() {
        return dataState;
    }

    /**
     * 设置状态
     *
     * @param dataState 状态
     */
    public void setDataState(Integer dataState) {
        this.dataState = dataState;
    }

    /**
     * 获取租户ID
     *
     * @return TENANT_CODE - 租户ID
     */
    public String getTenantCode() {
        return tenantCode;
    }

    /**
     * 设置租户ID
     *
     * @param tenantCode 租户ID
     */
    public void setTenantCode(String tenantCode) {
        this.tenantCode = tenantCode;
    }
}