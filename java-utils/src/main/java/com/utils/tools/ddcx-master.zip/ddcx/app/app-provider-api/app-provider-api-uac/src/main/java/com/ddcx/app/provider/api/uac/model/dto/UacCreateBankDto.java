package com.ddcx.app.provider.api.uac.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@ApiModel(value = "UacCreateBankDto", description = "添加银行卡")
public class UacCreateBankDto implements java.io.Serializable {
    private static final long serialVersionUID = 6913067692457327303L;

    @ApiModelProperty(value = "银行卡主键（有则替换，无则新增）", name = "id", required = false)
    private Long id;

    @NotBlank(message = "持卡人不能为空")
    @ApiModelProperty(value = "持卡人", name = "cardVest", required = true)
    private String cardVest;

    @NotBlank(message = "卡号不能为空")
    @ApiModelProperty(value = "卡号", name = "cardNo", required = true)
    private String cardNo;

    @NotBlank(message = "手机号码不能为空")
    @ApiModelProperty(value = "手机号码", name = "phone", required = true)
    private String phone;

    @NotBlank(message = "验证码")
    @ApiModelProperty(value = "验证码", name = "phone", required = true)
    private String code;
}
