package com.ddcx.common.provider.job;


import com.ddcx.common.provider.mapper.MessageMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@Log4j2
@EnableScheduling
public class MessageJob {

    @Resource
    private MessageMapper messageMapper;

    /**
     * 把所有过期消息全部标记已读
     */
    @Scheduled(cron = "0 1/30 * * * ?")
    public void readRescueMessage(){
        messageMapper.readRescueMessage(System.currentTimeMillis()/1000-1800);
    }

}
