package com.ddcx.model.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@ApiModel("用户消息")
public class Message {

    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    @ApiModelProperty("消息内容ID")
    private Long configId;

    /**
     * 用户id
     */
    @ApiModelProperty("用户id")
    @Column(name = "user_id")
    private Long userId;

    /**
     * 消息状态（0.未读 1,.已读）
     */
    @ApiModelProperty("消息状态（0.未读 1,.已读）")
    private Byte state;

    /**
     * 删除表示（0.未删除 1.已删除）
     */
    @ApiModelProperty("删除表示（0.未删除 1.已删除）")
    @Column(name = "delete_tag")
    private Byte deleteTag;

    @Transient
    @ApiModelProperty("消息主体")
    private MessageConfig messageConfig;


    public MessageConfig getMessageConfig() {
        return messageConfig;
    }

    public void setMessageConfig(MessageConfig messageConfig) {
        this.messageConfig = messageConfig;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }


    public Long getConfigId() {
        return configId;
    }

    public void setConfigId(Long configId) {
        this.configId = configId;
    }



    /**
     * 获取用户id
     *
     * @return user_id - 用户id
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置用户id
     *
     * @param userId 用户id
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 获取消息状态（0.未读 1,.已读）
     *
     * @return state - 消息状态（0.未读 1,.已读）
     */
    public Byte getState() {
        return state;
    }

    /**
     * 设置消息状态（0.未读 1,.已读）
     *
     * @param state 消息状态（0.未读 1,.已读）
     */
    public void setState(Byte state) {
        this.state = state;
    }

    /**
     * 获取删除表示（0.未删除 1.已删除）
     *
     * @return delete_tag - 删除表示（0.未删除 1.已删除）
     */
    public Byte getDeleteTag() {
        return deleteTag;
    }

    /**
     * 设置删除表示（0.未删除 1.已删除）
     *
     * @param deleteTag 删除表示（0.未删除 1.已删除）
     */
    public void setDeleteTag(Byte deleteTag) {
        this.deleteTag = deleteTag;
    }
}