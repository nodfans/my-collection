package com.ddcx.app.provider.truck.web;


import com.ddcx.app.provider.api.truck.model.param.ARUParam;
import com.ddcx.app.provider.api.truck.model.param.TruckParam;
import com.ddcx.app.provider.api.truck.model.vo.TruckInsurance;
import com.ddcx.app.provider.truck.service.TruckService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.Truck;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/02/28.
 */
@RestController
@RequestMapping("/truck/main")
@Api(value = "汽车模块", tags = "汽车模块")
public class TruckController extends BaseController {
    @Resource
    private TruckService truckService;


    @ApiOperation("查询自己的汽车列表")
    @GetMapping("/getOwnTrucks")
    public Wrapper<List<Truck>> getOwnTrucks() {
        return truckService.getOwnTrucks(getLoginAuthDto().getUserId());
    }


    @ApiOperation("更改汽车年检、续保、保养信息")
    @PostMapping("/updateTruckARU")
    public Wrapper updateTruckARU(@RequestBody @ApiParam("参数")@Validated ARUParam param) {
        return truckService.updateTruckARU(param, getLoginAuthDto().getUserId());
    }


    @ApiOperation("查询自己的汽车详情")
    @GetMapping("/getTruckDetail")
    public Wrapper<Truck> getTruckDetail(@ApiParam(value = "汽车主键", required = true) @RequestParam Long id) {
        return truckService.getTruckDetail(id, getLoginAuthDto().getUserId());
    }


    @ApiOperation("汽车解除绑定操作")
    @PostMapping("/clearTruckBinding")
    public Wrapper clearTruckBinding(@ApiParam("参数")@RequestBody TruckParam param) {
        return truckService.clearTruckBinding(param.getTruckId(), param.getOldDriverId(), getLoginAuthDto().getUserId());
    }

    @ApiOperation("汽车更换司机操作")
    @PostMapping("/updateTruckDriver")
    public Wrapper updateTruckDriver(@ApiParam("参数")@RequestBody TruckParam param) {
        return truckService.updateTruckDriver(param.getTruckId(), param.getNewDriverId(), param.getOldDriverId(), getLoginAuthDto().getUserId());
    }

    @ApiOperation("取消出售")
    @GetMapping("/cancelSale")
    public Wrapper cancelSale(@ApiParam(value = "truckId",required = true)@RequestParam Long truckId){
        return truckService.cancelSale(truckId,getLoginAuthDto().getUserId());
    }


    @ApiOperation("安全检查-车辆选择")
    @GetMapping("/getTruckSelects")
    public Wrapper getTruckSelects(){
        return truckService.getTruckSelects(getLoginAuthDto());
    }


    @ApiOperation("我的保险")
    @GetMapping("/getOwnTruckInsurances")
    public Wrapper<TruckInsurance> getOwnTruckInsurances(@ApiParam(value = "页数", defaultValue = "1") @RequestParam(defaultValue = "1") Integer page,
                                                         @ApiParam(value = "每页记录数", defaultValue = "10") @RequestParam(defaultValue = "10") Integer size){
            return  truckService.getOwnTruckInsurances(page,size,getLoginAuthDto());
    }

}
