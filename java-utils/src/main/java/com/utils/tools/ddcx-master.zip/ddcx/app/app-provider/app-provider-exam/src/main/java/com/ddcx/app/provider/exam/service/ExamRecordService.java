package com.ddcx.app.provider.exam.service;

import com.ddcx.framework.util.wrapper.Wrapper;

/**
 * Created by CodeGenerator on 2020/04/14.
 */
public interface ExamRecordService {

    Wrapper getOwnExamRecords(Integer page,Integer size,Long userId);

}
