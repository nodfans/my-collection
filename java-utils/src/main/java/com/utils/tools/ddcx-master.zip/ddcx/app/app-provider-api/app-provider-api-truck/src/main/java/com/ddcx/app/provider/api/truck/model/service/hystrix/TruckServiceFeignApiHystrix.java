package com.ddcx.app.provider.api.truck.model.service.hystrix;


import com.ddcx.app.provider.api.truck.model.service.TruckFeignClientApi;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class TruckServiceFeignApiHystrix implements TruckFeignClientApi {


    @Override
    public Set<Long> getAllValidUserId(String lng, String lat, Integer askHelpKm) {
        return null;
    }
}
