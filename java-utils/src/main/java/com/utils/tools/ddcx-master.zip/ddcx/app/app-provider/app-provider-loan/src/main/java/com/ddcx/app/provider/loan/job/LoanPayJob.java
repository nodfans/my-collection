package com.ddcx.app.provider.loan.job;


import com.ddcx.app.provider.api.uac.service.UacUserServiceFeignApi;
import com.ddcx.app.provider.loan.mapper.LoanRepaymentItemMapper;
import com.ddcx.common.provider.api.service.CommonServiceFeignApi;
import com.ddcx.model.common.RelatedReminders;
import com.ddcx.model.loan.LoanRepaymentItem;
import com.ddcx.model.uac.UserBacklog;
import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * 生成还款待办
 */
@Component
@Log4j2
@EnableScheduling
public class LoanPayJob {

    @Resource
    private CommonServiceFeignApi commonServiceFeignApi;
    @Resource
    private LoanRepaymentItemMapper itemMapper;
    @Resource
    private UacUserServiceFeignApi uacUserServiceFeignApi;

    //生成还款待办
    @Scheduled(cron = "2 2 2 * * ?")
    public void addBacklog()    {
        LocalDate localDate=LocalDate.now();
        //获取待办还款配置
        RelatedReminders relatedReminders=commonServiceFeignApi.selectRelatedReminders();
        Integer days=relatedReminders.getRepaymentDays();
        //获取所有待还款条目
        Long limitDay=System.currentTimeMillis()/1000+3600*24*days;
        List<LoanRepaymentItem> items=itemMapper.listBacklogItems(limitDay);
        List<UserBacklog> anBacklogs=new ArrayList<>(items.size());
        UserBacklog backlog;
        for (LoanRepaymentItem item : items) {
            backlog=new UserBacklog();
            backlog.setState((byte) 0);
            backlog.setTitle("还款办理");
            backlog.setType((byte) 3);
            backlog.setObjId(item.getId());
            backlog.setOverdueState((byte) 1);
            backlog.setDetails("您的贷款将于"+LocalDate.ofEpochDay(limitDay/3600/24).format(DateTimeFormatter.ofPattern("yyyy年MM月dd号"))+"到期，请尽快办理。");
            backlog.setLimitDate(limitDay);
            backlog.setInitiateDate(System.currentTimeMillis()/1000);
            backlog.setDriverId(item.getoId());
            anBacklogs.add(backlog);
        }
        if(anBacklogs.size()>0){
            uacUserServiceFeignApi.addAllUserBackLog(anBacklogs);
        }

    }
}
