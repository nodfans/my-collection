package com.ddcx.common.provider.service;

import com.ddcx.common.provider.api.model.dto.SendCodeDto;
import com.ddcx.common.provider.api.model.dto.VerifyCodeDto;
import com.ddcx.common.provider.api.model.vo.VerifyCodeResultVo;
import com.ddcx.framework.core.redis.RedisUtil;
import lombok.Data;

public interface CodeService {

    Boolean send(SendCodeDto sendCodeDto);

    VerifyCodeResultVo verify(VerifyCodeDto verifyCodeDto);

    String VERIFY_CODE = "VERIFY_CODE";

}
