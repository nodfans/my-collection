package com.ddcx.model.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Table(name = "sys_config")
@ApiModel("系统配置")
public class SysConfig {
    /**
     * 主键
     */
    @ApiModelProperty("主键")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;

    /**
     * 配置键
     */
    @ApiModelProperty("配置键")
    @Column(name = "config_key")
    private String configKey;

    /**
     * 键说明
     */
    @ApiModelProperty("键说明")
    @Column(name = "config_info")
    private String configInfo;

    /**
     * 值
     */
    @ApiModelProperty("值")
    @Column(name = "config_value")
    private String configValue;

    /**
     * 更新时间
     */
    @ApiModelProperty("更新时间")
    @Column(name = "update_time")
    private Long updateTime;

    /**
     * 更新人
     */
    @ApiModelProperty("更新人")
    @Column(name = "update_by")
    private Long updateBy;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取配置键
     *
     * @return config_key - 配置键
     */
    public String getConfigKey() {
        return configKey;
    }

    /**
     * 设置配置键
     *
     * @param configKey 配置键
     */
    public void setConfigKey(String configKey) {
        this.configKey = configKey;
    }

    /**
     * 获取键说明
     *
     * @return config_info - 键说明
     */
    public String getConfigInfo() {
        return configInfo;
    }

    /**
     * 设置键说明
     *
     * @param configInfo 键说明
     */
    public void setConfigInfo(String configInfo) {
        this.configInfo = configInfo;
    }

    /**
     * 获取值
     *
     * @return config_value - 值
     */
    public String getConfigValue() {
        return configValue;
    }

    /**
     * 设置值
     *
     * @param configValue 值
     */
    public void setConfigValue(String configValue) {
        this.configValue = configValue;
    }

    /**
     * 获取更新时间
     *
     * @return update_time - 更新时间
     */
    public Long getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * 获取更新人
     *
     * @return update_by - 更新人
     */
    public Long getUpdateBy() {
        return updateBy;
    }

    /**
     * 设置更新人
     *
     * @param updateBy 更新人
     */
    public void setUpdateBy(Long updateBy) {
        this.updateBy = updateBy;
    }
}