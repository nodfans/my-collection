package com.ddcx.app.provider.truck.service.impl;


import com.ddcx.app.provider.truck.mapper.TruckSafeInformMapper;
import com.ddcx.app.provider.truck.service.TruckSafeInformService;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.TruckSafeInform;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created by CodeGenerator on 2020/04/17.
 */
@Service
@Transactional
public class TruckSafeInformServiceImpl implements TruckSafeInformService {
    @Resource
    private TruckSafeInformMapper truckSafeInformMapper;

    /**
     * 安全隐患三级联动菜单
     */
    private static Map<String, Map<String, List<String>>> selectMap;

    @PostConstruct
    public void initMap(){
        selectMap=new HashMap<>();
        //行车证件
        selectMap.put("行车证件",new HashMap<String,List<String>>(){{
            put("各类行车证件是否齐全有效：行驶证、营运证",new LinkedList<String>(){{
                add("更换新配件");
                add("补充新配件");
            }});
        }});
        //安全带
        selectMap.put("安全带",new HashMap<String,List<String>>(){{
            put("是否完好有效",new LinkedList<String>(){{
                add("更换新配件");
            }});
        }});
        //离合及换挡操作情况
        selectMap.put("离合及换挡操作情况",new HashMap<String,List<String>>(){{
            put("是否正常",new LinkedList<String>(){{
                add("维修保养");
            }});
        }});
        //转向系统
        selectMap.put("转向系统",new HashMap<String,List<String>>(){{
            put("方向盘自由度、紧度是否适当",new LinkedList<String>(){{
                add("维修保养");
            }});
        }});
        //刹车系统
        selectMap.put("刹车系统",new HashMap<String,List<String>>(){{
            put("刹车板踏度是否适当",new LinkedList<String>(){{
                add("维修保养");
            }});
            put("制动距离是否达到安全",new LinkedList<String>(){{
                add("维修保养");
            }});
        }});
        //轮胎
        selectMap.put("轮胎",new HashMap<String,List<String>>(){{
            put("气压是否适当",new LinkedList<String>(){{
                add("维修保养");
            }});
            put("轮胎无特别损耗或损伤",new LinkedList<String>(){{
                add("更换新配件");
            }});
            put("备胎是否完好",new LinkedList<String>(){{
                add("补充新配件");
            }});
        }});
        //底盘、钢板总成
        selectMap.put("底盘、钢板总成",new HashMap<String,List<String>>(){{
            put("钢板是否断裂",new LinkedList<String>(){{
                add("维修保养");
            }});
            put("传动部件是否紧固",new LinkedList<String>(){{
                add("维修保养");
            }});
        }});
        //引擎
        selectMap.put("引擎",new HashMap<String,List<String>>(){{
            put("注意排气的颜色有没有异常",new LinkedList<String>(){{
                add("维修保养");
            }});
            put("水箱的水，油箱的油是否适当，有无滴漏",new LinkedList<String>(){{
                add("维修保养");
            }});
            put("运转声音有无异常，润滑油是否合适",new LinkedList<String>(){{
                add("维修保养");
            }});
        }});
        //电路、油路
        selectMap.put("油电路",new HashMap<String,List<String>>(){{
            put("点火是否正常，有无漏电现象",new LinkedList<String>(){{
                add("更换新配件");
                add("维修保养");
            }});
            put("油路是否畅通，有无滴漏现象",new LinkedList<String>(){{
                add("更换新配件");
                add("维修保养");
            }});
        }});
        //喇叭
        selectMap.put("喇叭",new HashMap<String,List<String>>(){{
            put("是否正常",new LinkedList<String>(){{
                add("更换新配件");
                add("维修保养");
            }});
        }});
        //雨刮器
        selectMap.put("雨刮",new HashMap<String,List<String>>(){{
            put("是否正常",new LinkedList<String>(){{
                add("更换新配件");
                add("维修保养");
            }});
        }});
        //车门锁
        selectMap.put("车门锁",new HashMap<String,List<String>>(){{
            put("开、锁是否正常",new LinkedList<String>(){{
                add("维修保养");
            }});
        }});
        //左、右及车内后视镜
        selectMap.put("左右及车内后视镜",new HashMap<String,List<String>>(){{
            put("左、右及车内后视镜",new LinkedList<String>(){{
                add("更换新配件");
            }});
        }});
        //车灯
        selectMap.put("车灯",new HashMap<String,List<String>>(){{
            put("左右转向灯、刹车灯、近远光等、应急灯是否完好无损，工作正常",new LinkedList<String>(){{
                add("更换新配件");
            }});
        }});
        //车牌照
        selectMap.put("车牌照",new HashMap<String,List<String>>(){{
            put("是否完好无损，号码清晰",new LinkedList<String>(){{
                add("更换新配件");
            }});
        }});
        //仪表指示
        selectMap.put("仪表指示",new HashMap<String,List<String>>(){{
            put("是否完好无损，号码清晰",new LinkedList<String>(){{
                add("更换新配件");
            }});
        }});
        //车辆外观
        selectMap.put("车辆外观",new HashMap<String, List<String>>(){{
            put("车容外观整洁，是否破损，反光标志是否完整",new LinkedList<String>(){{
                add("维修保养");
            }});
        }});
        //车辆常备工具
        selectMap.put("车辆常备工具",new HashMap<String,List<String>>(){{
            put("千斤顶/1个",new LinkedList<String>(){{
                add("更换新配件");
                add("补充新配件");
            }});
            put("灭火器/1个",new LinkedList<String>(){{
                add("更换新配件");
                add("补充新配件");
            }});
            put("停车应急三角警示牌/1个",new LinkedList<String>(){{
                add("更换新配件");
                add("补充新配件");
            }});
            put("三角木/2个",new LinkedList<String>(){{
                add("更换新配件");
                add("补充新配件");
            }});
        }});
        //防滑链
        selectMap.put("防滑链",new HashMap<String, List<String>>(){{
            put("是否有防滑链",new LinkedList<String>(){{
                add("更换新配件");
                add("补充新配件");
            }});
            put("防滑链是否破损",new LinkedList<String>(){{
                add("更换新配件");
                add("补充新配件");
            }});
        }});
        //前后保险杠
        selectMap.put("前后保险杠",new HashMap<String, List<String>>(){{
            put("是否完好无损",new LinkedList<String>(){{
                add("更换新配件");
            }});
        }});
        //GPS
        selectMap.put("GPS",new HashMap<String, List<String>>(){{
            put("是否在线",new LinkedList<String>(){{
                add("无");
            }});
        }});
    }


    @Override
    public Wrapper getById(Long id) {
        TruckSafeInform inform=truckSafeInformMapper.selectByPrimaryKey(id);
        inform.setList(selectMap.get(inform.getCheckPart()));
        return WrapMapper.ok();
    }

    @Override
    public Wrapper submitTruckSafeInfo(TruckSafeInform safeInform) {
        safeInform.setState((byte) 1);
        int i=truckSafeInformMapper.updateByPrimaryKeySelective(safeInform);
        if(i>0){
            return WrapMapper.ok();
        }
        return WrapMapper.error("提交失败");
    }

    @Override
    public Wrapper getByTruckId(Long truckId) {
        TruckSafeInform truckSafeInform=truckSafeInformMapper.selectByTruckId(truckId);
        if(truckSafeInform==null){
            return WrapMapper.error("不存在安全隐患整改");
        }
        return WrapMapper.ok(truckSafeInform);
    }
}
