package com.ddcx.app.provider.truck.service;


import com.ddcx.app.provider.api.truck.model.vo.SubscribeParam;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;

/**
 * Created by CodeGenerator on 2020/03/11.
 */
public interface SubscribeService {


    Wrapper subscribe(SubscribeParam param, LoginAuthDto dto);

    Wrapper getMySubscribes(Integer page,Integer size,LoginAuthDto dto);

    Wrapper cancelSubscribe(Long id,LoginAuthDto dto);
}
