package com.ddcx.common.provider.service;

import com.ddcx.common.provider.api.zhiyun.*;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.Truck;

public interface ZhiYunService {

    /**
     * 身份证识别
     * @param frontPath
     * @param reversePath
     * @return
     * @throws Exception
     */
    Wrapper<ZhiYunIdAuth> idCardLicense(String frontPath, String reversePath) throws Exception;

    /**
     * 获取车辆最新位置
     * @param truckNum 车牌号
     */
    TruckLocation vLastLocationV3(String truckNum) throws Exception;


    /**
     * 行驶证识别
     * @param drivingPath 行驶证路径
     * @return
     * @throws Exception
     */
    Wrapper<ZhiYunDrivingLicence> drivingLicense(String drivingPath) throws Exception;


    /**
     * 获取车辆的违规信息
     * @return
     */
    ZhiYunBreakRules getBreakRules(Truck truck) throws Exception;

    /**
     * 获取车辆的里程信息
     * @return
     */
    ZhiYunMileageStatistics getMileageStatistics(Truck truck,String startDate,String endDate) throws Exception;

}
