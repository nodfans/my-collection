package com.ddcx.app.provider.api.uac.model.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class MyselfInfoVo implements java.io.Serializable {

    @ApiModelProperty(value = "userId")
    private Long userId;
    @ApiModelProperty(value = "头像")
    private String headImg;
    @ApiModelProperty("挂靠公司")
    private String comName;
    @ApiModelProperty(value = "类型 1：自营，2：挂靠", name = "userType")
    private Integer userType;
    @ApiModelProperty(value = "状态 0：禁用，1：正常", name = "state")
    private Integer state;
    @ApiModelProperty("紧急联系人")
    private String emergency;
    @ApiModelProperty("驾驶证到期时间")
    private Long licenceTime;
    @ApiModelProperty("从业资格证到期时间")
    private Long jobTime;
    @ApiModelProperty("身份证号码")
    private String idCard;
    @ApiModelProperty("银行卡绑定状态 1已绑定 0未绑定")
    private Integer bankState;
}
