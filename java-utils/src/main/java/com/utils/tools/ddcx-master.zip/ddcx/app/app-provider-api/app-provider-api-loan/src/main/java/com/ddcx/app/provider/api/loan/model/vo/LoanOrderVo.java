package com.ddcx.app.provider.api.loan.model.vo;

import com.ddcx.model.loan.LoanOrder;
import com.ddcx.model.loan.LoanRepaymentItem;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@ApiModel("贷款显示类")
@Data
public class LoanOrderVo {

    @ApiModelProperty("贷款主体信息")
    private LoanOrder loanOrder;

    @ApiModelProperty("贷款分期明细")
    private List<LoanRepaymentItem> items;

}
