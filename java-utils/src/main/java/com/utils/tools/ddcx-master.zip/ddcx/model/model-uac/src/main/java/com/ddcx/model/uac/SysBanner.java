package com.ddcx.model.uac;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Table(name = "sys_banner")
@ApiModel("banner")
public class SysBanner {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    /**
     * 标题
     */
    @ApiModelProperty("标题")
    @NotBlank
    private String title;

    /**
     * 位置 1.首页 2.二手车 3.保险
     */
    @NotNull
    @ApiModelProperty("位置:1.首页 2.二手车 3.保险")
    private Byte pos;

    /**
     * 开始时间
     */
    @ApiModelProperty("开始时间")
    @Column(name = "start_time")
    private Long startTime;

    /**
     * 结束时间
     */
    @ApiModelProperty("结束时间")
    @Column(name = "end_time")
    private Long endTime;

    /**
     * 状态 0：下线，1：上线
     */
    @ApiModelProperty("状态 0：下线，1：上线")
    @NotNull
    private Byte state;

    /**
     * 图片
     */
    @ApiModelProperty("图片")
    @NotBlank
    private String img;

    /**
     * 链接
     */
    @ApiModelProperty("链接")
    @NotBlank
    private String url;

    /**
     * 备注
     */
    @ApiModelProperty("备注")
    private String remarks;

    /**
     * 创建人
     */
    @ApiModelProperty("创建人")
    @Column(name = "create_user")
    private Long createUser;

    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    @Column(name = "create_time")
    private Long createTime;



    @ApiModelProperty("点击量")
    @Column(name = "click_count")
    private Integer clickCount;

    @ApiModelProperty("生产转化")
    @Column(name = "product_conversion")
    private Integer productConversion;

    @ApiModelProperty("排序")
    @Column(name = "sort")
    private Integer sort;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取标题
     *
     * @return title - 标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置标题
     *
     * @param title 标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取位置
     *
     * @return pos - 位置
     */
    public Byte getPos() {
        return pos;
    }

    /**
     * 设置位置
     *
     * @param pos 位置
     */
    public void setPos(Byte pos) {
        this.pos = pos;
    }

    /**
     * 获取开始时间
     *
     * @return start_time - 开始时间
     */
    public Long getStartTime() {
        return startTime;
    }

    /**
     * 设置开始时间
     *
     * @param startTime 开始时间
     */
    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    /**
     * 获取结束时间
     *
     * @return end_time - 结束时间
     */
    public Long getEndTime() {
        return endTime;
    }

    /**
     * 设置结束时间
     *
     * @param endTime 结束时间
     */
    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    /**
     * 获取状态 0：下线，1：上线
     *
     * @return state - 状态 0：下线，1：上线
     */
    public Byte getState() {
        return state;
    }

    /**
     * 设置状态 0：下线，1：上线
     *
     * @param state 状态 0：下线，1：上线
     */
    public void setState(Byte state) {
        this.state = state;
    }

    /**
     * 获取图片
     *
     * @return img - 图片
     */
    public String getImg() {
        return img;
    }

    /**
     * 设置图片
     *
     * @param img 图片
     */
    public void setImg(String img) {
        this.img = img;
    }

    /**
     * 获取链接
     *
     * @return url - 链接
     */
    public String getUrl() {
        return url;
    }

    /**
     * 设置链接
     *
     * @param url 链接
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * 获取备注
     *
     * @return remarks - 备注
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * 设置备注
     *
     * @param remarks 备注
     */
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    /**
     * 获取创建人
     *
     * @return create_user - 创建人
     */
    public Long getCreateUser() {
        return createUser;
    }

    /**
     * 设置创建人
     *
     * @param createUser 创建人
     */
    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }


    public Integer getClickCount() {
        return clickCount;
    }

    public void setClickCount(Integer clickCount) {
        this.clickCount = clickCount;
    }

    public Integer getProductConversion() {
        return productConversion;
    }

    public void setProductConversion(Integer productConversion) {
        this.productConversion = productConversion;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }
}