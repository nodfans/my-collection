package com.ddcx.app.provider.friend.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.friend.FriendLike;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface FriendLikeMapper extends MyMapper<FriendLike> {

    @Select("select * from friend_like where id=#{id}")
    List<FriendLike> selectByFriendCircleId(@Param("id") Long id);


    @Delete("delete from friend_like where id=#{id}")
    int deleteByFriendCircleId(@Param("id") Long id);

    @Select("select count(*) from friend_like where id=#{id} and user_id=#{userId}")
    byte selectCountByCircleAndUserId(@Param("id") Long id,@Param("userId") Long userId);

    @Select("delete from friend_like where id=#{id} and user_id=#{userId}")
    Integer clearLike(@Param("id") Long id,@Param("userId") Long userId);

    @Select("select count(*) from friend_like where id=#{id}")
    int selectCountByCircleId(@Param("id") Long id);

    @Update("update friend_like set nick_name=#{userName} where user_id=#{userId}")
    int updateUserNameByUserId(@Param("userId") Long userId,@Param("userName") String userName);
}