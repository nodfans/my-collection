package com.ddcx.app.provider.api.exam.vo;

import com.ddcx.model.exam.UacLearnInformation;
import com.ddcx.model.exam.UacLearnRecord;
import io.swagger.annotations.ApiModel;
import lombok.Data;

@ApiModel("学习资料显示类")
@Data
public class LearnVo {

    private UacLearnInformation uacLearnInformation;

    private UacLearnRecord uacLearnRecord;


}
