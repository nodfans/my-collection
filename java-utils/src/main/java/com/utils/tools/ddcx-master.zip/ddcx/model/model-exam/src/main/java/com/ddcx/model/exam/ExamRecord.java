package com.ddcx.model.exam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Table(name = "exam_record")
@ApiModel("考场记录表")
public class ExamRecord {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 考场地址
     */
    @ApiModelProperty("考场地址")
    @Column(name = "room_address")
    private String roomAddress;

    /**
     * 考生姓名
     */
    @ApiModelProperty("考生姓名")
    @Column(name = "user_name")
    private String userName;

    /**
     * 考生分数
     */
    @ApiModelProperty("考生分数")
    private Integer score;

    /**
     * 选择题正确数量
     */
    @ApiModelProperty("选择题正确数量")
    @Column(name = "select_true_num")
    private Integer selectTrueNum;

    /**
     * 判断题正确数量
     */
    @ApiModelProperty("判断题正确数量")
    @Column(name = "judge_true_num")
    private Integer judgeTrueNum;

    /**
     * 记录状态(1.有效 0.无效)
     */
    @ApiModelProperty("记录状态(1.有效 0.无效)")
    private Byte state;

    @ApiModelProperty("考生主键")
    private Long userId;

    @ApiModelProperty("考试时间")
    private Long examTime;

    @ApiModelProperty("考场主键")
    private Long roomId;

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public Long getExamTime() {
        return examTime;
    }

    public void setExamTime(Long examTime) {
        this.examTime = examTime;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    public String getRoomAddress() {
        return roomAddress;
    }

    public void setRoomAddress(String roomAddress) {
        this.roomAddress = roomAddress;
    }

    /**
     * 获取考生姓名
     *
     * @return user_name - 考生姓名
     */
    public String getUserName() {
        return userName;
    }

    /**
     * 设置考生姓名
     *
     * @param userName 考生姓名
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * 获取考生分数
     *
     * @return score - 考生分数
     */
    public Integer getScore() {
        return score;
    }

    /**
     * 设置考生分数
     *
     * @param score 考生分数
     */
    public void setScore(Integer score) {
        this.score = score;
    }

    /**
     * 获取选择题正确数量
     *
     * @return select_true_num - 选择题正确数量
     */
    public Integer getSelectTrueNum() {
        return selectTrueNum;
    }

    /**
     * 设置选择题正确数量
     *
     * @param selectTrueNum 选择题正确数量
     */
    public void setSelectTrueNum(Integer selectTrueNum) {
        this.selectTrueNum = selectTrueNum;
    }

    /**
     * 获取判断题正确数量
     *
     * @return judge_true_num - 判断题正确数量
     */
    public Integer getJudgeTrueNum() {
        return judgeTrueNum;
    }

    /**
     * 设置判断题正确数量
     *
     * @param judgeTrueNum 判断题正确数量
     */
    public void setJudgeTrueNum(Integer judgeTrueNum) {
        this.judgeTrueNum = judgeTrueNum;
    }

    /**
     * 获取记录状态(1.有效 2.无效)
     *
     * @return state - 记录状态(1.有效 2.无效)
     */
    public Byte getState() {
        return state;
    }

    /**
     * 设置记录状态(1.有效 2.无效)
     *
     * @param state 记录状态(1.有效 0.无效)
     */
    public void setState(Byte state) {
        this.state = state;
    }
}