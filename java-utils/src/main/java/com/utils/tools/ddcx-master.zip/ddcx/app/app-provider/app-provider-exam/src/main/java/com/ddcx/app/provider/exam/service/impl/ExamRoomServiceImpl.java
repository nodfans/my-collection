package com.ddcx.app.provider.exam.service.impl;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ddcx.app.provider.api.exam.param.ExamParam;
import com.ddcx.app.provider.exam.mapper.ExamRecordMapper;
import com.ddcx.app.provider.exam.mapper.ExamRoomMapper;
import com.ddcx.app.provider.exam.mapper.UserAnswerMapper;
import com.ddcx.app.provider.exam.service.ExamRoomService;
import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.common.provider.api.service.CommonServiceFeignApi;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.exam.ExamRecord;
import com.ddcx.model.exam.ExamRoom;
import com.ddcx.model.exam.QuestionVo;
import com.ddcx.model.exam.UserAnswer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by CodeGenerator on 2020/03/11.
 */
@Service
@Transactional
public class ExamRoomServiceImpl  implements ExamRoomService {
    @Resource
    private ExamRoomMapper examRoomMapper;
    @Resource
    private RedisUtil redisUtil;
    @Resource
    private UserAnswerMapper answerMapper;
    @Resource
    private ExamRecordMapper recordMapper;
    @Resource
    private CommonServiceFeignApi commonServiceFeignApi;

    @Override
    public Wrapper getValidRooms(LoginAuthDto dto) {
        Object o=redisUtil.get(RedisKey.EXAM_KEY+dto.getMotorcadeId());
        if(o==null){
            return WrapMapper.error("暂无考场安排");
        }
        JSONObject scoreConfig=commonServiceFeignApi.getSysConfigByKey(RedisKey.EXAM_SCORE_CONFIG+dto.getMotorcadeId());
        Integer selectScore=scoreConfig.getInteger("select");
        Integer judgeScore=scoreConfig.getInteger("judge");
        List<ExamRoom> list= JSON.parseArray(o.toString(),ExamRoom.class);
        list.forEach(room->{room.setTotalScore(room.getSelectCount()*selectScore+room.getJudgeCount()*judgeScore);});
        list=list.stream().filter(examRoom -> {if(examRoom.getRoomDate()+examRoom.getDuration()>System.currentTimeMillis()/1000){
         return true;
        }else {
            return false;
        }
        }).collect(Collectors.toList());
        return WrapMapper.ok(list);
    }

    @Override
    public Wrapper getQuestionsByRoomId(Long roomId, LoginAuthDto dto) {
        Object o1=redisUtil.get(RedisKey.ALREADY_EXAM+dto.getMotorcadeId()+dto.getUserId()+roomId);
        if(o1!=null){
            return WrapMapper.error("您已经交卷请勿重复考试");
        }
        Object o=redisUtil.hget(RedisKey.EXAM_TIME+dto.getMotorcadeId(),roomId+"");
        if(o==null){
            return WrapMapper.error("考场不存在");
        }
        if(Long.valueOf(String.valueOf(o))>System.currentTimeMillis()/1000){
            return WrapMapper.error("考试暂未开始，请耐心等候");
        }
        List<QuestionVo> list=JSON.parseArray(redisUtil.hget(RedisKey.QUESTION_KEY+dto.getMotorcadeId(),roomId+"").toString(),QuestionVo.class);
        return WrapMapper.ok(list);
    }

    @Override
    public Wrapper carryOutPaper(ExamParam param, LoginAuthDto dto) {
        Object o1=redisUtil.get(RedisKey.ALREADY_EXAM+dto.getMotorcadeId()+dto.getUserId()+param.getRoomId());
        if(o1!=null){
            return WrapMapper.error("您已经交卷请勿重复考试");
        }
        Long roomId=param.getRoomId();
        ExamRoom room=JSON.parseObject(redisUtil.hget(RedisKey.EXAM_ROOM+dto.getMotorcadeId(),roomId+"").toString(),ExamRoom.class);
        if(room==null||room.getDuration()*60+room.getRoomDate()<System.currentTimeMillis()/1000){
            return WrapMapper.error("考试已结束");
        }
        List<String> standardAnswers=JSON.parseArray(redisUtil.hget(RedisKey.QUESTION_ANSWER+dto.getMotorcadeId(),roomId+"").toString(),String.class);
        List<QuestionVo> questionVos=JSON.parseArray(redisUtil.hget(RedisKey.QUESTION_KEY+dto.getMotorcadeId(),roomId+"").toString(),QuestionVo.class);;
        //获取当前分值配置
        JSONObject scoreConfig=commonServiceFeignApi.getSysConfigByKey(RedisKey.EXAM_SCORE_CONFIG+dto.getMotorcadeId());
        Integer selectScore=scoreConfig.getInteger("select");
        Integer judgeScore=scoreConfig.getInteger("judge");
        //阅卷。。。。。。我竟然阅卷了 哈哈哈哈。。。
        List<String> userAnswers=param.getUserAnswers();
        ExamRecord record=new ExamRecord();
        List<UserAnswer> answers=new ArrayList<>(questionVos.size());
        UserAnswer userAnswer;
        int s=0;//记录选择题正确数
        int j=0;//记录判断题正确数
        String standardAnswer;
        String userAnswerStr;
        QuestionVo vo;
        for (int i = 0; i < questionVos.size()&&i<userAnswers.size(); i++) {
            vo=questionVos.get(i);
            standardAnswer=standardAnswers.get(i);
            userAnswerStr=userAnswers.get(i);
            userAnswer=new UserAnswer();
            userAnswer.setQuestionId(vo.getId());
            userAnswer.setTrueAnswer(standardAnswer);
            userAnswer.setUserAnswer(userAnswerStr);
            userAnswer.setQuestionNum(vo.getNum());
            answers.add(userAnswer);
            if(standardAnswer.equals(userAnswerStr)){
                if(vo.getType().intValue()==3){
                    j++;
                }else {
                    s++;
                }
            }
        }
        Integer totalScore=selectScore*s+judgeScore*j;
        record.setSelectTrueNum(s);
        record.setJudgeTrueNum(j);
        record.setRoomAddress(room.getAddress());
        record.setState((byte) 0);
        record.setScore(totalScore);
        record.setUserId(dto.getUserId());
        record.setUserName(dto.getUserName());
        record.setExamTime(room.getRoomDate());
        record.setRoomId(roomId);
        recordMapper.insertReturnId(record);
        answers.forEach(answer->{answer.setRecordId(record.getId());});
        answerMapper.insertList(answers);
        redisUtil.set(RedisKey.ALREADY_EXAM+dto.getMotorcadeId()+dto.getUserId()+roomId,1,6*60*60);
        return WrapMapper.ok(totalScore);
    }

}
