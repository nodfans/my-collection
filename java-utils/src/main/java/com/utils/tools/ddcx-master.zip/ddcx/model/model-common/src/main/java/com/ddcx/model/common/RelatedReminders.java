package com.ddcx.model.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Id;

@Data
@ApiModel("提醒配置")
public class RelatedReminders implements java.io.Serializable {

    @Id
    @ApiModelProperty("主键ID")
    private Long id;
    @ApiModelProperty("续保提醒天数")
    private Integer renewalDays;
    @ApiModelProperty("年检提醒天数")
    private Integer annualInspectionDays;
    @ApiModelProperty("还款提醒天数")
    private Integer repaymentDays;
    @ApiModelProperty("保养提醒天数")
    private Integer maintenanceDays;
    @ApiModelProperty("违章提醒天数")
    private Integer violationDays;
    @ApiModelProperty("请求救援提醒")
    private Integer askHelpKm;

}
