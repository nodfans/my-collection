package com.ddcx.common.provider.api.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "VerifyCodeResultVo", description = "验证码校验返回信息")
public class VerifyCodeResultVo implements java.io.Serializable {
    private static final long serialVersionUID = 7416825409765107685L;

    @ApiModelProperty(value = "账号", name = "account")
    private String account;

    @ApiModelProperty(value = "操作凭证", name = "actionToken")
    private String actionToken;
}
