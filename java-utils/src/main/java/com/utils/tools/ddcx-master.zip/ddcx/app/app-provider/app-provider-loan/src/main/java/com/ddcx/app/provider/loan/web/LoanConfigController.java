package com.ddcx.app.provider.loan.web;


import com.ddcx.app.provider.loan.service.LoanConfigService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.loan.LoanConfig;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/03/23.
*/
@RestController
@RequestMapping("/loan/config")
@Api(value = "贷款配置" ,tags = "贷款配置")
public class LoanConfigController extends BaseController {
    @Resource
    private LoanConfigService loanConfigService;


    @ApiOperation("根据车队id获取贷款设置")
    @GetMapping("/getLoanConfigByMotorcadeId")
    public Wrapper<LoanConfig> getLoanConfigByMotorcadeId(){
        return loanConfigService.getLoanConfigByMotorcadeId(getLoginAuthDto());
    }

}
