package com.ddcx.model.truck;

import com.ddcx.framework.util.StringUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

@ApiModel("汽车对象")
public class Truck {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long id;

    /**
     * 品牌
     */
    @ApiModelProperty(value = "品牌")
    private String brand;


    /**
     * 车辆类型
     */
    @ApiModelProperty(value = "车辆类型")
    private String type;

    /**
     * 核定吨位(吨)
     */
    @ApiModelProperty(value = "核定吨位(吨)")
    @Column(name = "load_weight")
    private Float loadWeight;

    /**
     * 车辆自重
     */
    @ApiModelProperty(value = "车辆自重")
    @Column(name = "own_weight")
    private Float ownWeight;

    /**
     * 发动机号
     */
    @ApiModelProperty(value = "发动机号")
    @Column(name = "engine_num")
    private String engineNum;

    /**
     * 底盘号
     */
    @ApiModelProperty(value = "底盘号")
    @Column(name = "chassis_number")
    private String chassisNumber;

    /**
     * 车牌号
     */
    @ApiModelProperty(value = "车牌号")
    @Column(name = "truck_num")
    private String truckNum;

    /**
     * 挂车车牌号
     */
    @ApiModelProperty(value = "挂车车牌号")
    @Column(name = "semitrailer_num")
    private String semitrailerNum;

    /**
     * 挂车车架号
     */
    @ApiModelProperty(value = "挂车车架号")
    @Column(name = "semitrailer_shelf_num")
    private String semitrailerShelfNum;

    /**
     * 车辆状态（1.正常 2.报停 3.报废）
     */
    @ApiModelProperty(value = "车辆状态（1.正常 2.报停 3.报废）")
    private Integer state;

    /**
     * 驾驶人id
     */
    @ApiModelProperty(value = "驾驶人id")
    @Column(name = "driver_id")
    private Long driverId;

    /**
     * 车主id
     */
    @ApiModelProperty(value = "车主id")
    @Column(name = "truck_owner_id")
    private Long truckOwnerId;

    /**
     * 上次年检时间
     */
    @ApiModelProperty(value = "上次年检时间")
    @Column(name = "annual_inspection_time")
    private Long annualInspectionTime;

    /**
     * 上次年检时间
     */
    @ApiModelProperty(value = "年检有效期（月）")
    @Column(name = "annual_inspection_valid")
    private Integer annualInspectionValid;

    /**
     * 年检到期时间
     */
    @ApiModelProperty(value = "年检到期时间")
    @Column(name = "annual_inspection_limit_time")
    private Long annualInspectionLimitTime;

    /**
     * 上次续保时间
     */
    @ApiModelProperty(value = "上次续保时间")
    @Column(name = "renewal_insurance_time")
    private Long renewalInsuranceTime;

    @ApiModelProperty(value = "续保有效期（月）")
    @Column(name = "renewal_insurance_valid")
    private Integer renewalInsuranceValid;

    /**
     * 续保到期时间
     */
    @ApiModelProperty(value = "续保到期时间")
    @Column(name = "renewal_insurance_limit_time")
    private Long renewalInsuranceLimitTime;

    /**
     * 上次保养时间
     */
    @ApiModelProperty(value = "上次保养时间")
    @Column(name = "upkeep_time")
    private Long upkeepTime;

    @ApiModelProperty(value = "续保有效期（月）")
    @Column(name = "upkeep_valid")
    private Integer upkeepValid;

    /**
     * 保养到期时间
     */
    @ApiModelProperty(value = "保养到期时间")
    @Column(name = "upkeep_limit_time")
    private Long upkeepLimitTime;

    /**
     * 车辆照片
     */
    @ApiModelProperty(value = "车辆照片")
    @Column(name = "truck_img")
    private String truckImg;

    /**
     * 合格证
     */
    @ApiModelProperty(value = "合格证")
    @Column(name = "certificate_qualification")
    private String certificateQualification;

    /**
     * 车检信息
     */
    @ApiModelProperty(value = "车检信息")
    @Column(name = "vehicle_inspection")
    private String vehicleInspection;

    /**
     * 发票
     */
    @ApiModelProperty(value = "发票")
    private String invoice;

    /**
     * 保单
     */
    @ApiModelProperty(value = "保单")
    @Column(name = "guarantee_slip")
    private String guaranteeSlip;

    /**
     * 机动车登记证书
     */
    @ApiModelProperty(value = "机动车登记证书")
    @Column(name = "locomotive_registration_certificate")
    private String locomotiveRegistrationCertificate;

    /**
     * GPS数据
     */
    @ApiModelProperty(value = "GPS数据")
    @Column(name = "gps_data")
    private String gpsData;

    @ApiModelProperty(value = "信息录入时间")
    private Long createTime;

    @ApiModelProperty(value = "车队id")
    @Column(name = "motorcade_id")
    private Long motorcadeId;

    @ApiModelProperty(value = "创建者id")
    @Column(name = "create_by")
    private Long createBy;

    @ApiModelProperty(value = "司机名称")
    @Column(name = "driver_name")
    private String driverName;

    @ApiModelProperty(value = "车主名称")
    @Column(name = "owner_name")
    private String ownerName;

    @ApiModelProperty(value = "汽车出售价格<汽车出售中，使用>")
    @Transient
    private BigDecimal salePrice;

    @ApiModelProperty(value = "出售状态:1.出售中 2.未出售; 该状态用来关联二手车交易")
    private Byte saleState;

    @ApiModelProperty(value = "用户级别: 0.无关人员 1.司机 2.车主")
    @Transient
    private Integer truckUserLevel = 0;

    @ApiModelProperty(value = "车辆最新位置经度")
    private String lng;

    @ApiModelProperty(value = "车辆最新位置纬度")
    private String lat;

    @ApiModelProperty(value = "车牌颜色")
    private Byte truckNumColor;

    @ApiModelProperty("保险公司")
    private String insuranceCompany;

    @ApiModelProperty("购买险种")
    private String insuranceType;


    @ApiModelProperty("车牌类型")
    private String carType;
    @Transient
    private String carTypeCode;

    @ApiModelProperty("公司主键")
    private Long comId;

    @ApiModelProperty("品牌厂商")
    private String  brandManufacturer;

    @Transient
    @ApiModelProperty("车辆图片传送数组")
    private List<String> truckImgList;


    public List<String> getTruckImgList() {
        return truckImgList;
    }

    public void setTruckImgList(List<String> truckImgList) {
        this.truckImgList = truckImgList;
    }

    public void setCarTypeCode(String carTypeCode) {
        this.carTypeCode = carTypeCode;
    }

    public String getBrandManufacturer() {
        return brandManufacturer;
    }

    public void setBrandManufacturer(String brandManufacturer) {
        this.brandManufacturer = brandManufacturer;
    }

    public Long getComId() {
        return comId;
    }

    public void setComId(Long comId) {
        this.comId = comId;
    }

    public String getCarTypeCode() {
        return carTypeCode;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
        if(carType!=null && carType.trim().length()!=0){
            switch (carType){
                case "大型汽车":carTypeCode="01"; break;
                case "小型汽车":carTypeCode="02"; break;
                case "使馆汽车":carTypeCode="03"; break;
                case "领馆汽车":carTypeCode="04"; break;
                case "境外汽车":carTypeCode="05"; break;
                case "外籍汽车":carTypeCode="06"; break;
                case "两三轮摩托车":carTypeCode="07"; break;
                case "轻便摩托车":carTypeCode="08"; break;
                case "使馆摩托车":carTypeCode="09"; break;
                case "领馆摩托车":carTypeCode="10"; break;
                case "境外摩托车":carTypeCode="11"; break;
                case "外籍摩托车":carTypeCode="12"; break;
                case "农用运输车":carTypeCode="13"; break;
                case "拖拉机":carTypeCode="14"; break;
                case "挂车":carTypeCode="15"; break;
                case "教练汽车":carTypeCode="16"; break;
                case "教练摩托车":carTypeCode="17"; break;
                case "香港入境车":carTypeCode="26"; break;
                case "澳门入境车":carTypeCode="27"; break;
                case "新能源大车":carTypeCode="51"; break;
                case "新能源小车":carTypeCode="52"; break;
                default:carTypeCode="0";
            }
        }
    }

    public String getInsuranceCompany() {
        return insuranceCompany;
    }

    public void setInsuranceCompany(String insuranceCompany) {
        this.insuranceCompany = insuranceCompany;
    }

    public String getInsuranceType() {
        return insuranceType;
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    public Byte getTruckNumColor() {
        return truckNumColor;
    }

    public void setTruckNumColor(Byte truckNumColor) {
        this.truckNumColor = truckNumColor;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public BigDecimal getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

    public Byte getSaleState() {
        return saleState;
    }

    public void setSaleState(Byte saleState) {
        this.saleState = saleState;
    }

    public Integer getTruckUserLevel() {
        return truckUserLevel;
    }

    public void setTruckUserLevel(Integer truckUserLevel) {
        this.truckUserLevel = truckUserLevel;
    }

    public Integer getRenewalInsuranceValid() {
        return renewalInsuranceValid;
    }

    public void setRenewalInsuranceValid(Integer renewalInsuranceValid) {
        this.renewalInsuranceValid = renewalInsuranceValid;
    }

    public Integer getUpkeepValid() {
        return upkeepValid;
    }

    public void setUpkeepValid(Integer upkeepValid) {
        this.upkeepValid = upkeepValid;
    }

    public Integer getAnnualInspectionValid() {
        return annualInspectionValid;
    }

    public void setAnnualInspectionValid(Integer annualInspectionValid) {
        this.annualInspectionValid = annualInspectionValid;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取品牌
     *
     * @return brand - 品牌
     */
    public String getBrand() {
        return brand;
    }

    /**
     * 设置品牌
     *
     * @param brand 品牌
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * 获取车辆类型
     *
     * @return type - 车辆类型
     */
    public String getType() {
        return type;
    }


    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    /**
     * 设置车辆类型
     *
     * @param type 车辆类型
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 获取核定吨位(吨)
     *
     * @return load_weight - 核定吨位(吨)
     */
    public Float getLoadWeight() {
        return loadWeight;
    }

    /**
     * 设置核定吨位(吨)
     *
     * @param loadWeight 核定吨位(吨)
     */
    public void setLoadWeight(Float loadWeight) {
        this.loadWeight = loadWeight;
    }

    /**
     * 获取车辆自重
     *
     * @return own_weight - 车辆自重
     */
    public Float getOwnWeight() {
        return ownWeight;
    }

    /**
     * 设置车辆自重
     *
     * @param ownWeight 车辆自重
     */
    public void setOwnWeight(Float ownWeight) {
        this.ownWeight = ownWeight;
    }

    /**
     * 获取发动机号
     *
     * @return engine_num - 发动机号
     */
    public String getEngineNum() {
        return engineNum;
    }

    /**
     * 设置发动机号
     *
     * @param engineNum 发动机号
     */
    public void setEngineNum(String engineNum) {
        this.engineNum = engineNum;
    }

    /**
     * 获取底盘号
     *
     * @return chassis_number - 底盘号
     */
    public String getChassisNumber() {
        return chassisNumber;
    }

    /**
     * 设置底盘号
     *
     * @param chassisNumber 底盘号
     */
    public void setChassisNumber(String chassisNumber) {
        this.chassisNumber = chassisNumber;
    }

    /**
     * 获取车牌号
     *
     * @return truck_num - 车牌号
     */
    public String getTruckNum() {
        return truckNum;
    }

    /**
     * 设置车牌号
     *
     * @param truckNum 车牌号
     */
    public void setTruckNum(String truckNum) {
        this.truckNum = truckNum;
    }

    /**
     * 获取挂车车牌号
     *
     * @return semitrailer_num - 挂车车牌号
     */
    public String getSemitrailerNum() {
        return semitrailerNum;
    }

    /**
     * 设置挂车车牌号
     *
     * @param semitrailerNum 挂车车牌号
     */
    public void setSemitrailerNum(String semitrailerNum) {
        this.semitrailerNum = semitrailerNum;
    }

    /**
     * 获取挂车车架号
     *
     * @return semitrailer_shelf_num - 挂车车架号
     */
    public String getSemitrailerShelfNum() {
        return semitrailerShelfNum;
    }

    /**
     * 设置挂车车架号
     *
     * @param semitrailerShelfNum 挂车车架号
     */
    public void setSemitrailerShelfNum(String semitrailerShelfNum) {
        this.semitrailerShelfNum = semitrailerShelfNum;
    }

    /**
     * 获取车辆状态（1.正常 2.报停 3.报废）
     *
     * @return state - 车辆状态（1.正常 2.报停 3.报废）
     */
    public Integer getState() {
        return state;
    }

    /**
     * 设置车辆状态（1.正常 2.报停 3.报废）
     *
     * @param state 车辆状态（1.正常 2.报停 3.报废）
     */
    public void setState(Integer state) {
        this.state = state;
    }

    /**
     * 获取驾驶人id
     *
     * @return driver_id - 驾驶人id
     */
    public Long getDriverId() {
        return driverId;
    }

    /**
     * 设置驾驶人id
     *
     * @param driverId 驾驶人id
     */
    public void setDriverId(Long driverId) {
        this.driverId = driverId;
    }

    /**
     * 获取车主id
     *
     * @return truck_owner_id - 车主id
     */
    public Long getTruckOwnerId() {
        return truckOwnerId;
    }

    /**
     * 设置车主id
     *
     * @param truckOwnerId 车主id
     */
    public void setTruckOwnerId(Long truckOwnerId) {
        this.truckOwnerId = truckOwnerId;
    }

    /**
     * 获取上次年检时间
     *
     * @return annual_inspection_time - 上次年检时间
     */
    public Long getAnnualInspectionTime() {
        return annualInspectionTime;
    }

    /**
     * 设置上次年检时间
     *
     * @param annualInspectionTime 上次年检时间
     */
    public void setAnnualInspectionTime(Long annualInspectionTime) {
        this.annualInspectionTime = annualInspectionTime;
    }

    /**
     * 获取年检到期时间
     *
     * @return annual_inspection_limit_time - 年检到期时间
     */
    public Long getAnnualInspectionLimitTime() {
        return annualInspectionLimitTime;
    }

    /**
     * 设置年检到期时间
     *
     * @param annualInspectionLimitTime 年检到期时间
     */
    public void setAnnualInspectionLimitTime(Long annualInspectionLimitTime) {
        this.annualInspectionLimitTime = annualInspectionLimitTime;
    }

    /**
     * 获取上次续保时间
     *
     * @return renewal_insurance_time - 上次续保时间
     */
    public Long getRenewalInsuranceTime() {
        return renewalInsuranceTime;
    }

    /**
     * 设置上次续保时间
     *
     * @param renewalInsuranceTime 上次续保时间
     */
    public void setRenewalInsuranceTime(Long renewalInsuranceTime) {
        this.renewalInsuranceTime = renewalInsuranceTime;
    }

    /**
     * 获取续保到期时间
     *
     * @return renewal_insurance_limit_time - 续保到期时间
     */
    public Long getRenewalInsuranceLimitTime() {
        return renewalInsuranceLimitTime;
    }

    /**
     * 设置续保到期时间
     *
     * @param renewalInsuranceLimitTime 续保到期时间
     */
    public void setRenewalInsuranceLimitTime(Long renewalInsuranceLimitTime) {
        this.renewalInsuranceLimitTime = renewalInsuranceLimitTime;
    }

    /**
     * 获取上次保养时间
     *
     * @return upkeep_time - 上次保养时间
     */
    public Long getUpkeepTime() {
        return upkeepTime;
    }

    /**
     * 设置上次保养时间
     *
     * @param upkeepTime 上次保养时间
     */
    public void setUpkeepTime(Long upkeepTime) {
        this.upkeepTime = upkeepTime;
    }

    /**
     * 获取保养到期时间
     *
     * @return upkeep_limit_time - 保养到期时间
     */
    public Long getUpkeepLimitTime() {
        return upkeepLimitTime;
    }

    /**
     * 设置保养到期时间
     *
     * @param upkeepLimitTime 保养到期时间
     */
    public void setUpkeepLimitTime(Long upkeepLimitTime) {
        this.upkeepLimitTime = upkeepLimitTime;
    }

    /**
     * 获取车辆照片
     *
     * @return truck_img - 车辆照片
     */
    public String getTruckImg() {
        return truckImg;
    }

    /**
     * 设置车辆照片
     *
     * @param truckImg 车辆照片
     */
    public void setTruckImg(String truckImg) {
        this.truckImg = truckImg;
        if(StringUtils.isNotBlank(truckImg)){
            String[] strings=truckImg.split(";");
            truckImgList= Arrays.asList(strings);
        }
    }

    /**
     * 获取合格证
     *
     * @return certificate_qualification - 合格证
     */
    public String getCertificateQualification() {
        return certificateQualification;
    }

    /**
     * 设置合格证
     *
     * @param certificateQualification 合格证
     */
    public void setCertificateQualification(String certificateQualification) {
        this.certificateQualification = certificateQualification;
    }

    /**
     * 获取车检信息
     *
     * @return vehicle_inspection - 车检信息
     */
    public String getVehicleInspection() {
        return vehicleInspection;
    }

    /**
     * 设置车检信息
     *
     * @param vehicleInspection 车检信息
     */
    public void setVehicleInspection(String vehicleInspection) {
        this.vehicleInspection = vehicleInspection;
    }

    /**
     * 获取发票
     *
     * @return invoice - 发票
     */
    public String getInvoice() {
        return invoice;
    }

    /**
     * 设置发票
     *
     * @param invoice 发票
     */
    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }

    /**
     * 获取保单
     *
     * @return guarantee_slip - 保单
     */
    public String getGuaranteeSlip() {
        return guaranteeSlip;
    }

    /**
     * 设置保单
     *
     * @param guaranteeSlip 保单
     */
    public void setGuaranteeSlip(String guaranteeSlip) {
        this.guaranteeSlip = guaranteeSlip;
    }

    /**
     * 获取机动车登记证书
     *
     * @return locomotive_registration_certificate - 机动车登记证书
     */
    public String getLocomotiveRegistrationCertificate() {
        return locomotiveRegistrationCertificate;
    }

    /**
     * 设置机动车登记证书
     *
     * @param locomotiveRegistrationCertificate 机动车登记证书
     */
    public void setLocomotiveRegistrationCertificate(String locomotiveRegistrationCertificate) {
        this.locomotiveRegistrationCertificate = locomotiveRegistrationCertificate;
    }

    /**
     * 获取GPS数据
     *
     * @return gps_data - GPS数据
     */
    public String getGpsData() {
        return gpsData;
    }

    /**
     * 设置GPS数据
     *
     * @param gpsData GPS数据
     */
    public void setGpsData(String gpsData) {
        this.gpsData = gpsData;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }


    public Long getMotorcadeId() {
        return motorcadeId;
    }

    public void setMotorcadeId(Long motorcadeId) {
        this.motorcadeId = motorcadeId;
    }

    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }
}