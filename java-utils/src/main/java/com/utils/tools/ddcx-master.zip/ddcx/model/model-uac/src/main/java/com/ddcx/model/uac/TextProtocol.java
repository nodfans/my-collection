package com.ddcx.model.uac;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Table(name = "text_protocol")
@ApiModel("文本协议")
public class TextProtocol {
    /**
     * 主键
     */
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    @NotNull
    @Id
    private Long id;

    /**
     * 标题
     */
    @NotBlank
    @ApiModelProperty("标题")
    private String title;

    /**
     * 内容
     */
    @NotBlank
    @ApiModelProperty("内容")
    private String congtent;

    /**
     * 类型 1.关于我们 2.用户协议
     */
    @NotNull
    @ApiModelProperty("1.关于我们 2.用户协议")
    private Byte type;


    /**
     * 修改人
     */
    @ApiModelProperty("修改人")
    @Column(name = "update_by")
    private Long updateBy;

    /**
     * 修改时间
     */
    @ApiModelProperty("修改时间")
    @Column(name = "update_time")
    private Long updateTime;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取标题
     *
     * @return title - 标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置标题
     *
     * @param title 标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取内容
     *
     * @return congtent - 内容
     */
    public String getCongtent() {
        return congtent;
    }

    /**
     * 设置内容
     *
     * @param congtent 内容
     */
    public void setCongtent(String congtent) {
        this.congtent = congtent;
    }

    /**
     * 获取类型
     *
     * @return type - 类型
     */
    public Byte getType() {
        return type;
    }

    /**
     * 设置类型
     *
     * @param type 类型
     */
    public void setType(Byte type) {
        this.type = type;
    }


    /**
     * 获取修改人
     *
     * @return update_by - 修改人
     */
    public Long getUpdateBy() {
        return updateBy;
    }

    /**
     * 设置修改人
     *
     * @param updateBy 修改人
     */
    public void setUpdateBy(Long updateBy) {
        this.updateBy = updateBy;
    }

    /**
     * 获取修改时间
     *
     * @return update_time - 修改时间
     */
    public Long getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置修改时间
     *
     * @param updateTime 修改时间
     */
    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }
}