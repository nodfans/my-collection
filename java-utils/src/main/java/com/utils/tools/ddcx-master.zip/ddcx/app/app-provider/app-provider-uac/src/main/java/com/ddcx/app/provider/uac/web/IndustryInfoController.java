package com.ddcx.app.provider.uac.web;


import com.ddcx.app.provider.uac.service.IndustryInfoService;
import com.ddcx.framework.core.annotation.NoNeedAccessAuthentication;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.IndustryInfo;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
* Created by CodeGenerator on 2020/03/16.
*/
@RestController
@RequestMapping("/industry/info")
@Api(value = "行业资讯接口" , tags = "行业资讯接口")
public class IndustryInfoController {
    @Resource
    private IndustryInfoService industryInfoService;


    @NoNeedAccessAuthentication
    @ApiOperation("行业资讯列表查询")
    @GetMapping("/listOfPage")
    public Wrapper<PageInfo<IndustryInfo>> list(
                        @ApiParam(value = "页数", defaultValue = "1") @RequestParam(defaultValue = "1") Integer page,
                        @ApiParam(value = "每页记录数", defaultValue = "10") @RequestParam(defaultValue = "10") Integer size){
        return industryInfoService.listOfPage(page,size);
    }


    @NoNeedAccessAuthentication
    @ApiOperation("行业资讯详情")
    @GetMapping("/detail")
    public Wrapper<IndustryInfo> detail(@ApiParam("主键") @RequestParam  Long id){
        return industryInfoService.detail(id);
    }



}
