package com.ddcx.app.provider.exam.web;

import com.ddcx.app.provider.exam.service.ExamRecordService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.exam.ExamRecord;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/04/14.
*/
@RestController
@RequestMapping("/exam/record")
@Api(value = "考试记录模块",tags = "考试记录模块")
public class ExamRecordController extends BaseController {
    @Resource
    private ExamRecordService examRecordService;

    @ApiOperation("获取用户考试记录")
    @GetMapping("/getOwnExamRecords")
    public Wrapper<PageInfo<ExamRecord>> getOwnExamRecords(@ApiParam(value = "当前页", defaultValue = "1") Integer page,
                                                           @ApiParam(value = "每页记录数", defaultValue = "10") Integer size){
        return examRecordService.getOwnExamRecords(page,size,getLoginAuthDto().getUserId());
    }

}
