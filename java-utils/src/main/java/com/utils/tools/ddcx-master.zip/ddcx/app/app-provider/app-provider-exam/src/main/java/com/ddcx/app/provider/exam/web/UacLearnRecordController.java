package com.ddcx.app.provider.exam.web;


import com.ddcx.app.provider.exam.service.UacLearnRecordService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.exam.UacLearnRecord;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/03/11.
*/
@RestController
@RequestMapping("/uac/learn/record")
@Api(value = "用户记录模块",tags = "用户记录模块")
public class UacLearnRecordController extends BaseController {
    @Resource
    private UacLearnRecordService uacLearnRecordService;


    @ApiOperation("添加用户学习记录")
    @PostMapping("/saveRecord")
    public Wrapper saveRecord(@ApiParam("记录主体") @RequestBody @Validated UacLearnRecord record){
        return uacLearnRecordService.saveRecord(record,getLoginAuthDto());
    }
}
