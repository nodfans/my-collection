package com.ddcx.app.provider.api.exam.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;

@ApiModel("考试参数")
@Data
public class ExamParam {

    @NotNull(message = "考场主键不能为空")
    @ApiModelProperty("考场id")
    private Long roomId;

    @NotNull(message = "用户答案不能为空")
    @ApiModelProperty("用户答案列表")
    private List<String> userAnswers;


}
