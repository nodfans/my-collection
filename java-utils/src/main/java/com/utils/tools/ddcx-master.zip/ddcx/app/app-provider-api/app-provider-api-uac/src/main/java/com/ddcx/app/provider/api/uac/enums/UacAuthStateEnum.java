package com.ddcx.app.provider.api.uac.enums;



public enum UacAuthStateEnum {
    refuse(-1,"审核失败"),audit(0,"审核中"),pass(1,"认证通过");

    private Integer code;

    private String msg;

    UacAuthStateEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
