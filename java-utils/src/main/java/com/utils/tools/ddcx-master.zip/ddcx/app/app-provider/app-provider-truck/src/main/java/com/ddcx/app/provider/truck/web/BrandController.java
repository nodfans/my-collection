package com.ddcx.app.provider.truck.web;


import com.ddcx.app.provider.truck.service.BrandService;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.BrandVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/02/26.
 * 汽车品牌
 */
@RestController
@RequestMapping("/truck/brand")
@Api(value = "汽车品牌", tags = "汽车品牌")
public class BrandController {
    @Resource
    private BrandService brandService;

    @GetMapping("/getBrandVos")
    @ApiOperation("获取汽车品牌列表")
    public Wrapper<List<BrandVo>> getBrandVos() {
        return WrapMapper.ok(brandService.getBrandVo());
    }


}
