package com.ddcx.app.provider.truck.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.truck.TruckYearLogin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;


@Component
@Mapper
public interface TruckYearLoginMapper extends MyMapper<TruckYearLogin> {


    @Select("select * from truck_year_login where truck_id=#{truckId} order by assess desc limit 1")
    TruckYearLogin getTruckYearLogin(@Param("truckId") Long truckId);


}