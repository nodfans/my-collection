package com.ddcx.app.provider.truck.web;


import com.ddcx.app.provider.truck.service.TruckMileageStatisticsService;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.TruckMileageStatistics;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/04/17.
*/
@RestController
@RequestMapping("/truck/mileage/statistics")
@Api(value = "车辆行驶里程统计表模块",tags = "车辆行驶里程统计表模块")
public class TruckMileageStatisticsController {
    @Resource
    private TruckMileageStatisticsService truckMileageStatisticsService;


    @ApiOperation("获取车辆最近行驶里程数据")
    @GetMapping("/getMileageStatistics")
    public Wrapper<TruckMileageStatistics> getMileageStatistics(@ApiParam(value = "车辆主键",required = true)@RequestParam Long truckId){
        return truckMileageStatisticsService.getMileageStatistics(truckId);
    }


}
