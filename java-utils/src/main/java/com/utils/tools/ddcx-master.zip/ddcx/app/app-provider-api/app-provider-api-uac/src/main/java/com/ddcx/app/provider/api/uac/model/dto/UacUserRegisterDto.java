package com.ddcx.app.provider.api.uac.model.dto;

import com.ddcx.app.provider.api.uac.enums.UacFromTypeEnum;
import com.ddcx.app.provider.api.uac.enums.UacUserTypeEnum;
import com.ddcx.framework.core.validated.EnumValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@ApiModel(value = "UacUserRegisterDto", description = "用户注册")
public class UacUserRegisterDto implements java.io.Serializable {

    private static final long serialVersionUID = 5008856796284437075L;

    @NotBlank(message = "手机号码不能为空")
    @ApiModelProperty(value = "手机号码", name = "phone", required = true)
    private String phone;

    @NotBlank(message = "密码不能为空")
    @ApiModelProperty(value = "密码", name = "password", required = true)
    private String password;

    @NotNull(message = "用户类型不能为空")
    @EnumValid(target = UacUserTypeEnum.class, message = "用户类型错误")
    @ApiModelProperty(value = "用户类型 1-自营，2-挂靠", name = "userType", required = true)
    private Integer userType;

    @NotNull(message = "车队id不能为空")
    @ApiModelProperty(value = "车队id", name = "motorcadeId", required = true)
    private Long motorcadeId;

    @NotBlank(message = "车队名称不能为空")
    @ApiModelProperty(value = "车队名称", name = "motorcadeName", required = true)
    private String motorcadeName;

    @NotBlank(message = "企业名称不能为空")
    @ApiModelProperty(value = "企业名称", name = "comName", required = true)
    private String comName;

    @NotBlank(message = "验证码不能为空<注册时传token>")
    @ApiModelProperty(value = "验证码", name = "code", required = true)
    private String code;

    @NotNull(message = "来源不能为空")
    @EnumValid(target = UacFromTypeEnum.class, message = "来源类型错误")
    @ApiModelProperty(value = "来源 1-android，2-ios，3-pc", name = "fromType", required = true)
    private Integer fromType;



//    @NotBlank(message = "昵称不能为空")
    @ApiModelProperty(value = "昵称", name = "nickName", required = false)
    private String nickName;


//    @NotBlank(message = "头像不能为空")
    @ApiModelProperty(value = "头像", name = "headImg", required = false)
    private String headImg;




}
