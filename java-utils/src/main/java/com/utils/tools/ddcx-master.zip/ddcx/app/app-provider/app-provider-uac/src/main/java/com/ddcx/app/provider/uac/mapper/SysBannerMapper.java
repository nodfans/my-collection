package com.ddcx.app.provider.uac.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.uac.SysBanner;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import java.util.List;


@Mapper
@Component
public interface SysBannerMapper extends MyMapper<SysBanner> {

    @Select("select * from sys_banner where pos=#{pos} and state=1 and  end_time > #{createTime} and  start_time < #{createTime} order by sort")
    List<SysBanner> selectCurrentBanner(SysBanner banner);

    @Update("update sys_banner set click_count=click_count+1 where id=#{bannerId}")
    void addSelf(@Param("bannerId") Long bannerId);

}