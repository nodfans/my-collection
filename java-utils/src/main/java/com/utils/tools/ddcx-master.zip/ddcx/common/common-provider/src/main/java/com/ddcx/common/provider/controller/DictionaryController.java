package com.ddcx.common.provider.controller;


import com.ddcx.framework.core.annotation.NoNeedAccessAuthentication;
import com.ddcx.model.common.Dictionary;
import com.ddcx.common.provider.service.DictionaryService;
import com.ddcx.framework.util.wrapper.Wrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/02/27.
 */
@RestController
@RequestMapping("/dictionary")
@Api(value = "数据字典", tags = "数据字典")
public class DictionaryController {
    @Resource
    private DictionaryService dictionaryService;


    @NoNeedAccessAuthentication
    @GetMapping({"/getDictionaryByType","/admin/getDictionaryByType"})
    @ApiOperation(value = "获取对应类型的数据字典")
    public Wrapper<List<Dictionary>> getDictionaryByType(@RequestParam @ApiParam(value = "类型：1.车辆类型 2.驱动形式 3.发动机 4.环保标准 5.检查部位 6.整改措施 7.车牌类型", required = true) Integer type) {
        return dictionaryService.getDictionaryByType(type);
    }


    @ApiOperation(value = "数据字典数据添加",notes = "类型：1.车辆类型 2.驱动形式 3.发动机 4.环保标准 5.检查部位 6.整改措施 7.车牌类型")
    @GetMapping("/admin/addDictionary")
    public Wrapper addDictionary(@RequestParam @ApiParam(value = "数据字典信息")String data,@RequestParam@ApiParam("数据字典参数") Integer type){
        return dictionaryService.addDictionary(data,type);
    }

    @ApiOperation(value = "数据字典类型删除")
    @GetMapping("/admin/deleteDictionary")
    public Wrapper deleteDictionary(@RequestParam@ApiParam("数据字典主键") Long id){
        return dictionaryService.deleteDictionary(id);
    }

}
