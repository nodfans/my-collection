package com.ddcx.app.provider.api.uac.service;

import com.ddcx.app.provider.api.uac.model.dto.UacCheckAccountDto;
import com.ddcx.app.provider.api.uac.model.vo.UacUserVo;
import com.ddcx.app.provider.api.uac.service.hystrix.UacUserServiceFeignApiHystrix;
import com.ddcx.framework.core.annotation.NoNeedAccessAuthentication;
import com.ddcx.framework.core.feign.FeignAutoConfiguration;
import com.ddcx.model.uac.IdAuth;
import com.ddcx.model.uac.UacUser;
import com.ddcx.model.uac.UserBacklog;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Component
@FeignClient(value = "ddcx-app-provider-uac", configuration = FeignAutoConfiguration.class, fallback = UacUserServiceFeignApiHystrix.class)
public interface UacUserServiceFeignApi {

    @NoNeedAccessAuthentication
    @PostMapping(value = "/api/user/phone")
    UacUserVo getUserByPhone(@RequestBody UacCheckAccountDto uacCheckAccountDto);

    @NoNeedAccessAuthentication
    @GetMapping(value = "/api/user/{id}")
    UacUserVo getUserById(@PathVariable(value = "id") Long id);


    @NoNeedAccessAuthentication
    @GetMapping(value = "/api/user/getAuthInfo")
    IdAuth getAuthInfo(@RequestParam Long userId);


    /**
     * 新增待办事宜
     * @param backlog
     * @return
     */
    @NoNeedAccessAuthentication
    @PostMapping(value = "/api/user/addUserBackLog")
    Integer addUserBackLog(@RequestBody UserBacklog backlog);


    /**
     * 批量新增待办事宜
     * @param backlogs
     * @return
     */
    @NoNeedAccessAuthentication
    @PostMapping(value = "/api/user/addAllUserBackLog")
    Integer addAllUserBackLog(@RequestBody List<UserBacklog> backlogs);



    @NoNeedAccessAuthentication
    @GetMapping(value = "/api/get/user")
    UacUser getUser(@PathVariable(value = "id") Long id);

}
