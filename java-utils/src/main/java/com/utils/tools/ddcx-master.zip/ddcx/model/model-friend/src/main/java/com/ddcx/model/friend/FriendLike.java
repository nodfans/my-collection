package com.ddcx.model.friend;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Table(name = "friend_like")
@ApiModel("朋友圈喜欢")
public class FriendLike {
    /**
     * 卡友圈主键
     */
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("卡友圈主键")
    @Id
    private Long id;

    /**
     * 用户主键
     */
    @ApiModelProperty("用户主键")
    @Column(name = "user_id")
    private Long userId;

    /**
     * 用户昵称
     */
    @ApiModelProperty("用户昵称")
    @Column(name = "nick_name")
    private String nickName;

    /**
     * 获取卡友圈主键
     *
     * @return id - 卡友圈主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置卡友圈主键
     *
     * @param id 卡友圈主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取用户主键
     *
     * @return user_id - 用户主键
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置用户主键
     *
     * @param userId 用户主键
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 获取用户昵称
     *
     * @return nick_name - 用户昵称
     */
    public String getNickName() {
        return nickName;
    }

    /**
     * 设置用户昵称
     *
     * @param nickName 用户昵称
     */
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
}