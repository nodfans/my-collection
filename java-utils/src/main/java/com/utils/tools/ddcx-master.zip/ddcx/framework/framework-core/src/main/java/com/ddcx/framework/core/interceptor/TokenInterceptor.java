package com.ddcx.framework.core.interceptor;

import com.ddcx.framework.base.constant.GlobalConstant;
import com.ddcx.framework.base.dto.AdminLoginAutoDto;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.base.enums.ErrorCodeEnum;
import com.ddcx.framework.base.exception.BizException;
import com.ddcx.framework.core.annotation.NoNeedAccessAuthentication;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.framework.util.RequestUtil;
import com.ddcx.framework.util.ThreadLocalMap;
import com.ddcx.framework.util.token.JwtUtil;
import com.ddcx.framework.util.token.TokenObject;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class TokenInterceptor implements HandlerInterceptor {

    @Value(value = "${token.secretKey}")
    private String token_secret_key;

    private String token_admin_secret_key="9ac123123gdrgde2a133a0988faa05b9";

    @Autowired
    private RedisUtil redisUtil;

    /**
     * 不用配置的默认权限
     */
    private List<String> whiteFunction=new ArrayList<>();

    {
        whiteFunction.add("/admin/logout2");
        whiteFunction.add("/admin/refresh");
        whiteFunction.add("/admin/function/main");
        whiteFunction.add("/admin/function/current");
        whiteFunction.add("/admin/motorcade/getValidMotorcadeId");
        whiteFunction.add("/admin/subscribe/getByConfigId");
        whiteFunction.add("/admin/user/getUsersByMotorcadeId");
        whiteFunction.add("/admin/truck/getTrucksByMotorcadeId");
        whiteFunction.add("/admin/loan/order/getHistoryLoanListOfPage");
        whiteFunction.add("/admin/loan/config/getLoanConfigByMotorcadeId");
        whiteFunction.add("/admin/question/getAllQuestionByType");
        whiteFunction.add("/admin/reminder/get");
        whiteFunction.add("/admin/circle/reply/deleteFriendReply");
        whiteFunction.add("/admin/sys/banner/detail");
        whiteFunction.add("/admin/function/getFunctionIdsByRoleId");
        whiteFunction.add("/dictionary/admin/deleteDictionary");
        whiteFunction.add("/ddcx/img/admin/upload/view");
        whiteFunction.add("/ddcx/img/admin/upload");
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object arg2, Exception ex) throws Exception {
        if (ex != null) {
            log.error("<== afterCompletion - 解析token失败. ex={}", ex.getMessage(), ex);
            this.handleException(response);
        }
    }


    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object arg2, ModelAndView mv) {

    }


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String uri = request.getRequestURI();
        log.info("<== preHandle url={}", uri);
        System.out.println(request.getRequestURL());
        String token = RequestUtil.getToken(request);
        log.info("token= {}", token);
        if (isHaveAccess(handler)) {
            log.info("<== preHandle - 不需要认证  uri={}", uri);
            if(PublicUtil.isEmpty(token)){
                return true;
            }
            whiteFunction.add(uri);
        }



        if (PublicUtil.isNotEmpty(token)) {
            token = new String(Base64.decodeBase64(token));
            log.info("token---->>>>" + token);
            TokenObject tokenObject = new TokenObject();
            if(uri.contains("admin")){
                tokenObject.setSecretKey(token_admin_secret_key);
                String userId;
                try {
                    final Claims claims = new JwtUtil().parseJWT(token, tokenObject);
                    userId = claims.getSubject();
                } catch (Exception e) {
                    log.error(e.getMessage());
                    throw new BizException(ErrorCodeEnum.GL99990101);
                }
                log.info("adminUserId= {}", userId);
                if (PublicUtil.isEmpty(userId)) {
                    throw new BizException(ErrorCodeEnum.GL99990101);
                }
                AdminLoginAutoDto loginUser = (AdminLoginAutoDto) redisUtil.hget(GlobalConstant.ADMIN_LOGIN , userId);
                if (PublicUtil.isEmpty(loginUser)) {
                    log.error("获取用户信息失败, 不允许操作");
                    throw new BizException(ErrorCodeEnum.GL99990101);
                }
                String loginToken = new String(Base64.decodeBase64(loginUser.getToken()));
                if (!token.equals(loginToken)) {
                    throw new BizException(ErrorCodeEnum.GL99990101);
                }
                List<String> list= (List<String>) redisUtil.hget(GlobalConstant.ADMIN_FUNCTION,userId);
                list.addAll(whiteFunction);
                if(!list.contains(uri)){
                    throw new BizException(ErrorCodeEnum.GL99990104);
                }
                ThreadLocalMap.put(GlobalConstant.Sys.TOKEN_AUTH_DTO, loginUser);
            }else {
                tokenObject.setSecretKey(token_secret_key);
                Long userId;
                try {
                    final Claims claims = new JwtUtil().parseJWT(token, tokenObject);
                    userId = Long.valueOf(claims.getSubject());
                } catch (Exception e) {
                    log.error(e.getMessage());
                    throw new BizException(ErrorCodeEnum.GL99990101);
                }
                log.info("userId= {}", userId);
                if (PublicUtil.isEmpty(userId)) {
                    throw new BizException(ErrorCodeEnum.GL99990101);
                }
                LoginAuthDto loginUser = (LoginAuthDto) redisUtil.get(GlobalConstant.Sys.LOGIN_TOKEN + ":" + userId);
                if (PublicUtil.isEmpty(loginUser)) {
                    log.error("获取用户信息失败, 不允许操作");
                    throw new BizException(ErrorCodeEnum.GL99990101);
                }
                String loginToken = new String(Base64.decodeBase64(loginUser.getToken()));
                if (!token.equals(loginToken)) {
                    throw new BizException(ErrorCodeEnum.GL99990101);
                }
                ThreadLocalMap.put(GlobalConstant.Sys.TOKEN_AUTH_DTO, loginUser);
            }

        }
        return true;
    }

    private void handleException(HttpServletResponse res) throws IOException {
        res.resetBuffer();
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Credentials", "true");
        res.setContentType("application/json");
        res.setCharacterEncoding("UTF-8");
        res.getWriter().write("{\"code\":100009 ,\"message\" :\"解析token失败\"}");
        res.flushBuffer();
    }

    private boolean isHaveAccess(Object handler) {
        HandlerMethod handlerMethod = (HandlerMethod) handler;

        Method method = handlerMethod.getMethod();

        NoNeedAccessAuthentication responseBody = AnnotationUtils.findAnnotation(method, NoNeedAccessAuthentication.class);
        return responseBody != null;
    }
}
