package com.ddcx.app.provider.exam.web;


import com.ddcx.app.provider.exam.service.UacLearnInformationService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.exam.UacLearnInformation;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/03/11.
*/
@RestController
@RequestMapping("/uac/learn/information")
@Api(value = "学习资料",tags = "学习资料")
public class UacLearnInformationController extends BaseController {
    @Resource
    private UacLearnInformationService uacLearnInformationService;


    @ApiOperation("获取学习资料")
    @GetMapping("/getInfoByType")
    public Wrapper<UacLearnInformation> getInfoByType(@ApiParam("1.文字 2.视频") @RequestParam Byte type){
        return uacLearnInformationService.getInfoByType(type,getLoginAuthDto());
    }


    @ApiOperation("获取学习资料详情")
    @GetMapping("/detail")
    public Wrapper<UacLearnInformation> detail(@ApiParam("资料主键") @RequestParam Long id){
        return uacLearnInformationService.detail(id,getLoginAuthDto());

    }


}
