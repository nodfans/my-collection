package com.ddcx.app.provider.truck.service;

import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.TruckYearLogin;

/**
 * Created by CodeGenerator on 2020/04/17.
 */
public interface TruckYearLoginService {

    Wrapper addTruckYearLogin(TruckYearLogin yearLogin);


    Wrapper getTruckYearLogin(Long truckId);

}
