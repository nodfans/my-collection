package com.ddcx.model.uac;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@ApiModel("企业表")
public class Company {
    /**
     * 主键
     */
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    @Id
    private Long id;

    /**
     * 企业名
     */
    @ApiModelProperty("企业名")
    private String name;

    /**
     * 唯一社会信用代码
     */
    @ApiModelProperty("唯一社会信用代码")
    private String code;

    /**
     * 企业管理员
     */
    @ApiModelProperty("企业管理员")
    @Column(name = "admin_id")
    private Long adminId;

    /**
     * 企业地址
     */
    @ApiModelProperty("企业地址")
    private String address;

    /**
     * 企业管理员手机号码
     */
    @ApiModelProperty("企业管理员手机号码")
    @Column(name = "admin_phone")
    private String adminPhone;

    /**
     * 来源:1.平台创建 2.网页申请
     */
    @ApiModelProperty("来源:1.平台创建 2.网页申请")
    private Byte source;

    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    @Column(name = "create_time")
    private Long createTime;

    @Transient
    @ApiModelProperty("公司管理员角色主键")
    private Long adminRoleId;

    /**
     * 状态:1.审核中 2.审核通过 3.审核拒绝
     */
    @ApiModelProperty("状态:1.审核中 2.审核通过(启用) 3.审核拒绝 4.禁用")
    private Byte state;

    @ApiModelProperty("审核人主键")
    private Long auditBy;

    @ApiModelProperty("最新车队名称")
    private String newMotorcadeName;

    public String getNewMotorcadeName() {
        return newMotorcadeName;
    }

    public void setNewMotorcadeName(String newMotorcadeName) {
        this.newMotorcadeName = newMotorcadeName;
    }

    public Long getAuditBy() {
        return auditBy;
    }

    public Long getAdminRoleId() {
        return adminRoleId;
    }

    public void setAuditBy(Long auditBy) {
        this.auditBy = auditBy;
    }

    public void setAdminRoleId(Long adminRoleId) {
        this.adminRoleId = adminRoleId;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取企业名
     *
     * @return name - 企业名
     */
    public String getName() {
        return name;
    }

    /**
     * 设置企业名
     *
     * @param name 企业名
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取唯一社会信用代码
     *
     * @return code - 唯一社会信用代码
     */
    public String getCode() {
        return code;
    }

    /**
     * 设置唯一社会信用代码
     *
     * @param code 唯一社会信用代码
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 获取企业管理员
     *
     * @return admin_id - 企业管理员
     */
    public Long getAdminId() {
        return adminId;
    }

    /**
     * 设置企业管理员
     *
     * @param adminId 企业管理员
     */
    public void setAdminId(Long adminId) {
        this.adminId = adminId;
    }

    /**
     * 获取企业地址
     *
     * @return address - 企业地址
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置企业地址
     *
     * @param address 企业地址
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * 获取企业管理员手机号码
     *
     * @return admin_phone - 企业管理员手机号码
     */
    public String getAdminPhone() {
        return adminPhone;
    }

    /**
     * 设置企业管理员手机号码
     *
     * @param adminPhone 企业管理员手机号码
     */
    public void setAdminPhone(String adminPhone) {
        this.adminPhone = adminPhone;
    }

    /**
     * 获取来源:1.平台创建 2.网页申请
     *
     * @return source - 来源:1.平台创建 2.网页申请
     */
    public Byte getSource() {
        return source;
    }

    /**
     * 设置来源:1.平台创建 2.网页申请
     *
     * @param source 来源:1.平台创建 2.网页申请
     */
    public void setSource(Byte source) {
        this.source = source;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取状态:1.审核中 2.审核通过 3.审核拒绝
     *
     * @return state - 状态:1.审核中 2.审核通过 3.审核拒绝
     */
    public Byte getState() {
        return state;
    }

    /**
     * 设置状态:1.审核中 2.审核通过 3.审核拒绝
     *
     * @param state 状态:1.审核中 2.审核通过 3.审核拒绝
     */
    public void setState(Byte state) {
        this.state = state;
    }
}