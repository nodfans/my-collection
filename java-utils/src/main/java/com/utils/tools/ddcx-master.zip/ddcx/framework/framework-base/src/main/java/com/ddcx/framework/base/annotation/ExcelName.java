package com.ddcx.framework.base.annotation;

import java.lang.annotation.*;

/**
 * @author yjw
 * @describe 该注解应用于实体类属性上，用于在将该类的相关属性导入Excel表格时，标题显示所用
 * @Date 2018-10-8
 */
@Target(ElementType.FIELD)
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface ExcelName {
    //生成Excel表格时第一行所显示的字段名称
    String value() default "备用";

    //判断是否需要用中文替换对应数字(从0开始)若从1开始请占位ex：{"","value1","value2"}
    String[] replaceNumber() default {};

    //需要使用特定时间格式请传对应时间格式字符串
    String timePattern() default "yyyy-MM-dd";

    boolean isTimestamp() default false;

    //此属性用来标注该字段是否为对象（即非基本数据类型和其包装类）
    boolean isObject() default false;

    //此属性用于标记该属性的导出级别  该级别表示显示字段，比如  属性为一级  而导出级别为二级则一级属性将被导出 反之属性级别高于导出级别将不被导出
    int level() default 0;
}
