package com.ddcx.app.provider.uac.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.uac.UacUserAuth;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface UacUserAuthMapper extends MyMapper<UacUserAuth> {


    @Select("select * from uac_user_auth where user_id=#{userId}")
    UacUserAuth selectByUserId(@Param("userId") Long userId);
}