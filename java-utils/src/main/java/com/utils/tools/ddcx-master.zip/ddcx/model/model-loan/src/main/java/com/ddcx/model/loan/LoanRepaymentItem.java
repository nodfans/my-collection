package com.ddcx.model.loan;

import com.ddcx.framework.util.LoanIssueUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Table(name = "loan_repayment_item")
@ApiModel("还款明细")
public class LoanRepaymentItem {
    /**
     * 主键
     */
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    @Id
    private Long id;

    /**
     * 订单id
     */
    @NotNull
    @Column(name = "o_id")
    @ApiModelProperty(value = "<支付必传>订单id",required = true)
    private Long oId;


    /**
     * 还款日期
     */
    @ApiModelProperty("还款日期")
    @Column(name = "repayment_time")
    private Long repaymentTime;

    /**
     * 本金
     */
    @ApiModelProperty("本金")
    private BigDecimal amount;

    /**
     * 利息
     */
    @ApiModelProperty("利息")
    private BigDecimal interest;

    /**
     * 应还金额
     */
    @ApiModelProperty("应还金额")
    @Column(name = "repayment_amount")
    private BigDecimal repaymentAmount;

    /**
     * 期次
     */
    @ApiModelProperty(value = "期次")
    private Integer issue;

    @ApiModelProperty("期次<中文版，仅做显示使用>")
    @Transient
    private String issueMsg;

    /**
     * 状态 0：待还款，1：已还款，2：逾期
     */
    @ApiModelProperty("状态 0：待还款，1：已还款，2：逾期 3：待审核")
    private Byte state;

    /**
     * 过期天数
     */
    @ApiModelProperty("过期天数")
    @Column(name = "expire_day")
    private Integer expireDay;

    /**
     * 还款途径
     */
    @ApiModelProperty(value = "还款途径")
    @Column(name = "repayment_type")
    private String repaymentType;


    @Transient
    @ApiModelProperty("1 表示当前要还的 ")
    private Byte current=0;

    @Transient
    @NotNull(message = "支付类型不能为空")
    @ApiModelProperty(value = "<支付必传>支付类型：1.微信支付 2.支付宝支付 3.银联支付 4.小程序支付 5:线下支付",required = true)
    private Byte payType=0;

    @ApiModelProperty("线下付款附件")
    private String remarkFile;

    @ApiModelProperty("逾期息")
    private BigDecimal overdueMoney;


    @ApiModelProperty("月利率")
    @Transient
    private BigDecimal rate;

    @ApiModelProperty("逾期利率")
    @Transient
    private BigDecimal overdueRate;

    public BigDecimal getRate() {
        return rate;
    }

    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }

    public BigDecimal getOverdueRate() {
        return overdueRate;
    }

    public void setOverdueRate(BigDecimal overdueRate) {
        this.overdueRate = overdueRate;
    }

    public BigDecimal getOverdueMoney() {
        return overdueMoney;
    }

    public void setOverdueMoney(BigDecimal overdueMoney) {
        this.overdueMoney = overdueMoney;
    }

    public String getRemarkFile() {
        return remarkFile;
    }

    public void setRemarkFile(String remarkFile) {
        this.remarkFile = remarkFile;
    }

    public Byte getPayType() {
        return payType;
    }

    public void setPayType(Byte payType) {
        this.payType = payType;
        if(payType!=null){
            switch (payType){
                case 1: repaymentType="微信支付";break;
                case 2: repaymentType="支付宝支付";break;
                case 3: repaymentType="银联支付";break;
                case 4: repaymentType="小程序支付";break;
                case 5: repaymentType="线下支付";break;
                default:   repaymentType="";break;
            }
        }
    }

    public Byte getCurrent() {
        return current;
    }

    public void setCurrent(Byte current) {
        this.current = current;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }



    public Long getoId() {
        return oId;
    }

    public void setoId(Long oId) {
        this.oId = oId;
    }

    /**
     * 获取还款日期
     *
     * @return repayment_time - 还款日期
     */
    public Long getRepaymentTime() {
        return repaymentTime;
    }

    /**
     * 设置还款日期
     *
     * @param repaymentTime 还款日期
     */
    public void setRepaymentTime(Long repaymentTime) {
        this.repaymentTime = repaymentTime;
    }


    public String getIssueMsg() {
        return issueMsg;
    }

    public void setIssueMsg(String issueMsg) {
        this.issueMsg = issueMsg;
    }

    /**
     * 获取本金
     *
     * @return amount - 本金
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * 设置本金
     *
     * @param amount 本金
     */
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    /**
     * 获取利息
     *
     * @return interest - 利息
     */
    public BigDecimal getInterest() {
        return interest;
    }

    /**
     * 设置利息
     *
     * @param interest 利息
     */
    public void setInterest(BigDecimal interest) {
        this.interest = interest;
    }

    /**
     * 获取应还金额
     *
     * @return repayment_amount - 应还金额
     */
    public BigDecimal getRepaymentAmount() {
        return repaymentAmount;
    }

    /**
     * 设置应还金额
     *
     * @param repaymentAmount 应还金额
     */
    public void setRepaymentAmount(BigDecimal repaymentAmount) {
        this.repaymentAmount = repaymentAmount;
    }

    /**
     * 获取期次
     *
     * @return issue - 期次
     */
    public Integer getIssue() {
        return issue;
    }

    /**
     * 设置期次
     *
     * @param issue 期次
     */
    public void setIssue(Integer issue) {
        this.issue = issue;
        if(issue!=null){
            issueMsg= LoanIssueUtil.getChinaIssueMsg(issue);
        }
    }

    /**
     * 获取状态 0：待还款，1：已还款，2：逾期
     *
     * @return state - 状态 0：待还款，1：已还款，2：逾期
     */
    public Byte getState() {
        return state;
    }

    /**
     * 设置状态 0：待还款，1：已还款，2：逾期
     *
     * @param state 状态 0：待还款，1：已还款，2：逾期
     */
    public void setState(Byte state) {
        this.state = state;
    }

    /**
     * 获取过期天数
     *
     * @return expire_day - 过期天数
     */
    public Integer getExpireDay() {
        return expireDay;
    }

    /**
     * 设置过期天数
     *
     * @param expireDay 过期天数
     */
    public void setExpireDay(Integer expireDay) {
        this.expireDay = expireDay;
    }

    /**
     * 获取还款途径
     *
     * @return repayment_type - 还款途径
     */
    public String getRepaymentType() {
        return repaymentType;
    }

    /**
     * 设置还款途径
     *
     * @param repaymentType 还款途径
     */
    public void setRepaymentType(String repaymentType) {
        this.repaymentType = repaymentType;
    }
}