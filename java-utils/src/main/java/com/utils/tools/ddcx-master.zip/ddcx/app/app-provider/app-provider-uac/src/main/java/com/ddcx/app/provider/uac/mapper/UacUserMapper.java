package com.ddcx.app.provider.uac.mapper;

import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.uac.UacUser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface UacUserMapper extends MyMapper<UacUser> {


    @Update("update uac_user set source=source+#{source} where id=#{userId}")
    void addSource(@Param("source") Integer source, @Param("userId") Long userId);

    @Select("select * from uac_user where phone=#{phone} limit 1")
    UacUser selectByPhone(@Param("phone") String phone);


    @Select("select id ,real_name from uac_user where motorcade_id=#{motorcadeId} ")
    List<UacUser> getByMotorcadeId(@Param("motorcadeId") Long motorcadeId);

    @Update("update uac_user set open_id = #{openId} where phone = #{phone}")
    Integer updateOpenId(@Param("openId") String openId, @Param("phone") String phone);
}
