package com.ddcx.app.provider.loan.util;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.domain.AlipayTradeAppPayModel;
import com.alipay.api.internal.util.AlipaySignature;
import com.alipay.api.request.AlipayTradeAppPayRequest;
import com.alipay.api.response.AlipayTradeAppPayResponse;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;

@Component
public class AliUtils {
    //prod
    public static final String  APP_ID="2021001157613961";

    private static final String  GATEWAY="https://openapi.alipay.com/gateway.do";

    private static final String  PRIVATEKEY="MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCncMGMavZrPPEEIzVJd5QVxT4gjHU6u19rEpJOXFtp3hbimOSTRLHtLmxFmKSqaOrCsaQbNolZtnU9OyH0FBYAmD7WM4hocwqM6CfbUDbkp81PN6FI6ZEAG6he6LvPGN9UOxjsAQJF4Qo5L0EPFccoMwYDGNGWX40TwWrxxDUj+17DJ6ZKUdsF8Zn+UL8aLZU5A9WDizEaMiG0MyLWSRjkHjFeQ+EjvBkqM9aa7g7RdSKQVwLAsXb0EKIFDl8sQpxPyQwXUIQ4+XTs4qtyT8kl81b50VHEujSD9N7EMDstNOqR+SRJC84Yz21Fk34Hzqu6Lg4wiAZ60ZUgUL6+Jh1BAgMBAAECggEAa1gXTU05g1CDd1KXE+1sa3STOsyxTyDWsE8sqr39AOcXpte8Gkm9A8ByOz/7uSAf+QdnnOaesXwOt12Ui+Tgoir4hdxtxACUr/cZrjlDp92H+xQ/+v16LyaMD6SG2uMoMdjdRlfzPBdktXp87A3bKwNjBFNB8nR5fkPOqwZNxy2QY04Sa2hXumC020v3cK17uss2Hc7OiGaOOqXHw+HsSEuw2fI1wdO2OYYRCzcKW2AE65Qg8T+lQdxXg+Hp5xqM9PltaOVuWFbh9wjKknMYyPghwlVWI1LrDqyu/AdARIWlrEzmcPlRlTY2t6npI2c6axpxt2T15Jrcau2m52z9UQKBgQDxSlbRkyScyooZ/Gw2ehE+dsY8HpTCHj3ZAMg3gJbtN7p/l/FeN6lHC2sT7AlsrCY8ES3M0GWPq0ey4nSbr7lkaQH1+DFMyKpniyVGRA6wTT4kWZQHJILAc/MwkGZOhG47dPMnkxVSwhwWJY9UbPVyzH7wloahxtLGYGvVXlKqnQKBgQCxpeOwzNOrDLwhmGqyzDTnVU8o8mIQvdW94aIrLH8gxYYCeTIqR7K4f1uDtzvmnGahjNJCcHdw/yJoj/sNh30TE/F2GPZ7o8aHfkyrfj77OL22H6HwnwczOP8FF1OeqEPKrDBGSpejz8h6Q7Yw2P1LXTGqq0ytcEptsDp+7AWZ9QKBgQDo779IqyhZRR51X76ICOfEyZ0uRMePbup+J8ch7b3GXFpq+yBEuK9uqpNAtEmU48w1iNASPc0OGWgqRXwVIFt1l/oQnv3ZBo+bTjU51FHp2Wf4Z5IEIzcm28kWRRC/FBHmzExBFDktn77FkpUACAAcR1b0pBxs6Shp4oO3hEuB8QKBgGtj/0rn56Vlo20juIyxyeF2vs3gCMxaFhYdim1TDt7+yU5BecP5Z98EjowHftyf+6L5gDnNx0a11VUkhP3exAt+aN+do5OGpANQpISfYu93k6e/Y6QUXsPmVrP7L/+fdKvWf7Bec2EBwQ24VTEeW7Dte5LSzx2h3jyE5jfH8nLpAoGADDSk32QDDR/zSQ20rmOEoim4lO4XCnU6ui4J8873MqO2wAVNutX7Cq5tEzRZ58bHRFIbDu43cFgzoW7c+OWPXHmPk0Dt6+6NA2Iq5fSY8y3Y7BcFDtgiSVTIriiUt7j7kIP/z804Bu+yEvHR6pI0JjCN7ehdMeaPfiClNBRK+70=";

    private static final String ALIPAY_PUBLIC_KEY="MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsJ2zTAD6X+JZfe69ccjHWpv2W7IS8VGc2WS+kaXgu0kXDRtOsEUSqPR0nyWwVsS6NJmKS4NbfxWSXeHk4yEiwPLGtVvHW/yM+eM/bStiBRLdroi9KcYtHGkSRVTSDYqEOqx59g4E3aTGdalINuLOPj4odmN+IpathO3dz6X0rUhTGV7nD7W5q4b/2aeo1miUnGow+rLL1lXVCOPyiB95x7uGuhXO82WkK0A1zyXyS32h3ee/cMdd0KxIwz5xhfxGqhk5eqKt08KvaZJaG+Y8VW5uT7NYSUZdBYIICQ77wHloR2WNO0dcvN3Cs+Ef47rrSbyOxNMhRa0yGxUp7mJX+QIDAQAB";

//    //dev
//    private static final String  GATEWAY="https://openapi.alipaydev.com/gateway.do";
//
//    public static final String  APP_ID="2016102400748789";
//
//    private static final String  PRIVATEKEY="MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCkerU+wYWwfUMgwKdxndQWZWxoxeqS42thZuaqQOkrmn7XkiaJBNq6sn+fSpCvRdow/VuEaBanvR3dVoTPdyya1JxGPKkbhjk1MbR3M4UYoBVvmcAM3pLh2zGFNDdCXUoS5VV0fvEUBSHipn2tL5WpECVcJn1DBn0mqJN+rjHCFmuQ2RJMzenlquNvX/GRXdFBlfVZORrlDRxULd1Hi+lcEeTuTbmUjLm6wTQtVgBRN9YAjOwjYs0yY5q3BGSGEdSe4xvyQDZINv8j7dd0q1bnwyDTzpUR3Wca8FCm/KYjjIisMZROZz04PalQ0pS0/F4PJ0OOCW8pbiJxhBC2fHrtAgMBAAECggEAVkldff+uL+l25t7KuQsQcXNhzRFPPyH5ek6uYdDNwic5tcOhXa5jRSBRXXKTtq+RiLPRaAPnJrZKzYwO/nvJtawmE57NJHhk2KgrwYEQqNuKg1KIcvfs3HnOX9AF0VX5fzI6g3P46wTKQwoO0mUtQVUMFGzIt/nWfAph3kpqJiQcDYRgp1bmDCGFWlQdIdgKA4lrHKlecFskVAGpIps1ptYwRCeUV40FV9gy54wujlDhMDc1odQdxCqzPTGFI9mN68XIczfgCsr5wPixueFUxNH3Ptm0FLu3kxiJztmw36+7HobYynLToJGobHXMr7RuQ+VZKbDQzFsEAfylI1xTzQKBgQD2BZ0sz6cI1mvdrnrwN1ZN7RHoB6wUXxpkZc0zWYNa2y38tmoyRblQS5SGjWf3S++TM4NiPfc0PniacLI3P+7i00EibdE9yoirdl5er2UAhdeAYc00iq/VUcymgm621+S83Nak4HARVKEGh3E9Atxj/qyRoRudtBufLTQdskbEiwKBgQCrJnT7wwsJJ+kT09dQ7z7QuCPFUL4+HAZbGeJuX/vpVii1BlJ0d/g17I2gbMZ9KMJTk3Rf5o3QknYrtTVOa7I+dO0zHo4lH+Qv3PzqOHp6DC6YZ7FuHwKmCkad4kJcNHi9MQ3YQWd6fkjxdbzrY+8SZx+djZN1KgeveyO78iwVZwKBgQDyKLx46zxC2qv53FBuOkndEkjZ1xNuSd40jG/a53T/7VXqtbL6IN8zRfHAL1fydvAuODpObSfyaLtVaTBCac+9vKsUNHwNElpMS4rAMGx+gz+Hwry1xv0kQAvsqd5IY2Fm9Qjh6Xjl1iNZxd+Uakh8tKUwAyCnriyyFVCDGoPF2QKBgCMupJ2cWohnS+Jnibt5ctA1CiVlk7XwzN2tVH6b/IzayUNtKUYH414yYmq38ZWI62mCxklwe3aEpQYXGf4k5V8xahE4FsBK7f1o0BTVx1ePaYSqzC528XRwaFPMTxflMWyyyMXLrBniG9yG927r/BksWbNphwZuvWW1SoM4JRfBAoGARMGcSFG+qJD2UvuzYhghONUlOvIrk8HyxDXfCbBpOLnGiHvu7OBjh/ZWb82mV3vVX43N0hUYERcGvAijmdS+xq3RR5s+K+1N1UaOWY57c4aMMMHbvWogd0KhWtI1ObBxO+Vxf7UzPbhBt0WLTENls6Z/ISi0TL9azeWI/Un5+tU=";
//
//    private static final String ALIPAY_PUBLIC_KEY="MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnWxzXPFMd4ArvWRGF8QvZWGTyx5Ni/TqdPaRTtJcYyvv93uuIUMWI63/G0Re28AkhRhGm+gDHIlU9HMCKXGam1d0wy6WtQPAEO5FOGxFuQ6h0ETQstXY8R/ytVbXSpf/nVIlgSkZYEDoNNvuva17gO54epbvd/AstkHyXzwtFnKsYGqUkZEZ9TkLXDvHwQwcELZrPsIRxe0h1ixjwyh9DGu/TaNiRQg/YrCcFIJH3iWSJUGskaa1X3vURQ7wp7eXu21K1sv+EEz5m6Ypo/qQUq7U6c0k61H8O5oTc5keRGyky3MZvKFtWbQu8jodg7rBdgnG4sEsR37P9A/9NHSZJwIDAQAB";

    private static final String  CHARSET="utf-8";

    private static final String  SIGN_TYPE="RSA2";
//    //同步返回
//    private static final String  RETURN_URL="http://112.74.217.123/ddcx/loan/";
    //异步返回
    private static final String  NOTIFY_URL="http://112.74.217.123/ddcx/loan/loan/repayment/item/aliPayReturn";

    private static final AlipayClient alipayClient=new DefaultAlipayClient(GATEWAY,APP_ID,PRIVATEKEY,"json",CHARSET,ALIPAY_PUBLIC_KEY,SIGN_TYPE);


    /**
     * 支付调用
     * @param price         支付金额
     * @param orderNum      订单号
     * @return 支付宝返回
     */
    public AlipayTradeAppPayResponse pay(BigDecimal price,String orderNum){
        AlipayTradeAppPayRequest request=new AlipayTradeAppPayRequest();
        AlipayTradeAppPayModel model=new AlipayTradeAppPayModel();
        model.setTimeoutExpress("20m");
        model.setTotalAmount(price.setScale(2,BigDecimal.ROUND_HALF_UP).toString());
        model.setSubject("还款");
        model.setOutTradeNo(orderNum);
        request.setBizModel(model);
        request.setApiVersion("2.0");
        request.setNotifyUrl(NOTIFY_URL);
        AlipayTradeAppPayResponse response = null;
        try {
            response = alipayClient.sdkExecute(request);
        } catch (AlipayApiException e) {
            e.printStackTrace();
        }
        if(response.isSuccess()){
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
        }
        return response;
    }

    /**
     * 验签
     * @param params
     * @return
     */
    public boolean aliAttestation(Map<String,String> params,String content){
        try {
            return AlipaySignature.rsaCheck (content,params.get("sign"),ALIPAY_PUBLIC_KEY,CHARSET,SIGN_TYPE);
        } catch (AlipayApiException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 阿里回调验签
     * @param params
     * @return
     */
    public boolean aliReturnAttestation(Map<String,String> params){
        try {
            return AlipaySignature.rsaCheckV1(params, ALIPAY_PUBLIC_KEY, CHARSET,SIGN_TYPE);
        } catch (AlipayApiException e) {
            e.printStackTrace();
            return false;
        }
    }


}
