package com.ddcx.common.provider.service;


import com.ddcx.common.provider.api.model.vo.MessageVo;
import com.ddcx.framework.base.dto.BaseQueryDto;
import com.ddcx.framework.util.wrapper.PageWrapper;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.common.MessageConfig;
import com.ddcx.web.provider.api.uac.model.dto.MessageDto;
import com.ddcx.web.provider.api.uac.model.vo.UacRescueListVo;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/02.
 */
public interface MessageService {

    /**
     * 获取用户的未读消息数量
     *
     * @param userId 当前用户主键
     * @return
     */
    Wrapper<MessageVo> getUserNoReadNum(Long userId);

    /**
     * 根据类型获取用户消息
     *
     * @param page   当前页
     * @param size   每页记录数
     * @param userId 当前用户id
     * @param type   消息类型(1.系统消息 2.优惠消息 3.救援消息 4.学习消息)
     * @return
     */
    Wrapper<PageInfo<MessageVo>> getMessageListByType(Integer page, Integer size, Long userId, Integer type);

    /**
     * 标记已读
     *
     * @param id     消息主键
     * @param userId 当前用户id
     * @return
     */
    Wrapper alreadyReadTag(Long id, Long userId);


    Wrapper testJpush(String title, String content, LoginAuthDto dto);




    Wrapper<PageInfo<MessageConfig>> list(BaseQueryDto baseQueryDto, String title, Long createBy, Long date);

    Wrapper publishSystemMessage(MessageDto messageDto, Long adminUserId);

    Wrapper update(MessageConfig config,Long adminUserId);

    PageWrapper<List<UacRescueListVo>> getRescueList(BaseQueryDto baseQueryDto);

    Wrapper deleteRescueList(List<Long> ids);

    Wrapper deleteSystemMessage(List<Long> ids);
}
