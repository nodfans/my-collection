package com.ddcx.app.provider.loan.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.loan.LoanConfig;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface LoanConfigMapper extends MyMapper<LoanConfig> {


    @Update("update set  loan_type = #{loanType},loan_deadline = #{loanDeadline},loan_way = #{loanWay},month_rate = #{monthRate},overdue_rate = #{overdueRate},remind_date = #{remindDate},expire_text = #{expireText},overdue_text = #{overdueText},update_by = #{updateBy},update_time = #{updateTime} where motorcade_id=#{motorcadeId}")
    void updateByMotorcadeId(LoanConfig config);

}