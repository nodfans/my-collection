package com.ddcx.app.provider.exam.service.impl;


import com.ddcx.app.provider.exam.mapper.UacLearnRecordMapper;
import com.ddcx.app.provider.exam.service.UacLearnRecordService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.exam.UacLearnRecord;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/03/11.
 */
@Service
@Transactional
public class UacLearnRecordServiceImpl  implements UacLearnRecordService {
    @Resource
    private UacLearnRecordMapper uacLearnRecordMapper;

    @Override
    public Wrapper saveRecord(UacLearnRecord record, LoginAuthDto dto) {
        UacLearnRecord record1=uacLearnRecordMapper.selectByOwn(record.getlIId(),dto.getUserId());
        if(record1==null){
            record.setUserId(dto.getUserId());
            record.setCreateTime(System.currentTimeMillis()/1000);
            uacLearnRecordMapper.insert(record);
        }else {
            UacLearnRecord record2=new UacLearnRecord();
            record2.setDuration(record.getDuration());
            if(record1.getFinish().intValue()!=1){
                record2.setFinish(record.getFinish());
            }
            record2.setViewDuration(record.getViewDuration());
            record2.setId(record1.getId());
            uacLearnRecordMapper.updateDuration(record2);
        }
        return WrapMapper.ok();
    }
}
