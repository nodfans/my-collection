package com.ddcx.common.provider.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.common.BsStreet;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;


@Mapper
@Component
public interface BsStreetMapper extends MyMapper<BsStreet> {


    @Select("select STREET_CODE ,STREET_NAME from bs_street")
    List<BsStreet> selectAllOfFewColumn();
}