package com.ddcx.gateway.config;

import lombok.Data;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import springfox.documentation.swagger.web.SwaggerResource;
import springfox.documentation.swagger.web.SwaggerResourcesProvider;

import java.util.ArrayList;
import java.util.List;

@Component
@Primary
@Data
public class DocumentationConfig implements SwaggerResourcesProvider {

    @Override
    public List<SwaggerResource> get() {
        List resources = new ArrayList();
        resources.add(swaggerResource("公共模块", "/common/v2/api-docs", "1.0"));
        resources.add(swaggerResource("用户模块", "/uac/v2/api-docs", "1.0"));
        resources.add(swaggerResource("汽车模块", "/truck/v2/api-docs", "1.0"));
        resources.add(swaggerResource("卡友圈模块", "/friend/v2/api-docs", "1.0"));
        resources.add(swaggerResource("后台用户模块", "/admin/uac/v2/api-docs", "1.0"));
        resources.add(swaggerResource("后台汽车模块", "/admin/truck/v2/api-docs", "1.0"));
        resources.add(swaggerResource("后台学习模块", "/admin/exam/v2/api-docs", "1.0"));
        resources.add(swaggerResource("学习模块", "/exam/v2/api-docs", "1.0"));
        resources.add(swaggerResource("后台借贷款模块", "/admin/loan/v2/api-docs", "1.0"));
        resources.add(swaggerResource("后台卡友圈模块", "/admin/friend/v2/api-docs", "1.0"));
        resources.add(swaggerResource("借贷款模块", "/loan/v2/api-docs", "1.0"));
        return resources;
    }

    private SwaggerResource swaggerResource(String name, String location, String version) {
        SwaggerResource swaggerResource = new SwaggerResource();
        swaggerResource.setName(name);
        swaggerResource.setLocation(location);
        swaggerResource.setSwaggerVersion(version);
        return swaggerResource;
    }

    @Data
    private class Server {
        private String name;
        private String location;
        private String version;
    }
}
