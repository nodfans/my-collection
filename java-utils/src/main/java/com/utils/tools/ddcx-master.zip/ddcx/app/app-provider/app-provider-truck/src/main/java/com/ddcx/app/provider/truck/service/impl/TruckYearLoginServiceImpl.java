package com.ddcx.app.provider.truck.service.impl;


import com.ddcx.app.provider.truck.mapper.TruckYearLoginMapper;
import com.ddcx.app.provider.truck.service.TruckYearLoginService;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.TruckYearLogin;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/04/17.
 */
@Service
@Transactional
public class TruckYearLoginServiceImpl extends BaseService<TruckYearLogin> implements TruckYearLoginService {
    @Resource
    private TruckYearLoginMapper truckYearLoginMapper;

    @Override
    public Wrapper addTruckYearLogin(TruckYearLogin yearLogin) {
        yearLogin.setId(generateId());
        truckYearLoginMapper.insert(yearLogin);
        return WrapMapper.ok();
    }

    @Override
    public Wrapper getTruckYearLogin(Long truckId) {
        TruckYearLogin truckYearLogin=truckYearLoginMapper.getTruckYearLogin(truckId);
        if(truckYearLogin==null){
            return WrapMapper.error("暂无年检复核记录");
        }
        return WrapMapper.ok(truckYearLogin);
    }
}
