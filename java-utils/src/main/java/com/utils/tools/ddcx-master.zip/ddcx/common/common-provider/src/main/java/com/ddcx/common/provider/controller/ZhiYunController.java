package com.ddcx.common.provider.controller;

import com.ddcx.common.provider.api.zhiyun.ZhiYunDrivingLicence;
import com.ddcx.common.provider.api.zhiyun.ZhiYunIdAuth;
import com.ddcx.common.provider.service.ZhiYunService;
import com.ddcx.framework.core.annotation.NoNeedAccessAuthentication;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.log4j.Log4j2;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("/zhiyun")
@Log4j2
@Api(value = "智云第三方接口", tags = "智云第三方接口")
public class ZhiYunController {

    @Resource
    private ZhiYunService zhiYunService;

    @ApiOperation("身份证认证")
    @NoNeedAccessAuthentication
    @GetMapping({"/idCardLicense","/admin/idCardLicense"})
    public Wrapper<ZhiYunIdAuth> idCardLicense(@RequestParam@ApiParam("身份证正面路径") String frontPath, @ApiParam("身份证反面路径")@RequestParam String reversePath){
        try {
            return zhiYunService.idCardLicense(frontPath,reversePath);
        } catch (Exception e) {
            e.printStackTrace();
            return WrapMapper.error("身份解析异常");
        }
    }

    @ApiOperation("行驶证认证")
    @GetMapping({"/drivingLicense","/admin/drivingLicense"})
    public Wrapper<ZhiYunDrivingLicence> drivingLicense(@RequestParam@ApiParam("身份证正面路径") String drivingPath){
        try {
            return zhiYunService.drivingLicense(drivingPath);
        } catch (Exception e) {
            e.printStackTrace();
            return WrapMapper.error("身份解析异常");
        }
    }


}
