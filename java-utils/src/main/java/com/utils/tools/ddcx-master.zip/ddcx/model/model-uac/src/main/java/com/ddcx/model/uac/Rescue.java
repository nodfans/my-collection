package com.ddcx.model.uac;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@ApiModel("救援信息")
public class Rescue {
    /**
     * 主键ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    /**
     * 发布人用户ID
     */
    @Column(name = "user_id")
    @ApiModelProperty("救援信息")
    private Long userId;

    /**
     * 救援原因
     */
    @ApiModelProperty(value = "救援原因",required = true)
    @NotBlank
    private String reason;

    /**
     * 紧急联系人电话
     */
    @ApiModelProperty(value = "紧急联系人电话",required = true)
    @Column(name = "contact_phone")
    @NotNull
    private String contactPhone;

    /**
     * 1：发布中  0：已过期
     */
    @ApiModelProperty("1：发布中  0：已过期")
    private Byte state;

    /**
     * 发布位置
     */
    @ApiModelProperty(value = "发布位置",required = true)
    @NotBlank
    private String address;

    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    @Column(name = "create_time")
    private Long createTime;

    @ApiModelProperty(value = "经度",required = true)
    @NotBlank
    private String lng;

    @ApiModelProperty(value = "纬度",required = true)
    @NotBlank
    private String lat;

    @ApiModelProperty("发布人姓名")
    @Transient
    private String userName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    /**
     * 获取主键ID
     *
     * @return id - 主键ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键ID
     *
     * @param id 主键ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取发布人用户ID
     *
     * @return user_id - 发布人用户ID
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置发布人用户ID
     *
     * @param userId 发布人用户ID
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 获取救援原因
     *
     * @return reason - 救援原因
     */
    public String getReason() {
        return reason;
    }

    /**
     * 设置救援原因
     *
     * @param reason 救援原因
     */
    public void setReason(String reason) {
        this.reason = reason;
    }

    /**
     * 获取紧急联系人电话
     *
     * @return contact_phone - 紧急联系人电话
     */
    public String getContactPhone() {
        return contactPhone;
    }

    /**
     * 设置紧急联系人电话
     *
     * @param contactPhone 紧急联系人电话
     */
    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    /**
     * 获取1：发布中  0：已过期
     *
     * @return state - 1：发布中  0：已过期
     */
    public Byte getState() {
        return state;
    }

    /**
     * 设置1：发布中  0：已过期
     *
     * @param state 1：发布中  0：已过期
     */
    public void setState(Byte state) {
        this.state = state;
    }

    /**
     * 获取发布位置
     *
     * @return address - 发布位置
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置发布位置
     *
     * @param address 发布位置
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
}