package com.ddcx.common.provider.api.service;

import com.alibaba.fastjson.JSONObject;
import com.ddcx.common.provider.api.model.dto.MessageDto;
import com.ddcx.common.provider.api.model.vo.CommonBankBinVo;
import com.ddcx.common.provider.api.service.hystrix.CommonServiceFeignApiHystrix;
import com.ddcx.common.provider.api.zhiyun.ZhiYunDrivingLicence;
import com.ddcx.common.provider.api.zhiyun.ZhiYunIdAuth;
import com.ddcx.framework.core.annotation.NoNeedAccessAuthentication;
import com.ddcx.framework.core.feign.FeignAutoConfiguration;
import com.ddcx.model.common.BsArea;
import com.ddcx.model.common.CnRegionInfo;
import com.ddcx.model.common.RelatedReminders;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

@Component
@FeignClient(name = "ddcx-common-provider", configuration = FeignAutoConfiguration.class, fallback = CommonServiceFeignApiHystrix.class)
public interface CommonServiceFeignApi {

    /**
     * 上传图片
     * @param imgData 图片数据
     * @return 图片路径
     */
    @NoNeedAccessAuthentication
    @PostMapping("/api/admin/common/data/upload")
    String upload(@RequestBody byte[] imgData);

    /**
     * 删除图片
     * @param filePath 图片数据
     * @return 图片路径
     */
    @NoNeedAccessAuthentication
    @GetMapping("/api/common/data/deleteFile")
    String deleteFile(@RequestParam String filePath);

    /**
     * 删除图片
     * @param filePath 图片数据
     * @return 图片路径
     */
    @NoNeedAccessAuthentication
    @GetMapping("/api/common/admin/data/deleteFile")
    String deleteAdminFile(@RequestParam String filePath);

    @NoNeedAccessAuthentication
    @GetMapping(value = "/api/common/bankbin/{cardNo}")
    CommonBankBinVo getBankBin(@PathVariable(name = "cardNo") String cardNo);


    @NoNeedAccessAuthentication
    @GetMapping(value = "/api/common/bankbin/getSysConfigByKey")
    JSONObject getSysConfigByKey(@RequestParam("key") String key);

    /**
     * 添加消息
     * @param dto 消息对象
     * @return
     */
    @NoNeedAccessAuthentication
    @PostMapping("/api/common/message/add")
    int addMessage(@RequestBody MessageDto dto);

    /**
     * 添加消息
     * @param dto 消息对象
     * @return
     */
    @NoNeedAccessAuthentication
    @PostMapping("/api/common/admin/message/addAdminMessage")
    int addAdminMessage(@RequestBody MessageDto dto);

    /**
     * 添加消息
     * @param dto 消息对象
     * @return
     */
    @NoNeedAccessAuthentication
    @PostMapping("/api/common/message/addMessageOfAll")
    int addMessageOfAll(@RequestBody MessageDto dto);


    /**
     * 添加消息
     * @param map  1, MessageDto 消息主体; 2,List<Long> 目标用户列表  3.true 表示需要极光推送 false 为不需要 4.极光推送参数主体
     * @return
     */
    @NoNeedAccessAuthentication
    @PostMapping("/api/common/message/addMessageOfAllByUserIds")
    int addMessageOfAllByUserIds(@RequestParam("map") String map);


    /**
     * 根据编码获取对应的字符串
     * @param code
     * @return
     */
    @NoNeedAccessAuthentication
    @RequestMapping(value = "/api/admin/common/cnRegionInfo/getRegionMsgByCode",method = RequestMethod.GET)
    CnRegionInfo getRegionMsgByCode(@RequestParam("code") String code);


//    /**
//     * 根据编码获取对应的街道对象
//     * @param code
//     * @return
//     */
//    @NoNeedAccessAuthentication
//    @GetMapping("/api/common/cnRegionInfo/getBsStreetByCode")
//    BsStreet getBsStreetByCode(@RequestParam("code")String code);


    /**
     * 根据编码获取对应的区对象
     * @param code
     * @return
     */
    @NoNeedAccessAuthentication
    @GetMapping("/api/common/cnRegionInfo/admin/getBsAreaByCode")
    BsArea getBsAreaByCode(@RequestParam("code")String code);


    /**
     * 获取提醒天数配置
     * @return
     */
    @NoNeedAccessAuthentication
    @GetMapping("/api/common/cnRegionInfo/admin/selectRelatedReminders")
    RelatedReminders selectRelatedReminders();


    /**
     * 获取救援消息总数
     * @return
     */
    @NoNeedAccessAuthentication
    @GetMapping("/api/common/cnRegionInfo/admin/message/total")
    Integer getHelpMessageTotal();


    /**
     * 移除已经取消的救援消息
     * @return
     */
    @NoNeedAccessAuthentication
    @GetMapping("/api/common/message/deleteRescueMessage")
    int deleteRescueMessage(@RequestParam Long rescueId);

    /**
     * 移除已经取消的救援消息
     * @return
     */
    @NoNeedAccessAuthentication
    @GetMapping("/api/admin/common/message/idCardLicense")
    ZhiYunIdAuth idCardLicense(@RequestParam String frontPath,@RequestParam String reversePath) throws Exception;

    /**
     * 移除已经取消的救援消息
     * @return
     */
    @NoNeedAccessAuthentication
    @GetMapping("/api/admin/common/message/drivingLicense")
    ZhiYunDrivingLicence drivingLicense(@RequestParam String drivingPath) throws Exception;

}
