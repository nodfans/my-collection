package com.ddcx.app.provider.friend.service.impl;


import com.ddcx.app.provider.friend.mapper.FriendCircleMapper;
import com.ddcx.app.provider.friend.mapper.FriendCircleReplyMapper;
import com.ddcx.app.provider.friend.service.FriendCircleReplyService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.friend.FriendCircle;
import com.ddcx.model.friend.FriendCircleReply;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/02.
 */
@Service
@Transactional
public class FriendCircleReplyServiceImpl implements FriendCircleReplyService {
    @Resource
    private FriendCircleReplyMapper friendCircleReplyMapper;
    @Resource
    private FriendCircleMapper friendCircleMapper;

    @Override
    public Wrapper saveFriendReply(FriendCircleReply reply, LoginAuthDto dto) {
        reply.setUserId(dto.getUserId());
        reply.setUserNickName(dto.getUserName());
        reply.setCreateTime(System.currentTimeMillis()/1000);
        friendCircleReplyMapper.insert(reply);
        FriendCircle friendCircle=new FriendCircle();
        friendCircle.setId(reply.getFriendCircleId());
        int i=friendCircleReplyMapper.selectCountByFriendCircleId(reply.getFriendCircleId());
        friendCircle.setReplyCount(i);
        friendCircleMapper.updateByPrimaryKeySelective(friendCircle);
        return WrapMapper.ok("回复成功");
    }

    @Override
    public Wrapper getOwnReply(Integer page, Integer size,Long userId) {
        PageHelper.startPage(page,size);
        List<FriendCircle> circles=friendCircleMapper.getOwnReply(userId);
        for (FriendCircle circle : circles) {
        }
        return WrapMapper.ok(new PageInfo<>(circles));
    }
}
