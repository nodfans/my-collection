package com.ddcx.model.truck;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Table(name = "truck_change_record")
@ApiModel("车辆变更登记表")
public class TruckChangeRecord {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    /**
     * 车辆主键
     */
    @Column(name = "truck_id")
    @ApiModelProperty("车辆主键")
    @NotNull(message = "车辆主键不能为空")
    private Long truckId;

    /**
     * 变更事项
     */
    @Column(name = "change_info")
    @ApiModelProperty("变更事项")
    private String changeInfo;

    /**
     * 变更内容
     */
    @Column(name = "change_content")
    @ApiModelProperty("变更内容")
    private String changeContent;

    /**
     * 备注
     */
    @ApiModelProperty("备注")
    private String remark;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取车辆主键
     *
     * @return truck_id - 车辆主键
     */
    public Long getTruckId() {
        return truckId;
    }

    /**
     * 设置车辆主键
     *
     * @param truckId 车辆主键
     */
    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    /**
     * 获取变更事项
     *
     * @return change_info - 变更事项
     */
    public String getChangeInfo() {
        return changeInfo;
    }

    /**
     * 设置变更事项
     *
     * @param changeInfo 变更事项
     */
    public void setChangeInfo(String changeInfo) {
        this.changeInfo = changeInfo;
    }

    /**
     * 获取变更内容
     *
     * @return change_content - 变更内容
     */
    public String getChangeContent() {
        return changeContent;
    }

    /**
     * 设置变更内容
     *
     * @param changeContent 变更内容
     */
    public void setChangeContent(String changeContent) {
        this.changeContent = changeContent;
    }

    /**
     * 获取备注
     *
     * @return remark - 备注
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 设置备注
     *
     * @param remark 备注
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }
}