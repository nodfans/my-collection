package com.ddcx.app.provider.api.truck.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("汽车参数")
public class TruckParam {

    @ApiModelProperty("汽车主键")
    private Long truckId;

    @ApiModelProperty("旧司机主键")
    private Long oldDriverId;

    @ApiModelProperty("新司机主键")
    private Long newDriverId;
}
