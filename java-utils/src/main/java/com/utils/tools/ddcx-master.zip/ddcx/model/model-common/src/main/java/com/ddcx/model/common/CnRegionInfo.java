package com.ddcx.model.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Table(name = "cn_region_info")
@ApiModel("省市区街道对象")
public class CnRegionInfo  implements Serializable {
    /**
     * 自增ID
     */
    @Id
    @Column(name = "CRI_ID")
    @ApiModelProperty("自增ID")
    private Integer criId;

    /**
     * 代码
     */
    @ApiModelProperty("代码")
    @Column(name = "CRI_CODE")
    private String criCode;

    /**
     * 名称
     */
    @ApiModelProperty("名称")
    @Column(name = "CRI_NAME")
    private String criName;

    /**
     * 简称
     */
    @ApiModelProperty("简称")
    @Column(name = "CRI_SHORT_NAME")
    private String criShortName;

    /**
     * 上级代码
     */
    @ApiModelProperty("上级代码")
    @Column(name = "CRI_SUPERIOR_CODE")
    private String criSuperiorCode;

    /**
     * 经度
     */
    @ApiModelProperty("经度")
    @Column(name = "CRI_LNG")
    private String criLng;

    /**
     * 纬度
     */
    @ApiModelProperty("纬度")
    @Column(name = "CRI_LAT")
    private String criLat;

    /**
     * 排序
     */
    @ApiModelProperty("排序")
    @Column(name = "CRI_SORT")
    private Integer criSort;

    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    @Column(name = "CRI_GMT_CREATE")
    private Date criGmtCreate;

    /**
     * 修改时间
     */
    @ApiModelProperty("修改时间")
    @Column(name = "CRI_GMT_MODIFIED")
    private Date criGmtModified;

    /**
     * 备注
     */
    @ApiModelProperty("备注")
    @Column(name = "CRI_MEMO")
    private String criMemo;

    /**
     * 状态
     */
    @ApiModelProperty("状态<无用>")
    @Column(name = "CRI_DATA_STATE")
    private Integer criDataState;

    /**
     * 租户ID
     */
    @ApiModelProperty("租户ID<无用>")
    @Column(name = "CRI_TENANT_CODE")
    private String criTenantCode;

    /**
     * 级别
     */
    @ApiModelProperty("级别")
    @Column(name = "CRI_LEVEL")
    private String criLevel;

    /**
     * 获取自增ID
     *
     * @return CRI_ID - 自增ID
     */
    public Integer getCriId() {
        return criId;
    }

    /**
     * 设置自增ID
     *
     * @param criId 自增ID
     */
    public void setCriId(Integer criId) {
        this.criId = criId;
    }

    /**
     * 获取代码
     *
     * @return CRI_CODE - 代码
     */
    public String getCriCode() {
        return criCode;
    }

    /**
     * 设置代码
     *
     * @param criCode 代码
     */
    public void setCriCode(String criCode) {
        this.criCode = criCode;
    }

    /**
     * 获取名称
     *
     * @return CRI_NAME - 名称
     */
    public String getCriName() {
        return criName;
    }

    /**
     * 设置名称
     *
     * @param criName 名称
     */
    public void setCriName(String criName) {
        this.criName = criName;
    }

    /**
     * 获取简称
     *
     * @return CRI_SHORT_NAME - 简称
     */
    public String getCriShortName() {
        return criShortName;
    }

    /**
     * 设置简称
     *
     * @param criShortName 简称
     */
    public void setCriShortName(String criShortName) {
        this.criShortName = criShortName;
    }

    /**
     * 获取上级代码
     *
     * @return CRI_SUPERIOR_CODE - 上级代码
     */
    public String getCriSuperiorCode() {
        return criSuperiorCode;
    }

    /**
     * 设置上级代码
     *
     * @param criSuperiorCode 上级代码
     */
    public void setCriSuperiorCode(String criSuperiorCode) {
        this.criSuperiorCode = criSuperiorCode;
    }

    /**
     * 获取经度
     *
     * @return CRI_LNG - 经度
     */
    public String getCriLng() {
        return criLng;
    }

    /**
     * 设置经度
     *
     * @param criLng 经度
     */
    public void setCriLng(String criLng) {
        this.criLng = criLng;
    }

    /**
     * 获取纬度
     *
     * @return CRI_LAT - 纬度
     */
    public String getCriLat() {
        return criLat;
    }

    /**
     * 设置纬度
     *
     * @param criLat 纬度
     */
    public void setCriLat(String criLat) {
        this.criLat = criLat;
    }

    /**
     * 获取排序
     *
     * @return CRI_SORT - 排序
     */
    public Integer getCriSort() {
        return criSort;
    }

    /**
     * 设置排序
     *
     * @param criSort 排序
     */
    public void setCriSort(Integer criSort) {
        this.criSort = criSort;
    }

    /**
     * 获取创建时间
     *
     * @return CRI_GMT_CREATE - 创建时间
     */
    public Date getCriGmtCreate() {
        return criGmtCreate;
    }

    /**
     * 设置创建时间
     *
     * @param criGmtCreate 创建时间
     */
    public void setCriGmtCreate(Date criGmtCreate) {
        this.criGmtCreate = criGmtCreate;
    }

    /**
     * 获取修改时间
     *
     * @return CRI_GMT_MODIFIED - 修改时间
     */
    public Date getCriGmtModified() {
        return criGmtModified;
    }

    /**
     * 设置修改时间
     *
     * @param criGmtModified 修改时间
     */
    public void setCriGmtModified(Date criGmtModified) {
        this.criGmtModified = criGmtModified;
    }

    /**
     * 获取备注
     *
     * @return CRI_MEMO - 备注
     */
    public String getCriMemo() {
        return criMemo;
    }

    /**
     * 设置备注
     *
     * @param criMemo 备注
     */
    public void setCriMemo(String criMemo) {
        this.criMemo = criMemo;
    }

    /**
     * 获取状态
     *
     * @return CRI_DATA_STATE - 状态
     */
    public Integer getCriDataState() {
        return criDataState;
    }

    /**
     * 设置状态
     *
     * @param criDataState 状态
     */
    public void setCriDataState(Integer criDataState) {
        this.criDataState = criDataState;
    }

    /**
     * 获取租户ID
     *
     * @return CRI_TENANT_CODE - 租户ID
     */
    public String getCriTenantCode() {
        return criTenantCode;
    }

    /**
     * 设置租户ID
     *
     * @param criTenantCode 租户ID
     */
    public void setCriTenantCode(String criTenantCode) {
        this.criTenantCode = criTenantCode;
    }

    /**
     * 获取级别
     *
     * @return CRI_LEVEL - 级别
     */
    public String getCriLevel() {
        return criLevel;
    }

    /**
     * 设置级别
     *
     * @param criLevel 级别
     */
    public void setCriLevel(String criLevel) {
        this.criLevel = criLevel;
    }
}