package com.ddcx.app.provider.uac.service;


import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.IndustryInfo;

/**
 * Created by CodeGenerator on 2020/03/16.
 */
public interface IndustryInfoService {

    Wrapper listOfPage( Integer page, Integer size);


    Wrapper detail(Long id);
}
