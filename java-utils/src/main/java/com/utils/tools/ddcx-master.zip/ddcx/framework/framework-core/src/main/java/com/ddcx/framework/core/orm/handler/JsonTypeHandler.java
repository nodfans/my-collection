package com.ddcx.framework.core.orm.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Map;

@MappedJdbcTypes(JdbcType.VARCHAR)
@MappedTypes(BeanWrapper.class)
public class JsonTypeHandler extends BaseTypeHandler<BeanWrapper> {
    private Map jsonToMap(String value) {
        if (value == null || "".equals(value)) {
            return Collections.emptyMap();
        } else {
            return JSON.parseObject(value, new TypeReference<Map<String, Object>>() {
            });
        }
    }

    @Override
    public void setNonNullParameter(PreparedStatement ps, int i, BeanWrapper parameter, JdbcType jdbcType)
            throws SQLException {
        ps.setString(i, JSON.toJSONString(parameter.getInnerMap()));
    }

    public boolean isJson(String value) {
        if (value == null || "".equals(value)) {
            return false;
        } else {
            if (value.startsWith("{")) {
                return true;
            }
        }
        return false;
    }

    @Override
    public BeanWrapper getNullableResult(ResultSet rs, String columnName) throws SQLException {
        String value = rs.getString(columnName);
        Map innerMap = jsonToMap(value);
        BeanWrapper extBeanTag = new BeanWrapper();
        extBeanTag.setInnerMap(innerMap);
        return extBeanTag;
    }

    @Override
    public BeanWrapper getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        String value = rs.getString(columnIndex);
        Map innerMap = jsonToMap(value);
        BeanWrapper extBeanTag = new BeanWrapper();
        extBeanTag.setInnerMap(innerMap);
        return extBeanTag;
    }

    @Override
    public BeanWrapper getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        String value = cs.getString(columnIndex);
        Map innerMap = jsonToMap(value);
        BeanWrapper extBeanTag = new BeanWrapper();
        extBeanTag.setInnerMap(innerMap);
        return extBeanTag;
    }
}
