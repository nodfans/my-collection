package com.ddcx.app.provider.exam.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.exam.QuestionRoom;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface QuestionRoomMapper extends MyMapper<QuestionRoom> {
}