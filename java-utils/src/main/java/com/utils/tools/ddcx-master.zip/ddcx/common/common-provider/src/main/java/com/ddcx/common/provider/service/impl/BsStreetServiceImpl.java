package com.ddcx.common.provider.service.impl;


import com.ddcx.common.provider.mapper.BsStreetMapper;
import com.ddcx.common.provider.service.BsStreetService;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.model.common.BsStreet;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/03/23.
 */
@Service
@Transactional
public class BsStreetServiceImpl extends BaseService<BsStreet> implements BsStreetService {
    @Resource
    private BsStreetMapper bsStreetMapper;

    @Resource
    private RedisUtil redisUtil;


//    /**
//     * redis初始化信息
//     */
//    @PostConstruct
//    public  void InitInfo(){
//        Long area=redisUtil.hgetSize(RedisKey.BS_STREET);
//        System.out.println("街道信息加载中。。。");
//        if(area>0){
//            return;
//        }
//        List<BsStreet> list=bsStreetMapper.selectAll();
//        for (BsStreet bsArea : list) {
//            redisUtil.hset(RedisKey.BS_STREET,bsArea.getStreetCode()+"",bsArea);
//        }
//    }

}
