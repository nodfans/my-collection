package com.ddcx.common.provider.controller;

import com.ddcx.common.provider.service.BsCityService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/03/23.
*/
@RestController
@RequestMapping("/bs/city")
public class BsCityController {
    @Resource
    private BsCityService bsCityService;

}
