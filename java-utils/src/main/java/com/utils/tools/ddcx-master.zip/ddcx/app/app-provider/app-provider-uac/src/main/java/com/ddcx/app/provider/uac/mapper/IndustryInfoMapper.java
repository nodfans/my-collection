package com.ddcx.app.provider.uac.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.uac.IndustryInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;


@Mapper
@Component
public interface IndustryInfoMapper extends MyMapper<IndustryInfo> {

    @Update("update industry_info set view_num=view_num+1 where id=#{id}")
    void updateViewNum(@Param("id")Long id);
}