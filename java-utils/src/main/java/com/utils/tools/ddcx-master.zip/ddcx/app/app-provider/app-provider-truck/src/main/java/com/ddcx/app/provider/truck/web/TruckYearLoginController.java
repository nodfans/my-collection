package com.ddcx.app.provider.truck.web;


import com.ddcx.app.provider.truck.service.TruckYearLoginService;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.TruckYearLogin;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/04/17.
*/
@RestController
@RequestMapping("/truck/year/login")
@Api(value = "年度复核记录表",tags = "年度复核记录表")
public class TruckYearLoginController {
    @Resource
    private TruckYearLoginService truckYearLoginService;


//    @ApiOperation("添加年度复核记录表")
//    @PostMapping("/addTruckYearLogin")
//    public Wrapper addTruckYearLogin(@RequestBody @Validated TruckYearLogin yearLogin){
//        return  truckYearLoginService.addTruckYearLogin(yearLogin);
//    }
        @ApiOperation("获取年度复核记录表")
        @GetMapping("/getTruckYearLogin")
        public Wrapper<TruckYearLogin> getTruckYearLogin(@RequestParam @ApiParam("truckId") Long  truckId){
            return  truckYearLoginService.getTruckYearLogin(truckId);
            }
        }
