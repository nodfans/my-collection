package com.ddcx.app.provider.truck.web;


import com.ddcx.app.provider.truck.service.SubscribeConfigService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.SubscribeConfig;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
* Created by CodeGenerator on 2020/03/11.
*/
@RestController
@RequestMapping("/subscribe/config")
@Api(value = "年检预约配置",tags = "年检预约配置")
public class SubscribeConfigController extends BaseController {
    @Resource
    private SubscribeConfigService subscribeConfigService;


    @ApiOperation("获取年检预约配置信息")
    @GetMapping("/getCurrentConfig")
    public Wrapper<List<SubscribeConfig>> getCurrentConfig(){
        return subscribeConfigService.getCurrentConfig(getLoginAuthDto());
    }

}





















