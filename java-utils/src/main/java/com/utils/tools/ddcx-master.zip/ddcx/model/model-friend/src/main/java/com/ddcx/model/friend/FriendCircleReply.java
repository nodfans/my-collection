package com.ddcx.model.friend;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Table(name = "friend_circle_reply")
@ApiModel("卡友圈回复")
public class FriendCircleReply {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 卡友圈主键
     */
    @ApiModelProperty(value = "卡友圈主键", required = true)
    @Column(name = "friend_circle_id")
    private Long friendCircleId;

    /**
     * 回复内容
     */
    @ApiModelProperty(value = "回复内容", required = true)
    private String content;

    /**
     * 回复用户主键
     */
    @ApiModelProperty("回复用户主键")
    @Column(name = "user_id")
    private Long userId;

    /**
     * 回复用户昵称
     */
    @ApiModelProperty("回复用户昵称")
    @Column(name = "user_nick_name")
    private String userNickName;

    /**
     * 回复时间
     */
    @ApiModelProperty("回复时间")
    @Column(name = "create_time")
    private Long createTime;

    /**
     * 回复对象主键
     */
    @ApiModelProperty("回复对象主键")
    @Column(name = "to_user_id")
    private Long toUserId;

    /**
     * 回复对象昵称
     */
    @ApiModelProperty("回复对象昵称")
    @Column(name = "to_user_nick_name")
    private String toUserNickName;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取卡友圈主键
     *
     * @return friend_circle_id - 卡友圈主键
     */
    public Long getFriendCircleId() {
        return friendCircleId;
    }

    /**
     * 设置卡友圈主键
     *
     * @param friendCircleId 卡友圈主键
     */
    public void setFriendCircleId(Long friendCircleId) {
        this.friendCircleId = friendCircleId;
    }

    /**
     * 获取回复内容
     *
     * @return content - 回复内容
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置回复内容
     *
     * @param content 回复内容
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取回复用户主键
     *
     * @return user_id - 回复用户主键
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置回复用户主键
     *
     * @param userId 回复用户主键
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 获取回复用户昵称
     *
     * @return user_nick_name - 回复用户昵称
     */
    public String getUserNickName() {
        return userNickName;
    }

    /**
     * 设置回复用户昵称
     *
     * @param userNickName 回复用户昵称
     */
    public void setUserNickName(String userNickName) {
        this.userNickName = userNickName;
    }

    /**
     * 获取回复时间
     *
     * @return create_time - 回复时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置回复时间
     *
     * @param createTime 回复时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取回复对象主键
     *
     * @return to_user_id - 回复对象主键
     */
    public Long getToUserId() {
        return toUserId;
    }

    /**
     * 设置回复对象主键
     *
     * @param toUserId 回复对象主键
     */
    public void setToUserId(Long toUserId) {
        this.toUserId = toUserId;
    }

    /**
     * 获取回复对象昵称
     *
     * @return to_user_nick_name - 回复对象昵称
     */
    public String getToUserNickName() {
        return toUserNickName;
    }

    /**
     * 设置回复对象昵称
     *
     * @param toUserNickName 回复对象昵称
     */
    public void setToUserNickName(String toUserNickName) {
        this.toUserNickName = toUserNickName;
    }
}