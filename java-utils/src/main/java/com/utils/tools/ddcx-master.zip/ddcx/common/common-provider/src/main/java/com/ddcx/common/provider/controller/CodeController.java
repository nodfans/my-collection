package com.ddcx.common.provider.controller;

import com.ddcx.common.provider.api.model.dto.SendCodeDto;
import com.ddcx.common.provider.api.model.dto.VerifyCodeDto;
import com.ddcx.common.provider.api.model.vo.VerifyCodeResultVo;
import com.ddcx.common.provider.service.CodeService;
import com.ddcx.framework.base.enums.LogTypeEnum;
import com.ddcx.framework.core.annotation.RequestLog;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.google.common.base.Preconditions;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/code")
@Api(value = "验证码", tags = {"验证码"})
public class CodeController {

    @Autowired
    private CodeService codeService;

    @ApiOperation(value = "发送", notes = "发送")
    @PostMapping(value = "/send")
    @RequestLog(logType = LogTypeEnum.REQUEST_LOG, isSaveRequestData = true, isSaveResponseData = true)
    public Wrapper send(@RequestBody SendCodeDto sendCodeDto) {
        Preconditions.checkArgument(PublicUtil.isNotEmpty(sendCodeDto.getAccount()), "账号不能为空");
        Preconditions.checkArgument(PublicUtil.isNotEmpty(sendCodeDto.getSendType()) && (1 == sendCodeDto.getSendType() || 2 == sendCodeDto.getSendType()), "类型不能为空");
        Preconditions.checkArgument(PublicUtil.isNotEmpty(sendCodeDto.getBizType()) && (1 == sendCodeDto.getBizType() || 2 == sendCodeDto.getBizType() || 3 == sendCodeDto.getBizType()|| 4 == sendCodeDto.getBizType()|| 5 == sendCodeDto.getBizType()), "类型不能为空");
        Boolean flag = codeService.send(sendCodeDto);
        if (flag) {
            return WrapMapper.ok("发送成功");
        }
        return WrapMapper.error("发送失败");
    }

    @ApiOperation(value = "验证", notes = "验证")
    @PostMapping(value = "/verify")
    @RequestLog(logType = LogTypeEnum.REQUEST_LOG, isSaveRequestData = true, isSaveResponseData = true)
    public Wrapper<VerifyCodeResultVo> verify(@RequestBody VerifyCodeDto verifyCodeDto) {
        Preconditions.checkArgument(PublicUtil.isNotEmpty(verifyCodeDto.getAccount()), "账号不能为空");
        Preconditions.checkArgument(PublicUtil.isNotEmpty(verifyCodeDto.getCode()), "验证码不能为空");
        VerifyCodeResultVo verifyCodeResultVo = codeService.verify(verifyCodeDto);
        return WrapMapper.ok(verifyCodeResultVo);
    }
}
