package com.ddcx.app.provider.friend.web;


import com.ddcx.app.provider.api.friend.model.vo.FriendCircleVo;
import com.ddcx.app.provider.friend.service.FriendCircleService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.annotation.NoNeedAccessAuthentication;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.friend.FriendCircle;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/03/02.
 */
@RestController
@RequestMapping("/friend/circle")
@Api(value = "卡友圈", tags = "卡友圈")
public class FriendCircleController extends BaseController {
    @Resource
    private FriendCircleService friendCircleService;

    @ApiOperation("添加卡友圈信息")
    @PostMapping("/saveFriendCircle")
    public Wrapper saveFriendCircle(@ApiParam(value = "卡友圈对象") @RequestBody @Validated FriendCircle friendCircle) {
        return friendCircleService.saveFriendCircle(friendCircle, getLoginAuthDto());
    }

    @ApiOperation("获取卡友圈列表<未登录使用>")
    @GetMapping("/getFriendCircle")
    public Wrapper<PageInfo<FriendCircle>> getFriendCircle(@ApiParam(value = "当前页", defaultValue = "1") @RequestParam(defaultValue = "1") Integer page,
                                                           @ApiParam(value = "每页记录数", defaultValue = "10") @RequestParam(defaultValue = "5")Integer size,
                                                           @ApiParam(value = "参数",defaultValue = "")@RequestParam(defaultValue = "") String param
    ) {
        LoginAuthDto dto;
        try {
            dto=getLoginAuthDto();
        } catch (Exception e) {
            dto=null;
        }
        return friendCircleService.getFriendCircle(page, size, param,dto);
    }

    @ApiOperation("获取我的卡友圈列表")
    @GetMapping("/getOwnFriendCircle")
    public Wrapper<PageInfo<FriendCircle>> getOwnFriendCircle(@ApiParam(value = "当前页", defaultValue = "1") @RequestParam(defaultValue = "1") Integer page,
                                                           @ApiParam(value = "每页记录数", defaultValue = "10") @RequestParam(defaultValue = "5")Integer size
    ) {
        return friendCircleService.getOwnFriendCircle(page, size,getLoginAuthDto());
    }

    @NoNeedAccessAuthentication
    @ApiOperation("获取卡友圈详情")
    @GetMapping("/getFriendCircleDetail")
    public Wrapper<FriendCircleVo> getFriendCircleDetail(@ApiParam(value = "卡友圈主键", required = true) @RequestParam Long id) {
        LoginAuthDto dto;
        try {
            dto=getLoginAuthDto();
        } catch (Exception e) {
            dto=null;
        }
        return friendCircleService.getFriendCircleDetail(id,dto);
    }

    @ApiOperation("删除卡友圈信息")
    @GetMapping("/deleteFriendCircle")
    public Wrapper deleteFriendCircle(@ApiParam(value = "卡友圈主键") Long id) {
        return friendCircleService.deleteFriendCircle(id, getLoginAuthDto().getUserId());
    }

}
