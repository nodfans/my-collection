package com.ddcx.framework.base.enums;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum LogTypeEnum {
    /**
     * 操作日志
     */
    REQUEST_LOG(10, "操作日志"),
    /**
     * 登录日志
     */
    LOGIN_LOG(20, "登录日志"),
    /**
     * 异常日志
     */
    EXCEPTION_LOG(30, "异常日志");

    /**
     * The Type.
     */
    Integer type;
    /**
     * The Name.
     */
    String name;

    LogTypeEnum(Integer type, String name) {
        this.type = type;
        this.name = name;
    }

    /**
     * Gets type.
     *
     * @return the type
     */
    public Integer getType() {
        return type;
    }

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Gets name.
     *
     * @param type the type
     * @return the name
     */
    public static String getName(String type) {
        for (LogTypeEnum ele : LogTypeEnum.values()) {
            if (type.equals(ele.getType())) {
                return ele.getName();
            }
        }
        return null;
    }

    /**
     * Gets enum.
     *
     * @param type the type
     * @return the enum
     */
    public static LogTypeEnum getEnum(Integer type) {
        for (LogTypeEnum ele : LogTypeEnum.values()) {
            if (type.intValue() == ele.getType().intValue()) {
                return ele;
            }
        }
        return LogTypeEnum.REQUEST_LOG;
    }

    /**
     * Gets list.
     *
     * @return the list
     */
    public static List<Map<String, Object>> getList() {
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        for (LogTypeEnum ele : LogTypeEnum.values()) {
            Map<String, Object> map = new HashMap<>();
            map.put("key", ele.getType());
            map.put("value", ele.getName());
            list.add(map);
        }
        return list;
    }
}
