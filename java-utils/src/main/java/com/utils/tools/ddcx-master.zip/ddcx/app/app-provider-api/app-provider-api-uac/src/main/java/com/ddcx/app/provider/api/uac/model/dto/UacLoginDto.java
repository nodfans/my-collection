package com.ddcx.app.provider.api.uac.model.dto;

import com.ddcx.app.provider.api.uac.enums.UacFromTypeEnum;
import com.ddcx.app.provider.api.uac.enums.UacLoginTypeEnum;
import com.ddcx.framework.core.validated.EnumValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@ApiModel(value = "UacLoginDto", description = "用户登录")
public class UacLoginDto implements java.io.Serializable {

    private static final long serialVersionUID = -2515686385988679874L;
    /**
     * @NotNull 验证对象是否不为null, 无法查检长度为0的字符串
     * @NotBlank 检查约束 (字符串) 是不是Null还有被Trim的长度是否大于0,只对字符串,且会去掉前后空格.
     * @NotEmpty 检查(集合)约束元素是否为NULL或者是EMPTY.
     */
    @NotBlank(message = "账号不能为空")
    @ApiModelProperty(value = "账号", name = "account", required = true)
    private String account;

//    @NotBlank(message = "密码不能为空")
    @ApiModelProperty(value = "密码", name = "password")
    private String password;

    @ApiModelProperty(value = "验证码 短信登录需要", name = "code")
    private String code;

    @NotNull(message = "登录类型不能为空")
    @EnumValid(target = UacLoginTypeEnum.class, message = "登录类型错误")
    @ApiModelProperty(value = "登录类型 1-短信登录，2-密码登录", name = "loginType", required = true)
    private Integer loginType;

    @NotNull(message = "来源不能为空")
    @EnumValid(target = UacFromTypeEnum.class, message = "来源类型错误")
    @ApiModelProperty(value = "来源 1-android，2-ios，3-pc", name = "fromType", required = true)
    private Integer fromType;

//    @NotBlank(message = "昵称不能为空")
    @ApiModelProperty(value = "昵称", name = "nickName", required = false)
    private String nickName;


}
