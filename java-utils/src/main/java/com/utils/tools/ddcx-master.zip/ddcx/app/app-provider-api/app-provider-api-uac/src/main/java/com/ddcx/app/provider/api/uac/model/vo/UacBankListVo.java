package com.ddcx.app.provider.api.uac.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "UacBankListVo", description = "用户银行卡列表")
public class UacBankListVo implements java.io.Serializable {
    private static final long serialVersionUID = 5259334410512805582L;

    @ApiModelProperty(value = "id", name = "id")
    private Long id;

    @ApiModelProperty(value = "cardVest", name = "持卡人")
    private String cardVest;

    @ApiModelProperty(value = "cardNo", name = "银行卡号")
    private String cardNo;

    @ApiModelProperty(value = "bankCode", name = "银行编码")
    private String bankCode;

    @ApiModelProperty(value = "bankName", name = "银行名称")
    private String bankName;

    @ApiModelProperty(value = "cardType", name = "卡类型 DC-储蓄卡，CC-信用卡(贷记卡)，SCC-准贷记卡，PC-预付费卡")
    private String cardType;

    @ApiModelProperty(value = "phone", name = "手机号码")
    private String phone;

    @ApiModelProperty(value = "createTime", name = "创建时间")
    private Long createTime;

    @ApiModelProperty("银行卡图标")
    private  String icon;

    @ApiModelProperty("银行卡背景")
    private String background;
}
