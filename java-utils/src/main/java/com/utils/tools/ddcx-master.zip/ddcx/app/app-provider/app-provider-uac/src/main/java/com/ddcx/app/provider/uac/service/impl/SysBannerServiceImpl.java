package com.ddcx.app.provider.uac.service.impl;


import com.ddcx.app.provider.uac.mapper.SysBannerMapper;
import com.ddcx.app.provider.uac.service.SysBannerService;
import com.ddcx.framework.base.dto.AdminLoginAutoDto;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.SysBanner;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/16.
 */
@Service
@Transactional
public class SysBannerServiceImpl implements SysBannerService {
    @Resource
    private SysBannerMapper sysBannerMapper;

    @Override
    public Wrapper listOfPage(SysBanner banner, Integer page, Integer sizes) {
        PageHelper.startPage(page,sizes);
        if(banner.getPos()==null){
            return WrapMapper.error("位置未指定");
        }
        SysBanner sysBanner=new SysBanner();
        sysBanner.setPos(banner.getPos());
        sysBanner.setCreateTime(System.currentTimeMillis()/1000);
        List<SysBanner> list=sysBannerMapper.selectCurrentBanner(sysBanner);
        return WrapMapper.ok(new PageInfo<>(list));
    }


    @Override
    public Wrapper detail(Long id) {
        SysBanner banner=new SysBanner();
        banner.setId(id);
        banner.setState((byte) 1);
        SysBanner sysBanner=sysBannerMapper.selectOne(banner);
        sysBannerMapper.addSelf(id);
        return WrapMapper.ok(sysBanner);
    }

}
