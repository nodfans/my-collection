package com.ddcx.app.provider.truck.service.impl;


import com.ddcx.app.provider.truck.service.TruckMileageStatisticsService;
import com.ddcx.app.provider.truck.mapper.TruckMileageStatisticsMapper;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.TruckMileageStatistics;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/04/17.
 */
@Service
@Transactional
public class TruckMileageStatisticsServiceImpl  implements TruckMileageStatisticsService {
    @Resource
    private TruckMileageStatisticsMapper truckMileageStatisticsMapper;

    @Override
    public Wrapper getMileageStatistics(Long truckId) {
        TruckMileageStatistics truckMileageStatistics=truckMileageStatisticsMapper.selectByTruckId(truckId);
        if(truckMileageStatistics==null){
            return WrapMapper.error("暂无里程表");
        }
        return WrapMapper.ok(truckMileageStatistics);
    }
}
