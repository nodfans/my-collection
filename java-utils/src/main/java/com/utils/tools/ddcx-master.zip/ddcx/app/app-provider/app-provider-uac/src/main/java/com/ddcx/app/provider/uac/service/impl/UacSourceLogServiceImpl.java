package com.ddcx.app.provider.uac.service.impl;


import com.ddcx.app.provider.uac.mapper.UacSourceLogMapper;
import com.ddcx.app.provider.uac.mapper.UacUserMapper;
import com.ddcx.app.provider.uac.service.UacSourceLogService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.UacSourceLog;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDate;

/**
 * Created by CodeGenerator on 2020/03/27.
 */
@Service
@Transactional
public class UacSourceLogServiceImpl extends BaseService<UacSourceLog> implements UacSourceLogService {
    @Resource
    private UacSourceLogMapper uacSourceLogMapper;
    @Resource
    private UacUserMapper uacUserMapper;

    @Override
    public Wrapper loginSource(LoginAuthDto dto) {
        UacSourceLog log = uacSourceLogMapper.selectLastLoginInfo(dto.getUserId());
        if (log == null || log.getCreateTime() / 60 / 60 / 24 < LocalDate.now().toEpochDay()) {
            UacSourceLog sourceLog = new UacSourceLog();
            sourceLog.setCreateTime(System.currentTimeMillis() / 1000);
            sourceLog.setScore(1);
            sourceLog.setSourceType(1);
            sourceLog.setuId(dto.getUserId());
            uacSourceLogMapper.insertSelective(sourceLog);
            uacUserMapper.addSource(1, dto.getUserId());
            return WrapMapper.ok(1);
        } else {
            return WrapMapper.ok(0);
        }
    }

    @Override
    public Wrapper addLog(Long userId) {
        UacSourceLog log = new UacSourceLog();
        log.setsId(generateId());
        log.setRemarks("小程序登录");
        log.setuId(userId);
        log.setScore(1);
        log.setCreateTime(currentTime());
        uacSourceLogMapper.insertSelective(log);
        return WrapMapper.ok();
    }
}
