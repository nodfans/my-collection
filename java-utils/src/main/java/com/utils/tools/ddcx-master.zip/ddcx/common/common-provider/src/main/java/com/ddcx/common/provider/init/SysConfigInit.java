package com.ddcx.common.provider.init;


import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.common.provider.mapper.SysConfigMapper;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.model.common.SysConfig;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;

@Component
public class SysConfigInit {

    @Resource
    private SysConfigMapper configMapper;
    @Resource
    private RedisUtil redisUtil;

    @PostConstruct
    public void sysConfigInit(){
        List<SysConfig> configs=configMapper.selectAll();
        for (SysConfig config : configs) {
             redisUtil.hset(RedisKey.SYS_CONFIG,config.getConfigKey(),config.getConfigValue());
        }
    }

}
