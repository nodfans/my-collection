package com.ddcx.app.provider.friend;

import com.ddcx.framework.core.config.SwaggerConfiguration;
import com.ddcx.framework.core.support.GlobalExceptionHandler;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication(scanBasePackages = {"com.ddcx"})
@EnableDiscoveryClient
@Import({SwaggerConfiguration.class, GlobalExceptionHandler.class})
@EnableFeignClients(basePackages = {"com.ddcx.app.provider.api.uac.service","com.ddcx.common.provider.api.service"})
@EnableTransactionManagement
public class FriendApplication {
    public static void main(String[] args) {
        SpringApplication.run(FriendApplication.class, args);
    }
}
