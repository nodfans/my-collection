package com.ddcx.app.provider.truck.service;

import com.ddcx.framework.util.wrapper.Wrapper;

/**
 * Created by CodeGenerator on 2020/04/17.
 */
public interface TruckMileageStatisticsService {

    Wrapper getMileageStatistics(Long truckId);
}
