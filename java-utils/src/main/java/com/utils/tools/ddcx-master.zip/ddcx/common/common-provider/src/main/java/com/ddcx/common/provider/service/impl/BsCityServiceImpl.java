package com.ddcx.common.provider.service.impl;


import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.common.provider.mapper.BsCityMapper;
import com.ddcx.common.provider.service.BsCityService;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.model.common.BsCity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/23.
 */
@Service
@Transactional
public class BsCityServiceImpl extends BaseService<BsCity> implements BsCityService {
    @Resource
    private BsCityMapper bsCityMapper;

    @Resource
    private RedisUtil redisUtil;


    /**
     * redis初始化信息
     */
    @PostConstruct
    public   void InitInfo(){
        Long area=redisUtil.hgetSize(RedisKey.BS_CITY);
        if(area>0){
            return;
        }
        List<BsCity> list=bsCityMapper.selectAll();
        for (BsCity bsArea : list) {
            redisUtil.hset(RedisKey.BS_CITY,bsArea.getCityCode()+"",bsArea);
        }
    }

}
