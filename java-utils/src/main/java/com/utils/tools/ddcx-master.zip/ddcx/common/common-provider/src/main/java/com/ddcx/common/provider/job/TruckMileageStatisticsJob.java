package com.ddcx.common.provider.job;


import com.ddcx.common.provider.api.zhiyun.ZhiYunMileageStatistics;
import com.ddcx.common.provider.service.ZhiYunService;
import com.ddcx.model.truck.Truck;
import com.ddcx.model.truck.TruckMileageStatistics;
import com.ddcx.web.provider.api.truck.model.service.AdminTruckFeignClientApi;
import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Component
@EnableScheduling
@Log4j2
public class TruckMileageStatisticsJob {

    @Resource
    private ZhiYunService zhiYunService;
    @Resource
    private AdminTruckFeignClientApi truckFeignClientApi;

    /**
     * 每月一号固定统计所有车辆的行驶里程
     */
//    @Scheduled(cron = "0 2 0 1 * ?")
    public void truckMileageStatistisc(){

        String endDate=LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss"));
        String startDate=LocalDateTime.now().plusMonths(-1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss"));
        //获取所有有效车辆信息
        List<Truck> list=truckFeignClientApi.getAllTruckWithMileageStatistics();
        if(list.size()==0){
            return;
        }
        ZhiYunMileageStatistics statistics;
        List<TruckMileageStatistics> truckMileageStatisticses=new ArrayList<>(list.size());
        TruckMileageStatistics truckMileageStatistics;
        for (Truck truck : list) {
            try {
                statistics=zhiYunService.getMileageStatistics(truck,startDate,endDate);
            } catch (Exception e) {
                e.printStackTrace();
                statistics=null;
            }
            if(statistics!=null){
                truckMileageStatistics=new TruckMileageStatistics();
                truckMileageStatistics.setCreateTime(System.currentTimeMillis()/1000);
                truckMileageStatistics.setPeriod(BigDecimal.valueOf(Double.valueOf(statistics.getMileage())));
                truckMileageStatistics.setTruckId(truck.getId());
                truckMileageStatisticses.add(truckMileageStatistics);
            }
        }
        truckFeignClientApi.addAllTruckMileageStatisticses(truckMileageStatisticses);

    }

}
