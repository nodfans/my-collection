package com.ddcx.model.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

@Data
@ApiModel("消息配置")
public class MessageConfig implements java.io.Serializable {

    @Id
    @ApiModelProperty("主键")
    private Long id;
    @NotBlank(message = "标题不能为空")
    @ApiModelProperty("标题")
    private String topic;
    @NotBlank(message = "消息内容不能为空")
    @ApiModelProperty("消息内容")
    private String content;
    @ApiModelProperty("消息类型(1.系统消息 2.优惠消息 3.救援消息 4.学习消息)")
    private Integer type;
    @ApiModelProperty("创建人")
    private Long createUser;
    @ApiModelProperty("消息创建时间")
    private Long createTime;
    @ApiModelProperty("请求路径")
    private String requestUrl="0";
    @ApiModelProperty("图片url")
    private String imgUrl;
    @ApiModelProperty("1：已删除  0：未删除")
    private Integer isDelete;
}
