package com.ddcx.app.provider.truck.service;


import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.OverallSubscribeDto;

/**
 * Created by CodeGenerator on 2020/03/11.
 */
public interface SubscribeConfigService {


    Wrapper getCurrentConfig(LoginAuthDto dto);

    OverallSubscribeDto getByYearAndMonth(int year, int month, Long motorcadeId);
}
