package com.ddcx.app.provider.uac.service.impl;

import com.alibaba.fastjson.JSON;
import com.ddcx.app.provider.api.friend.service.FriendServiceFeignApi;
import com.ddcx.app.provider.api.uac.enums.UacErrorCodeEnum;
import com.ddcx.app.provider.api.uac.exception.UacBizException;
import com.ddcx.app.provider.api.uac.model.dto.*;
import com.ddcx.app.provider.api.uac.model.vo.*;
import com.ddcx.app.provider.uac.mapper.*;
import com.ddcx.app.provider.uac.service.UacBankService;
import com.ddcx.app.provider.uac.service.UacLoginTokenService;
import com.ddcx.app.provider.uac.service.UacUserService;
import com.ddcx.common.provider.api.enums.CommonErrorCodeEnum;
import com.ddcx.common.provider.api.exception.CommonBizException;
import com.ddcx.framework.base.constant.GlobalConstant;
import com.ddcx.framework.base.dto.ActionTokenDto;
import com.ddcx.framework.base.dto.BaseQueryDto;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.base.dto.VerifyCode;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.CollectionUtils;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.framework.util.StringUtils;
import com.ddcx.framework.util.encrypt.Md5Utils;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.*;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UacUserServiceImpl extends BaseService<UacUser> implements UacUserService {

    @Autowired
    private UacLoginTokenService loginTokenService;

    @Autowired
    private UacSourceLogMapper logMapper;

    @Autowired
    private FriendServiceFeignApi friendServiceFeignApi;

    @Resource
    private UacUserAuthMapper authMapper;

    @Resource
    private UacUserMapper uacUserMapper;


    @Resource
    private UacBankService uacBankService;

    @Resource
    private RedisUtil redisUtil;

    @Resource
    private UacUserMiniMapper uacUserMiniMapper;

    @Override
    public UacUser getById(Long id) {
        return selectByKey(id);
    }

    @Override
    public UacUser getByPhone(String phone) {
        Example example = new Example(UacUser.class);
        Example.Criteria criteria = example.createCriteria();
        if (phone.length() > 11) {
            criteria.andEqualTo("idCard", phone);
        } else {
            criteria.andEqualTo("phone", phone);
        }
        return uacUserMapper.selectOneByExample(example);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public UacLoginTokenVo register(UacUserRegisterDto uacUserRegisterDto) {
        if (PublicUtil.isNotEmpty(getByPhone(uacUserRegisterDto.getPhone()))) {
            throw new UacBizException(UacErrorCodeEnum.UAC20000004);
        }
        ActionTokenDto actionTokenDto = (ActionTokenDto) redisUtil.get(GlobalConstant.Sys.ACTION_TOKEN + ":" + uacUserRegisterDto.getPhone());
        if (PublicUtil.isEmpty(actionTokenDto)) {
            throw new CommonBizException(CommonErrorCodeEnum.COMMON10000005);
        }
        if (!uacUserRegisterDto.getCode().equals(actionTokenDto.getToken())) {
            throw new CommonBizException(CommonErrorCodeEnum.COMMON10000005);
        }
        redisUtil.del(GlobalConstant.Sys.ACTION_TOKEN + ":" + uacUserRegisterDto.getPhone());
        if (uacUserMapper.selectByPhone(uacUserRegisterDto.getPhone()) != null) {
            throw new CommonBizException(CommonErrorCodeEnum.COMMON10000006);
        }

        UacLoginTokenVo uacLoginTokenVo = null;
        UacUser uacUser = new UacUser();
        uacUser.setId(generateId());
        uacUser.setUserNo(String.valueOf(System.currentTimeMillis()));
        uacUser.setPhone(uacUserRegisterDto.getPhone());
        uacUser.setPassword(Md5Utils.md5Str(uacUserRegisterDto.getPassword()));
        uacUser.setUserType(uacUserRegisterDto.getUserType());
        uacUser.setCreateTime(currentTime());
        uacUser.setFromType(uacUserRegisterDto.getFromType());
        uacUser.setState(1);
        uacUser.setNickName(uacUserRegisterDto.getNickName());
        uacUser.setHeadImg(uacUserRegisterDto.getHeadImg());
        uacUser.setComName(uacUserRegisterDto.getComName());
        uacUser.setMotorcadeId(uacUserRegisterDto.getMotorcadeId());
        uacUser.setMotorcadeName(uacUserRegisterDto.getMotorcadeName());
        //查找小程序该手机号是否有登录记录，有的话，进行数据填充
        UacUserMini mini = uacUserMiniMapper.selectByPhone(uacUserRegisterDto.getPhone());
        if (mini != null) {
            uacUser.setOpenId(mini.getOpenId());
            uacUser.setNickName(mini.getNickName());
            uacUser.setHeadImg(mini.getAvatarUrl());
        }
        if (insert(uacUser) > 0) {
            uacLoginTokenVo = loginTokenService.generateToken(uacUser);
        }
        return uacLoginTokenVo;
    }

    @Override
    public Wrapper updatePWD(UacLoginDto dto) {
        UacUser uacUser = uacUserMapper.selectByPhone(dto.getAccount());
        if (uacUser == null) {
            return WrapMapper.error("手机账户不存在");
        }
        VerifyCode verifyCode = (VerifyCode) redisUtil.get(VERIFY_CODE + ":" + dto.getAccount());
        if (PublicUtil.isEmpty(verifyCode)) {
            throw new CommonBizException(CommonErrorCodeEnum.COMMON10000004);
        }
        if (!dto.getCode().toLowerCase().equals(verifyCode.getCode())) {
            throw new CommonBizException(CommonErrorCodeEnum.COMMON10000004);
        }
        redisUtil.del(VERIFY_CODE + ":" + verifyCode.getAccount());
        UacUser user = new UacUser();
        user.setId(uacUser.getId());
        user.setPassword(Md5Utils.md5Str(dto.getPassword()));
        uacUserMapper.updateByPrimaryKeySelective(user);
        return WrapMapper.ok();
    }

    @Override
    public UacUser checkId(Long id) {
        UacUser uacUser = null;
        if (PublicUtil.isNotEmpty(id)) {
            uacUser = getById(id);
            if (PublicUtil.isEmpty(uacUser)) {
                throw new UacBizException(UacErrorCodeEnum.UAC20000003);
            }
        }
        return uacUser;
    }

    @Override
    public UacUserVo getUser(LoginAuthDto loginAuthDto) {
        UacUser uacUser = getById(loginAuthDto.getUserId());
        UacUserVo uacUserVo = new ModelMapper().map(uacUser, UacUserVo.class);
        uacUserVo.setUserId(uacUser.getId());
        uacUserVo.setUserType(uacUser.getUserType());
        UacUserAuth auth = authMapper.selectByUserId(uacUser.getId());
        uacUserVo.setUacUserAuth(auth);

        uacUserVo.setBanks(uacBankService.getByUserId(uacUser.getId()));
        return uacUserVo;
    }

    @Override
    public Boolean update(LoginAuthDto loginAuthDto, UacUpdateUserDto uacUpdateUserDto) {
        if (uacUpdateUserDto.isNew()) {
            UacUser updateUacUser = new ModelMapper().map(uacUpdateUserDto, UacUser.class);
            updateUacUser.setId(loginAuthDto.getUserId());
            if (PublicUtil.isNotEmpty(uacUpdateUserDto.getAddressCode())) {
                updateUacUser.setAddressCode(uacUpdateUserDto.getAddressCode());
                updateUacUser.setAddressMsg(uacUpdateUserDto.getAddressMsg());
            }
            if(updateUacUser.getBirthday()!=null&&updateUacUser.getBirthday().toString().length()>10){
                updateUacUser.setBirthday(updateUacUser.getBirthday()/1000);
            }
            if (update(updateUacUser) > 0) {
                if (StringUtils.isNotBlank(uacUpdateUserDto.getHeadImg()) || StringUtils.isNotBlank(uacUpdateUserDto.getRealName())) {
                    friendServiceFeignApi.updateUserHeadImgAndUserName(loginAuthDto.getUserId(), uacUpdateUserDto.getHeadImg(), uacUpdateUserDto.getRealName());
                }
                loginTokenService.refreshRedis(loginAuthDto.getUserId(), loginAuthDto.getToken());
                return true;
            }
        }
        return false;
    }


    private UacUserAuth getAuthById(Long userId) {
        UacUserAuth uacUserAuth = authMapper.selectByUserId(userId);
        if (uacUserAuth == null) {
            uacUserAuth = new UacUserAuth();
            uacUserAuth.setUserId(userId);
            authMapper.insertSelective(uacUserAuth);
            uacUserAuth = authMapper.selectByUserId(userId);
        }
        return uacUserAuth;
    }

    @Override
    public Wrapper idAuth(IdAuth idAuth, LoginAuthDto dto) {
        UacUserAuth uacUserAuth = getAuthById(dto.getUserId());
        uacUserAuth.setIdAuth(JSON.toJSONString(idAuth));
        authMapper.updateByPrimaryKeySelective(uacUserAuth);
        UacUser uacUser=new UacUser();
        uacUser.setId(dto.getUserId());
        uacUser.setSex("男".equals(idAuth.getSex())?(byte)1:2);
        uacUser.setIdCard(idAuth.getIdCard());
        uacUser.setRealName(idAuth.getRealName());
        uacUserMapper.updateByPrimaryKeySelective(uacUser);
        return WrapMapper.ok();
    }

    @Override
    public Wrapper cardAuth(CardAuth cardAuth, LoginAuthDto dto, Integer type) {
        UacUserAuth uacUserAuth = getAuthById(dto.getUserId());
        switch (type) {
            case 1:
                if (uacUserAuth.getLicenceAuth() != null) {
                    CardAuth cardAuth1 = JSON.parseObject(uacUserAuth.getLicenceAuth(), CardAuth.class);
                    if (cardAuth.getImg() == null && cardAuth1 != null) {
                        cardAuth.setImg(cardAuth1.getImg());
                    }
                    if (cardAuth.getImgTranscript() == null && cardAuth1.getImgTranscript() != null) {
                        cardAuth.setImgTranscript(cardAuth1.getImgTranscript());
                    }
                }
                uacUserAuth.setLicenceAuth(JSON.toJSONString(cardAuth));
                break;
            case 2:
                uacUserAuth.setDrivingLicence(JSON.toJSONString(cardAuth));
                break;
            case 3:
                uacUserAuth.setJobAuth(JSON.toJSONString(cardAuth));
                break;
            default:
                return WrapMapper.error("非法类型");
        }
        authMapper.updateByPrimaryKeySelective(uacUserAuth);
        return WrapMapper.ok();
    }

    @Override
    public Wrapper getOwnMotorcadeDrivers(LoginAuthDto dto) {
        List<UacUser> users = uacUserMapper.getByMotorcadeId(dto.getMotorcadeId());
        List<Map<String, Object>> list = new ArrayList(users.size());
        for (UacUser user : users) {
            if (StringUtils.isEmpty(user.getRealName())) {
                continue;
            }
            list.add(new HashMap<String, Object>() {{
                put("id", user.getId());
                put("name", user.getRealName());
            }});
        }
        return WrapMapper.ok(list);
    }

    @Override
    public Boolean updateOpenId(String openId, String phone) {
        Integer updateOpenId = uacUserMapper.updateOpenId(openId, phone);
        if (1 == updateOpenId) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public Wrapper<DeepMyselfInfoVo> getDeepMyselfInfo(Long userId) {
        UacUser uacUser = uacUserMapper.selectByPrimaryKey(userId);
        if (PublicUtil.isNotEmpty(uacUser.getOpenId())) {
            DeepMyselfInfoVo infoVo = new DeepMyselfInfoVo();
            infoVo.setUserId(uacUser.getId());
            infoVo.setPhone(uacUser.getPhone());
            if (null != uacUser.getNickName()) {
                infoVo.setName(uacUser.getRealName());
            }
            if (null != uacUser.getHeadImg()) {
                infoVo.setHeadImg(uacUser.getHeadImg());
            }
            if (null != uacUser.getBirthday()) {
                infoVo.setBirthday(uacUser.getBirthday());
            }
            if (null != uacUser.getAddressMsg()) {
                infoVo.setAddressMsg(uacUser.getAddressMsg());
            }
            return WrapMapper.ok(infoVo);
        } else {
            UacUserMini user = uacUserMiniMapper.selectByPhone(uacUser.getPhone());
            if (PublicUtil.isNotEmpty(user)) {
                DeepMyselfInfoVo infoVo = new ModelMapper().map(user, DeepMyselfInfoVo.class);
                infoVo.setHeadImg(user.getAvatarUrl());
                infoVo.setName(user.getNickName());
                return WrapMapper.ok(infoVo);
            }
        }
        return null;
    }

    @Override
    public Wrapper editDeepMyselfInfo(LoginAuthDto loginAuthDto, MyselfInfoDto dto) {
        UacUser uacUser = uacUserMapper.selectByPrimaryKey(loginAuthDto.getUserId());
        if (PublicUtil.isNotEmpty(dto)) {
            if (null != dto.getName()) {
                uacUser.setRealName(dto.getName());
            }
            if (null != dto.getHeadImg()) {
                uacUser.setHeadImg(dto.getHeadImg());
            }
            if (null != dto.getBirthday()) {
                uacUser.setBirthday(dto.getBirthday());
            }
            if (null != dto.getAddressMsg()) {
                uacUser.setAddressMsg(dto.getAddressMsg());
            }
            uacUserMapper.updateByPrimaryKey(uacUser);
            loginTokenService.refreshRedis(uacUser.getId(), loginAuthDto.getToken());
            return WrapMapper.ok("修改成功");
        } else {
            UacUserMini uacUserMini = uacUserMiniMapper.selectByPhone(loginAuthDto.getPhone());
            if (PublicUtil.isNotEmpty(dto)) {
                if (null != dto.getName()) {
                    uacUserMini.setNickName(dto.getName());
                }
                if (null != dto.getHeadImg()) {
                    uacUserMini.setAvatarUrl(dto.getHeadImg());
                }
                if (null != dto.getBirthday()) {
                    uacUserMini.setBirthday(dto.getBirthday());
                }
                if (null != dto.getAddressMsg()) {
                    uacUserMini.setAddressMsg(dto.getAddressMsg());
                }
            }
            uacUserMiniMapper.updateByPrimaryKeySelective(uacUserMini);
            loginTokenService.refreshRedis(uacUser.getId(), loginAuthDto.getToken());
            return WrapMapper.ok("修改成功");
        }
    }

    @Override
    public Wrapper<MyselfInfoVo> getMyselfInfo(LoginAuthDto loginAuthDto) {
        UacUser user = uacUserMapper.selectByPrimaryKey(loginAuthDto.getUserId());
        if (PublicUtil.isNotEmpty(user)) {
            UacUserAuth auth = authMapper.selectByUserId(user.getId());
            if (PublicUtil.isNotEmpty(auth)) {
                MyselfInfoVo myself = new MyselfInfoVo();
                myself.setUserId(user.getId());
                if (null != user.getHeadImg()) {
                    myself.setHeadImg(user.getHeadImg());
                }
                myself.setUserType(user.getUserType());
                myself.setState(user.getState());
                if (null != user.getComName()) {
                    myself.setComName(user.getComName());
                }
                if (null != user.getEmergency()) {
                    myself.setEmergency(user.getEmergency());
                }
                CardAuth licenceInfo = JSON.parseObject(auth.getDrivingLicence(), CardAuth.class);
                myself.setLicenceTime(licenceInfo.getExpireTime());
                CardAuth jobInfo = JSON.parseObject(auth.getJobAuth(), CardAuth.class);
                myself.setJobTime(jobInfo.getExpireTime());
                IdAuth idInfo = JSON.parseObject(auth.getIdAuth(), IdAuth.class);
                myself.setIdCard(idInfo.getIdCard());
                List<UacBank> uacBanks = uacBankService.getByUserId(auth.getUserId());
                if (CollectionUtils.isNotEmpty(uacBanks)) {
                    myself.setBankState(1);
                } else {
                    myself.setBankState(0);
                }
                return WrapMapper.ok(myself);
            }
        } else {
            return WrapMapper.wrap(400, "请在APP端注册并提交有效信息");
        }
        return null;
    }

    @Override
    public Wrapper<UacUserDiffInfoVo> getMyselfDiffInfo(LoginAuthDto loginAuthDto, Integer type) {
        UacUser user = uacUserMapper.selectByPrimaryKey(loginAuthDto.getUserId());
        if (null != type && null != user) {
            UacUserDiffInfoVo diffInfo = new UacUserDiffInfoVo();
            UacUserAuth uacUserAuth = authMapper.selectByUserId(user.getId());
            if (1 == type) {
                UacUserDiffInfoVo.licenceInfo licenceInfo = new UacUserDiffInfoVo.licenceInfo();
                if (null != uacUserAuth.getLicenceAuth()) {
                    CardAuth licence = JSON.parseObject(uacUserAuth.getLicenceAuth(), CardAuth.class);
                    licenceInfo.setLicenseImg(licence.getImg());
                    licenceInfo.setLicenceExpireTime(licence.getExpireTime());
                }
                if (null != uacUserAuth.getDrivingLicence()) {
                    CardAuth driving = JSON.parseObject(uacUserAuth.getDrivingLicence(), CardAuth.class);
                    licenceInfo.setDrivingImg(driving.getImg());
                    licenceInfo.setDrivingExpireTime(driving.getExpireTime());
                }
                diffInfo.setLicenceInfo(licenceInfo);
                return WrapMapper.ok(diffInfo);
            } else if (2 == type) {
                UacUserDiffInfoVo.jobInfo jobInfo = new UacUserDiffInfoVo.jobInfo();
                if (null != uacUserAuth.getJobAuth()) {
                    CardAuth cardAuth = JSON.parseObject(uacUserAuth.getJobAuth(), CardAuth.class);
                    jobInfo.setJobImg(cardAuth.getImg());
                    jobInfo.setExpireTime(cardAuth.getExpireTime());
                }
                diffInfo.setJobInfo(jobInfo);
                return WrapMapper.ok(diffInfo);
            } else if (3 == type) {
                UacUserDiffInfoVo.idInfo idInfo = new UacUserDiffInfoVo.idInfo();
                if (null != uacUserAuth.getIdAuth()) {
                    IdAuth idAuth = JSON.parseObject(uacUserAuth.getIdAuth(), IdAuth.class);
                    idInfo.setName(idAuth.getRealName());
                    idInfo.setIdCard(idAuth.getIdCard());
                    idInfo.setFrontImg(idAuth.getCardFront());
                    idInfo.setReverseImg(idAuth.getCardBack());
                }
                diffInfo.setIdInfo(idInfo);
                return WrapMapper.ok(diffInfo);
            } else if (4 == type) {
                List<UacBank> uacBanks = uacBankService.getByUserId(loginAuthDto.getUserId());
                List<UacUserDiffInfoVo.bankInfo> banks = new ArrayList<>();
                if (PublicUtil.isNotEmpty(uacBanks)) {
                    uacBanks.forEach(bank -> {
                        UacUserDiffInfoVo.bankInfo bankInfo = new UacUserDiffInfoVo.bankInfo();
                        bankInfo.setId(bank.getId());
                        bankInfo.setBankName(bank.getBankName());
                        bankInfo.setCardNo(bank.getCardNo());
                        bankInfo.setCardVest(bank.getCardVest());
                        banks.add(bankInfo);
                    });
                }
                diffInfo.setBankInfos(banks);
                return WrapMapper.ok(diffInfo);
            }
        } else {
            throw new UacBizException(UacErrorCodeEnum.UAC20000009);
        }
        return null;
    }

    @Override
    public Wrapper editMyselfDiffInfo(LoginAuthDto loginAuthDto, Integer type, UacUserDiffInfoDto dto) {
        UacUser uacUser = uacUserMapper.selectByPrimaryKey(loginAuthDto.getUserId());
        if (PublicUtil.isNotEmpty(uacUser)) {
            UacUserAuth uacUserAuth = authMapper.selectByUserId(loginAuthDto.getUserId());
            if (PublicUtil.isNotEmpty(uacUserAuth)) {
                if (1 == type) {
                    CardAuth licence = new CardAuth();
                    licence.setState((byte) 0);
                    licence.setExpireTime(dto.getLicenceInfo().getLicenceExpireTime());
                    licence.setImg(dto.getLicenceInfo().getLicenseImg());
                    CardAuth driving = new CardAuth();
                    driving.setState((byte) 0);
                    driving.setExpireTime(dto.getLicenceInfo().getDrivingExpireTime());
                    driving.setImg(dto.getLicenceInfo().getDrivingImg());
                    uacUserAuth.setLicenceAuth(JSON.toJSONString(licence));
                    uacUserAuth.setDrivingLicence(JSON.toJSONString(driving));
                } else if (2 == type) {
                    CardAuth job = new CardAuth();
                    job.setState((byte) 0);
                    job.setExpireTime(dto.getJobInfo().getExpireTime());
                    job.setImg(dto.getJobInfo().getJobImg());
                    uacUserAuth.setJobAuth(JSON.toJSONString(job));
                } else if (3 == type) {
                    IdAuth idAuth = new IdAuth();
                    idAuth.setState("1");
                    idAuth.setCardFront(dto.getIdInfo().getFrontImg());
                    idAuth.setCardBack(dto.getIdInfo().getReverseImg());
                    idAuth.setIdCard(dto.getIdInfo().getIdCard());
                    idAuth.setRealName(dto.getIdInfo().getName());
                    uacUserAuth.setIdAuth(JSON.toJSONString(idAuth));
                }
                authMapper.updateByPrimaryKeySelective(uacUserAuth);
            } else {
                // 新增
                UacUserAuth auth = new UacUserAuth();
                auth.setId(generateId());
                auth.setUserId(loginAuthDto.getUserId());
                if (1 == type) {
                    CardAuth licence = new CardAuth();
                    licence.setState((byte) 0);
                    licence.setExpireTime(dto.getLicenceInfo().getLicenceExpireTime());
                    licence.setImg(dto.getLicenceInfo().getLicenseImg());
                    CardAuth driving = new CardAuth();
                    driving.setState((byte) 0);
                    driving.setExpireTime(dto.getLicenceInfo().getDrivingExpireTime());
                    driving.setImg(dto.getLicenceInfo().getDrivingImg());
                    auth.setLicenceAuth(JSON.toJSONString(licence));
                    auth.setDrivingLicence(JSON.toJSONString(driving));
                } else if (2 == type) {
                    CardAuth job = new CardAuth();
                    job.setState((byte) 0);
                    job.setExpireTime(dto.getJobInfo().getExpireTime());
                    job.setImg(dto.getJobInfo().getJobImg());
                    auth.setJobAuth(JSON.toJSONString(job));
                } else if (3 == type) {
                    IdAuth idAuth = new IdAuth();
                    idAuth.setState("1");
                    idAuth.setCardFront(dto.getIdInfo().getFrontImg());
                    idAuth.setCardBack(dto.getIdInfo().getReverseImg());
                    idAuth.setIdCard(dto.getIdInfo().getIdCard());
                    idAuth.setRealName(dto.getIdInfo().getName());
                    auth.setIdAuth(JSON.toJSONString(idAuth));
                }
                authMapper.insertSelective(auth);
            }
        }
        throw new UacBizException(UacErrorCodeEnum.UAC20000009);
    }

    @Override
    public Wrapper<PageInfo<UacSourceLog>> getLog(LoginAuthDto loginAuthDto, BaseQueryDto baseQueryDto) {
        PageHelper.startPage(baseQueryDto.getPageNum(), baseQueryDto.getPageSize());
        Example example = new Example(UacSourceLog.class);
        example.createCriteria().andEqualTo("uId", loginAuthDto.getUserId());
        example.orderBy("createTime").desc();
        List<UacSourceLog> uacSourceLogs = logMapper.selectByExample(example);
        return WrapMapper.ok(new PageInfo<>(uacSourceLogs));
    }

    @Override
    public UacUser getUacUser(Long id) {
        return uacUserMapper.selectByPrimaryKey(id);
    }
}



