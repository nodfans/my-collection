package com.ddcx.model.truck;


import com.ddcx.framework.util.date.DateUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

@ApiModel("年检配置信息")
@Data
public class OverallSubscribeDto implements Serializable {


    @ApiModelProperty("车队主键")
    private Long motorcadeId;

    @ApiModelProperty("年")
    private Integer year;

    @ApiModelProperty("月")
    private Integer month;

    @ApiModelProperty("日")
    private List<Integer> days;

    @ApiModelProperty("预约配置主键<前端无需理会>")
    private Long configId;



    public OverallSubscribeDto(){

    }

    public OverallSubscribeDto(Long motorcadeId, Integer year, Integer month) {
        this.motorcadeId = motorcadeId;
        this.year = year;
        this.month = month;
        this.days = Arrays.asList(new Integer[DateUtil.countDaysOfMonthAndYear(year,month)]);
        for (int i = 0; i < days.size(); i++) {
            days.set(i,0);
        }
    }
}
