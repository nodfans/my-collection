package com.ddcx.app.provider.uac.service.impl;


import com.ddcx.app.provider.uac.mapper.UacSourceMapper;
import com.ddcx.app.provider.uac.service.UacSourceService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/03/27.
 */
@Service
@Transactional
public class UacSourceServiceImpl  implements UacSourceService {
    @Resource
    private UacSourceMapper uacSourceMapper;

}
