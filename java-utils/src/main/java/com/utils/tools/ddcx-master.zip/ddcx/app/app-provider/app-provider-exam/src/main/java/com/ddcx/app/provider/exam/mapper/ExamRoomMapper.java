package com.ddcx.app.provider.exam.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.exam.ExamRoom;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface ExamRoomMapper extends MyMapper<ExamRoom> {
}