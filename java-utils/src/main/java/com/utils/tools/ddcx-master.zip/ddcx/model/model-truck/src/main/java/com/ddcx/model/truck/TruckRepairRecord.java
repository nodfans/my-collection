package com.ddcx.model.truck;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Table(name = "truck_repair_record")
@ApiModel("车辆维修记录表")
public class TruckRepairRecord {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    /**
     * 车辆主键
     */
    @Column(name = "truck_id")
    @ApiModelProperty("车辆主键")
    @NotNull(message = "车辆主键不能为空")
    private Long truckId;

    /**
     * 序号
     */
    @Column(name = "serial_num")
    @ApiModelProperty("序号")
    private String serialNum;

    /**
     * 里程表示值
     */
    @Column(name = "mileage_value")
    @ApiModelProperty("里程表示值")
    private String mileageValue;

    /**
     * 主要修理作业内容及零部件更换情况
     */
    @Column(name = "main_content")
    @ApiModelProperty("主要修理作业内容及零部件更换情况")
    private String mainContent;

    /**
     * 修理单位
     */
    @Column(name = "repair_factory")
    @ApiModelProperty("修理单位")
    private String repairFactory;

    /**
     * 出场合格证编号
     */
    @Column(name = "out_factory_num")
    @ApiModelProperty("出场合格证编号")
    private String outFactoryNum;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    @ApiModelProperty("创建时间")
    private Long createTime;

    /**
     * 创建人
     */
    @Column(name = "create_by")
    @ApiModelProperty("创建人")
    private Long createBy;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取车辆主键
     *
     * @return truck_id - 车辆主键
     */
    public Long getTruckId() {
        return truckId;
    }

    /**
     * 设置车辆主键
     *
     * @param truckId 车辆主键
     */
    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    /**
     * 获取序号
     *
     * @return serial_num - 序号
     */
    public String getSerialNum() {
        return serialNum;
    }

    /**
     * 设置序号
     *
     * @param serialNum 序号
     */
    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }

    /**
     * 获取里程表示值
     *
     * @return mileage_value - 里程表示值
     */
    public String getMileageValue() {
        return mileageValue;
    }

    /**
     * 设置里程表示值
     *
     * @param mileageValue 里程表示值
     */
    public void setMileageValue(String mileageValue) {
        this.mileageValue = mileageValue;
    }

    /**
     * 获取主要修理作业内容及零部件更换情况
     *
     * @return main_content - 主要修理作业内容及零部件更换情况
     */
    public String getMainContent() {
        return mainContent;
    }

    /**
     * 设置主要修理作业内容及零部件更换情况
     *
     * @param mainContent 主要修理作业内容及零部件更换情况
     */
    public void setMainContent(String mainContent) {
        this.mainContent = mainContent;
    }

    /**
     * 获取修理单位
     *
     * @return repair_factory - 修理单位
     */
    public String getRepairFactory() {
        return repairFactory;
    }

    /**
     * 设置修理单位
     *
     * @param repairFactory 修理单位
     */
    public void setRepairFactory(String repairFactory) {
        this.repairFactory = repairFactory;
    }

    /**
     * 获取出场合格证编号
     *
     * @return out_factory_num - 出场合格证编号
     */
    public String getOutFactoryNum() {
        return outFactoryNum;
    }

    /**
     * 设置出场合格证编号
     *
     * @param outFactoryNum 出场合格证编号
     */
    public void setOutFactoryNum(String outFactoryNum) {
        this.outFactoryNum = outFactoryNum;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取创建人
     *
     * @return create_by - 创建人
     */
    public Long getCreateBy() {
        return createBy;
    }

    /**
     * 设置创建人
     *
     * @param createBy 创建人
     */
    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }
}