package com.ddcx.framework.util;

import java.util.ArrayList;
import java.util.List;

public class LoanIssueUtil {
    private static List<String> issueMsgs;
    private static   String[] nums={"","一","二","三","四","五","六","七","八","九"};

    static {
        issueMsgs=new ArrayList<>(100);
        issueMsgs.add("");
        issueMsgs.add("首期");
        for (int i =2; i < 100; i++) {
            issueMsgs.add(parseInteger(i)+"期");
        }
    }

    private static   String parseInteger(int i){
        if(i>=10){
            return (nums[i/10].equals("一")?"":nums[i/10])+"十"+nums[i%10];
        }else {
            return nums[i];
        }
    }

    public static String getChinaIssueMsg(int issue){
        return issueMsgs.get(issue);
    }

    public static void main(String[] args) {
    }

}
