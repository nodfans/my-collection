package com.ddcx.app.provider.api.truck.model.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@ApiModel("预约参数")
public class SubscribeParam {

    @ApiModelProperty("年")
    @NotNull
    private Integer year;
    @NotNull
    @ApiModelProperty("月")
    private Integer month;
    @NotNull
    @ApiModelProperty("日")
    private Integer day;

    @ApiModelProperty("经度<暂不使用>")
    private Double lng;

    @ApiModelProperty("纬度<暂不使用>")
    private Double lat;




}
