package com.ddcx.common.provider.job;


import com.ddcx.common.provider.api.zhiyun.TruckLocation;
import com.ddcx.common.provider.service.ZhiYunService;
import com.ddcx.web.provider.api.truck.model.service.AdminTruckFeignClientApi;
import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Component
@Log4j2
@EnableScheduling
public class TruckLocationJob {

    @Resource
    private ZhiYunService zhiYunService;
    @Resource
    private AdminTruckFeignClientApi truckFeignClientApi;


//    @Scheduled(cron = "0 0 0/1 * * ? ")
    public void  truckLocationJob(){
        //获取所有车牌号
        List<String> truckNums=truckFeignClientApi.getAllTruckNum();
        //查出所有最新定位并更新
        List<TruckLocation> locations=new ArrayList<>(truckNums.size());
        TruckLocation truckLocation;
        for (String truckNum : truckNums) {
            try {
                truckLocation=zhiYunService.vLastLocationV3(truckNum);
            } catch (Exception e) {
                e.printStackTrace();
                truckLocation=new TruckLocation();
            }
            truckLocation.setTruckNum(truckNum);
            locations.add(truckLocation);
        }
        truckFeignClientApi.loadTruckLocation(locations);
        log.info("车辆位置信息已更新");
    }


}
