package com.ddcx.app.provider.truck.service;

import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.TruckSafeInform;

/**
 * Created by CodeGenerator on 2020/04/17.
 */
public interface TruckSafeInformService {

    Wrapper getById(Long id);

    Wrapper submitTruckSafeInfo(TruckSafeInform safeInform);


    Wrapper getByTruckId(Long truckId);
}
