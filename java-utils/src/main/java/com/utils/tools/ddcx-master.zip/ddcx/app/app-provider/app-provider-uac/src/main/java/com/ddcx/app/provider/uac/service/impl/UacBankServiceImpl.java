package com.ddcx.app.provider.uac.service.impl;

import com.ddcx.app.provider.api.uac.enums.UacErrorCodeEnum;
import com.ddcx.app.provider.api.uac.exception.UacBizException;
import com.ddcx.app.provider.api.uac.model.dto.UacCreateBankDto;
import com.ddcx.app.provider.api.uac.model.vo.UacBankListVo;
import com.ddcx.app.provider.uac.mapper.UacBankMapper;
import com.ddcx.app.provider.uac.service.UacBankService;
import com.ddcx.common.provider.api.model.vo.CommonBankBinVo;
import com.ddcx.common.provider.api.service.CommonServiceFeignApi;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.model.uac.UacBank;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UacBankServiceImpl extends BaseService<UacBank> implements UacBankService {

    @Resource
    private CommonServiceFeignApi commonServiceFeignApi;

    @Resource
    private UacBankMapper bankMapper;


    private static Map<String, Map<String,String>> mapMap;


    static {
        mapMap=new HashMap<String, Map<String, String>>(){{
            //中央银行
            put("0104",new HashMap<String,String>(){
                {
                    put("icon","http://112.74.217.123/dd/bank_img/1_1.png");
                    put("background","http://112.74.217.123/dd/bank_img/1_2.png");
                }
            });
            //交通银行
            put("0301",new HashMap<String,String>(){
                {
                    put("icon","http://112.74.217.123/dd/bank_img/2_1.png");
                    put("background","http://112.74.217.123/dd/bank_img/2_2.png");
                }
            });
            //其他银行
            put("0000",new HashMap<String,String>(){
                {
                    put("icon","http://112.74.217.123/dd/bank_img/3_1.png");
                    put("background","http://112.74.217.123/dd/bank_img/3_2.png");
                }
            });
            //农业银行
            put("0103",new HashMap<String,String>(){
                {
                    put("icon","http://112.74.217.123/dd/bank_img/4_1.png");
                    put("background","http://112.74.217.123/dd/bank_img/4_2.png");
                }
            });
            //工商银行
            put("0102",new HashMap<String,String>(){
                {
                    put("icon","http://112.74.217.123/dd/bank_img/5_1.png");
                    put("background","http://112.74.217.123/dd/bank_img/5_2.png");
                }
            });
            //建设银行
            put("0105",new HashMap<String,String>(){
                {
                    put("icon","http://112.74.217.123/dd/bank_img/6_1.png");
                    put("background","http://112.74.217.123/dd/bank_img/6_2.png");
                }
            });
            //招商银行
            put("0308",new HashMap<String,String>(){
                {
                    put("icon","http://112.74.217.123/dd/bank_img/7_1.png");
                    put("background","http://112.74.217.123/dd/bank_img/7_2.png");
                }
            });

        }};
    }

    @Override
    public Boolean create(LoginAuthDto loginAuthDto, UacCreateBankDto uacCreateBankDto) {
        String cardNo = uacCreateBankDto.getCardNo().trim();
        if (PublicUtil.isNotEmpty(getByCardNo(cardNo))) {
            throw new UacBizException(UacErrorCodeEnum.UAC20000007);
        }
        CommonBankBinVo commonBankBinVo = commonServiceFeignApi.getBankBin(cardNo);
        if (PublicUtil.isEmpty(commonBankBinVo)) {
            throw new UacBizException(UacErrorCodeEnum.UAC20000006);
        }
        UacBank createUacBank = new ModelMapper().map(uacCreateBankDto, UacBank.class);
        createUacBank.setCardNo(cardNo);
        createUacBank.setBankCode(commonBankBinVo.getBankCode());
        createUacBank.setBankName(commonBankBinVo.getBankName());
        createUacBank.setCardType(commonBankBinVo.getCardType());
        createUacBank.setUserId(loginAuthDto.getUserId());
        createUacBank.setCreateTime(currentTime());
        int i;
        if(createUacBank.getId()!=null){
            i=bankMapper.updateByPrimaryKeySelective(createUacBank);
        }else {
            createUacBank.setId(generateId());
            i=insert(createUacBank);
        }
        if (i > 0) {
            return true;
        }
        return false;
    }

    @Override
    public Boolean delete(LoginAuthDto loginAuthDto, Long id) {
        UacBank uacBank = selectByKey(id);
        if (PublicUtil.isNotEmpty(uacBank)) {
            if (uacBank.getUserId().longValue() == loginAuthDto.getUserId().longValue()) {
                if (deleteByKey(uacBank.getId()) > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public List<UacBank> getByUserId(Long UserId) {
        List<UacBank> uacBank=bankMapper.selectBanksByUserId(UserId);
        for (UacBank s : uacBank) {
            saveIconAndBackground(s);
        }
        return uacBank;
    }

    private void saveIconAndBackground(UacBankListVo uacBankListVo){
        String key=uacBankListVo.getBankCode().substring(0,4);
        Map<String,String> map=mapMap.get(key);
        if(map==null){
            map=mapMap.get("0000");
        }
        if(map!=null){
            uacBankListVo.setIcon(map.get("icon"));
            uacBankListVo.setBackground(map.get("background"));
        }
    }

    private void saveIconAndBackground(UacBank uacBankListVo){
        String key=uacBankListVo.getBankCode().substring(0,4);
        Map<String,String> map=mapMap.get(key);
        if(map==null){
            map=mapMap.get("0000");
        }
        if(map!=null){
            uacBankListVo.setIcon(map.get("icon"));
            uacBankListVo.setBackground(map.get("background"));
        }
    }

    @Override
    public List<UacBankListVo> list(LoginAuthDto loginAuthDto) {
        List<UacBankListVo> uacBankListVos = new ArrayList<>();
//        Example example = new Example(UacBank.class);
//        example.setOrderByClause("create_time desc");
//        Example.Criteria criteria = example.createCriteria();
//        criteria.andEqualTo("userId", loginAuthDto.getUserId());
        List<UacBank> uacBanks = bankMapper.selectBanksByUserId(loginAuthDto.getUserId());
        if (PublicUtil.isNotEmpty(uacBanks)) {
            for (UacBank uacBank : uacBanks) {
                UacBankListVo uacBankListVo = new ModelMapper().map(uacBank, UacBankListVo.class);
                saveIconAndBackground(uacBankListVo);
                uacBankListVos.add(uacBankListVo);
            }
        }
        return uacBankListVos;
    }

    @Override
    public UacBank getByCardNo(String cardNo) {
        Example example = new Example(UacBank.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("cardNo", cardNo);
        return mapper.selectOneByExample(example);
    }
}
