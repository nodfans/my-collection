package com.ddcx.framework.base.dto;

import lombok.Data;

@Data
public class ActionTokenDto implements java.io.Serializable {
    private static final long serialVersionUID = 556156111668350918L;

    /**
     * 账号
     */
    private String account;
    /**
     * token
     */
    private String token;

    /**
     * 过期时间
     */
    private Long expireTime;
}
