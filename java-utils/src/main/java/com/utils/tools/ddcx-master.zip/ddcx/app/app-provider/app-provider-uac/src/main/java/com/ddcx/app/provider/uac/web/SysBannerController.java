package com.ddcx.app.provider.uac.web;


import com.ddcx.app.provider.uac.service.SysBannerService;
import com.ddcx.framework.core.annotation.NoNeedAccessAuthentication;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.SysBanner;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
* Created by CodeGenerator on 2020/03/16.
*/
@RestController
@RequestMapping("/sys/banner")
@Api(value = "banner模块" , tags = "banner模块")
public class SysBannerController extends BaseController {
    @Resource
    private SysBannerService sysBannerService;


    @NoNeedAccessAuthentication
    @ApiOperation("列表获取")
    @GetMapping("/listOfPage")
    public Wrapper<PageInfo<SysBanner>> listOfPage(@ApiParam("参数") SysBanner sysBanner,
                                            @ApiParam(value = "页数", defaultValue = "1") @RequestParam(defaultValue = "1") Integer page,
                                            @ApiParam(value = "每页记录数", defaultValue = "10") @RequestParam(defaultValue = "10") Integer size){
        return sysBannerService.listOfPage(sysBanner,page,size);
    }

    @NoNeedAccessAuthentication
    @ApiOperation("详情")
    @GetMapping("/detail")
    public Wrapper<SysBanner> detail(@ApiParam("主键") @RequestParam  Long id){
        return sysBannerService.detail(id);
    }

}
