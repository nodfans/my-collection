package com.ddcx.app.provider.truck.service;

import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.TruckCheck;

/**
 * Created by CodeGenerator on 2020/04/17.
 */
public interface TruckCheckService {

    Wrapper addTruckCheck(TruckCheck check, LoginAuthDto dto);

}
