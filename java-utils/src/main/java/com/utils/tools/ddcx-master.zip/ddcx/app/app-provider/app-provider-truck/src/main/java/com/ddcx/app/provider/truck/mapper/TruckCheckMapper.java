package com.ddcx.app.provider.truck.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.truck.TruckCheck;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;


@Component
@Mapper
public interface TruckCheckMapper extends MyMapper<TruckCheck> {
}