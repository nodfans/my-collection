package com.ddcx.app.provider.uac.web;

import com.ddcx.app.provider.api.uac.model.dto.UacCreateBankDto;
import com.ddcx.app.provider.api.uac.model.vo.UacBankListVo;
import com.ddcx.app.provider.uac.service.UacBankService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.base.enums.LogTypeEnum;
import com.ddcx.framework.core.annotation.RequestLog;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/bank")
@Api(value = "银行卡", tags = {"银行卡"})
public class UacBankController extends BaseController {

    @Autowired
    private UacBankService uacBankService;

    @ApiOperation(value = "新增", notes = "新增")
    @PostMapping(value = "/create")
    @RequestLog(logType = LogTypeEnum.REQUEST_LOG, isSaveRequestData = true, isSaveResponseData = true)
    public Wrapper create(@RequestBody @Validated UacCreateBankDto uacCreateBankDto) {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        Boolean flag = uacBankService.create(loginAuthDto, uacCreateBankDto);
        if (flag) {
            return WrapMapper.ok("操作成功");
        }
        return WrapMapper.error("操作失败");
    }

    @ApiOperation(value = "删除", notes = "删除")
    @DeleteMapping(value = "/delete/{id}")
    @RequestLog(logType = LogTypeEnum.REQUEST_LOG, isSaveRequestData = true, isSaveResponseData = true)
    public Wrapper delete(@PathVariable(value = "id") Long id) {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        Boolean flag = uacBankService.delete(loginAuthDto, id);
        if (flag) {
            return WrapMapper.ok("操作成功");
        }
        return WrapMapper.error("操作失败");
    }

    @ApiOperation(value = "列表", notes = "列表")
    @GetMapping(value = "/list")
    @RequestLog(logType = LogTypeEnum.REQUEST_LOG, isSaveRequestData = true, isSaveResponseData = true)
    public Wrapper<List<UacBankListVo>> list() {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        final List<UacBankListVo> uacBankListVos = uacBankService.list(loginAuthDto);
        return WrapMapper.ok(uacBankListVos);
    }
}
