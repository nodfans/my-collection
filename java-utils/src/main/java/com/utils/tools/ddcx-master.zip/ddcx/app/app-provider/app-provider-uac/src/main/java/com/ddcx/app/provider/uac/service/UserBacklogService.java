package com.ddcx.app.provider.uac.service;

import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;

/**
 * Created by CodeGenerator on 2020/04/17.
 */
public interface UserBacklogService {

    Wrapper getUserBackLog(Integer page, Integer size,Integer type, LoginAuthDto dto);
}
