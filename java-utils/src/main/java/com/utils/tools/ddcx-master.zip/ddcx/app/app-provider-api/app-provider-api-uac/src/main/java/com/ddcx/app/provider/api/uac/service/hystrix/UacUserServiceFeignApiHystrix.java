package com.ddcx.app.provider.api.uac.service.hystrix;

import com.ddcx.app.provider.api.uac.model.dto.UacCheckAccountDto;
import com.ddcx.app.provider.api.uac.model.vo.UacUserVo;
import com.ddcx.app.provider.api.uac.service.UacUserServiceFeignApi;
import com.ddcx.model.uac.IdAuth;
import com.ddcx.model.uac.UacUser;
import com.ddcx.model.uac.UserBacklog;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UacUserServiceFeignApiHystrix implements UacUserServiceFeignApi {
    @Override
    public UacUserVo getUserByPhone(UacCheckAccountDto uacCheckAccountDto) {
        return null;
    }

    @Override
    public UacUserVo getUserById(Long id) {
        return null;
    }

    @Override
    public IdAuth getAuthInfo(Long userId) {
        return null;
    }

    @Override
    public Integer addUserBackLog(UserBacklog backlog) {
        return null;
    }

    @Override
    public Integer addAllUserBackLog(List<UserBacklog> backlogs) {
        return null;
    }

    @Override
    public UacUser getUser(Long id) {
        return null;
    }
}
