package com.ddcx.app.provider.truck.job;

import com.ddcx.app.provider.api.uac.service.UacUserServiceFeignApi;
import com.ddcx.app.provider.truck.mapper.TruckMapper;
import com.ddcx.common.provider.api.service.CommonServiceFeignApi;
import com.ddcx.model.common.RelatedReminders;
import com.ddcx.model.uac.UserBacklog;
import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * 年检、续保、保养 待办生成
 */
@Component
@Log4j2
@EnableScheduling
public class SubscribeJob {

    @Resource
    private CommonServiceFeignApi commonServiceFeignApi;
    @Resource
    private TruckMapper truckMapper;
    @Resource
    private UacUserServiceFeignApi uacUserServiceFeignApi;

    @Scheduled(cron = "0 1 2 * * ?")
    public void addBacklog(){
        LocalDate localDate=LocalDate.now();
        //发送获取配置
        RelatedReminders relatedReminders=commonServiceFeignApi.selectRelatedReminders();
    //计算到期时间
        //年检到期时间
        Long annualInspectionLimitTime=localDate.plusDays(relatedReminders.getAnnualInspectionDays()).toEpochDay()*3600*24;
        //续保到期时间
        Long renewalInsuranceLimitTime=localDate.plusDays(relatedReminders.getRenewalDays()).toEpochDay()*3600*24;
        //保养到期时间
        Long upkeepLimitTime=localDate.plusDays(relatedReminders.getMaintenanceDays()).toEpochDay()*3600*24;
    //查询出所有到期时间
        //查询出年检到期司机列表
        List<Long> anUserIds=truckMapper.listByAnLimitDate(annualInspectionLimitTime);
        //查询出续保到期司机列表
        List<Long> reUserIds=truckMapper.listByReLimitDate(renewalInsuranceLimitTime);
        //查询出保养到期司机列表
        List<Long> upUserIds=truckMapper.listByUpLimitDate(upkeepLimitTime);
    //添加所有待办事宜
        //总待办
        List<UserBacklog> allUserBacklog=new ArrayList<>(anUserIds.size()+reUserIds.size()+upUserIds.size());
        //添加年检待办
        List<UserBacklog> anBacklogs=new ArrayList<>(anUserIds.size());
        UserBacklog backlog;
        for (Long anUserId : anUserIds) {
            backlog=new UserBacklog();
            backlog.setState((byte) 0);
            backlog.setTitle("年检办理");
            backlog.setType((byte) 3);
            backlog.setObjId(null);
            backlog.setOverdueState((byte) 1);
            backlog.setDetails("您的年检将于"+LocalDate.ofEpochDay(annualInspectionLimitTime/3600/24).format(DateTimeFormatter.ofPattern("yyyy年MM月dd号"))+"到期，请尽快办理。");
            backlog.setLimitDate(annualInspectionLimitTime);
            backlog.setInitiateDate(System.currentTimeMillis()/1000);
            backlog.setDriverId(anUserId);
            anBacklogs.add(backlog);
        }
        //添加续保待办
        List<UserBacklog> reBacklogs=new ArrayList<>(reUserIds.size());
        for (Long reUserId : reUserIds) {
            backlog=new UserBacklog();
            backlog.setState((byte) 0);
            backlog.setTitle("续保办理");
            backlog.setType((byte) 2);
            backlog.setObjId(null);
            backlog.setOverdueState((byte) 1);
            backlog.setDetails("您的保险将于"+LocalDate.ofEpochDay(renewalInsuranceLimitTime/3600/24).format(DateTimeFormatter.ofPattern("yyyy年MM月dd号"))+"到期，请尽快办理。");
            backlog.setLimitDate(renewalInsuranceLimitTime);
            backlog.setInitiateDate(System.currentTimeMillis()/1000);
            backlog.setDriverId(reUserId);
            reBacklogs.add(backlog);
        }
        //添加保养待办
        List<UserBacklog> upBacklogs=new ArrayList<>(upUserIds.size());
        for (Long upUserId : upUserIds) {
            backlog=new UserBacklog();
            backlog.setState((byte) 0);
            backlog.setTitle("保养办理");
            backlog.setType((byte) 4);
            backlog.setObjId(null);
            backlog.setOverdueState((byte) 1);
            backlog.setDetails("您的保养将于"+LocalDate.ofEpochDay(upkeepLimitTime/3600/24).format(DateTimeFormatter.ofPattern("yyyy年MM月dd号"))+"到期，请尽快办理。");
            backlog.setLimitDate(upkeepLimitTime);
            backlog.setInitiateDate(System.currentTimeMillis()/1000);
            backlog.setDriverId(upUserId);
            upBacklogs.add(backlog);
        }
        allUserBacklog.addAll(allUserBacklog);
        allUserBacklog.addAll(reBacklogs);
        allUserBacklog.addAll(upBacklogs);
        if(allUserBacklog.size()>0){
            uacUserServiceFeignApi.addAllUserBackLog(allUserBacklog);
        }
        log.info("待办生成完成");
    }

}
