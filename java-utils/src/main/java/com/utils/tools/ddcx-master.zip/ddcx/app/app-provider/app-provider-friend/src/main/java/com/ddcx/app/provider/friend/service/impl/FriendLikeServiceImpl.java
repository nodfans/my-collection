package com.ddcx.app.provider.friend.service.impl;


import com.ddcx.app.provider.friend.mapper.FriendCircleMapper;
import com.ddcx.app.provider.friend.mapper.FriendLikeMapper;
import com.ddcx.app.provider.friend.service.FriendLikeService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.friend.FriendCircle;
import com.ddcx.model.friend.FriendLike;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/03/02.
 */
@Service
@Transactional
public class FriendLikeServiceImpl implements FriendLikeService {
    @Resource
    private FriendLikeMapper friendLikeMapper;
    @Resource
    private FriendCircleMapper friendCircleMapper;

    @Override
    public Wrapper putLike(Long id, LoginAuthDto dto) {
        FriendLike like = new FriendLike();
        like.setId(id);
        like.setUserId(dto.getUserId());
        if(friendLikeMapper.selectCount(like)>0){
            return WrapMapper.ok("点赞成功");
        }
        like.setNickName(dto.getUserName());
        friendLikeMapper.insert(like);
        initLikes(id);
        return WrapMapper.ok("点赞成功");
    }

    @Override
    public Wrapper clearLike(Long id, LoginAuthDto dto) {
        friendLikeMapper.clearLike(id,dto.getUserId());
        initLikes(id);
        return WrapMapper.ok();
    }

    private void initLikes(Long circleId){
        FriendCircle friendCircle=new FriendCircle();
        friendCircle.setId(circleId);
        friendCircle.setLikeCount(friendLikeMapper.selectCountByCircleId(circleId));
        friendCircleMapper.updateByPrimaryKeySelective(friendCircle);
    }
}
