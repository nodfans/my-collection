package com.ddcx.common.provider.service;

import com.ddcx.framework.core.service.IService;
import com.ddcx.model.common.CommonBankBin;

public interface CommonBankBinService extends IService<CommonBankBin> {

    CommonBankBin getBankBin(String cardNo);
}
