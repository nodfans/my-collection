package com.ddcx.app.provider.uac.service;


/**
 * Created by CodeGenerator on 2020/03/27.
 */
public interface UacSourceService {

}
