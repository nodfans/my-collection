package com.ddcx.model.uac;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Table(name = "admin_user")
@ApiModel("后台账户")
public class AdminUser implements Serializable {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 用户名
     */
    @NotBlank(message = "账户名不能为空")
    @Column(name = "user_name")
    @ApiModelProperty(value = "用户名", required = true)
    private String userName;

    /**
     * 密码
     */
    @NotBlank(message = "密码不能为空")
    @ApiModelProperty(value = "密码", required = true)
    private String password;

    /**
     * 盐值
     */
    @Column(name = "password_sale")
    @ApiModelProperty("盐值")
    private String passwordSale;

    /**
     * 手机号
     */
    @NotBlank(message = "手机号不能为空")
    @ApiModelProperty(value = "手机号", required = true)
    private String phone;

    /**
     * 状态 1.正常 2.锁定
     */
    @ApiModelProperty("状态 1.正常 2.锁定")
    private Byte state;

    /**
     * 登录次数
     */
    @ApiModelProperty("最后一次登录时间")
    @Column(name = "login_count")
    private Integer loginCount;

    /**
     * 创建时间
     */
    @ApiModelProperty("最后一次登录时间")
    @Column(name = "create_time")
    private Long createTime;

    /**
     * 最后一次登录时间
     */
    @Column(name = "last_login_time")
    @ApiModelProperty("最后一次登录时间")
    private Long lastLoginTime;


    /**
     * 账号级别（一级：大道出行公司，二级：运输公司，三级：车队）
     */
    @NotNull
    @Max(value = 3)
    @Min(value = 1)
    @Column(name = "user_level")
    @ApiModelProperty(value = "账号级别（一级：大道出行公司，二级：运输公司，三级：车队）", required = true)
    private Byte userLevel;


    @Column(name = "create_by")
    @ApiModelProperty(value = "创建人id")
    private Long createBy;

    @Column(name = "auxiliary")
    @ApiModelProperty(value = "附属账户：1.为附属账户 0.主账号")
    private Byte auxiliary;


    @Transient
    @ApiModelProperty("角色名")
    private String roleName;

    @Transient
    @ApiModelProperty("角色Id")
    private Long roleId;

    @ApiModelProperty("账号姓名")
    private String realName;

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取用户名
     *
     * @return user_name - 用户名
     */
    public String getUserName() {
        return userName;
    }

    /**
     * 设置用户名
     *
     * @param userName 用户名
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * 获取密码
     *
     * @return password - 密码
     */
    public String getPassword() {
        return password;
    }

    /**
     * 设置密码
     *
     * @param password 密码
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * 获取盐值
     *
     * @return password_sale - 盐值
     */
    public String getPasswordSale() {
        return passwordSale;
    }

    /**
     * 设置盐值
     *
     * @param passwordSale 盐值
     */
    public void setPasswordSale(String passwordSale) {
        this.passwordSale = passwordSale;
    }

    /**
     * 获取手机号
     *
     * @return phone - 手机号
     */
    public String getPhone() {
        return phone;
    }

    /**
     * 设置手机号
     *
     * @param phone 手机号
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * 获取状态 1.正常 2.锁定
     *
     * @return state - 状态 1.正常 2.锁定
     */
    public Byte getState() {
        return state;
    }

    /**
     * 设置状态 1.正常 2.锁定
     *
     * @param state 状态 1.正常 2.锁定
     */
    public void setState(Byte state) {
        this.state = state;
    }

    /**
     * 获取登录次数
     *
     * @return login_count - 登录次数
     */
    public Integer getLoginCount() {
        return loginCount;
    }

    /**
     * 设置登录次数
     *
     * @param loginCount 登录次数
     */
    public void setLoginCount(Integer loginCount) {
        this.loginCount = loginCount;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取最后一次登录时间
     *
     * @return last_login_time - 最后一次登录时间
     */
    public Long getLastLoginTime() {
        return lastLoginTime;
    }

    /**
     * 设置最后一次登录时间
     *
     * @param lastLoginTime 最后一次登录时间
     */
    public void setLastLoginTime(Long lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }


    public Byte getUserLevel() {
        return userLevel;
    }

    public void setUserLevel(Byte userLevel) {
        this.userLevel = userLevel;
    }


    public Byte getAuxiliary() {
        return auxiliary;
    }

    public void setAuxiliary(Byte auxiliary) {
        this.auxiliary = auxiliary;
    }
}