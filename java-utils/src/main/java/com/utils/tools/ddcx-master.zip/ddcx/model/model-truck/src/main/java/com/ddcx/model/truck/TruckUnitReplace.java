package com.ddcx.model.truck;

import com.ddcx.framework.base.annotation.ExcelName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Table(name = "truck_unit_replace")
@ApiModel("车辆主要部件更换表")
public class TruckUnitReplace {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    @ApiModelProperty("序号")
    @Column(name = "serial_num")
    @ExcelName("序号")
    private String serialNum;

    /**
     * 车辆主键
     */
    @Column(name = "truck_id")
    @ApiModelProperty("车辆主键")
    private Long truckId;

    /**
     * 维修日期
     */
    @Column(name = "maintain_date")
    @ApiModelProperty("维修日期")
    @ExcelName("维修日期")
    private Long maintainDate;

    /**
     * 里程表示值
     */
    @ApiModelProperty("里程表示值")
    @ExcelName("里程表示值")
    private String mileage;

    /**
     * 主要部件更换部件名称，型号（规格），长名及编号
     */
    @ApiModelProperty("主要部件更换部件名称，型号（规格），长名及编号")
    @Column(name = "main_unit")
    @ExcelName("主要部件更换部件名称，型号（规格），长名及编号")
    private String mainUnit;

    /**
     * 维护单位
     */
    @ApiModelProperty("维护单位")
    @Column(name = "maintain_unit")
    @ExcelName("维护单位")
    private String maintainUnit;

    /**
     * 备注
     */
    @ApiModelProperty("备注")
    @ExcelName("备注")
    private String remark;




    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取车辆主键
     *
     * @return truck_id - 车辆主键
     */
    public Long getTruckId() {
        return truckId;
    }

    /**
     * 设置车辆主键
     *
     * @param truckId 车辆主键
     */
    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    /**
     * 获取维修日期
     *
     * @return maintain_date - 维修日期
     */
    public Long getMaintainDate() {
        return maintainDate;
    }

    /**
     * 设置维修日期
     *
     * @param maintainDate 维修日期
     */
    public void setMaintainDate(Long maintainDate) {
        this.maintainDate = maintainDate;
    }

    /**
     * 获取里程表示值
     *
     * @return mileage - 里程表示值
     */
    public String getMileage() {
        return mileage;
    }

    /**
     * 设置里程表示值
     *
     * @param mileage 里程表示值
     */
    public void setMileage(String mileage) {
        this.mileage = mileage;
    }

    /**
     * 获取主要部件更换部件名称，型号（规格），长名及编号
     *
     * @return main_unit - 主要部件更换部件名称，型号（规格），长名及编号
     */
    public String getMainUnit() {
        return mainUnit;
    }

    /**
     * 设置主要部件更换部件名称，型号（规格），长名及编号
     *
     * @param mainUnit 主要部件更换部件名称，型号（规格），长名及编号
     */
    public void setMainUnit(String mainUnit) {
        this.mainUnit = mainUnit;
    }

    /**
     * 获取维护单位
     *
     * @return maintain_unit - 维护单位
     */
    public String getMaintainUnit() {
        return maintainUnit;
    }

    /**
     * 设置维护单位
     *
     * @param maintainUnit 维护单位
     */
    public void setMaintainUnit(String maintainUnit) {
        this.maintainUnit = maintainUnit;
    }

    /**
     * 获取备注
     *
     * @return remark - 备注
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 设置备注
     *
     * @param remark 备注
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }
}