package com.ddcx.app.provider.uac.web;


import com.ddcx.app.provider.uac.service.UserBacklogService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.UserBacklog;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/04/17.
*/
@RestController
@RequestMapping("/user/backlog")
@Api(value = "待办事宜",tags = "待办事宜")
public class UserBacklogController extends BaseController {
    @Resource
    private UserBacklogService userBacklogService;


    @ApiOperation("查询用户待办事宜")
    @GetMapping("/getUserBackLog")
    public Wrapper<PageInfo<UserBacklog>> getUserBackLog(@ApiParam(value = "类型 1.未超期 2.已超期", defaultValue = "1") @RequestParam(defaultValue = "1") Integer type,
                                                         @ApiParam(value = "页数", defaultValue = "1") @RequestParam(defaultValue = "1") Integer page,
                                                         @ApiParam(value = "每页记录数", defaultValue = "10") @RequestParam(defaultValue = "10") Integer size){
        return userBacklogService.getUserBackLog(page,size,type,getLoginAuthDto());
    }

}
