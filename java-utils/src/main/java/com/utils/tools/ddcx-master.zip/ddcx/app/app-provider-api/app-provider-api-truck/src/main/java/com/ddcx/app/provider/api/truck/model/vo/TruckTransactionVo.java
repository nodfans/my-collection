package com.ddcx.app.provider.api.truck.model.vo;

import com.ddcx.model.truck.TruckTransaction;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
@ApiModel(value = "汽车（交易）显示类")
public class TruckTransactionVo {

    @ApiModelProperty(value = "用户名")
    private String userName;
    @ApiModelProperty(value = "用户手机号码")
    private String phone;
    @ApiModelProperty(value = "主要属性")
    private TruckTransaction truckTransaction;

    public TruckTransactionVo() {
    }

    public TruckTransactionVo(String userName, String phone, TruckTransaction truckTransaction) {
        this.userName = userName;
        this.phone = phone;
        this.truckTransaction = truckTransaction;
    }
}
