package com.ddcx.common.provider.api.service.hystrix;

import com.alibaba.fastjson.JSONObject;
import com.ddcx.common.provider.api.model.dto.MessageDto;
import com.ddcx.common.provider.api.model.vo.CommonBankBinVo;
import com.ddcx.common.provider.api.service.CommonServiceFeignApi;
import com.ddcx.common.provider.api.zhiyun.ZhiYunDrivingLicence;
import com.ddcx.common.provider.api.zhiyun.ZhiYunIdAuth;
import com.ddcx.model.common.BsArea;
import com.ddcx.model.common.CnRegionInfo;
import com.ddcx.model.common.RelatedReminders;
import org.springframework.stereotype.Component;

@Component
public class CommonServiceFeignApiHystrix implements CommonServiceFeignApi {
    @Override
    public String upload(byte[] imgData) {
        return null;
    }

    @Override
    public String deleteFile(String filePath) {
        return null;
    }

    @Override
    public String deleteAdminFile(String filePath) {
        return null;
    }

    @Override
    public CommonBankBinVo getBankBin(String cardBin) {
        return null;
    }

    @Override
    public JSONObject getSysConfigByKey(String key) {
        return null;
    }

    @Override
    public int addMessage(MessageDto dto) {
        return 0;
    }

    @Override
    public int addAdminMessage(MessageDto dto) {
        return 0;
    }

    @Override
    public int addMessageOfAllByUserIds(String map) {
        return 0;
    }

    @Override
    public int addMessageOfAll(MessageDto dto) {
        return 0;
    }

    @Override
    public CnRegionInfo getRegionMsgByCode(String code) {
        return null;
    }

//    @Override
//    public BsStreet getBsStreetByCode(String code) {
//        return null;
//    }

    @Override
    public BsArea getBsAreaByCode(String code) {
        return null;
    }

    @Override
    public RelatedReminders selectRelatedReminders() {
        return null;
    }

    @Override
    public Integer getHelpMessageTotal() {
        return null;
    }

    @Override
    public int deleteRescueMessage(Long rescueId) {
        return 0;
    }

    @Override
    public ZhiYunIdAuth idCardLicense(String frontPath, String reversePath) {
        return null;
    }

    @Override
    public ZhiYunDrivingLicence drivingLicense(String drivingPath) {
        return null;
    }


}
