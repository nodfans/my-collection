package com.ddcx.app.provider.exam.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.exam.UacLearnRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface UacLearnRecordMapper extends MyMapper<UacLearnRecord> {


    @Select("select * from uac_learn_record where l_i_id=#{id} and user_id=#{uId}")
    UacLearnRecord selectByOwn(@Param("id")Long id, @Param("uId")Long uId);

    int updateDuration(UacLearnRecord record);
}