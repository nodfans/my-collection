package com.ddcx.common.provider.controller;

import com.ddcx.common.provider.api.enums.UploadFolderEnum;
import com.ddcx.common.provider.api.model.Result;
import com.ddcx.common.provider.api.util.CommonUtil;
import com.ddcx.common.provider.api.util.ResultGenerator;
import com.ddcx.common.provider.mapper.TotalImgPathMapper;
import com.ddcx.common.provider.util.ViewUtils;
import com.ddcx.framework.util.StringUtils;
import com.ddcx.model.common.TotalImgPath;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.log4j.Log4j2;
import org.apache.http.entity.ContentType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/ddcx/img")
@Log4j2
@Api(value = "文件上传", tags = "文件上传")
public class PicUploadController {

    private UploadFolderEnum image = UploadFolderEnum.IMAGE;

    @Value("${ddcx.file.uploadPath}")
    private String basePath = "/";
    @Value("${ddcx.file.uploadViewPath}")
    private String baseViewPath = "/";
    @Value("${ddcx.file.httpip}")
    private String httpIp = "/";
    @Value("${ddcx.file.httpipView}")
    private String httpIpView = "/";

    @Value("${ddcx.file.fileType}")
    private String fileType = "/";
    @Resource
    private TotalImgPathMapper totalImgPathMapper;

    /**
     * @CrossOrigin 注解是为了解决跨域问题
     */
    @CrossOrigin(allowCredentials = "true", allowedHeaders = "*", methods = {RequestMethod.GET,
            RequestMethod.POST, RequestMethod.DELETE, RequestMethod.OPTIONS,
            RequestMethod.HEAD, RequestMethod.PUT, RequestMethod.PATCH}, origins = "*")
    @PostMapping({"/upload","/admin/upload"})
    @ApiOperation(value = "文件上传", notes = "文件上传")
    public Result upload(@RequestBody @ApiParam(name = "流文件") MultipartFile fileUpload,@RequestParam(required = false) @ApiParam(name = "原图片路径(有值为修改，无值为新增)") String imgPath) {
        if (fileUpload == null) {
            return ResultGenerator.genFailResult("文件不能为空");
        }
        if(StringUtils.isBlank(imgPath)){
            //获取文件名
            String fileName1 = fileUpload.getOriginalFilename();
            //获取文件后缀名
            String suffixName = fileName1.substring(fileName1.lastIndexOf(".") + 1);
            //String suffixList = "jpg,png,jpeg,wmv,ogg,mp4,webm";
            //判断是否包含
            if (fileType.contains(suffixName.trim().toLowerCase())) {
                //指定服务器文件路径
                String path1 = image.doDateFilePath();
                String fileName = CommonUtil.retrieveUUID() + "." + suffixName;
                String path2 = basePath + path1;
                if (!new File(path2).exists()) {
                    new File(path2).mkdirs();
                }
                try {
                    String filePath = path2 + "/" + fileName;
                    //spring的transferTo保存文件方法
                    fileUpload.transferTo(new File(filePath));
                    log.info("上传图片成功，服务器路径为：{}", filePath);
                    log.info("http路径为：{}", httpIp + path1 + "/" + fileName);
                    totalImgPathMapper.insert(new TotalImgPath(httpIp + path1 + "/" + fileName));
                    return ResultGenerator.genSuccessResult(httpIp + path1 + "/" + fileName);
                } catch (Exception e) {
                    e.printStackTrace();
                    return ResultGenerator.genFailResult("上传失败:" + e.getMessage());
                }
            }
            return ResultGenerator.genFailResult("上传失败，只能上传：" + fileType + "格式的文件");
        }else {
            String temp=imgPath;
            imgPath=basePath+imgPath.substring(24);
            //获取文件名
            String fileName1 = fileUpload.getOriginalFilename();
            //获取文件后缀名
            String suffixName = fileName1.substring(fileName1.lastIndexOf(".") + 1);
            //String suffixList = "jpg,png,jpeg,wmv,ogg,mp4,webm";
            //判断是否包含
            if (fileType.contains(suffixName.trim().toLowerCase())) {
                //指定服务器文件路径
                if (!new File(imgPath).exists()) {
                    return ResultGenerator.genFailResult("原图片不存在，修改失败");
                }
                try {
                    //spring的transferTo保存文件方法
                    fileUpload.transferTo(new File(imgPath));
                    log.info("修改图片成功，服务器路径为：{}", imgPath);
                    log.info("http路径为：{}", imgPath);
                    return ResultGenerator.genSuccessResult(temp);
                } catch (Exception e) {
                    e.printStackTrace();
                    return ResultGenerator.genFailResult("修改失败:" + e.getMessage());
                }

            }
            return ResultGenerator.genFailResult("修改失败，只能上传：" + fileType + "格式的文件");
        }


    }


    /**
     * @CrossOrigin 注解是为了解决跨域问题
     */
    @CrossOrigin(allowCredentials = "true", allowedHeaders = "*", methods = {RequestMethod.GET,
            RequestMethod.POST, RequestMethod.DELETE, RequestMethod.OPTIONS,
            RequestMethod.HEAD, RequestMethod.PUT, RequestMethod.PATCH}, origins = "*")
    @PostMapping("/admin/upload/view")
    @ApiOperation(value = "视频文件上传", notes = "视频文件上传")
    public Result uploadView(@RequestBody @ApiParam(name = "流文件") MultipartFile fileUpload) {
        if (fileUpload == null) {
            return ResultGenerator.genFailResult("文件不能为空");
        }
            //获取文件名
            String fileName1 = fileUpload.getOriginalFilename();
            //获取文件后缀名
            String suffixName = fileName1.substring(fileName1.lastIndexOf(".") + 1);
            //String suffixList = "jpg,png,jpeg,wmv,ogg,mp4,webm";
            //判断是否包含
            if (fileType.contains(suffixName.trim().toLowerCase())) {
                //指定服务器文件路径
                String fileName = CommonUtil.retrieveUUID() + "." + suffixName;
                String path2 = baseViewPath + "/";
                try {
                    Map<String,String> map=new HashMap<>();
                    String filePath = path2 + "/" + fileName;
                    //spring的transferTo保存文件方法
                    fileUpload.transferTo(new File(filePath));
                    log.info("上传视频成功，服务器路径为：{}", filePath);
                    log.info("http路径为：{}", httpIpView  + "/" + fileName);
                    totalImgPathMapper.insert(new TotalImgPath(httpIpView  + "/" + fileName));
                    map.put("path",httpIpView  + "/" + fileName);
                    map.put("viewDuration", String.valueOf(ViewUtils.ReadVideoTime(new File("/ddcx/ddcx_video/"+fileName))));
                    return ResultGenerator.genSuccessResult(map);
                } catch (Exception e) {
                    e.printStackTrace();
                    return ResultGenerator.genFailResult("上传失败:" + e.getMessage());
                }
            }
            return ResultGenerator.genFailResult("上传失败，只能上传：" + fileType + "格式的文件");
        }

    @GetMapping("/admin/deleteFile")
    @ApiOperation("删除文件<后台用下>")
    /**
     * 删除服务上的文件
     * @author Master.Pan
     * @date 2017年11月20日 上午11:06:48
     * @param filePath 路径
     * @param fileName 文件名
     * @return
     */
    public  Result deleteFile(@ApiParam("文件路径") String filePath){
        if(StringUtils.isEmpty(filePath)){
            return ResultGenerator.genFailResult("删除失败");
        }
        filePath=basePath+filePath.substring(24);
        File file = new File(filePath);
        if (file.exists() && file.isFile() && file.delete())
            return ResultGenerator.genSuccessResult();
        else
            return ResultGenerator.genFailResult("删除失败");
    }

    public  void publicDeleteFile(String filePath){
        if(StringUtils.isEmpty(filePath)){
        }
        filePath=basePath+filePath.substring(24);
        log.info(filePath);
        File file = new File(filePath);
        if(file.exists() && file.isFile() ){
            file.delete();
        }
    }


    public String uploadImg(byte[] imgBytes) {
        if (imgBytes.length==0) {
            return null;
        }
            //判断是否包含
                //指定服务器文件路径
                String path1 = image.doDateFilePath();
                String fileName = CommonUtil.retrieveUUID() + "." + "jpg";
                String path2 = basePath + path1;
                if (!new File(path2).exists()) {
                    new File(path2).mkdirs();
                }
        InputStream inputStream = new ByteArrayInputStream(imgBytes);
        MultipartFile fileUpload;
        try {
            fileUpload = new MockMultipartFile(path1,path1, ContentType.APPLICATION_OCTET_STREAM.toString(), inputStream);
        } catch (IOException e) {
            return null;
        }
        try {
                    String filePath = path2 + "/" + fileName;
                    //spring的transferTo保存文件方法
                    fileUpload.transferTo(new File(filePath));
                    log.info("上传图片成功，服务器路径为：{}", filePath);
                    log.info("http路径为：{}", httpIp + path1 + "/" + fileName);
                    return httpIp + path1 + "/" + fileName;
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
    }


}