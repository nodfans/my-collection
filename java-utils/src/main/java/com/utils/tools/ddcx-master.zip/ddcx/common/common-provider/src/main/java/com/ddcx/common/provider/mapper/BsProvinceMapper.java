package com.ddcx.common.provider.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.common.BsProvince;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;


@Mapper
@Component
public interface BsProvinceMapper extends MyMapper<BsProvince> {
}