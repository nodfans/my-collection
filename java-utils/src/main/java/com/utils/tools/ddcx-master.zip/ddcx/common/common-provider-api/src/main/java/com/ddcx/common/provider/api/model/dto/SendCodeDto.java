package com.ddcx.common.provider.api.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@ApiModel(value = "SendCodeDto", description = "发送验证码")
public class SendCodeDto implements java.io.Serializable {
    private static final long serialVersionUID = 9152244064713854991L;

    @ApiModelProperty(value = "账号", name = "account", required = true)
    @NotBlank(message = "手机号码不能为空")
    private String account;

    @ApiModelProperty(value = "发送类型 1-短信，2-邮箱", name = "sendType", required = true)
    @NotNull(message = "发送类型不能为空")
    private Integer sendType;

    @ApiModelProperty(value = "业务类型 1-手机号登录，2-校验账号是否存在，3-绑定手机号 ,4-注册,5-添加银行卡  如果是1,2 则账号不存在,不处理 如果是3,4 则账号存在,不处理 如果是5 恒处理", name = "bizType", required = true)
    @NotNull(message = "业务类型不能为空")
    private Integer bizType;

    @ApiModelProperty(value = "请求平台：1.app 2.管理平台 默认（1）")
    private Byte platform=1;
}
