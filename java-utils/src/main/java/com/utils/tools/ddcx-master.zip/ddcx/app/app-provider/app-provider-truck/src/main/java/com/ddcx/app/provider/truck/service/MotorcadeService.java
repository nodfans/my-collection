package com.ddcx.app.provider.truck.service;


import com.ddcx.framework.util.wrapper.Wrapper;

/**
 * Created by CodeGenerator on 2020/03/09.
 */
public interface MotorcadeService {

    Wrapper getMotorcadeByComName(String comName);

}
