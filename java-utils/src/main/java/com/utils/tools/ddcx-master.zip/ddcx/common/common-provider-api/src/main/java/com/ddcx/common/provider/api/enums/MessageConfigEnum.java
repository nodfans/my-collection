package com.ddcx.common.provider.api.enums;

public enum MessageConfigEnum {
    SYSTEM(1,"系统消息"),
    DISCOUNTS(2,"优惠消息"),
    RESCUE(3,"救援消息"),
    STUDY(4,"学习消息");


    private Integer code;

    private String msg;


    MessageConfigEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
