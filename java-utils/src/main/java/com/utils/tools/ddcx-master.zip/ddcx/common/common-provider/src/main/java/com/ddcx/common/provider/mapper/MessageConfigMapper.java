package com.ddcx.common.provider.mapper;

import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.common.MessageConfig;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface MessageConfigMapper extends MyMapper<MessageConfig> {

    @Select("select * from message_config where is_delete = 0 ")
    List<MessageConfig> getNonDeleteList();

    @Update("update message_config set is_delete = 1 where id = #{id}")
    void update(@Param("id") Long id);

    List<MessageConfig> getNoDeleteList(@Param("title") String title,@Param("createBy") Long createBy,@Param("startDate") Long startDate,@Param("endDate") Long endDate);


    @Update("update message_config set is_delete = 1 where is_delete=0 and request_url = #{rescueId}")
    int updateRescueMessage(@Param("rescueId") String rescueId);
}
