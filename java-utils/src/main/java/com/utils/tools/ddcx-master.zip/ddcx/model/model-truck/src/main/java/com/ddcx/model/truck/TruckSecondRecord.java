package com.ddcx.model.truck;

import com.ddcx.framework.base.annotation.ExcelName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Table(name = "truck_second_record")
@ApiModel("车辆二级维护记录表")
public class TruckSecondRecord {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    /**
     * 序号
     */
    @Column(name = "serial_num")
    @ApiModelProperty("出场合格证编号")
    @ExcelName("出场合格证编号")
    private String serialNum;

    /**
     * 车辆主键
     */
    @Column(name = "truck_id")
    @ApiModelProperty("车辆主键")
    private Long truckId;

    /**
     * 维护日期
     */
    @Column(name = "maintain_date")
    @ApiModelProperty("维护日期")
    @ExcelName(value = "维护日期",isTimestamp = true)
    private Long maintainDate;

    /**
     * 计划维护间隔
     */
    @Column(name = "plan_maintain_period")
    @ApiModelProperty("计划维护间隔")
    @ExcelName("计划维护间隔")
    private String planMaintainPeriod;

    /**
     * 实际维护间隔
     */
    @Column(name = "real_maintain_period")
    @ApiModelProperty("实际维护间隔")
    @ExcelName("实际维护间隔")
    private String realMaintainPeriod;

    /**
     * 主要附加维修作业内容及零件更换情况
     */
    @Column(name = "main_job")
    @ApiModelProperty("主要附加维修作业内容及零件更换情况")
    @ExcelName("主要附加维修作业内容及零件更换情况")
    private String mainJob;

    /**
     * 维护单位
     */
    @Column(name = "maintain_unit")
    @ApiModelProperty("维护单位")
    @ExcelName("维护单位")
    private String maintainUnit;

    /**
     * 出场合格证编号
     */
    @Column(name = "certificate_num")
    @ApiModelProperty("出场合格证编号")
    @ExcelName("出场合格证编号")
    private String certificateNum;




    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取车辆主键
     *
     * @return truck_id - 车辆主键
     */
    public Long getTruckId() {
        return truckId;
    }

    /**
     * 设置车辆主键
     *
     * @param truckId 车辆主键
     */
    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    /**
     * 获取维护日期
     *
     * @return maintain_date - 维护日期
     */
    public Long getMaintainDate() {
        return maintainDate;
    }

    /**
     * 设置维护日期
     *
     * @param maintainDate 维护日期
     */
    public void setMaintainDate(Long maintainDate) {
        this.maintainDate = maintainDate;
    }

    /**
     * 获取计划维护间隔
     *
     * @return plan_maintain_period - 计划维护间隔
     */
    public String getPlanMaintainPeriod() {
        return planMaintainPeriod;
    }

    /**
     * 设置计划维护间隔
     *
     * @param planMaintainPeriod 计划维护间隔
     */
    public void setPlanMaintainPeriod(String planMaintainPeriod) {
        this.planMaintainPeriod = planMaintainPeriod;
    }

    /**
     * 获取实际维护间隔
     *
     * @return real_maintain_period - 实际维护间隔
     */
    public String getRealMaintainPeriod() {
        return realMaintainPeriod;
    }

    /**
     * 设置实际维护间隔
     *
     * @param realMaintainPeriod 实际维护间隔
     */
    public void setRealMaintainPeriod(String realMaintainPeriod) {
        this.realMaintainPeriod = realMaintainPeriod;
    }

    /**
     * 获取主要附加维修作业内容及零件更换情况
     *
     * @return main_job - 主要附加维修作业内容及零件更换情况
     */
    public String getMainJob() {
        return mainJob;
    }

    /**
     * 设置主要附加维修作业内容及零件更换情况
     *
     * @param mainJob 主要附加维修作业内容及零件更换情况
     */
    public void setMainJob(String mainJob) {
        this.mainJob = mainJob;
    }

    /**
     * 获取维护单位
     *
     * @return maintain_unit - 维护单位
     */
    public String getMaintainUnit() {
        return maintainUnit;
    }

    /**
     * 设置维护单位
     *
     * @param maintainUnit 维护单位
     */
    public void setMaintainUnit(String maintainUnit) {
        this.maintainUnit = maintainUnit;
    }

    /**
     * 获取出场合格证编号
     *
     * @return certificate_num - 出场合格证编号
     */
    public String getCertificateNum() {
        return certificateNum;
    }

    /**
     * 设置出场合格证编号
     *
     * @param certificateNum 出场合格证编号
     */
    public void setCertificateNum(String certificateNum) {
        this.certificateNum = certificateNum;
    }
}