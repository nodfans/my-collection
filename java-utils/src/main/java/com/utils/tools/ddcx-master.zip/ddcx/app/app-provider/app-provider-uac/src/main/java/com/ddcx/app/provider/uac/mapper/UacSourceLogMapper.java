package com.ddcx.app.provider.uac.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.uac.UacSourceLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface UacSourceLogMapper extends MyMapper<UacSourceLog> {


    @Select("select * from uac_source_log where u_id=#{userId} and source_type=1 order by create_time desc limit 1")
    UacSourceLog selectLastLoginInfo(@Param("userId") Long userId);
}