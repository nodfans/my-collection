package com.ddcx.common.provider.api.zhiyun;

import lombok.Data;

@Data
public class ZhiYunRedis {

    private String cid;

    private String token;

    private Integer loginNum;

    private Long loginDate;
}
