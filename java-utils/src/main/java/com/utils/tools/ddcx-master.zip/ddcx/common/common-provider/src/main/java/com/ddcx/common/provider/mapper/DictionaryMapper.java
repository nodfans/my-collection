package com.ddcx.common.provider.mapper;


import com.ddcx.model.common.Dictionary;
import com.ddcx.framework.core.orm.MyMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;


@Mapper
@Component
public interface DictionaryMapper extends MyMapper<Dictionary> {

    @Select("select * from dictionary order by type, convert(name using gbk) asc  ")
    List<Dictionary> selectAllOrder();
}