package com.ddcx.common.provider.job;

import com.ddcx.common.provider.controller.PicUploadController;
import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@Log4j2
@EnableScheduling
public class ClearDisablesImgsJob {


    @Resource
    private PicUploadController picUploadController;

    /**
     * 清除服务器所有无效的图片
     */
    @Scheduled(cron = "0 0 2 * * ?")
    public void clearDisablesImgs(){
        // TODO: 2020/5/11 删除无用图片
    }


}
