package com.ddcx.common.provider.job;


import com.ddcx.app.provider.api.uac.service.UacUserServiceFeignApi;
import com.ddcx.common.provider.api.zhiyun.ZhiYunBreakRules;
import com.ddcx.common.provider.service.ZhiYunService;
import com.ddcx.model.truck.Truck;
import com.ddcx.model.uac.UserBacklog;
import com.ddcx.web.provider.api.truck.model.service.AdminTruckFeignClientApi;
import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * 形成违章待办
 */
@Component
@EnableScheduling
@Log4j2
public class BreakRulesAndRegulationsJob {

    @Resource
    private ZhiYunService zhiYunService;
    @Resource
    private AdminTruckFeignClientApi truckFeignClientApi;
    @Resource
    private UacUserServiceFeignApi uacUserServiceFeignApi;


//    @Scheduled(cron = "0 0 3 * * *")
    public void breakRulesAndRegulations(){
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
        Date date=new Date();
        String localDate=format.format(date);
        //待办截止日期
        LocalDate limitDate=LocalDate.now().plusDays(14);
        String limitStr=limitDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        List<Truck> trucks=truckFeignClientApi.getAllTruckWithBreakRules();
        ZhiYunBreakRules rules;
        List<UserBacklog> list=new ArrayList<>(trucks.size());
        UserBacklog userBacklog;
        for (Truck truck : trucks) {
            try {
                rules=zhiYunService.getBreakRules(truck);
            } catch (Exception e) {
                e.printStackTrace();
                rules=null;
            }
            if(rules!=null){
                for (ZhiYunBreakRules.BreakRule breakRule : rules.getBreakRules()) {
                    if(localDate.equals(breakRule.getTime())){
                        userBacklog=new UserBacklog();
                        userBacklog.setInitiateDate(System.currentTimeMillis()/1000);
                        userBacklog.setLimitDate(limitDate.toEpochDay()*24*3600);
                        userBacklog.setTitle("违章办理");
                        userBacklog.setDetails("您车牌号为："+truck.getTruckNum()+"的车辆的违章将于"+limitStr+"到期，请尽快处理。");
                        userBacklog.setOverdueState((byte) 1);
                        userBacklog.setType((byte) 6);
                        userBacklog.setState((byte) 0);
                        if(truck.getDriverId()!=null){
                            userBacklog.setDriverId(truck.getDriverId());
                            list.add(userBacklog);
                        }
                        if(truck.getTruckOwnerId()!=null&&!truck.getTruckOwnerId().equals(truck.getDriverId())){
                            userBacklog.setDriverId(truck.getTruckOwnerId());
                            list.add(userBacklog);
                        }
                    }
                }
            }
        }
        uacUserServiceFeignApi.addAllUserBackLog(list);
        log.info("共生成"+list.size()+"条违章待办");
    }
}
