package com.ddcx.framework.base.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class LoginAuthDto implements Serializable {
    private static final long serialVersionUID = -1137852221455042256L;

    /**
     * 用户ID
     */
    private Long userId;
    /**
     * 手机号码
     */
    private String phone;
    /**
     * 用户类型
     */
    private Integer userType;
    /**
     * 用户名称
     */
    private String userName;
    /**
     * token
     */
    private String token;
    /**
     * 过期时间
     */
    private Long expireTime;

    /**
     * 用户昵称
     */
    private String nickName;


    /**
     * 用户头像
     */
    private String headImg;


    private Long motorcadeId;


    private String motorcadeName;

    private Long comId;

    private String comName;

    private String sex;


}
