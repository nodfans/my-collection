package com.ddcx.model.exam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@ApiModel("试题表")
public class Question {
    /**
     * 主键
     */
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    @Id
    private Long id;

    /**
     * 题目类型
     */
    @ApiModelProperty("题目类型:1.单选 2.多选 3.判断")
    private Byte type;

    /**
     * 题目
     */
    @ApiModelProperty("题目")
    private String title;

    /**
     * 答案
     */
    @ApiModelProperty("答案")
    private String answer;

    /**
     * 题目内容:JSON字符串（Map集合）
     */
    @ApiModelProperty("题目内容:JSON字符串（Map集合）")
    private String content;

    @ApiModelProperty("创建时间")
    private Long createTime;

    @ApiModelProperty("分值")
    private Integer score;

    @ApiModelProperty("车队主键")
    private Long motorcadeId;

    public Long getMotorcadeId() {
        return motorcadeId;
    }

    public void setMotorcadeId(Long motorcadeId) {
        this.motorcadeId = motorcadeId;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取题目类型
     *
     * @return type - 题目类型
     */
    public Byte getType() {
        return type;
    }

    /**
     * 设置题目类型
     *
     * @param type 题目类型
     */
    public void setType(Byte type) {
        this.type = type;
    }

    /**
     * 获取题目
     *
     * @return title - 题目
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置题目
     *
     * @param title 题目
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取答案
     *
     * @return answer - 答案
     */
    public String getAnswer() {
        return answer;
    }

    /**
     * 设置答案
     *
     * @param answer 答案
     */
    public void setAnswer(String answer) {
        this.answer = answer;
    }

    /**
     * 获取题目内容:JSON字符串（Map集合）
     *
     * @return content - 题目内容:JSON字符串（Map集合）
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置题目内容:JSON字符串（Map集合）
     *
     * @param content 题目内容:JSON字符串（Map集合）
     */
    public void setContent(String content) {
        this.content = content;
    }


    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }



}