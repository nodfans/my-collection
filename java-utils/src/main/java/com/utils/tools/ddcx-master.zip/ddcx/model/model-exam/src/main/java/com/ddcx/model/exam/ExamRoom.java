package com.ddcx.model.exam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Table(name = "exam_room")
@ApiModel("考场表")
public class ExamRoom implements Serializable {
    /**
     * 主键
     */
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    @Id
    private Long id;

    /**
     * 考场名
     */
    @ApiModelProperty("考场名")
    private String name;

    /**
     * 地址
     */
    @ApiModelProperty("地址")
    private String address;

    /**
     * 时长
     */
    @ApiModelProperty("时长")
    private Integer duration;

    /**
     * 时间
     */
    @ApiModelProperty("时间")
    @Column(name = "room_date")
    private Long roomDate;

    /**
     * 考试顺序 1. 选择题优先 2.判断题优先
     */
    @ApiModelProperty("考试顺序 1. 选择题优先 2.判断题优先")
    @Column(name = "order_by")
    private Byte orderBy;

    /**
     * 状态：0.禁用 1.启用
     */
    @ApiModelProperty("状态：0.禁用 1.启用")
    private Byte state;

    /**
     * 题目数
     */
    @ApiModelProperty("题目数")
    @Column(name = "question_count")
    private Integer questionCount;

    @ApiModelProperty("及格分数")
    @Column(name = "pass_mark")
    private Integer passMark;

    @ApiModelProperty("选择题数目")
    @Column(name = "select_count")
    private Integer selectCount;

    @ApiModelProperty("判断题数目")
    @Column(name = "judge_count")
    private Integer judgeCount;

    @Transient
    @ApiModelProperty("试题id表")
    private List<Long> questionIds;

    @Transient
    @ApiModelProperty("满分")
    private Integer totalScore;

    @ApiModelProperty("车队主键")
    private Long motorcadeId;

    public Long getMotorcadeId() {
        return motorcadeId;
    }

    public void setMotorcadeId(Long motorcadeId) {
        this.motorcadeId = motorcadeId;
    }

    public Integer getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(Integer totalScore) {
        this.totalScore = totalScore;
    }

    public List<Long> getQuestionIds() {
        return questionIds;
    }

    public void setQuestionIds(List<Long> questionIds) {
        this.questionIds = questionIds;
    }

    public Integer getSelectCount() {
        return selectCount;
    }

    public void setSelectCount(Integer selectCount) {
        this.selectCount = selectCount;
    }

    public Integer getJudgeCount() {
        return judgeCount;
    }

    public void setJudgeCount(Integer judgeCount) {
        this.judgeCount = judgeCount;
    }

    public Integer getPassMark() {
        return passMark;
    }

    public void setPassMark(Integer passMark) {
        this.passMark = passMark;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取考场名
     *
     * @return name - 考场名
     */
    public String getName() {
        return name;
    }

    /**
     * 设置考场名
     *
     * @param name 考场名
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取地址
     *
     * @return address - 地址
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置地址
     *
     * @param address 地址
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * 获取时长
     *
     * @return duration - 时长
     */
    public Integer getDuration() {
        return duration;
    }

    /**
     * 设置时长
     *
     * @param duration 时长
     */
    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    /**
     * 获取时间
     *
     * @return room_date - 时间
     */
    public Long getRoomDate() {
        return roomDate;
    }

    /**
     * 设置时间
     *
     * @param roomDate 时间
     */
    public void setRoomDate(Long roomDate) {
        this.roomDate = roomDate;
    }

    /**
     * 获取考试顺序 1. 选择题优先 2.判断题优先
     *
     * @return order_by - 考试顺序 1. 选择题优先 2.判断题优先
     */
    public Byte getOrderBy() {
        return orderBy;
    }

    /**
     * 设置考试顺序 1. 选择题优先 2.判断题优先
     *
     * @param orderBy 考试顺序 1. 选择题优先 2.判断题优先
     */
    public void setOrderBy(Byte orderBy) {
        this.orderBy = orderBy;
    }

    /**
     * 获取状态：0.禁用 1.启用
     *
     * @return state - 状态：0.禁用 1.启用
     */
    public Byte getState() {
        return state;
    }

    /**
     * 设置状态：0.禁用 1.启用
     *
     * @param state 状态：0.禁用 1.启用
     */
    public void setState(Byte state) {
        this.state = state;
    }

    /**
     * 获取题目数
     *
     * @return question_count - 题目数
     */
    public Integer getQuestionCount() {
        return questionCount;
    }

    /**
     * 设置题目数
     *
     * @param questionCount 题目数
     */
    public void setQuestionCount(Integer questionCount) {
        this.questionCount = questionCount;
    }
}