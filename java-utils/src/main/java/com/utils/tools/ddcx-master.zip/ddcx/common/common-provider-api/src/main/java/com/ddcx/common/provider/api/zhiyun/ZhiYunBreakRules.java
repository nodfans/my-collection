package com.ddcx.common.provider.api.zhiyun;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
@ApiModel("违章信息")
public class ZhiYunBreakRules {

        @ApiModelProperty("违章条数")
        private String times;
        @ApiModelProperty("违章罚款合计")
        private String fineTotal;
        @ApiModelProperty("违章积分合计")
        private String integralTotal;
        @ApiModelProperty("具体违章")
        private List<BreakRule> breakRules;

        @Data
        public class BreakRule{
            @ApiModelProperty("违章信息")
            private String info;
            @ApiModelProperty("违章记录状态 1:未处理未缴费;2:已处理未缴费")
            private String Illegalflag;
            @ApiModelProperty("违章时间")
            private String time;
            @ApiModelProperty("违章地址")
            private String location;
            @ApiModelProperty("违章罚款金额")
            private String fines;
            @ApiModelProperty("违章扣分")
            private String penaltyPoint;
            @ApiModelProperty("违章原因")
            private String reason;
            @ApiModelProperty("违章所在城市名称")
            private String city;
            @ApiModelProperty("违章代码")
            private String number;
            @ApiModelProperty("在线处理  1、可以处理 2 、不支持处理")
            private String handle;
            @ApiModelProperty("司机主键")
            private Long driverId;
            @ApiModelProperty("车主主键")
            private Long truckOwnerId;
        }



}
