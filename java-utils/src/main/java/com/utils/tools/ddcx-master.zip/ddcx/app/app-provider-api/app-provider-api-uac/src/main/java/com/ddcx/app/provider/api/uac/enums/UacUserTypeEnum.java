package com.ddcx.app.provider.api.uac.enums;

import lombok.Getter;

@Getter
public enum UacUserTypeEnum {
    /**
     * 自营
     */
    USER_TYPE_1(1, "自营"),
    /**
     * 挂靠
     */
    USER_TYPE_2(2, "挂靠");


    private int code;
    private String msg;

    public int code() {
        return code;
    }

    public String msg() {
        return msg;
    }

    UacUserTypeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static UacUserTypeEnum getEnum(int code) {
        for (UacUserTypeEnum ele : UacUserTypeEnum.values()) {
            if (ele.code() == code) {
                return ele;
            }
        }
        return null;
    }
}
