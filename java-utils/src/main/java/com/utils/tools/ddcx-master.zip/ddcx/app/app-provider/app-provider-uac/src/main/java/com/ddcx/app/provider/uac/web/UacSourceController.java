package com.ddcx.app.provider.uac.web;


import com.ddcx.app.provider.uac.service.UacSourceService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/03/27.
*/
@RestController
@RequestMapping("/uac/source")
public class UacSourceController {
    @Resource
    private UacSourceService uacSourceService;

}
