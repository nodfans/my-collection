package com.ddcx.app.provider.friend.service;


import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.friend.FriendCircleReply;

/**
 * Created by CodeGenerator on 2020/03/02.
 */
public interface FriendCircleReplyService {


    /**
     * 添加回复
     *
     * @param reply
     * @param dto
     * @return
     */
    Wrapper saveFriendReply(FriendCircleReply reply, LoginAuthDto dto);


    Wrapper getOwnReply(Integer page,Integer size,Long userId);
}
