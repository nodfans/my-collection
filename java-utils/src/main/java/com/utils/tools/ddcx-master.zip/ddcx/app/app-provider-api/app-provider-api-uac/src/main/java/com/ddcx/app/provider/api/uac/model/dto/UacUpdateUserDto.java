package com.ddcx.app.provider.api.uac.model.dto;

import com.ddcx.framework.base.dto.BaseDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "UacUpdateUserDto", description = "修改用户信息")
public class UacUpdateUserDto extends BaseDto {

    private static final long serialVersionUID = -2542334698030374127L;

    @ApiModelProperty(value = "姓名", name = "realName")
    private String realName;

    @ApiModelProperty(value = "生日", name = "birthday")
    private Long birthday;

    @ApiModelProperty(value = "头像", name = "headImg")
    private String headImg;

    @ApiModelProperty(value = "地址码")
    private String addressCode;

    @ApiModelProperty(value = "地址码")
    private String addressMsg;

    @ApiModelProperty(value = "紧急联系人")
    private String emergency;


}
