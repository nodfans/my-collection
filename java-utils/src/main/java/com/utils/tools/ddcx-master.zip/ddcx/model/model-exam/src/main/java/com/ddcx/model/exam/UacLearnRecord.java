package com.ddcx.model.exam;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Table(name = "uac_learn_record")
@ApiModel("学习记录")
public class UacLearnRecord {
    /**
     * 主键
     */
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    @Id
    private Long id;

    /**
     * 用户
     */
    @Column(name = "user_id")
    @ApiModelProperty("用户")
    private Long userId;

    /**
     * 资料ID
     */
    @NotNull
    @Column(name = "l_i_id")
    @ApiModelProperty("资料ID")
    private Long lIId;

    /**
     * 时长（单位秒）
     */
    @NotNull
    @ApiModelProperty("时长（单位秒）<用于保存当次阅读所用的时间>")
    private Long duration;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    @ApiModelProperty("创建时间")
    private Long createTime;


    @ApiModelProperty("视频观看时长")
    private Long viewDuration;

    @ApiModelProperty("是否完成: 0.未完成 1.已完成")
    private Byte finish;

    public Long getViewDuration() {
        return viewDuration;
    }

    public void setViewDuration(Long viewDuration) {
        this.viewDuration = viewDuration;
    }

    public Byte getFinish() {
        return finish;
    }

    public void setFinish(Byte finish) {
        this.finish = finish;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取用户
     *
     * @return user_id - 用户
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置用户
     *
     * @param userId 用户
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 获取资料ID
     *
     * @return l_i_id - 资料ID
     */
    public Long getlIId() {
        return lIId;
    }

    /**
     * 设置资料ID
     *
     * @param lIId 资料ID
     */
    public void setlIId(Long lIId) {
        this.lIId = lIId;
    }

    /**
     * 获取时长（单位秒）
     *
     * @return duration - 时长（单位秒）
     */
    public Long getDuration() {
        return duration;
    }

    /**
     * 设置时长（单位秒）
     *
     * @param duration 时长（单位秒）
     */
    public void setDuration(Long duration) {
        this.duration = duration;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
}