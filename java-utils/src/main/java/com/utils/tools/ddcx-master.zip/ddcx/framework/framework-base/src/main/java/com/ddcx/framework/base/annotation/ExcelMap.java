package com.ddcx.framework.base.annotation;

import java.lang.annotation.*;

/**
 * 该注解用于标识对象中的map集合
 */
@Target({ElementType.FIELD, ElementType.TYPE})
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface ExcelMap {
    //map集合的键的数据类型
    Class key();

    //map集合值的数据类型
    Class value();
}
