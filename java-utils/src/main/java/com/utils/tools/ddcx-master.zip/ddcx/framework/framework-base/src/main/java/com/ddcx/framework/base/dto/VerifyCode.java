package com.ddcx.framework.base.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class VerifyCode implements Serializable {

    private static final long serialVersionUID = 8442219532313060183L;
    private String account;
    private String code;
    private Long expireTime;
}
