package com.ddcx.app.provider.exam.web;


import com.ddcx.app.provider.api.exam.param.ExamParam;
import com.ddcx.app.provider.exam.service.ExamRoomService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.exam.ExamRoom;
import com.ddcx.model.exam.QuestionVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
* Created by CodeGenerator on 2020/03/11.
*/
@RestController
@RequestMapping("/exam/room")
@Api(value = "考场模块",tags = "考场模块")
public class ExamRoomController extends BaseController {
    @Resource
    private ExamRoomService examRoomService;

    @ApiOperation("获取考场列表")
    @GetMapping("/getValidRooms")
    public Wrapper<List<ExamRoom>> getValidRooms(){
        return examRoomService.getValidRooms(getLoginAuthDto());
    }

    @ApiOperation("开始考试<获取考题列表>")
    @GetMapping("/getQuestionsByRoomId")
    public Wrapper<QuestionVo> getQuestionsByRoomId(@ApiParam("考场id")@RequestParam Long roomId){
        return examRoomService.getQuestionsByRoomId(roomId,getLoginAuthDto());
    }

    @ApiOperation("交卷")
    @PostMapping("/carryOutPaper")
    public Wrapper carryOutPaper(@ApiParam("参数")@RequestBody@Validated ExamParam param){
        return examRoomService.carryOutPaper(param,getLoginAuthDto());
    }

}
