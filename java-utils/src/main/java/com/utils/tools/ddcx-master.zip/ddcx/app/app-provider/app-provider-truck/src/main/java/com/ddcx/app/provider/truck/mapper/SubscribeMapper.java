package com.ddcx.app.provider.truck.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.truck.Subscribe;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface SubscribeMapper extends MyMapper<Subscribe> {

    @Select("select count(*) from subscribe where subscribe_id=#{configId} and date=#{date}")
    int selectSubscribeCountOfDate(@Param("configId") Long configId, @Param("date")Integer date);
}