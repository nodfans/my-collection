package com.ddcx.common.provider.controller;


import com.ddcx.common.provider.service.SysConfigService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/03/17.
*/
@RestController
@RequestMapping("/sys/config")
@Api(value = "系统配置",tags = "系统配置")
public class SysConfigController extends BaseController {
    @Resource
    private SysConfigService sysConfigService;


    @ApiOperation("获取考试分值配置<后台使用>")
    @GetMapping("/admin/getAdminExamScoreConfig")
    public Wrapper<String> getAdminExamScoreConfig(){
        return sysConfigService.getExamScoreConfig(getAdminLoginAuthDto().getMotorcadeId());
    }

    @ApiOperation("获取考试分值配置")
    @GetMapping("/getExamScoreConfig")
    public Wrapper<String> getExamScoreConfig(){
        return sysConfigService.getExamScoreConfig(getLoginAuthDto().getMotorcadeId());
    }

    @ApiOperation("配置考试分值<后台使用>")
    @GetMapping("/admin/initExamScoreConfig")
    public Wrapper initExamScoreConfig(@ApiParam(value = "题目类型：1.选择题  3.判断题",required = true)@RequestParam Byte qType,
                                       @ApiParam(value = "题目分值",required = true)@RequestParam Integer score){
        return sysConfigService.initExamScoreConfig(qType,score,getAdminLoginAuthDto());
    }


}
