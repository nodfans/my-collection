package com.ddcx.app.provider.uac.service;


import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.uac.Rescue;

/**
 * Created by CodeGenerator on 2020/03/26.
 */
public interface RescueService {


    Wrapper saveRescue(Rescue rescue, LoginAuthDto dto);

    Wrapper rescueList(String lng,String lat,LoginAuthDto dto);

    Wrapper currentRescue(LoginAuthDto dto);

    Wrapper cancelRescue(Long id , LoginAuthDto dto);

    Wrapper getRescueInfo(String lng,String lat,LoginAuthDto dto);

    Wrapper getRescueInfoById(Long id);
}
