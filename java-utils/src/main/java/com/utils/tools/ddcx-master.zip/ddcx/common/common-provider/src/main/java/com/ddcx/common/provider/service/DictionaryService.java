package com.ddcx.common.provider.service;


import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.model.common.Dictionary;
import com.ddcx.framework.util.wrapper.Wrapper;

import java.util.List;

/**
 * Created by CodeGenerator on 2020/02/27.
 */
public interface DictionaryService {

    Wrapper<List<Dictionary>> getDictionaryByType(Integer type);

    Wrapper addDictionary(String data,Integer type);

    Wrapper deleteDictionary(Long id);

}
