package com.ddcx.app.provider.friend.service;


import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;

/**
 * Created by CodeGenerator on 2020/03/02.
 */
public interface FriendLikeService {

    /**
     * 点赞
     *
     * @param id  卡友圈主键
     * @param dto 用户登录信息
     * @return
     */
    Wrapper putLike(Long id, LoginAuthDto dto);

    Wrapper clearLike(Long id, LoginAuthDto dto);

}
