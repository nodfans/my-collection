package com.ddcx.model.loan;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

@Table(name = "loan_order")
@ApiModel("借款订单")
public class LoanOrder {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    /**
     * 用途
     */
    @NotBlank
    @ApiModelProperty("用途")
    private String purpose;

    /**
     * 借款本金
     */
    @NotNull
    @ApiModelProperty("借款本金")
    private BigDecimal amount;

    /**
     * 还款总额
     */
    @ApiModelProperty("还款总额")
    @Column(name = "repayment_amount")
    private BigDecimal repaymentAmount;

    /**
     * 利息
     */
    @ApiModelProperty("利息")
    @Column(name = "interest")
    private BigDecimal interest;

    /**
     * 还款方式 1.等额本金 2.等额本息 3.到期一次性还本付息
     */
    @NotNull
    @ApiModelProperty("还款方式 1.等额本金 2.等额本息 3.到期一次性还本付息")
    @Column(name = "repayment_way")
    private Byte repaymentWay;

    /**
     * 借款期限（单位月）
     */
    @NotNull
    @ApiModelProperty("借款期限（单位月）")
    @Column(name = "time_limit")
    private Integer timeLimit;

    /**
     * 借款到期日
     */
    @ApiModelProperty("借款到期日")
    @Column(name = "expire_date")
    private Long expireDate;

    /**
     * 状态 -1：撤销，0：已申请（待审核），1：审核通过，2：审核不通过
     */
    @ApiModelProperty("状态 -1：撤销，0：已申请（待审核），1：审核通过(待还款)，2：审核不通过，3.逾期，4.已完成 5.线下还款待审核")
    private Byte state;

    @Transient
    @ApiModelProperty("逾期天数")
    private Integer overdueDays;

    @Transient
    @ApiModelProperty("当期应还")
    private BigDecimal localIssueMoney;


    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    @Column(name = "create_time")
    private Long createTime;

    /**
     * 手续费
     */
    @ApiModelProperty("手续费")
    @Column(name = "service_charge")
    private BigDecimal serviceCharge;

    /**
     * 月利率
     */
    @ApiModelProperty("月利率")
    private BigDecimal rate;

    /**
     * 用户id
     */
    @ApiModelProperty("用户id")
    @Column(name = "user_id")
    private Long userId;

    /**
     * 用户姓名
     */
    @ApiModelProperty("用户姓名")
    @Column(name = "user_name")
    private String userName;

    /**
     * 性别
     */
    @ApiModelProperty("性别")
    private String sex;

    /**
     * 身份证
     */
    @ApiModelProperty("身份证")
    @Column(name = "id_card")
    private String idCard;

    /**
     * 手机号码
     */
    @ApiModelProperty("手机号码")
    @Column(name = "user_phone")
    private String userPhone;

    /**
     * 车牌号
     */
    @ApiModelProperty("车牌号")
    @Column(name = "truck_license")
    private String truckLicense;

    /**
     * 车队主键
     */
    @ApiModelProperty("车队主键")
    @Column(name = "motorcade_id")
    private Long motorcadeId;

    /**
     * 车队名
     */
    @ApiModelProperty("车队名")
    @Column(name = "motorcade_name")
    private String motorcadeName;

    @ApiModelProperty("分期信息")
    @Transient
    private List<LoanRepaymentItem> items;

    @ApiModelProperty("逾期利率")
    private BigDecimal overdueRate;

    @ApiModelProperty("还款途径")
    private String repaymentType;

    @ApiModelProperty("企业主键")
    private Long comId;

    public Long getComId() {
        return comId;
    }

    public void setComId(Long comId) {
        this.comId = comId;
    }

    public String getRepaymentType() {
        return repaymentType;
    }

    public void setRepaymentType(String repaymentType) {
        this.repaymentType = repaymentType;
    }

    public BigDecimal getOverdueRate() {
        return overdueRate;
    }

    public void setOverdueRate(BigDecimal overdueRate) {
        this.overdueRate = overdueRate;
    }

    public BigDecimal getLocalIssueMoney() {
        return localIssueMoney;
    }

    public void setLocalIssueMoney(BigDecimal localIssueMoney) {
        this.localIssueMoney = localIssueMoney;
    }

    public String getMotorcadeName() {
        return motorcadeName;
    }

    public void setMotorcadeName(String motorcadeName) {
        this.motorcadeName = motorcadeName;
    }

    public Long getMotorcadeId() {
        return motorcadeId;
    }

    public void setMotorcadeId(Long motorcadeId) {
        this.motorcadeId = motorcadeId;
    }


    public Integer getOverdueDays() {
        return overdueDays;
    }

    public void setOverdueDays(Integer overdueDays) {
        this.overdueDays = overdueDays;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取用途
     *
     * @return purpose -LoanOrderServiceImpl 用途
     */
    public String getPurpose() {
        return purpose;
    }

    /**
     * 设置用途
     *
     * @param purpose 用途
     */
    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }


    public List<LoanRepaymentItem> getItems() {
        return items;
    }

    public void setItems(List<LoanRepaymentItem> items) {
        this.items = items;
    }

    /**
     * 获取借款本金
     *
     * @return amount - 借款本金
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * 设置借款本金
     *
     * @param amount 借款本金
     */
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    /**
     * 获取还款总额
     *
     * @return repayment_amount - 还款总额
     */
    public BigDecimal getRepaymentAmount() {
        return repaymentAmount;
    }

    /**
     * 设置还款总额
     *
     * @param repaymentAmount 还款总额
     */
    public void setRepaymentAmount(BigDecimal repaymentAmount) {
        this.repaymentAmount = repaymentAmount;
    }

    /**
     * 获取利息
     *
     * @return interest_rate - 利息
     */
    public BigDecimal getInterest() {
        return interest;
    }

    /**
     * 设置利息
     *
     * @param interest 利息
     */
    public void setInterest(BigDecimal interest) {
        this.interest = interest;
    }

    /**
     * 获取还款方式 1.等额本金 2.等额本息
     *
     * @return repayment_way - 还款方式 1.等额本金 2.等额本息
     */
    public Byte getRepaymentWay() {
        return repaymentWay;
    }

    /**
     * 设置还款方式 1.等额本金 2.等额本息
     *
     * @param repaymentWay 还款方式 1.等额本金 2.等额本息
     */
    public void setRepaymentWay(Byte repaymentWay) {
        this.repaymentWay = repaymentWay;
    }

    /**
     * 获取借款期限（单位月）
     *
     * @return time_limit - 借款期限（单位月）
     */
    public Integer getTimeLimit() {
        return timeLimit;
    }

    /**
     * 设置借款期限（单位月）
     *
     * @param timeLimit 借款期限（单位月）
     */
    public void setTimeLimit(Integer timeLimit) {
        this.timeLimit = timeLimit;
    }

    /**
     * 获取借款到期日
     *
     * @return expire_date - 借款到期日
     */
    public Long getExpireDate() {
        return expireDate;
    }

    /**
     * 设置借款到期日
     *
     * @param expireDate 借款到期日
     */
    public void setExpireDate(Long expireDate) {
        this.expireDate = expireDate;
    }

    /**
     * 获取状态 -1：撤销，0：已申请（待审核），1：审核通过，2：审核不通过
     *
     * @return state - 状态 -1：撤销，0：已申请（待审核），1：审核通过，2：审核不通过
     */
    public Byte getState() {
        return state;
    }

    /**
     * 设置状态 -1：撤销，0：已申请（待审核），1：审核通过，2：审核不通过
     *
     * @param state 状态 -1：撤销，0：已申请（待审核），1：审核通过，2：审核不通过
     */
    public void setState(Byte state) {
        this.state = state;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取手续费
     *
     * @return service_charge - 手续费
     */
    public BigDecimal getServiceCharge() {
        return serviceCharge;
    }

    /**
     * 设置手续费
     *
     * @param serviceCharge 手续费
     */
    public void setServiceCharge(BigDecimal serviceCharge) {
        this.serviceCharge = serviceCharge;
    }

    /**
     * 获取月利率
     *
     * @return rate - 月利率
     */
    public BigDecimal getRate() {
        return rate;
    }

    /**
     * 设置月利率
     *
     * @param rate 月利率
     */
    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }

    /**
     * 获取用户id
     *
     * @return user_id - 用户id
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置用户id
     *
     * @param userId 用户id
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 获取用户姓名
     *
     * @return user_name - 用户姓名
     */
    public String getUserName() {
        return userName;
    }

    /**
     * 设置用户姓名
     *
     * @param userName 用户姓名
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * 获取性别
     *
     * @return sex - 性别
     */
    public String getSex() {
        return sex;
    }

    /**
     * 设置性别
     *
     * @param sex 性别
     */
    public void setSex(String sex) {
        this.sex = sex;
    }

    /**
     * 获取身份证
     *
     * @return id_card - 身份证
     */
    public String getIdCard() {
        return idCard;
    }

    /**
     * 设置身份证
     *
     * @param idCard 身份证
     */
    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    /**
     * 获取手机号码
     *
     * @return user_phone - 手机号码
     */
    public String getUserPhone() {
        return userPhone;
    }

    /**
     * 设置手机号码
     *
     * @param userPhone 手机号码
     */
    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    /**
     * 获取车牌号
     *
     * @return truck_license - 车牌号
     */
    public String getTruckLicense() {
        return truckLicense;
    }

    /**
     * 设置车牌号
     *
     * @param truckLicense 车牌号
     */
    public void setTruckLicense(String truckLicense) {
        this.truckLicense = truckLicense;
    }
}