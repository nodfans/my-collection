package com.ddcx.app.provider.friend.service.impl;


import com.ddcx.app.provider.api.friend.model.vo.FriendCircleVo;
import com.ddcx.app.provider.friend.mapper.FriendCircleMapper;
import com.ddcx.app.provider.friend.mapper.FriendCircleReplyMapper;
import com.ddcx.app.provider.friend.mapper.FriendLikeMapper;
import com.ddcx.app.provider.friend.service.FriendCircleService;
import com.ddcx.common.provider.api.service.CommonServiceFeignApi;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.friend.FriendCircle;
import com.ddcx.model.friend.FriendCircleReply;
import com.ddcx.model.friend.FriendLike;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/02.
 */
@Service
@Transactional
public class FriendCircleServiceImpl implements FriendCircleService {
    @Resource
    private FriendCircleMapper friendCircleMapper;
    @Resource
    private FriendCircleReplyMapper replyMapper;
    @Resource
    private FriendLikeMapper likeMapper;
    @Resource
    private CommonServiceFeignApi commonServiceFeignApi;

    @Override
    public Wrapper saveFriendCircle(FriendCircle friendCircle, LoginAuthDto loginAuthDto) {
        friendCircle.setCreateTime(System.currentTimeMillis() / 1000);
        friendCircle.setNickName(loginAuthDto.getUserName());
        friendCircle.setHeadImg(loginAuthDto.getHeadImg());
        friendCircle.setUserId(loginAuthDto.getUserId());
        friendCircle.setLikeCount(0);
        friendCircle.setReplyCount(0);
        int i = friendCircleMapper.insert(friendCircle);
        if (i > 0) {
            return WrapMapper.ok("发布成功");
        }
        return WrapMapper.error("发布失败");
    }

    @Override
    public Wrapper<PageInfo<FriendCircle>> getFriendCircle(Integer page, Integer size, String param,LoginAuthDto dto) {
        PageHelper.startPage(page, size);
        List<FriendCircle> list = friendCircleMapper.getFriendCircle(param);
        if(dto!=null){
            list.forEach(a->{if(a.getUserId().equals(dto.getUserId())){
                a.setOwn(true);}else {a.setOwn(false);}
                a.setIsLike(likeMapper.selectCountByCircleAndUserId(a.getId(),dto.getUserId()));}
            );
        }else {
            list.forEach(a->{a.setOwn(false);
            a.setIsLike((byte) 0);
            });
        }
        return WrapMapper.ok(new PageInfo<>(list));
    }

    @Override
    public Wrapper getOwnFriendCircle(Integer page, Integer size, LoginAuthDto dto) {
        PageHelper.startPage(page, size);
        List<FriendCircle> list = friendCircleMapper.getOwnFriendCircle(dto.getUserId());
        if(dto!=null){
            list.forEach(a->{if(a.getUserId().equals(dto.getUserId())){
                a.setOwn(true);}else {a.setOwn(false);}
                a.setIsLike(likeMapper.selectCountByCircleAndUserId(a.getId(),dto.getUserId()));}
            );
        }else {
            list.forEach(a->{a.setOwn(false);
                a.setIsLike((byte) 0);
            });
        }
        return WrapMapper.ok(new PageInfo<>(list));
    }

    @Override
    public Wrapper<FriendCircleVo> getFriendCircleDetail(Long id,LoginAuthDto dto) {
        FriendCircle circle = friendCircleMapper.selectByPrimaryKey(id);
        if(circle==null){
            return WrapMapper.error("卡友圈不存在");
        }
        List<FriendCircleReply> replies = replyMapper.selectByFriendCircleId(id);
        List<FriendLike> likes = likeMapper.selectByFriendCircleId(id);
        circle.setReplyCount(replies.size());
        circle.setLikeCount(likes.size());
        if(circle.getUserId().equals(dto.getUserId())){
            circle.setOwn(true);
        }else {
            circle.setOwn(false);
        }
        FriendCircleVo friendCircleVo = new FriendCircleVo();
        friendCircleVo.setFriendCircle(circle);
        friendCircleVo.setFriendCircleReplys(replies);
        friendCircleVo.setLikes(likes);
        friendCircleVo.setIsLike(likeMapper.selectCountByCircleAndUserId(id,dto.getUserId()));
        circle.setIsLike(friendCircleVo.getIsLike());
        return WrapMapper.ok(friendCircleVo);
    }

    @Override
    public Wrapper deleteFriendCircle(Long id, Long userId) {
        FriendCircle friendCircle=friendCircleMapper.selectByPrimaryKey(id);
        int i = friendCircleMapper.deleteById(id, userId);
        if (i == 0) {
            return WrapMapper.error("删除失败");
        }
        try {
            commonServiceFeignApi.deleteFile(friendCircle.getImgContent());
        } catch (Exception e) {
            e.printStackTrace();
        }
        replyMapper.deleteByFriendCircleId(id);
        likeMapper.deleteByFriendCircleId(id);
        return WrapMapper.ok("删除成功");
    }
}
