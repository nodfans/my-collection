package com.ddcx.model.truck;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;


@ApiModel("车队对象")
public class Motorcade {
    /**
     * 主键
     */
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @ApiModelProperty(value = "主鍵")
    private Long id;

    /**
     * 企业名称
     */
    @NotBlank(message = "企业名称不能为空")
    @Column(name = "com_name")
    @ApiModelProperty(value = "企业名称",required = true)
    private String comName;

    /**
     * 地址
     */
    @ApiModelProperty(value = "地址",required = true)
    @NotBlank(message = "地址不能为空")
    private String address;

    /**
     * 车队名称
     */
    @NotBlank(message = "车队名称不能为空")
    @ApiModelProperty(value = "车队名称",required = true)
    @Column(name = "motorcade_name")
    private String motorcadeName;

    /**
     * 车队管理员id
     */
    @NotNull(message = "车队管理员不能为空")
    @ApiModelProperty(value = "车队管理员主鍵",required = true)
    @Column(name = "admin_id")
    private Long adminId;

    /**
     * 车队状态 0.停用 1.启用 2.待审核 3.审核驳回
     */
    @ApiModelProperty(value = "车队状态 0.停用 1.启用 2.待审核 3.审核驳回",required = true)
    @NotNull(message = "车队状态不能为空")
    private Byte state;

    /**
     * 修改时间
     */
    @Column(name = "update_time")
    @ApiModelProperty(value = "修改时间")
    private Long updateTime;

    /**
     * 修改人
     */
    @Column(name = "update_by")
    @ApiModelProperty(value = "修改人")
    private Long updateBy;

    /**
     * 创建人
     */
    @Column(name = "create_by")
    @ApiModelProperty(value = "创建人")
    private Long createBy;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    @ApiModelProperty(value = "创建时间")
    private Long createTime;

    @Transient
    @ApiModelProperty("车辆数量")
    private Integer truckCounts;

    @Transient
    @ApiModelProperty("司机人数")
    private Integer driverCounts;

    @ApiModelProperty("联系人电话")
    private String contactsPhone;

    @ApiModelProperty("地址码")
    private String addressCode;

    @ApiModelProperty("地址中文信息")
    private String addressMsg;

    @ApiModelProperty("车队管理员名称")
    private String adminName;

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getAddressCode() {
        return addressCode;
    }

    public void setAddressCode(String addressCode) {
        this.addressCode = addressCode;
    }

    public String getAddressMsg() {
        return addressMsg;
    }

    public void setAddressMsg(String addressMsg) {
        this.addressMsg = addressMsg;
    }

    public String getContactsPhone() {
        return contactsPhone;
    }

    public void setContactsPhone(String contactsPhone) {
        this.contactsPhone = contactsPhone;
    }

    public Integer getTruckCounts() {
        return truckCounts;
    }

    public void setTruckCounts(Integer truckCounts) {
        this.truckCounts = truckCounts;
    }

    public Integer getDriverCounts() {
        return driverCounts;
    }

    public void setDriverCounts(Integer driverCounts) {
        this.driverCounts = driverCounts;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    @Column(name = "com_id")
    @ApiModelProperty("企业主键")
    private Long comId;

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }


    public Long getComId() {
        return comId;
    }

    public void setComId(Long comId) {
        this.comId = comId;
    }

    /**
     * 获取企业名称
     *
     * @return com_name - 企业名称
     */
    public String getComName() {
        return comName;
    }

    /**
     * 设置企业名称
     *
     * @param comName 企业名称
     */
    public void setComName(String comName) {
        this.comName = comName;
    }

    /**
     * 获取地址
     *
     * @return address - 地址
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置地址
     *
     * @param address 地址
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * 获取车队名称
     *
     * @return motorcade_name - 车队名称
     */
    public String getMotorcadeName() {
        return motorcadeName;
    }

    /**
     * 设置车队名称
     *
     * @param motorcadeName 车队名称
     */
    public void setMotorcadeName(String motorcadeName) {
        this.motorcadeName = motorcadeName;
    }

    /**
     * 获取车队管理员id
     *
     * @return admin_id - 车队管理员id
     */
    public Long getAdminId() {
        return adminId;
    }

    /**
     * 设置车队管理员id
     *
     * @param adminId 车队管理员id
     */
    public void setAdminId(Long adminId) {
        this.adminId = adminId;
    }

    /**
     * 获取0.停用 1.启用 2.待审核 3.审核驳回
     *
     * @return state - 0.停用 1.启用 2.待审核 3.审核驳回
     */
    public Byte getState() {
        return state;
    }

    /**
     * 设置0.停用 1.启用 2.待审核 3.审核驳回
     *
     * @param state 0.停用 1.启用 2.待审核 3.审核驳回
     */
    public void setState(Byte state) {
        this.state = state;
    }

    /**
     * 获取修改时间
     *
     * @return update_time - 修改时间
     */
    public Long getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置修改时间
     *
     * @param updateTime 修改时间
     */
    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * 获取修改人
     *
     * @return update_by - 修改人
     */
    public Long getUpdateBy() {
        return updateBy;
    }

    /**
     * 设置修改人
     *
     * @param updateBy 修改人
     */
    public void setUpdateBy(Long updateBy) {
        this.updateBy = updateBy;
    }

    /**
     * 获取创建人
     *
     * @return create_by - 创建人
     */
    public Long getCreateBy() {
        return createBy;
    }

    /**
     * 设置创建人
     *
     * @param createBy 创建人
     */
    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
}