package com.ddcx.common.provider.service;


import com.ddcx.framework.util.wrapper.Wrapper;

/**
 * Created by CodeGenerator on 2020/03/23.
 */
public interface CnRegionInfoService  {


    Wrapper getProvinceInfo();

    Wrapper getCityInfo();

    Wrapper getAreaInfo();

    Wrapper getStreetInfo();

    Wrapper getBcRegionInfo();





}
