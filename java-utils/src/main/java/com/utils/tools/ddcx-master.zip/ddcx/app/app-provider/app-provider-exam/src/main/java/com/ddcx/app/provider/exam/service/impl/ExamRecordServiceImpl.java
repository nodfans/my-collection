package com.ddcx.app.provider.exam.service.impl;


import com.ddcx.app.provider.exam.mapper.ExamRecordMapper;
import com.ddcx.app.provider.exam.service.ExamRecordService;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.exam.ExamRecord;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/04/14.
 */
@Service
@Transactional
public class ExamRecordServiceImpl implements ExamRecordService {
    @Resource
    private ExamRecordMapper examRecordMapper;

    @Override
    public Wrapper getOwnExamRecords(Integer page, Integer size, Long userId) {
        PageHelper.startPage(page,size);
        PageHelper.orderBy("id desc");
        List<ExamRecord> list=examRecordMapper.selectByUserId(userId);
        return WrapMapper.ok(new PageInfo<>(list));
    }
}
