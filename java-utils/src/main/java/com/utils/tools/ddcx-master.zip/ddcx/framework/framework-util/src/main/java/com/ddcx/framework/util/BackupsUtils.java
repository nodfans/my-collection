//package com.ddcx.framework.util;
//
//import org.springframework.stereotype.Component;
//
//import java.io.IOException;
//import java.util.Properties;
//
//
///**
// * 用于备份整个数据库
// */
//@Component
//public class BackupsUtils {
//
//
//    public void backUps(){
//        Properties props = new Properties();
//
//        try {
//
//        //通过Properties来加载jdbc.properties文件
//
//            props.load(BackupAction.class.getClassLoader().getResourceAsStream("config/properties/jdbc.properties"));
//
//        } catch (IOException e1) {
//
//            message="error";
//
//        }
//
//        url = props.getProperty("jdbc.url");
//
//        username = props.getProperty("jdbc.username");
//
//        password = props.getProperty("jdbc.password");
//
//        driverClassName = props.getProperty("jdbc.driverClassName");
//    }
//
//}
