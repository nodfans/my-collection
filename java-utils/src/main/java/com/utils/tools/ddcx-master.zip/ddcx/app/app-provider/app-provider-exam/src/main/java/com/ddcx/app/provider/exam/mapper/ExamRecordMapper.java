package com.ddcx.app.provider.exam.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.exam.ExamRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface ExamRecordMapper extends MyMapper<ExamRecord> {

    @Select("select * from exam_record where user_id=#{userId}")
    List<ExamRecord> selectByUserId(@Param("userId")Long userId);

    Long insertReturnId(ExamRecord record);
}