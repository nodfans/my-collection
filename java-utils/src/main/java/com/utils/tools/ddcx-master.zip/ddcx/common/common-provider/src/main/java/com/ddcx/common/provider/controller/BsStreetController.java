package com.ddcx.common.provider.controller;


import com.ddcx.common.provider.service.BsStreetService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/03/23.
*/
@RestController
@RequestMapping("/bs/street")
public class BsStreetController {
    @Resource
    private BsStreetService bsStreetService;

}
