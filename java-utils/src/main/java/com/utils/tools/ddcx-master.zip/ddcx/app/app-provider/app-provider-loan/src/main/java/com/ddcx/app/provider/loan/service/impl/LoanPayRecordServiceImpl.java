package com.ddcx.app.provider.loan.service.impl;


import com.ddcx.app.provider.loan.mapper.LoanPayRecordMapper;
import com.ddcx.app.provider.loan.service.LoanPayRecordService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/04/28.
 */
@Service
@Transactional
public class LoanPayRecordServiceImpl implements LoanPayRecordService {
    @Resource
    private LoanPayRecordMapper loanPayRecordMapper;

}
