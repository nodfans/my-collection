package com.ddcx.framework.core.orm.handler;

import com.alibaba.fastjson.JSON;

import java.util.HashMap;
import java.util.Map;

public class BeanWrapper {
    public BeanWrapper() {
    }

    ;

    public BeanWrapper(Object entity) {
        this.setObj(entity);
    }

    private Map innerMap = new HashMap();

    public Map getInnerMap() {
        return innerMap;
    }

    public void setInnerMap(Map innerMap) {
        this.innerMap = innerMap;
    }

    public void setObj(Object entity) {
        if (entity == null) {
            innerMap = null;
        }
        JSON jobj = (JSON) JSON.toJSON(entity);
        innerMap = JSON.toJavaObject(jobj, Map.class);
    }

    public Object getObj() {
        if (innerMap == null) {
            return null;
        }
        JSON jobj = (JSON) JSON.toJSON(innerMap);
        Map entity = JSON.toJavaObject(jobj, Map.class);
        return entity;
    }

    public Object getObj(Class targetClass) {
        if (innerMap == null) {
            return null;
        }
        JSON jobj = (JSON) JSON.toJSON(innerMap);
        Object entity = JSON.toJavaObject(jobj, targetClass);
        return entity;
    }

}
