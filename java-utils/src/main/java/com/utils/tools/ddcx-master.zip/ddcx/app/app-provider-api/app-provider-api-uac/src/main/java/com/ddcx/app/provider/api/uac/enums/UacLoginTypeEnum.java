package com.ddcx.app.provider.api.uac.enums;

public enum UacLoginTypeEnum {
    /**
     * 短信
     */
    LOGIN_TYPE_SMS(1, "短信"),
    /**
     * 邮箱
     */
    LOGIN_TYPE_EMAIL(2, "邮箱");


    private Integer code;
    private String msg;

    public Integer code() {
        return code;
    }

    public String msg() {
        return msg;
    }

    UacLoginTypeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
