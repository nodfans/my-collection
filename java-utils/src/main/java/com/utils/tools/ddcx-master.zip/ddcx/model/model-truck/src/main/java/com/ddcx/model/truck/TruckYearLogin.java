package com.ddcx.model.truck;

import com.ddcx.framework.base.annotation.ExcelName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Table(name = "truck_year_login")
@ApiModel("年检复核记录表")
public class TruckYearLogin {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    /**
     * 车辆主键
     */
    @Column(name = "truck_id")
    @NotNull(message = "车辆主键不能为空")
    @ApiModelProperty("车辆主键")
    private Long truckId;

    /**
     * 评定日期
     */
    @NotNull(message = "评定日期不能为空")
    @ApiModelProperty("评定日期")
    @ExcelName(value = "评定日期",isTimestamp = true)
    private Long assess;

    /**
     * 车辆技术等级
     */
    @Column(name = "technology_level")
    @NotBlank(message = "车辆技术等级不能为空")
    @ApiModelProperty("车辆技术等级")
    @ExcelName("车辆技术等级")
    private String technologyLevel;

    /**
     * 检测评定单位
     */
    @Column(name = "check_unit")
    @NotBlank(message = "检测评定单位不能为空")
    @ApiModelProperty("检测评定单位")
    @ExcelName("检测评定单位")
    private String checkUnit;

    /**
     * 客车类型及等级
     */
    @Column(name = "truck_type_level")
    @NotBlank(message = "客车类型及等级不能为空")
    @ApiModelProperty("客车类型及等级")
    @ExcelName("客车类型及等级")
    private String truckTypeLevel;

    /**
     * 评定（复核）单位
     */
    @Column(name = "recheck_unit")
    @NotBlank(message = "评定（复核）单位不能为空")
    @ApiModelProperty("评定（复核）单位")
    @ExcelName("评定（复核）单位")
    private String recheckUnit;


    @Column(name = "serial_num")
    @ApiModelProperty("评定（复核）单位")
    @ExcelName("评定（复核）单位")
    private String serialNum;

    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取车辆主键
     *
     * @return truck_id - 车辆主键
     */
    public Long getTruckId() {
        return truckId;
    }

    /**
     * 设置车辆主键
     *
     * @param truckId 车辆主键
     */
    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    /**
     * 获取评定日期
     *
     * @return assess - 评定日期
     */
    public Long getAssess() {
        return assess;
    }

    /**
     * 设置评定日期
     *
     * @param assess 评定日期
     */
    public void setAssess(Long assess) {
        this.assess = assess;
    }

    /**
     * 获取车辆技术等级
     *
     * @return technology_level - 车辆技术等级
     */
    public String getTechnologyLevel() {
        return technologyLevel;
    }

    /**
     * 设置车辆技术等级
     *
     * @param technologyLevel 车辆技术等级
     */
    public void setTechnologyLevel(String technologyLevel) {
        this.technologyLevel = technologyLevel;
    }

    /**
     * 获取检测评定单位
     *
     * @return check_unit - 检测评定单位
     */
    public String getCheckUnit() {
        return checkUnit;
    }

    /**
     * 设置检测评定单位
     *
     * @param checkUnit 检测评定单位
     */
    public void setCheckUnit(String checkUnit) {
        this.checkUnit = checkUnit;
    }

    /**
     * 获取客车类型及等级
     *
     * @return truck_type_level - 客车类型及等级
     */
    public String getTruckTypeLevel() {
        return truckTypeLevel;
    }

    /**
     * 设置客车类型及等级
     *
     * @param truckTypeLevel 客车类型及等级
     */
    public void setTruckTypeLevel(String truckTypeLevel) {
        this.truckTypeLevel = truckTypeLevel;
    }

    /**
     * 获取评定（复核）单位
     *
     * @return recheck_unit - 评定（复核）单位
     */
    public String getRecheckUnit() {
        return recheckUnit;
    }

    /**
     * 设置评定（复核）单位
     *
     * @param recheckUnit 评定（复核）单位
     */
    public void setRecheckUnit(String recheckUnit) {
        this.recheckUnit = recheckUnit;
    }
}