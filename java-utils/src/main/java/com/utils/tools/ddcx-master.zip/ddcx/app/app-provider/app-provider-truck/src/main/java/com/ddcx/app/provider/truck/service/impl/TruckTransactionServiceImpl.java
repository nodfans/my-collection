package com.ddcx.app.provider.truck.service.impl;

import com.ddcx.app.provider.api.truck.model.vo.TruckTransactionVo;
import com.ddcx.app.provider.api.uac.model.vo.UacUserVo;
import com.ddcx.app.provider.api.uac.service.UacUserServiceFeignApi;
import com.ddcx.app.provider.truck.mapper.TruckMapper;
import com.ddcx.app.provider.truck.mapper.TruckTransactionMapper;
import com.ddcx.app.provider.truck.service.TruckTransactionService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.Truck;
import com.ddcx.model.truck.TruckTransaction;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;


/**
 * Created by CodeGenerator on 2020/02/25.
 */
@Service
@Transactional
public class TruckTransactionServiceImpl implements TruckTransactionService {
    @Resource
    private TruckTransactionMapper truckTransactionMapper;

    @Resource
    private UacUserServiceFeignApi userServiceFeignApi;

    @Resource
    private TruckMapper truckMapper;

    @Override
    public Wrapper save(TruckTransaction truckTransaction, LoginAuthDto dto) {
        truckTransaction.setCreateTime(System.currentTimeMillis() / 1000);
        truckTransaction.setUserId(dto.getUserId());
        truckTransaction.setId(null);
        if(truckTransaction.getTruckId()!=null){
            Truck truck=new Truck();
            truck.setId(truckTransaction.getTruckId());
            truck.setSaleState((byte) 1);
            truckMapper.updateByPrimaryKeySelective(truck);
            truckTransaction.setSaleType((byte) 1);
        }
        truckTransaction.setFromType((byte) 2);
        int i = truckTransactionMapper.insert(truckTransaction);
        if (i > 0) {
            return WrapMapper.ok("汽车新增成功");
        }
        return WrapMapper.error("汽车新增失败");
    }

    @Override
    public Wrapper<PageInfo<TruckTransaction>> getTrucksPage(Integer page, Integer size, TruckTransaction truckTransaction) {
        PageHelper.startPage(page, size);
        List<TruckTransaction> list = truckTransactionMapper.getTrucksPage(truckTransaction);
        PageInfo<TruckTransaction> pageInfo = new PageInfo<>(list);
        return WrapMapper.ok(pageInfo);
    }

    @Override
    public Wrapper<TruckTransactionVo> getTruckDetail(Integer id) {
        TruckTransaction transaction = truckTransactionMapper.selectByPrimaryKey(id);
        if (transaction == null) {
            return WrapMapper.error("信息不存在");
        }
        TruckTransactionVo transactionVo = new TruckTransactionVo();
        transactionVo.setTruckTransaction(transaction);
        UacUserVo uacUserVo = userServiceFeignApi.getUserById(transaction.getUserId());
        transactionVo.setPhone(uacUserVo.getPhone());
        transactionVo.setUserName(uacUserVo.getRealName());
        return WrapMapper.ok(transactionVo);
    }

    @Override
    public Wrapper<PageInfo<TruckTransaction>> getTrucksOwnerPage(TruckTransaction truckTransaction, Integer page, Integer size) {
        PageHelper.startPage(page, size);
        List<TruckTransaction> list = truckTransactionMapper.getTrucksOwnerPage(truckTransaction);
        PageInfo<TruckTransaction> pageInfo = new PageInfo(list);
        return WrapMapper.ok(pageInfo);
    }

    @Override
    public Wrapper exitSaleState(Long id, Long userId) {
        if (userId == null) {
            return WrapMapper.error("用户非法，操作失败。");
        }
        TruckTransaction truckTransaction = new TruckTransaction();
        truckTransaction.setId(id);
        truckTransaction.setUserId(userId);
        TruckTransaction current=truckTransactionMapper.selectByPrimaryKey(id);
        if(current==null){
            return WrapMapper.error("车辆不存在");
        }
        int i = truckTransactionMapper.delete(truckTransaction);
        if(current.getSaleType().intValue()==1){
            int a=truckTransactionMapper.selectCountByTruckId(current.getTruckId());
            if(a==0){
                Truck truck=new Truck();
                truck.setId(current.getTruckId());
                truck.setSaleState((byte) 2);
                truckMapper.updateByPrimaryKeySelective(truck);
            }
        }
        if (i > 0) {
            return WrapMapper.ok("取消成功");
        }
        return WrapMapper.ok("取消失败");
    }
}
