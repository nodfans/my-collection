package com.ddcx.app.provider.exam.service;


import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;

/**
 * Created by CodeGenerator on 2020/03/11.
 */
public interface UacLearnInformationService {

    Wrapper getInfoByType(Byte type, LoginAuthDto dto);

    Wrapper detail(Long id, LoginAuthDto dto);

}
