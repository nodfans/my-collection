package com.ddcx.common.provider.api;

/**
 * redisKey存放位置
 */
public interface RedisKey {

    //品牌列表
    String BRAND_LIST = "BRAND_LIST";
    //数据字典列表
    String DICTIONARY_LIST = "DICTIONARY_LIST";

    //后台用户前缀
    String ADMIN_USER = "ADMIN_USER";

    //后台用户前缀
    String ADMIN_FUNCTION = "ADMIN_FUNCTION";


    String BANK_BIN = "BANK_BIN:";

    //后台控制账户的范围
    String MANAGER_IDS="MANAGER_IDS";
    //后台控制司机的范围
    String DRIVER_IDS="DRIVER_IDS";
    //后台控制车队的范围
    String MOTORCADE_IDS="MOTORCADE_IDS";
    //后台控制车辆的范围
    String TRUCK_IDS="TRUCK_IDS";
    //后台账户token
    String ADMIN_LOGIN="ADMIN_LOGIN";
    //系统配置键
    String SYS_CONFIG="SYS_CONFIG";
    //贷款配置<已废弃>
    String LOAN_CONFIG="LOAN_CONFIG";
    //考试分值配置
    String EXAM_SCORE_CONFIG="EXAM_SCORE_CONFIG:";

    //省
    String BS_PROVINCE  =  "BS_PROVINCE";
    //市
    String BS_CITY  =  "BS_CITY";
    //区
    String BS_AREA  =  "BS_AREA";
    //街道
    String BS_STREET  =  "BS_STREET";
    //全部
    String CN_REGION_INFO  =  "CN_REGION_INFO";
    //保存年检信息//放redis毫无意义
    String SUBSCRIBE_CONFIG = "SUBSCRIBE_CONFIG";

    //智云信息
    String ZHIYUN_TOKEN="ZHIYUN_TOKEN";


    //考场主键
    String EXAM_KEY="EXAM_KEY:";
    //考场信息
    String EXAM_ROOM="EXAM_ROOM:";
    //考场考试时间
    String EXAM_TIME="EXAM_TIME:";
    //考题列表
    String QUESTION_KEY="QUESTION_KEY:";
    //答案列表
    String QUESTION_ANSWER="QUESTION_ANSWER:";
    //标记用户已经考试
    String ALREADY_EXAM="ALREADY_EXAM:";



    //支付宝预支付订单存放
    String ALI_ORDER_NUMBER="ALI_ORDER_NUMBER";
    //微信
    String WX_ORDER_NUMBER="WX_ORDER_NUMBER";
    //银联
    String YL_ORDER_NUMBER="YL_ORDER_NUMBER";


    //Excel下载链接验证码
    String DOWNLOAD_EXCEL="DOWNLOAD_EXCEL:";

}
