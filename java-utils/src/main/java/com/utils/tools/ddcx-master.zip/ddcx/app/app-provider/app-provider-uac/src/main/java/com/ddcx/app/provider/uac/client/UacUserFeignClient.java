package com.ddcx.app.provider.uac.client;

import com.alibaba.fastjson.JSON;
import com.ddcx.app.provider.api.uac.model.dto.UacCheckAccountDto;
import com.ddcx.app.provider.api.uac.model.vo.UacUserVo;
import com.ddcx.app.provider.api.uac.service.UacUserServiceFeignApi;
import com.ddcx.app.provider.uac.mapper.UacUserAuthMapper;
import com.ddcx.app.provider.uac.mapper.UserBacklogMapper;
import com.ddcx.app.provider.uac.service.UacUserService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.model.uac.IdAuth;
import com.ddcx.model.uac.UacUser;
import com.ddcx.model.uac.UacUserAuth;
import com.ddcx.model.uac.UserBacklog;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RefreshScope
@RestController
public class UacUserFeignClient extends BaseController implements UacUserServiceFeignApi {

    @Autowired
    private UacUserService uacUserService;
    @Resource
    private UacUserAuthMapper authMapper;
    @Resource
    private UserBacklogMapper backlogMapper;

    @Override
    public UacUserVo getUserByPhone(UacCheckAccountDto uacCheckAccountDto) {
        UacUserVo uacUserVo = null;
        UacUser uacUser = uacUserService.getByPhone(uacCheckAccountDto.getAccount());
        if (PublicUtil.isNotEmpty(uacUser)) {
            uacUserVo = new ModelMapper().map(uacUser, UacUserVo.class);
        }
        return uacUserVo;
    }

    @Override
    public UacUserVo getUserById(Long id) {
        UacUserVo uacUserVo = null;
        UacUser uacUser = uacUserService.getById(id);
        if (PublicUtil.isNotEmpty(uacUser)) {
            uacUserVo = new ModelMapper().map(uacUser, UacUserVo.class);
        }
        return uacUserVo;
    }

    @Override
    public IdAuth getAuthInfo(Long userId) {
        UacUserAuth auth=authMapper.selectByUserId(userId);
        if(auth==null){
            return null;
        }
        IdAuth idAuth= JSON.parseObject(auth.getIdAuth(),IdAuth.class);
        return idAuth;
    }

    @Override
    public Integer addUserBackLog(UserBacklog backlog) {
        int i=backlogMapper.insert(backlog);
        return i;
    }

    @Override
    public Integer addAllUserBackLog(List<UserBacklog> backlogs) {
        int i=backlogMapper.insertList(backlogs);
        return i;
    }

    @Override
    public UacUser getUser(Long id) {
        UacUser user = uacUserService.getUacUser(id);
        return user;
    }

}
