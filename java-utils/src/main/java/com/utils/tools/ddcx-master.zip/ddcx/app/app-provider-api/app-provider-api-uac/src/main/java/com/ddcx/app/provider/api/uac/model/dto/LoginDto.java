package com.ddcx.app.provider.api.uac.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel(value = "LoginDto", description = "小程序登录信息")
@Data
public class LoginDto implements java.io.Serializable {

    private static final long serialVersionUID = -1356427061754644970L;

    @ApiModelProperty(value = "编码", name = "code", required = true)
    private String code;

    @ApiModelProperty(value = "加密数据", name = "encryptedData", required = true)
    private String encryptedData;

    @ApiModelProperty(value = "iv", name = "iv", required = true)
    private String iv;

    @ApiModelProperty(value = "登录类型：1 微信 2 手机号码", name = "type", required = true)
    private Integer type;

    @ApiModelProperty(value = "电话号码", name = "phone", required = true)
    private String phone;

    @ApiModelProperty(value = "验证码", name = "verifyCode", required = true)
    private String verifyCode;

    @ApiModelProperty(value = "用户信息", name = "userInfo")
    private LoginDto.UserInfo userInfo;

    @Data
    public static class UserInfo {

        @ApiModelProperty(value = "昵称", name = "nickName")
        private String nickName;

        @ApiModelProperty(value = "性别", name = "gender")
        private Integer gender;

        @ApiModelProperty(value = "头像", name = "gender")
        private String avatarUrl;
    }

}
