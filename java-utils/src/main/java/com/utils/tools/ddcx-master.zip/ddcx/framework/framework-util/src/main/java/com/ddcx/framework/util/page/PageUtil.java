package com.ddcx.framework.util.page;

import lombok.Data;

@Data
public class PageUtil {

    /**
     * The total row. 总条数
     */
    private int totalRow;

    /**
     * The total page.总页数
     */
    private int totalPage;

    /**
     * The start. 开始条数
     */
    private int pageNum;


    /**
     * The page size.每页条数
     */
    private int pageSize = 10;


    /**
     * Instantiates a new page util.
     */
    public PageUtil(int total, int pageNum, int pageSize) {
        this.totalRow = total;
        this.pageNum = pageNum;
        this.pageSize = pageSize;
        this.totalPage = (total + pageSize - 1) / pageSize;
    }

    /**
     * Instantiates a new page util.
     *
     * @param pageNum the current page
     */
    public PageUtil(int pageNum) {
        this.pageNum = pageNum;
    }

    /**
     * Instantiates a new page util.
     *
     * @param pageNum  the current page
     * @param pageSize the page size
     */
    public PageUtil(int pageNum, int pageSize) {
        this.pageNum = pageNum;
        this.pageSize = pageSize;
    }

}
