package com.ddcx.app.provider.friend.web;


import com.ddcx.app.provider.friend.service.FriendCircleReplyService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.friend.FriendCircle;
import com.ddcx.model.friend.FriendCircleReply;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/03/02.
 */
@RestController
@RequestMapping("/friend/circle/reply")
@Api(value = "卡友圈回复", tags = "卡友圈回复")
public class FriendCircleReplyController extends BaseController {
    @Resource
    private FriendCircleReplyService friendCircleReplyService;

    @ApiOperation("卡友圈回复")
    @PostMapping("saveFriendReply")
    public Wrapper saveFriendReply(@ApiParam(value = "卡友圈回复主体") @RequestBody FriendCircleReply reply) {
        return friendCircleReplyService.saveFriendReply(reply, getLoginAuthDto());
    }

    @ApiOperation("获取我的卡友圈回复列表")
    @GetMapping("/getOwnReply")
    public Wrapper<FriendCircle> getOwnReply(@ApiParam(value = "页数", defaultValue = "1") @RequestParam(defaultValue = "1") Integer page,
                                             @ApiParam(value = "每页记录数", defaultValue = "10") @RequestParam(defaultValue = "10") Integer size){
        return friendCircleReplyService.getOwnReply(page,size,getLoginAuthDto().getUserId());
    }
}
