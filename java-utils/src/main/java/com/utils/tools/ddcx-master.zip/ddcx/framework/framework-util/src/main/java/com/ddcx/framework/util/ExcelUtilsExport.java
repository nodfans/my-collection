package com.ddcx.framework.util;

import com.ddcx.framework.base.annotation.ExcelList;
import com.ddcx.framework.base.annotation.ExcelMap;
import com.ddcx.framework.base.annotation.ExcelName;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Excel导出
 */
public class ExcelUtilsExport {
    //Collection类型
    private final String LIST = "list";
    //Map类型
    private final String MAP = "map";
    //自定义对象类型
    private final String OBJECT = "object";
    //需要导出的级别
    private int level;
    //工作簿
    private XSSFWorkbook workbook;
    //工作表
    private XSSFSheet sheet;
    //行
    private XSSFRow row;
    //单元格
    private XSSFCell cell;
    //数据源
    private List data;
    //对于有对象中有集合的情况保存的初始数据源
    private List firstSource;
    //对于对象中有集合集合中有集合的情况存储的二次数据源
    private List secondSource;
    //基本属性集合(只含有ExcelName注解的属性)
    private List<Field> baseFields;
    //集合属性集合（只含有ExcelList注解的属性）
    private List<Field> eListFields;
    //只包含一个List属性的对象的属性存放位置
    private Field oneListFields;
    //对象内集合中对象属性集合
    private List<Field> listFields;
    //整合后的属性集合
    private List<Field> fields = new ArrayList<>();
    //对象的class对象
    private Class clazz;
    //从特定对象中取出的值
    private Object object;
    //从特定对象的子集合中取出的对象
    private Object secondObject;
    //对应的field属性
    private Field field;
    //当前所取到的属性值
    private Object value;
    //特定属性的ExcelName注解
    private ExcelName excelName;
    //单元格通用样式
    private XSSFCellStyle cellStyle;
    //表头样式
    private XSSFCellStyle titleCellStyle;
    //起始行下标
    private int startRow;
    //结束行下标
    private int endRow;

    public ExcelUtilsExport(List data, int level,Class clazz) {
        this.data = data;
        this.level = level; this.clazz=clazz;
        firstSource = data;
        init();
    }

    private void init() {
        workbook = new XSSFWorkbook();
        sheet = workbook.createSheet();
        cellStyle = workbook.createCellStyle();
        titleCellStyle = workbook.createCellStyle();
        initStyle();//初始化单元格样式
        if (data.size() == 0) {
            return;
        }
        clazz = data.get(0).getClass();
    }

    //团购计划单详情定制初始化
    public void grouppurchaseInit() throws IllegalAccessException {
        Object dataSource = firstSource.get(0);//转移数据对象
        clazz = dataSource.getClass();
        baseInit();
        for (Field eListField : eListFields) {
            eListField.setAccessible(true);
        }
        cycle(0, 2, dataSource);
        cycle(1, 2, dataSource);
        cycleList(2, 2, dataSource);
        cycle(3, 2, dataSource);
    }

    //生成横向平铺的对象集合显示类似于这样：----======
    private void cycleList(int i, int interval, Object dataSource) throws IllegalAccessException {
        startRow = endRow + interval;
        clazz = eListFields.get(i).getAnnotation(ExcelList.class).value();
        fields.clear();
        data = (List) eListFields.get(i).get(dataSource);
        listInit();
    }

    //带有集合的数据填充
    private void fillListData() throws IllegalAccessException {
        endRow = startRow + 1;
        for (int i = 0; i < data.size(); i++, endRow++) {
            object = data.get(i);
            oneListFields.setAccessible(true);
            secondSource = (List) oneListFields.get(object);
            row = sheet.createRow(endRow);
            for (int j = 0; j < fields.size(); j++) {
                if (j < baseFields.size()) {
                    if (secondSource.size() > 1) {//进行单元格合并
                        mergeCells(endRow, endRow + secondSource.size() - 1, j, j);
                    }
                    setValue(j);
                } else {
                    for (int k = 0; k < secondSource.size(); k++) {
                        secondObject = secondSource.get(k);
                        if (k > 0) {
                            row = sheet.createRow(++endRow);
                        }
                        for (int m = j; m < fields.size(); m++) {
                            object = secondObject;
                            setValue(m);
                        }
                    }
                    j = fields.size();
                }
            }
        }
    }

    //主集合对象属性填值
    private void setValue(int j) throws IllegalAccessException {
        field = fields.get(j);
        excelName = field.getAnnotation(ExcelName.class);
        field.setAccessible(true);
        cell = row.createCell(j);
        dataStyle();
        cell.setCellStyle(cellStyle);
        value = field.get(object);
        fillValue();
    }

    //执行一次基础生成 i为集合下标 interval为两次循环生成数据的间隔行数
    private void cycle(int i, int interval, Object dataSource) throws IllegalAccessException {
        startRow = endRow + interval;
        clazz = eListFields.get(i).getAnnotation(ExcelList.class).value();
        fields.clear();
        data = (List) eListFields.get(i).get(dataSource);
        baseInit();
    }

    //基础数据类型初始化
    public void baseInit() {
        fillFields();//获取属性集合
        fillHeader();//设置表头
        try {
            if(data.size()>0){
                fillData();  //填充数据
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    //类带有ExcelList注解且只含一个集合的数据类型初始化
    public void listInit() {
        fillFields();//获取属性集合
        fillHeader();//设置表头
        try {
            fillListData();  //填充数据
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    //填充fields属性
    private void fillFields() {
        parseBaseField();
        if (containsCollection() || containsMap()) {
            parseCollection((ExcelList) clazz.getAnnotation(ExcelList.class));
            fields.addAll(baseFields);
            fields.addAll(listFields);
        } else {
            fields.addAll(baseFields);
        }
    }
//    //设置表格密码 暂时没效果
//    private void protectedSheet(){
//        sheet.setSheetPassword("123456",HashAlgorithm.md5);
//    }

    //填充表头
    private void fillHeader() {
        row = sheet.createRow(startRow);
        for (int i = 0; i < fields.size(); i++) {
            cell = row.createCell(i);
            excelName = fields.get(i).getAnnotation(ExcelName.class);
            if (excelName.value().length() * 800 > sheet.getColumnWidth(i)) {
                sheet.setColumnWidth(i, excelName.value().length() * 800);
            }
            titleCellStyle.cloneStyleFrom(cell.getCellStyle());
            titleStyle();
            cell.setCellStyle(titleCellStyle);
            cell.setCellValue(excelName.value());
        }
    }

    //填充数据
    private void fillData() throws IllegalAccessException {
        endRow = startRow + 1;
        for (int i = 0; i < data.size(); i++, endRow++) {
            object = data.get(i);
            row = sheet.createRow(endRow);
            for (int j = 0; j < fields.size(); j++) {
                setValue(j);
            }
        }
    }

    //单元格填值
    private void fillValue() throws IllegalAccessException {
        if (value == null) {
            cell.setCellValue("空");
        } else if (excelName.isTimestamp()&&value instanceof Long) {
            cell.setCellValue(LocalDate.ofEpochDay((Long)value/24/3600).format(DateTimeFormatter.ofPattern(excelName.timePattern())));
        } else if (value instanceof Byte && excelName.replaceNumber().length > 0) {
            cell.setCellValue(excelName.replaceNumber()[((Byte) value).intValue()]);
        } else if (value instanceof Integer && excelName.replaceNumber().length > 0) {
            cell.setCellValue(excelName.replaceNumber()[((Integer) value).intValue()]);
        } else {
            cell.setCellValue(value.toString());
        }
    }

    /**
     * @param hAlignment 水平对齐样式
     * @param vAlignment 垂直对齐样式
     */
    private void cellStyleAlignment(XSSFCellStyle cellStyle, HorizontalAlignment hAlignment, VerticalAlignment vAlignment) {
        cellStyle.setAlignment(HorizontalAlignment.CENTER);//水平对齐方式
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);//垂直对齐方式
    }

    /**
     * @param borderStyle 边框样式
     * @param color       边框颜色
     */
    private void cellStyleBolder(XSSFCellStyle cellStyle, BorderStyle borderStyle, IndexedColors color) {
        cellStyle.setBorderBottom(borderStyle);
        cellStyle.setBorderLeft(borderStyle);
        cellStyle.setBorderRight(borderStyle);
        cellStyle.setBorderTop(borderStyle);
        cellStyle.setBottomBorderColor(color.getIndex());
        cellStyle.setLeftBorderColor(color.getIndex());
        cellStyle.setRightBorderColor(color.getIndex());
        cellStyle.setTopBorderColor(color.getIndex());
    }

    /**
     * @param backColor 背景颜色
     * @param foreColor 外景颜色
     * @param type      背景样式
     */
    private void cellStyleBackground(XSSFCellStyle cellStyle, IndexedColors backColor, IndexedColors foreColor, FillPatternType type) {
        cellStyle.setFillForegroundColor(foreColor.getIndex());//前景颜色（必须设置在背景颜色之前）
        cellStyle.setFillBackgroundColor(backColor.getIndex());//背景颜色设置
        cellStyle.setFillPattern(type);//背景样式
    }

    /**
     * @param cellStyle     样式对象
     * @param bold          是否加粗
     * @param color         颜色
     * @param fontFamily    字体
     * @param height        字高
     * @param italic        是否斜体
     * @param strikeout     是否有删除线
     * @param fontUnderline 下划线类型
     */
    private void cellStyleFont(XSSFCellStyle cellStyle, boolean bold, IndexedColors color, FontFamily fontFamily, short height, boolean italic, boolean strikeout, FontUnderline fontUnderline) {
        XSSFFont font = workbook.createFont();
        font.setBold(bold);//字体加粗
        font.setColor(color.getIndex());//字体颜色
        font.setFamily(fontFamily);//设置字体
        font.setFontHeightInPoints(height);//设置字体高度为11像素
        font.setItalic(italic);//斜体
        font.setStrikeout(strikeout);//删除线
        font.setUnderline(fontUnderline);//下划线
        cellStyle.setFont(font);//设置字体
    }

    //标题样式
    private void titleStyle() {
        cellStyleAlignment(titleCellStyle, HorizontalAlignment.CENTER, VerticalAlignment.CENTER);
        cellStyleFont(titleCellStyle, true, IndexedColors.LIGHT_BLUE, FontFamily.NOT_APPLICABLE, (short) 15, false, false, FontUnderline.NONE);
//        cellStyleBackground(titleCellStyle,IndexedColors.BLACK,IndexedColors.GREY_40_PERCENT,FillPatternType.SOLID_FOREGROUND);
//        cellStyleBolder(titleCellStyle,BorderStyle.THIN,IndexedColors.GREY_80_PERCENT);
    }

    //数据样式
    private void dataStyle() {
//        cellStyleAlignment(cellStyle,HorizontalAlignment.CENTER,VerticalAlignment.CENTER);
//        cellStyleFont(cellStyle,false,IndexedColors.BLACK,FontFamily.NOT_APPLICABLE, (short) 12,false,false,FontUnderline.NONE);
    }

    //初始化样式
    private void initStyle() {
        cellStyle.setAlignment(HorizontalAlignment.CENTER);//水平对齐方式
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);//垂直对齐方式
//        cellStyle.setBorderBottom(BorderStyle.DASH_DOT);//底部边框样式
//        cellStyle.setBottomBorderColor(IndexedColors.BLUE.getIndex());//底部边框颜色
//        cellStyleBolder(cellStyle,BorderStyle.THIN,IndexedColors.GREY_80_PERCENT);
//        cellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());//前景颜色（必须设置在背景颜色之前）
//        cellStyle.setFillBackgroundColor(IndexedColors.SKY_BLUE.getIndex());//背景颜色设置
//        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);//背景样式
//        cellStyle.setHidden(true);//隐藏掉设置的样式
//        cellStyle.setIndention((short) 22);//缩进22个空格
//        cellStyle.setLocked(true);//设置使用此样式的单元格锁定
//        cellStyle.setRotation((short) 22);//设置单元格中文本的旋转程度
        cellStyle.setWrapText(false);//设置为true表示将在文本过长时进行换行使得所有内容可见
        XSSFFont font = workbook.createFont();
//        font.setBold(true);//字体加粗
//        font.setColor(IndexedColors.RED.getIndex());//字体颜色
//        font.setFamily(FontFamily.MODERN);//设置字体
//        font.setFontHeightInPoints((short) 22);//设置字体高度为11像素
        font.setItalic(false);//斜体
        font.setStrikeout(false);//删除线
        font.setUnderline(FontUnderline.NONE);//下划线
        cellStyle.setFont(font);//设置字体
    }

    /**
     * 合并单元格
     *
     * @param firstRow 起始行
     * @param lastRow  结束行
     * @param firstCol 起始列
     * @param lastCol  结束列
     */
    private void mergeCells(int firstRow, int lastRow, int firstCol, int lastCol) {
        sheet.addMergedRegion(new CellRangeAddress(firstRow, lastRow, firstCol, lastCol));
        //此处处理合并后的单元格样式不全问题
    }

    //获取目标对象数据结构
    private String dataStructure() {
        if (data instanceof List)
            return LIST;
        if (data instanceof Map)
            return MAP;
        return OBJECT;
    }

    //判断对象中是否拥有集合
    private boolean containsCollection() {
        return !(clazz.getAnnotation(ExcelList.class) == null);
    }

    //判断对象中是否拥有map集合
    private boolean containsMap() {
        return !(clazz.getAnnotation(ExcelMap.class) == null);
    }

    //解析对象基本属性
    private void parseBaseField() {
        baseFields = Arrays.asList(clazz.getDeclaredFields());
        if (startRow == 0) {
            eListFields = baseFields.stream().filter(field1 -> field1.getAnnotation(ExcelList.class) != null).collect(Collectors.toList());
        } else if (containsCollection()) {
            oneListFields = baseFields.stream().filter(field1 -> field1.getAnnotation(ExcelList.class) != null).collect(Collectors.toList()).get(0);
        }
        baseFields = baseFields.stream().filter(field -> field.getAnnotation(ExcelName.class) != null && field.getAnnotation(ExcelName.class).level() <= level).collect(Collectors.toList());
    }

    //解析对象Collection集合属性
    private void parseCollection(ExcelList collection) {
        listFields = Arrays.asList(collection.value().getDeclaredFields());
        listFields = listFields.stream().filter(field -> field.getAnnotation(ExcelName.class) != null).collect(Collectors.toList());
    }

    //解析对象Map集合属性
    private void parseMap() {

    }

    /**
     * excel数据导出
     *
     * @param request
     * @param response
     * @param fileName 文件名
     * @throws IOException
     */
    public void importExcel(HttpServletRequest request, HttpServletResponse response, String fileName) throws IOException {
        String header = request.getHeader("User-Agent").toUpperCase();
        if (header.contains("MSIE") || header.contains("TRIDENT") || header.contains("EDGE")) {
            fileName = URLEncoder.encode(fileName, "utf-8");
        }
        fileName = fileName.replace("+", "%20"); //IE下载文件名空格变+号问题 } else { fileName = new String(fileName.getBytes(), "ISO8859-1"); }
        OutputStream os = response.getOutputStream();
        String name = new String((fileName + ".xlsx").getBytes(), "ISO-8859-1");
        response.setHeader("Content-Type", "application/vnd.ms-excel");
        response.setHeader("Content-disposition", "attachment; filename=" + name);
        workbook.write(os);
        os.flush();
        os.close();
    }


}
