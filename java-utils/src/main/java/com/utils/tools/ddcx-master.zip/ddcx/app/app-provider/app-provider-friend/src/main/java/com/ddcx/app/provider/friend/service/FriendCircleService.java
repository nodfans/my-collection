package com.ddcx.app.provider.friend.service;


import com.ddcx.app.provider.api.friend.model.vo.FriendCircleVo;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.friend.FriendCircle;
import com.github.pagehelper.PageInfo;

/**
 * Created by CodeGenerator on 2020/03/02.
 */
public interface FriendCircleService {

    /**
     * 添加朋友圈
     *
     * @param friendCircle 朋友圈信息
     * @param loginAuthDto 当前用户信息
     * @return
     */
    Wrapper saveFriendCircle(FriendCircle friendCircle, LoginAuthDto loginAuthDto);


    /**
     * 参数查找卡友圈
     *
     * @param page
     * @param size
     * @param param
     * @return
     */
    Wrapper<PageInfo<FriendCircle>> getFriendCircle(Integer page, Integer size, String param,LoginAuthDto dto);


    Wrapper getOwnFriendCircle(Integer page, Integer size,LoginAuthDto dto);

    /**
     * 获取卡友圈详情
     *
     * @param id
     * @return
     */
    Wrapper<FriendCircleVo> getFriendCircleDetail(Long id,LoginAuthDto dto);


    /**
     * 删除卡友圈
     *
     * @param id
     * @param userId
     * @return
     */
    Wrapper deleteFriendCircle(Long id, Long userId);
}
