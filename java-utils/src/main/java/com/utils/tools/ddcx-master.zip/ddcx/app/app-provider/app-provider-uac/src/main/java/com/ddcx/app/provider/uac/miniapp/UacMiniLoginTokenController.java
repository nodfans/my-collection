package com.ddcx.app.provider.uac.miniapp;


import com.ddcx.app.provider.api.uac.model.dto.LoginDto;
import com.ddcx.app.provider.api.uac.model.vo.UacLoginTokenVo;
import com.ddcx.app.provider.uac.service.UacLoginTokenService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/mini/user")
@Api(value = "登录---小程序", tags = {"登录---小程序"})
public class UacMiniLoginTokenController extends BaseController {


    @Autowired
    private UacLoginTokenService tokenService;

    /**
     * 登录获取token
     */
    @ApiOperation(value = "获取token", notes = "获取token")
    @PostMapping(value = "/token")
    public synchronized Wrapper<UacLoginTokenVo> login(@RequestBody LoginDto loginDto) {
        final UacLoginTokenVo loginTokenVo = tokenService.getToken(loginDto);
        return WrapMapper.ok(loginTokenVo);
    }

}
