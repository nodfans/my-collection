package com.ddcx.common.provider.controller;


import com.ddcx.common.provider.api.model.vo.MessageVo;
import com.ddcx.common.provider.service.MessageService;
import com.ddcx.framework.base.dto.AdminLoginAutoDto;
import com.ddcx.framework.base.dto.BaseQueryDto;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.PageWrapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.common.MessageConfig;
import com.ddcx.web.provider.api.uac.model.dto.MessageDto;
import com.ddcx.web.provider.api.uac.model.vo.UacRescueListVo;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/02.
 */
@RestController
@RequestMapping("/message")
@Api(value = "消息模块", tags = "消息模块")
public class MessageController extends BaseController {
    @Resource
    private MessageService messageService;

    @ApiOperation("获取用户未读消息数量")
    @GetMapping("/getUserNoReadNum")
    public Wrapper<MessageVo> getUserNoReadNum() {
        return messageService.getUserNoReadNum(getLoginAuthDto().getUserId());
    }

    @ApiOperation("根据类型获取用户消息列表（分页）")
    @GetMapping("/getMessageListByType")
    public Wrapper<PageInfo<MessageVo>> getMessageListByType(@RequestParam(value = "page", defaultValue = "1") Integer page,
                                                           @RequestParam(value = "size", defaultValue = "10") Integer size,
                                                           @ApiParam(value = "消息类型(1.系统消息 2.优惠消息 3.救援消息 4.学习消息<requestUrl==1 跳转文字学习列表，==2，跳转视频学习列表><如果是求援消息则id存放此处>)", required = true) @RequestParam Integer type) {
        return messageService.getMessageListByType(page, size, getLoginAuthDto().getUserId(), type);
    }


    @ApiOperation("标记已读")
    @GetMapping("/alreadyReadTag")
    public Wrapper alreadyReadTag(@ApiParam(value = "消息id", required = true) Long id) {
        return messageService.alreadyReadTag(id, getLoginAuthDto().getUserId());
    }

    // 系统转过来
    @ApiOperation("后台---消息列表")
    @GetMapping("/admin/list")
    public Wrapper<PageInfo<MessageConfig>> list(@ApiParam("参数") BaseQueryDto baseQueryDto, @Param("title") String title, @Param("createBy") Long createBy, @ApiParam("时间") Long date) {
        return messageService.list(baseQueryDto,title,createBy,date);
    }

    @ApiOperation("后台---发送系统消息")
    @PostMapping("/admin/publish")
    public Wrapper publishSystemMessage(@RequestBody MessageDto messageDto) {
        AdminLoginAutoDto adminLoginAuthDto = getAdminLoginAuthDto();
        return messageService.publishSystemMessage(messageDto, adminLoginAuthDto.getId());
    }

    @ApiOperation("后台---编辑<改删除---》新增>")
    @PostMapping("/admin/update")
    public Wrapper update(@RequestBody MessageConfig config) {
        return messageService.update(config, getAdminLoginAuthDto().getId());
    }


    @ApiOperation("后台---删除系统消息")
    @DeleteMapping("/admin/delete")
    public Wrapper deleteSystemMessage(@ApiParam("编号") @RequestParam("ids") List<Long> ids) {
        return messageService.deleteSystemMessage(ids);
    }


    @ApiOperation("后台---救援消息列表")
    @GetMapping("/admin/get/rescue/list")
    public PageWrapper<List<UacRescueListVo>> getRescueList(BaseQueryDto baseQueryDto) {
        return messageService.getRescueList(baseQueryDto);
    }


    @ApiOperation("后台---删除救援消息列表")
    @DeleteMapping("/admin/delete/rescue/list")
    public Wrapper deleteRescueList(@ApiParam("编号") @RequestParam("ids") List<Long> ids) {
        return messageService.deleteRescueList(ids);
    }

    @ApiOperation("标记已读")
    @GetMapping("/testJpush")
    public Wrapper testJpush(@ApiParam(value = "推送标题", required = true) String title,
                             @ApiParam(value = "推送内容", required = true) String content) {
        return messageService.testJpush(title,content, getLoginAuthDto());
    }


}
