package com.ddcx.model.loan;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.math.BigDecimal;

@Table(name = "loan_pay_record")
@ApiModel("支付记录表")
public class LoanPayRecord {
    /**
     * 支付宝、微信、银联订单号
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("支付宝、微信、银联订单号")
    private Long id;

    /**
     * 1.微信 2.支付宝 3.银联
     */
    @ApiModelProperty("1.微信 2.支付宝 3.银联")
    private Byte type;

    /**
     * 付款金额
     */
    @Column(name = "pay_money")
    @ApiModelProperty("付款金额")
    private BigDecimal payMoney;

    /**
     * 付款时间
     */
    @Column(name = "pay_date_time")
    @ApiModelProperty("付款时间")
    private Long payDateTime;

    /**
     * 还款期次主键
     */
    @Column(name = "item_id")
    @ApiModelProperty("还款期次主键")
    private Long itemId;

    @Column(name="order_number")
    @ApiModelProperty("支付订单号")
    private String orderNumber;

    /**
     * 还款期次主键
     */
    @Column(name = "source_data")
    @ApiModelProperty("支付回调数据源")
    private String sourceData;

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getSourceData() {
        return sourceData;
    }

    public void setSourceData(String sourceData) {
        this.sourceData = sourceData;
    }

    /**
     * 获取支付宝、微信、银联订单号
     *
     * @return id - 支付宝、微信、银联订单号
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置支付宝、微信、银联订单号
     *
     * @param id 支付宝、微信、银联订单号
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取1.微信 2.支付宝 3.银联
     *
     * @return type - 1.微信 2.支付宝 3.银联
     */
    public Byte getType() {
        return type;
    }

    /**
     * 设置1.微信 2.支付宝 3.银联
     *
     * @param type 1.微信 2.支付宝 3.银联
     */
    public void setType(Byte type) {
        this.type = type;
    }

    /**
     * 获取付款金额
     *
     * @return pay_money - 付款金额
     */
    public BigDecimal getPayMoney() {
        return payMoney;
    }

    /**
     * 设置付款金额
     *
     * @param payMoney 付款金额
     */
    public void setPayMoney(BigDecimal payMoney) {
        this.payMoney = payMoney;
    }

    /**
     * 获取付款时间
     *
     * @return pay_date_time - 付款时间
     */
    public Long getPayDateTime() {
        return payDateTime;
    }

    /**
     * 设置付款时间
     *
     * @param payDateTime 付款时间
     */
    public void setPayDateTime(Long payDateTime) {
        this.payDateTime = payDateTime;
    }

    /**
     * 获取还款期次主键
     *
     * @return item_id - 还款期次主键
     */
    public Long getItemId() {
        return itemId;
    }

    /**
     * 设置还款期次主键
     *
     * @param itemId 还款期次主键
     */
    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }
}