package com.ddcx.common.provider.init;

import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.common.provider.mapper.CommonBankBinMapper;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.model.common.CommonBankBin;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

@Component
@Slf4j
public class BankCardInit {

    @Autowired
    private CommonBankBinMapper commonBankBinMapper;

    @Autowired
    private RedisUtil redisUtil;

    @PostConstruct
    public void init() {
        log.info("初始化银行卡数据");
        List<CommonBankBin> commonBankBins = commonBankBinMapper.selectAll();
        loadData(commonBankBins);
    }

    private void loadData(List<CommonBankBin> commonBankBins) {
        Long startTime = System.currentTimeMillis() / 1000L;
        int BANK_BIN_SIZE = redisUtil.getKeyCount(RedisKey.BANK_BIN + "*");
        log.info("BANK_BIN size--->>>" + BANK_BIN_SIZE);
        if (BANK_BIN_SIZE == commonBankBins.size()) {
            log.info("银行卡数据mysql和redis已同步，不用插入缓存");
            return;
        }
        int count = 100;
        int listSize = commonBankBins.size();
        int runSize = (listSize / count) + 1;
        ThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(runSize);
        CountDownLatch countDownLatch = new CountDownLatch(runSize);
        for (int i = 0; i < runSize; i++) {
            List<CommonBankBin> newCommonBankBins = null;
            if ((i + 1) == runSize) {
                int startIndex = (i * count);
                int endIndex = commonBankBins.size();
                newCommonBankBins = commonBankBins.subList(startIndex, endIndex);
            } else {
                int startIndex = i * count;
                int endIndex = (i + 1) * count;
                newCommonBankBins = commonBankBins.subList(startIndex, endIndex);
            }
            List<CommonBankBin> finalNewCommonBankBins = newCommonBankBins;
            executor.execute(() -> {
                if (PublicUtil.isNotEmpty(finalNewCommonBankBins)) {
                    for (CommonBankBin commonBankBin : finalNewCommonBankBins) {
                        redisUtil.set(RedisKey.BANK_BIN + commonBankBin.getCardBin() + ":" + commonBankBin.getCardSize(), commonBankBin);
                    }
                }
                countDownLatch.countDown();
            });
        }
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            log.error(e.getMessage());
        }
        executor.shutdown();
        Long endTime = System.currentTimeMillis() / 1000L;
        Long time = endTime - startTime;
        log.info("time--->>>" + time);
    }
}
