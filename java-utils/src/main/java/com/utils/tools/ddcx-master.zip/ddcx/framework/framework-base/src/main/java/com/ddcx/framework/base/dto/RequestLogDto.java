package com.ddcx.framework.base.dto;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RequestLogDto implements java.io.Serializable {

    private static final long serialVersionUID = -79749434392099914L;
    private Long id;

    /**
     * 日志类型
     */
    private Integer logType;

    /**
     * 日志类型名称
     */
    private String logName;

    /**
     * IP地址
     */
    private String ip;

    /**
     * 操作位置
     */
    private String location;

    /**
     * 物理地址
     */
    private String mac;

    /**
     * 详细描述
     */
    private String description;

    /**
     * 请求参数
     */
    private String requestData;

    /**
     * 请求地址
     */
    private String requestUrl;

    /**
     * 响应结果
     */
    private String responseData;

    /**
     * 类名
     */
    private String className;

    /**
     * 方法名
     */
    private String methodName;

    /**
     * 开始时间
     */
    private Long startTime;

    /**
     * 结束时间
     */
    private Long endTime;

    /**
     * 耗时,秒
     */
    private Long excuteTime;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建人ID
     */
    private Long createdId;

    /**
     * 创建时间
     */
    private Long createdTime;

}
