package com.ddcx.app.provider.api.truck.model.enums;


public enum Result {
    success(200, "操作成功"), fail(400, "操作失败");

    private int code;
    private String msg;

    Result(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
