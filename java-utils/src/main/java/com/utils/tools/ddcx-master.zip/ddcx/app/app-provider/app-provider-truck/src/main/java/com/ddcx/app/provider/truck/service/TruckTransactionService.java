package com.ddcx.app.provider.truck.service;


import com.ddcx.app.provider.api.truck.model.vo.TruckTransactionVo;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.TruckTransaction;
import com.github.pagehelper.PageInfo;

/**
 * Created by CodeGenerator on 2020/02/25.
 */
public interface TruckTransactionService {

    /**
     * 发布车辆（交易）信息
     *
     * @param truckTransaction
     * @return
     */
    Wrapper save(TruckTransaction truckTransaction, LoginAuthDto dto);


    /**
     * 获取车辆（交易）信息
     *
     * @param page
     * @param size
     * @param truckTransaction
     * @return
     */
    Wrapper<PageInfo<TruckTransaction>> getTrucksPage(Integer page, Integer size, TruckTransaction truckTransaction);


    /**
     * 获取车辆详情
     *
     * @param id 主键
     * @return
     */
    Wrapper<TruckTransactionVo> getTruckDetail(Integer id);


    /**
     * 查询该用户挂起的交易车辆
     *
     * @param truckTransaction 参数
     * @param page             当前页
     * @param size             每页记录数
     * @return
     */
    Wrapper<PageInfo<TruckTransaction>> getTrucksOwnerPage(TruckTransaction truckTransaction, Integer page, Integer size);

    /**
     * 移除交易汽车信息
     *
     * @param id     汽车《交易》主键
     * @param userId 当前用户id
     * @return
     */
    Wrapper exitSaleState(Long id, Long userId);
}
