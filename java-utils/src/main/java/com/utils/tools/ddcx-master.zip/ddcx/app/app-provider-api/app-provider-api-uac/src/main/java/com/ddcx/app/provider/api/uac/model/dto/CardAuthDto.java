package com.ddcx.app.provider.api.uac.model.dto;

import com.ddcx.model.uac.CardAuth;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@ApiModel("证件认证传递类")
@Data
public class CardAuthDto {
    @ApiModelProperty("主体")
    private CardAuth cardAuth;

    @NotNull
    @ApiModelProperty("证件类型： 2.驾驶证 3.从业资格证")
    private Integer type;
}
