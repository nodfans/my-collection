package com.ddcx.app.provider.truck.service.impl;


import com.ddcx.app.provider.truck.mapper.MotorcadeMapper;
import com.ddcx.app.provider.truck.service.MotorcadeService;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.Motorcade;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by CodeGenerator on 2020/03/09.
 */
@Service
@Transactional
public class MotorcadeServiceImpl implements MotorcadeService {
    @Resource
    private MotorcadeMapper motorcadeMapper;

    @Override
    public Wrapper getMotorcadeByComName(String comName) {
        List<Motorcade> list=motorcadeMapper.getMotorcadeByComName(comName);
        return WrapMapper.ok(list);
    }
}
