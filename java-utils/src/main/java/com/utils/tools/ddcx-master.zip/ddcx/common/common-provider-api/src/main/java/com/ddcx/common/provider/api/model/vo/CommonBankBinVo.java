package com.ddcx.common.provider.api.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "CommonBankCardVo", description = "银行卡信息")
public class CommonBankBinVo implements java.io.Serializable {

    private static final long serialVersionUID = 3915725035489038063L;

    @ApiModelProperty(value = "银行名称", name = "bankName")
    private String bankName;

    @ApiModelProperty(value = "银行代码", name = "bankCode")
    private String bankCode;

    @ApiModelProperty(value = "卡名称", name = "cardName")
    private String cardName;

    @ApiModelProperty(value = "卡类型 DC-储蓄卡，CC-信用卡(贷记卡)，SCC-准贷记卡，PC-预付费卡", name = "cardType")
    private String cardType;
}
