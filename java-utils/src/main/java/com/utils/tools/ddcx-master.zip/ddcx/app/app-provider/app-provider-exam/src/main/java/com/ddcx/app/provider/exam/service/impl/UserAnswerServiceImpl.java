package com.ddcx.app.provider.exam.service.impl;


import com.ddcx.app.provider.exam.mapper.UserAnswerMapper;
import com.ddcx.app.provider.exam.service.UserAnswerService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by CodeGenerator on 2020/04/14.
 */
@Service
@Transactional
public class UserAnswerServiceImpl  implements UserAnswerService {
    @Resource
    private UserAnswerMapper userAnswerMapper;

}
