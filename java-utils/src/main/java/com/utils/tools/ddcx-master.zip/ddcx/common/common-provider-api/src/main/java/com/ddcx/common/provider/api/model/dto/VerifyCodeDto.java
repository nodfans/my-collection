package com.ddcx.common.provider.api.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "VerifyCodeDto", description = "校验验证码")
public class VerifyCodeDto implements java.io.Serializable {

    private static final long serialVersionUID = 8251129458559818043L;

    @ApiModelProperty(value = "账号", name = "account", required = true)
    private String account;

    @ApiModelProperty(value = "验证码", name = "code", required = true)
    private String code;
}
