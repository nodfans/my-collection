package com.ddcx.app.provider.uac.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.ddcx.app.provider.api.uac.model.dto.UacFeedbackDto;
import com.ddcx.app.provider.uac.service.UacFeedbackService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.model.uac.UacFeedback;
import org.springframework.stereotype.Service;

@Service
public class UacFeedbackServiceImpl extends BaseService<UacFeedback> implements UacFeedbackService {

    @Override
    public Boolean create(LoginAuthDto loginAuthDto, UacFeedbackDto uacFeedbackDto) {
        UacFeedback createFeedback = new UacFeedback();
        createFeedback.setId(generateId());
        createFeedback.setContent(uacFeedbackDto.getContent());
        if (PublicUtil.isNotEmpty(uacFeedbackDto.getImgs())) {
            createFeedback.setImgs(JSONArray.parseArray(JSON.toJSONString(uacFeedbackDto.getImgs())).toJSONString());
        }
        createFeedback.setUserId(loginAuthDto.getUserId());
        createFeedback.setCreateTime(currentTime());
        if (insert(createFeedback) > 0) {
            return true;
        }
        return false;
    }
}
