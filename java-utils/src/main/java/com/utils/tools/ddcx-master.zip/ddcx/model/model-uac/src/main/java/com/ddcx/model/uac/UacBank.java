package com.ddcx.model.uac;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Data
@Table(name = "uac_bank")
@ApiModel("银行卡")
public class UacBank implements java.io.Serializable {
    private static final long serialVersionUID = -25601080888362014L;

    @Id
    @ApiModelProperty("主键")
    private Long id;
    /**
     * 用户ID
     */
    @ApiModelProperty("用户ID")
    private Long userId;
    /**
     * 卡号
     */
    @ApiModelProperty("卡号")
    private String cardNo;
    /**
     * 持卡人
     */
    @ApiModelProperty("持卡人")
    private String cardVest;
    /**
     * 银行编码
     */
    @ApiModelProperty("银行编码")
    private String bankCode;
    /**
     * 银行名称
     */
    @ApiModelProperty("银行名称")
    private String bankName;
    /**
     * 卡类型 DC：储蓄卡，CC：信用卡(贷记卡)，SCC：准贷记卡，PC：预付费卡
     */
    @ApiModelProperty("卡类型 DC：储蓄卡，CC：信用卡(贷记卡)，SCC：准贷记卡，PC：预付费卡")
    private String cardType;
    /**
     * 手机号码
     */
    @ApiModelProperty("手机号码")
    private String phone;
    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    private Long createTime;


    @ApiModelProperty("银行卡图标")
    @Transient
    private  String icon;

    @ApiModelProperty("银行卡背景")
    @Transient
    private String background;
}
