package com.ddcx.model.truck;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 存储汽车品牌（车型）
 */
@ApiModel(value = "汽车品牌")
@Data
public class BrandVo {

    @ApiModelProperty(value = "首字母")
    private String firstLetter;


    @ApiModelProperty(value = "品牌")
    private List<Brand> brand;

}
