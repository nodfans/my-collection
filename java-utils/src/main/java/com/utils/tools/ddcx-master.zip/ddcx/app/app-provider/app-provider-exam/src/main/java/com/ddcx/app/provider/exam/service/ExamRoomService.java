package com.ddcx.app.provider.exam.service;


import com.ddcx.app.provider.api.exam.param.ExamParam;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;

/**
 * Created by CodeGenerator on 2020/03/11.
 */
public interface ExamRoomService  {


    Wrapper getValidRooms(LoginAuthDto dto);

    Wrapper getQuestionsByRoomId(Long roomId, LoginAuthDto dto);

    Wrapper carryOutPaper(ExamParam param, LoginAuthDto dto);
}
