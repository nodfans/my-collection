package com.ddcx.app.provider.api.uac.enums;

public enum UacFromTypeEnum {
    /**
     * android
     */
    FROM_TYPE_ANDROID(1, "android"),
    /**
     * 邮箱
     */
    FROM_TYPE_IOS(2, "ios"),
    /**
     * PC
     */
    FROM_TYPE_PC(3, "pc");


    private Integer code;
    private String msg;

    public Integer code() {
        return code;
    }

    public String msg() {
        return msg;
    }

    UacFromTypeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
