package com.ddcx.app.provider.friend.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.friend.FriendCircle;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;

import java.util.List;


@Mapper
@Component
public interface FriendCircleMapper extends MyMapper<FriendCircle> {


    @Select("select * from friend_circle where nick_name like concat('%',#{param},'%') or text_content like concat('%',#{param},'%') order by create_time desc ")
    List<FriendCircle> getFriendCircle(@Param("param") String param);

    @Delete("delete from friend_circle where id=#{id} and user_id=#{userId}")
    int deleteById(@Param("id") Long id, @Param("userId") Long userId);

    @Select("select c.id,c.title,c.img_content,c.text_content,c.nick_name,c.head_img,r.create_time from friend_circle c " +
            "left join (select friend_circle_id id,user_id, MAX(create_time) create_time from friend_circle_reply GROUP BY friend_circle_id ,user_id) r on c.id=r.id where r.user_id=#{userId}  " +
            "order by r.create_time desc")
    List<FriendCircle> getOwnReply(@Param("userId")Long userId);

    @Select("select * from friend_circle where user_id=#{userId} order by create_time desc")
    List<FriendCircle> getOwnFriendCircle(@Param("userId") Long userId);

    @Update("<script> update friend_circle" +
            " <set>" +
            "<if test='userName != null'> " +
            " nick_name=#{userName}, " +
            "</if>" +
            "<if test='imgPath != null'> " +
            " head_img=#{imgPath} " +
            "</if>" +
            "</set>" +
            " where user_id=#{userId}" +
            "</script>")
    int updateUserHeadImgAndUserName(@Param("userId") Long userId, @Param("imgPath") String imgPath,@Param("userName") String userName);

}