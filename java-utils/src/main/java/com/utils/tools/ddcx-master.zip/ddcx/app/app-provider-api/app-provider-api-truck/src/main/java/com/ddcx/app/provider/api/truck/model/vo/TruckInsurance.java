package com.ddcx.app.provider.api.truck.model.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("车辆保险信息")
public class TruckInsurance {

    @ApiModelProperty("车牌号")
    private String truckNum;

    @ApiModelProperty("保险公司")
    private String truckInsuranceCompany;

    @ApiModelProperty("购买险种")
    private String truckInsuranceType;

    @ApiModelProperty("购买日期")
    private Long startDate;

    @ApiModelProperty("到期日期")
    private Long limitDate;

    public String getTruckNum() {
        return truckNum;
    }

    public void setTruckNum(String truckNum) {
        this.truckNum = truckNum;
    }

    public String getTruckInsuranceCompany() {
        return truckInsuranceCompany;
    }

    public void setTruckInsuranceCompany(String truckInsuranceCompany) {
        this.truckInsuranceCompany = truckInsuranceCompany;
    }

    public String getTruckInsuranceType() {
        return truckInsuranceType;
    }

    public void setTruckInsuranceType(String truckInsuranceType) {
        this.truckInsuranceType = truckInsuranceType;
    }

    public Long getStartDate() {
        return startDate;
    }

    public void setStartDate(Long startDate) {
        this.startDate = startDate;
    }

    public Long getLimitDate() {
        return limitDate;
    }

    public void setLimitDate(Long limitDate) {
        this.limitDate = limitDate;
    }

    public TruckInsurance() {
    }

    public TruckInsurance(String truckNum, String truckInsuranceCompany, String truckInsuranceType, Long startDate, Long limitDate) {
        this.truckNum = truckNum;
        this.truckInsuranceCompany = truckInsuranceCompany;
        this.truckInsuranceType = truckInsuranceType;
        this.startDate = startDate;
        this.limitDate = limitDate;
    }
}
