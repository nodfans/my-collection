package com.ddcx.model.uac;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@ApiModel("驾驶证，行驶证，从业资格证")
@Data
public class CardAuth {

    @ApiModelProperty("到期时间")
    private Long expireTime;

    @NotBlank
    @ApiModelProperty(value = "图片路径",required = true)
    private String img;


    @ApiModelProperty("行驶证副本图片路径")
    private String imgTranscript;


    @ApiModelProperty("状态 -1：审核失败，0：审核中，1：身份通过")
    private Byte state;

}
