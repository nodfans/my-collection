package com.ddcx.app.provider.uac.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ddcx.app.provider.api.uac.enums.UacErrorCodeEnum;
import com.ddcx.app.provider.api.uac.exception.UacBizException;
import com.ddcx.app.provider.api.uac.model.dto.LoginDto;
import com.ddcx.app.provider.api.uac.model.dto.UacLoginDto;
import com.ddcx.app.provider.api.uac.model.vo.UacLoginTokenVo;
import com.ddcx.app.provider.uac.mapper.UacUserMiniMapper;
import com.ddcx.app.provider.uac.service.UacLoginTokenService;
import com.ddcx.app.provider.uac.service.UacSourceLogService;
import com.ddcx.app.provider.uac.service.UacUserService;
import com.ddcx.app.provider.uac.utils.AesCbcUtil;
import com.ddcx.app.provider.uac.utils.WeChatConfig;
import com.ddcx.app.provider.uac.utils.WeUtil;
import com.ddcx.common.provider.api.enums.CommonErrorCodeEnum;
import com.ddcx.common.provider.api.exception.CommonBizException;
import com.ddcx.framework.base.constant.GlobalConstant;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.base.dto.VerifyCode;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.core.service.BaseService;
import com.ddcx.framework.util.PublicUtil;
import com.ddcx.framework.util.date.DateUtil;
import com.ddcx.framework.util.encrypt.Md5Utils;
import com.ddcx.framework.util.token.JwtUtil;
import com.ddcx.framework.util.token.TokenObject;
import com.ddcx.model.uac.UacUser;
import com.ddcx.model.uac.UacUserMini;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Map;

import static com.ddcx.app.provider.uac.service.UacUserService.VERIFY_CODE;

@Service
public class UacLoginTokenServiceImpl extends BaseService<UacUserMini> implements UacLoginTokenService {

    protected final Logger logger = LoggerFactory.getLogger(UacLoginTokenServiceImpl.class);


    @Value(value = "${token.secretKey}")
    private String token_secret_key;

    @Value(value = "${token.ttl}")
    private Integer token_ttl;

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private UacUserService userService;

    @Autowired
    private UacUserMiniMapper userMiniMapper;

    @Autowired
    private UacSourceLogService logService;


    @Override
    public UacLoginTokenVo token(UacLoginDto uacLoginDto) {
        UacUser uacUser = userService.getByPhone(uacLoginDto.getAccount());
        if(uacUser==null){
            throw  new UacBizException(UacErrorCodeEnum.UAC20000001);
        }
        if (uacUser.getState().intValue() == 0) {
            throw new UacBizException(UacErrorCodeEnum.UAC20000008);
        }
        if (PublicUtil.isEmpty(uacUser)) {
            throw new UacBizException(UacErrorCodeEnum.UAC20000001);
        }
        if (uacLoginDto.getLoginType().intValue() == 2 && !uacUser.getPassword().equals(Md5Utils.md5Str(uacLoginDto.getPassword()))) {
            throw new UacBizException(UacErrorCodeEnum.UAC20000002);
        }
        if (uacLoginDto.getLoginType().intValue() == 1) {
            VerifyCode verifyCode = (VerifyCode) redisUtil.get(VERIFY_CODE + ":" + uacLoginDto.getAccount());
            if (PublicUtil.isEmpty(verifyCode)) {
                throw new CommonBizException(CommonErrorCodeEnum.COMMON10000004);
            }
            if (!uacLoginDto.getCode().toLowerCase().equals(verifyCode.getCode())) {
                throw new CommonBizException(CommonErrorCodeEnum.COMMON10000004);
            }
            redisUtil.del(VERIFY_CODE + ":" + verifyCode.getAccount());
        }
        return generateToken(uacUser);
    }

    @Override
    public UacLoginTokenVo refreshToken(Long userId) {
        UacUser uacUser = userService.getById(userId);
        return generateToken(uacUser);
    }

    @Override
    public void deleteToken(Long userId) {
        redisUtil.del(GlobalConstant.Sys.LOGIN_TOKEN + ":" + userId);
    }

    @Override
    public UacLoginTokenVo generateToken(UacUser uacUser) {
        final Date nowDate = new Date();
        final Date expiresIn = DateUtil.addDay(nowDate, token_ttl);
        final JwtUtil.JWTInfo jwtInfo = new JwtUtil().createJWT(nowDate, expiresIn, new TokenObject(token_secret_key, uacUser.getId()));

        String token = Base64.encodeBase64URLSafeString(jwtInfo.getToken().getBytes());

        LoginAuthDto loginAuthDto = new LoginAuthDto();
        loginAuthDto.setUserId(uacUser.getId());
        loginAuthDto.setToken(token);
        loginAuthDto.setExpireTime(jwtInfo.getExpireIn());
        loginAuthDto.setUserType(uacUser.getUserType());
        loginAuthDto.setPhone(uacUser.getPhone());
        loginAuthDto.setNickName(uacUser.getNickName());
        loginAuthDto.setMotorcadeId(uacUser.getMotorcadeId());
        loginAuthDto.setUserName(uacUser.getRealName() == null ? uacUser.getPhone() : uacUser.getRealName());
        loginAuthDto.setHeadImg(uacUser.getHeadImg());
        loginAuthDto.setMotorcadeName(uacUser.getMotorcadeName());
        loginAuthDto.setComId(uacUser.getComId());
        loginAuthDto.setComName(uacUser.getComName());
        if(uacUser.getSex()!=null)
        loginAuthDto.setSex(uacUser.getSex()==1?"男":"女");

        UacLoginTokenVo uacLoginTokenVo = new UacLoginTokenVo();
        uacLoginTokenVo.setUserId(uacUser.getId());
        uacLoginTokenVo.setToken(token);
        uacLoginTokenVo.setExpireIn(jwtInfo.getExpireIn());
        uacLoginTokenVo.setUserType(uacUser.getUserType());
        uacLoginTokenVo.setState(uacUser.getState());
        uacLoginTokenVo.setHeadImg(uacUser.getHeadImg());
        redisUtil.set(GlobalConstant.Sys.LOGIN_TOKEN + ":" + loginAuthDto.getUserId(), loginAuthDto, 60 * 60 * 24 * token_ttl);
        return uacLoginTokenVo;
    }

    @Override
    public void refreshRedis(Long userId,String token){
        UacUser uacUser = userService.getById(userId);
        LoginAuthDto loginAuthDto = new LoginAuthDto();
        loginAuthDto.setUserId(uacUser.getId());
        loginAuthDto.setToken(token);
        loginAuthDto.setUserType(uacUser.getUserType());
        loginAuthDto.setPhone(uacUser.getPhone());
        loginAuthDto.setNickName(uacUser.getNickName());
        loginAuthDto.setMotorcadeId(uacUser.getMotorcadeId());
        loginAuthDto.setUserName(uacUser.getRealName() == null ? uacUser.getPhone() : uacUser.getRealName());
        loginAuthDto.setHeadImg(uacUser.getHeadImg());
        loginAuthDto.setMotorcadeName(uacUser.getMotorcadeName());
        loginAuthDto.setComId(uacUser.getComId());
        loginAuthDto.setComName(uacUser.getComName());
        System.out.println(JSON.toJSONString(loginAuthDto));
        redisUtil.set(GlobalConstant.Sys.LOGIN_TOKEN + ":" + loginAuthDto.getUserId(), loginAuthDto, 60 * 60 * 24 * token_ttl);
    }


    @Override
    public UacLoginTokenVo getToken(LoginDto loginDto) {
        if (PublicUtil.isNotEmpty(loginDto)) {
            // 先获取信息
            String atUtl = WeChatConfig.ACCESSTOKENURL + "?js_code=" + loginDto.getCode() + "&appid=" + WeChatConfig.APPID + "&secret=" + WeChatConfig.APPSECRET + "&grant_type=authorization_code";
            System.out.println(atUtl);
            Map<String, Object> map1 = null;
            try {
                map1 = WeUtil.sendGet(atUtl);
                logger.info("map WechartApplet--->>>" + map1.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
            String session_key = (String) map1.get("session_key");
            String openId = (String) map1.get("openid");
            if (PublicUtil.isEmpty(session_key) && PublicUtil.isEmpty(openId)) {
                return null;
            }
            if (PublicUtil.isEmpty(openId)) {
                return null;
            }
            // 微信授权登录
            if (1 == loginDto.getType()) {
                UacUser user = userService.getByPhone(getPhone(loginDto, session_key));
                if (PublicUtil.isNotEmpty(user)) {
                    if (user.getState().intValue() == 0) {
                        throw new UacBizException(UacErrorCodeEnum.UAC20000008);
                    }
                    // 第一次在小程序登录并且在APP登陆过的用户
                    if (null == user.getOpenId()) {
                        user.setOpenId(openId);
                        userService.updateOpenId(openId, user.getPhone());
                    }
                    logService.addLog(user.getId());
                    return refreshToken(user.getId());
                } else {
                    // 是第一次登录但没有在APP注册并且没有提交信息
                    UacUser uacUser = addUser(loginDto, session_key, openId);
                    logService.addLog(user.getId());
                    return generateToken(uacUser);
                }
            } else {
                // 手机登录
                UacUser user = userService.getByPhone(loginDto.getPhone());
                // 手机登录新用户
                if (PublicUtil.isEmpty(user)) {
                    boolean check = check(loginDto.getVerifyCode(), loginDto.getPhone());
                    if (check) {
                        UacUser uacUser = addUser(loginDto, session_key, openId);
                        logService.addLog(user.getId());
                        return generateToken(uacUser);
                    } else {
                        throw new CommonBizException(CommonErrorCodeEnum.COMMON10000004);
                    }
                } else {
                    // APP有信息的现在在小程序用手机号码登录
                    boolean check = check(loginDto.getVerifyCode(), loginDto.getPhone());
                    if (check) {
                        user.setOpenId(openId);
                        userService.updateOpenId(openId, user.getPhone());
                        logService.addLog(user.getId());
                        return generateToken(user);
                    } else {
                        throw new CommonBizException(CommonErrorCodeEnum.COMMON10000004);
                    }
                }
            }
        }
        return null;
    }

    private String getPhone(LoginDto loginDto, String session_key) {
        String result = null;
        try {
            result = AesCbcUtil.decrypt(loginDto.getEncryptedData(), session_key.toString(), loginDto.getIv(), "UTF-8");
            logger.info("result--->>>" + result);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String phoneNumber = null;
        if (null != result && result.length() > 0) {
            JSONObject userInfoJSON = JSONObject.parseObject(result);
            logger.info("userInfoJSON--->>>" + userInfoJSON.toJSONString());
            phoneNumber = userInfoJSON.getString("phoneNumber");
            logger.info("phoneNumber--->>>" + phoneNumber);
        }
        return phoneNumber;
    }

    private UacUser addUser(LoginDto loginDto, String session_key, String openId) {
        LoginDto.UserInfo info = loginDto.getUserInfo();
        logger.info("loginDto.getUserInfo()--->>>" + info);
        String phone = getPhone(loginDto, session_key);
        UacUserMini mini = new UacUserMini();
        if (null == userMiniMapper.selectByPhone(phone)) {
            mini.setId(generateId());
            mini.setPhone(phone);
            mini.setOpenId(openId);
            mini.setAvatarUrl(info.getAvatarUrl());
            mini.setNickName(info.getNickName());
            if (1 == info.getGender()) {
                mini.setGender("女");
            } else {
                mini.setGender("男");
            }
            mini.setCreateTime(currentTime());
            userMiniMapper.insert(mini);
        }
        UacUser uacUser = new UacUser();
        uacUser.setId(generateId());
        uacUser.setUserType(0);
        uacUser.setPhone(mini.getPhone());
        uacUser.setNickName(mini.getNickName());
        uacUser.setMotorcadeId(1L);
        uacUser.setHeadImg(mini.getAvatarUrl());
        uacUser.setMotorcadeName("默认");
        return uacUser;
    }

    private boolean check(String code, String phone) {
        VerifyCode verifyCode = (VerifyCode) redisUtil.get(VERIFY_CODE + ":" + phone);
        if (PublicUtil.isEmpty(verifyCode)) {
            throw new CommonBizException(CommonErrorCodeEnum.COMMON10000004);
        }
        if (!code.toLowerCase().equals(verifyCode.getCode())) {
            throw new CommonBizException(CommonErrorCodeEnum.COMMON10000004);
        }
        redisUtil.del(VERIFY_CODE + ":" + verifyCode.getAccount());
        return true;
    }
}