package com.ddcx.app.provider.api.friend.model.vo;


import com.ddcx.model.friend.FriendCircle;
import com.ddcx.model.friend.FriendCircleReply;
import com.ddcx.model.friend.FriendLike;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 朋友圈显示类
 */
@Data
@ApiModel("朋友圈显示类")
public class FriendCircleVo {

    @ApiModelProperty("朋友圈主体")
    private FriendCircle friendCircle;

    @ApiModelProperty("朋友圈回复列表")
    private List<FriendCircleReply> friendCircleReplys;

    @ApiModelProperty("朋友圈点赞列表")
    private List<FriendLike> likes;

    @ApiModelProperty("是否已经点赞 大于0 已经点赞 等于0没有点赞")
    private Byte isLike;


}
