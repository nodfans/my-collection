package com.ddcx.model.truck;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.math.BigDecimal;

@Table(name = "truck_road_accident")
@ApiModel("车辆交通事故记录表")
public class TruckRoadAccident {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty("主键")
    private Long id;

    /**
     * 车辆主键
     */
    @Column(name = "truck_id")
    @ApiModelProperty("车辆主键")
    private Long truckId;

    /**
     * 事故发生地点
     */
    @ApiModelProperty("事故发生地点")
    private String place;

    /**
     * 事故性质
     */
    @ApiModelProperty("事故性质")
    private String nature;

    /**
     * 事故责任
     */
    @ApiModelProperty("事故责任")
    private String responsibility;

    /**
     * 事故原因及车辆损坏情况
     */
    @ApiModelProperty("事故原因及车辆损坏情况")
    @Column(name = "main_info")
    private String mainInfo;

    /**
     * 直接经济损失（元）
     */
    @ApiModelProperty("直接经济损失（元）")
    private BigDecimal loss;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取车辆主键
     *
     * @return truck_id - 车辆主键
     */
    public Long getTruckId() {
        return truckId;
    }

    /**
     * 设置车辆主键
     *
     * @param truckId 车辆主键
     */
    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    /**
     * 获取事故发生地点
     *
     * @return place - 事故发生地点
     */
    public String getPlace() {
        return place;
    }

    /**
     * 设置事故发生地点
     *
     * @param place 事故发生地点
     */
    public void setPlace(String place) {
        this.place = place;
    }

    /**
     * 获取事故性质
     *
     * @return nature - 事故性质
     */
    public String getNature() {
        return nature;
    }

    /**
     * 设置事故性质
     *
     * @param nature 事故性质
     */
    public void setNature(String nature) {
        this.nature = nature;
    }

    /**
     * 获取事故责任
     *
     * @return responsibility - 事故责任
     */
    public String getResponsibility() {
        return responsibility;
    }

    /**
     * 设置事故责任
     *
     * @param responsibility 事故责任
     */
    public void setResponsibility(String responsibility) {
        this.responsibility = responsibility;
    }

    /**
     * 获取事故原因及车辆损坏情况
     *
     * @return main_info - 事故原因及车辆损坏情况
     */
    public String getMainInfo() {
        return mainInfo;
    }

    /**
     * 设置事故原因及车辆损坏情况
     *
     * @param mainInfo 事故原因及车辆损坏情况
     */
    public void setMainInfo(String mainInfo) {
        this.mainInfo = mainInfo;
    }

    /**
     * 获取直接经济损失（元）
     *
     * @return loss - 直接经济损失（元）
     */
    public BigDecimal getLoss() {
        return loss;
    }

    /**
     * 设置直接经济损失（元）
     *
     * @param loss 直接经济损失（元）
     */
    public void setLoss(BigDecimal loss) {
        this.loss = loss;
    }
}