package com.ddcx.app.provider.uac.web;

import com.ddcx.app.provider.api.uac.model.dto.UacFeedbackDto;
import com.ddcx.app.provider.uac.service.UacFeedbackService;
import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.base.enums.LogTypeEnum;
import com.ddcx.framework.core.annotation.RequestLog;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/feedback")
@Api(value = "问题反馈", tags = {"问题反馈"})
public class UacFeedbackController extends BaseController {

    @Autowired
    private UacFeedbackService uacFeedbackService;

    @ApiOperation(value = "反馈", notes = "反馈")
    @PostMapping(value = "/create")
    @RequestLog(logType = LogTypeEnum.REQUEST_LOG, isSaveRequestData = true, isSaveResponseData = true)
    public Wrapper create(@RequestBody @Validated UacFeedbackDto uacFeedbackDto) {
        LoginAuthDto loginAuthDto = getLoginAuthDto();
        Boolean flag = uacFeedbackService.create(loginAuthDto, uacFeedbackDto);
        if (flag) {
            return WrapMapper.ok("操作成功");
        }
        return WrapMapper.error("操作失败");
    }
}
