package com.ddcx.app.provider.exam.service;


import com.ddcx.framework.base.dto.LoginAuthDto;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.exam.UacLearnRecord;

/**
 * Created by CodeGenerator on 2020/03/11.
 */
public interface UacLearnRecordService  {


    Wrapper saveRecord(UacLearnRecord record, LoginAuthDto dto);

}
