package com.ddcx.framework.base.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TypeNameVo implements java.io.Serializable {
    private static final long serialVersionUID = 2850281864288584081L;

    @ApiModelProperty(value = "类型", name = "type")
    private Integer type;

    @ApiModelProperty(value = "名称", name = "name")
    private String name;

    public TypeNameVo(Integer type, String name) {
        this.type = type;
        this.name = name;
    }
}
