package com.ddcx.app.provider.exam.web;


import com.ddcx.app.provider.exam.service.QuestionRoomService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/03/11.
*/
@RestController
@RequestMapping("/question/room")
public class QuestionRoomController {
    @Resource
    private QuestionRoomService questionRoomService;

}
