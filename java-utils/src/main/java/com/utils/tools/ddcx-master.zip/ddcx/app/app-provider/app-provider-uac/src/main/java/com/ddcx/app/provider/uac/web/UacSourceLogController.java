package com.ddcx.app.provider.uac.web;


import com.ddcx.app.provider.uac.service.UacSourceLogService;
import com.ddcx.framework.core.support.BaseController;
import com.ddcx.framework.util.wrapper.Wrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
* Created by CodeGenerator on 2020/03/27.
*/
@RestController
@RequestMapping("/uac/source/log")
@Api(value = "积分记录",tags = "添加用户登录记录")
public class UacSourceLogController extends BaseController {
    @Resource
    private UacSourceLogService uacSourceLogService;


    @ApiOperation("更新用户登录积分<返回：1：则弹窗，0：不弹窗>")
    @GetMapping("/loginSource")
    public Wrapper loginSource(){
        return uacSourceLogService.loginSource(getLoginAuthDto());
    }

}
