package com.ddcx.common.provider.controller;


import com.ddcx.common.provider.service.CnRegionInfoService;
import com.ddcx.framework.core.annotation.NoNeedAccessAuthentication;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.common.BsArea;
import com.ddcx.model.common.BsCity;
import com.ddcx.model.common.BsProvince;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
* Created by CodeGenerator on 2020/03/23.
*/
@RestController
@RequestMapping("/cn/region/info")
@Api(value = "地址模块",tags = "地址模块")
public class CnRegionInfoController {
    @Resource
    private CnRegionInfoService cnRegionInfoService;


    @ApiOperation("获取省份列表")
    @GetMapping("/getProvinceInfo")
    public Wrapper<BsProvince>  getProvinceInfo(){
        return cnRegionInfoService.getProvinceInfo();
    }

    @ApiOperation("获取市列表")
    @GetMapping("/getCityInfo")
    public Wrapper<BsCity>  getCityInfo(){
        return cnRegionInfoService.getCityInfo();
    }

    @ApiOperation("获取区列表")
    @GetMapping("/getAreaInfo")
    public Wrapper<BsArea>  getAreaInfo(){
        return cnRegionInfoService.getAreaInfo();
    }

//    @ApiOperation("获取街道列表")
//    @GetMapping("/getStreetInfo")
//    public Wrapper<BsStreet>  getStreetInfo(){
//        return cnRegionInfoService.getStreetInfo();
//    }

    @ApiOperation("获取省市区列表")
    @GetMapping("/admin/getBcRegionInfo")
    @NoNeedAccessAuthentication
    public Wrapper<List<BsProvince>>  getBcRegionInfo(){
        return cnRegionInfoService.getBcRegionInfo();
    }




}
