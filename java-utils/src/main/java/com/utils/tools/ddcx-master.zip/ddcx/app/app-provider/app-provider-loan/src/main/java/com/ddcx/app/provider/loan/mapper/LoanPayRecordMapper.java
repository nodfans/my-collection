package com.ddcx.app.provider.loan.mapper;


import com.ddcx.framework.core.orm.MyMapper;
import com.ddcx.model.loan.LoanPayRecord;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

@Component
@Mapper
public interface LoanPayRecordMapper extends MyMapper<LoanPayRecord> {
}