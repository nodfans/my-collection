package com.ddcx.app.provider.truck.service;


import com.ddcx.model.truck.BrandVo;

import java.util.List;

/**
 * Created by CodeGenerator on 2020/02/26.
 */
public interface BrandService {


    /**
     * 获取品牌信息
     *
     * @return
     */
    List<BrandVo> getBrandVo();
}
