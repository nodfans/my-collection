package com.ddcx.common.provider.service.impl;

import com.alibaba.druid.util.Base64;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ddcx.common.provider.api.RedisKey;
import com.ddcx.common.provider.api.zhiyun.*;
import com.ddcx.common.provider.service.ZhiYunService;
import com.ddcx.framework.core.redis.RedisUtil;
import com.ddcx.framework.util.FileUtils;
import com.ddcx.framework.util.wrapper.WrapMapper;
import com.ddcx.framework.util.wrapper.Wrapper;
import com.ddcx.model.truck.Truck;
import com.openapi.sdk.service.DataExchangeService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;


@Service
@Transactional
@Log4j2
public class ZhiYunServiceImpl implements ZhiYunService {

    @Resource
    private RedisUtil redisUtil;

    @Value("${zhiyun.api.user}")
    private String zhiyunUser;

    @Value("${zhiyun.api.pwd}")
    private String zhiyunPwd;

    @Value("${zhiyun.api.srt}")
    private String zhiyunSrt;

    @Value("${zhiyun.api.cid}")
    private String zhiyunCid;

    @Value("${zhiyun.api.base_url}")
    private String zhiyunBaseUrl;





    //获取智云登录信息
    private ZhiYunRedis getZhiYunAuth(){
        Object value=redisUtil.get(RedisKey.ZHIYUN_TOKEN);
        ZhiYunRedis oldRedis=null;
        if(value!=null){
            oldRedis=JSON.parseObject(value.toString(),ZhiYunRedis.class);
        }else {
            oldRedis=login();
        }
        return oldRedis;
    }

    //登录智云
    private synchronized  ZhiYunRedis login() {
        try {
            Object value=redisUtil.get(RedisKey.ZHIYUN_TOKEN);
            ZhiYunRedis oldRedis=null;
            if(value!=null){
                oldRedis=JSON.parseObject(value.toString(),ZhiYunRedis.class);
            }
            if(oldRedis!=null&&oldRedis.getLoginNum()>8&&oldRedis.getLoginDate()==System.currentTimeMillis()/1000/60/60/24){
                log.warn("智云登录次数已经触发安全警戒，已停止登录");
                return null;
            }
            Map<String, String> map = new HashMap<>(4);
            map.put("user",zhiyunUser );
            map.put("pwd", zhiyunPwd);
            map.put("srt", zhiyunSrt);
            map.put("cid", zhiyunCid);
            String url = zhiyunBaseUrl+"/save/apis/login";
            // 通过 https 方式调用，此方法内部会使用私钥生成签名参数 sign,私钥不会发送
            DataExchangeService des = new DataExchangeService( 5000,8000);
             String result= des.postHttps(url,map);
            ZhiYunResult<String> res= JSONObject.parseObject(result,new ZhiYunResult<String>().getClass());
            log.info("返回"+result);
             ZhiYunRedis zhiYunRedis=new ZhiYunRedis();
            zhiYunRedis.setCid(zhiyunCid);
            zhiYunRedis.setLoginDate(System.currentTimeMillis()/1000/60/60/24);
            zhiYunRedis.setToken(res.getResult());
            if(!res.getStatus().equals(Integer.valueOf("1001"))){
                log.info("智云登录失败");
                return null;
            }
            if(oldRedis==null){
                zhiYunRedis.setLoginNum(1);
            }else {
                zhiYunRedis.setLoginNum(oldRedis.getLoginNum()+1);
            }
            redisUtil.set(RedisKey.ZHIYUN_TOKEN, JSON.toJSONString(zhiYunRedis));
            log.info("智云登录成功，今日已登录"+zhiYunRedis.getLoginNum()+"次。");
            return zhiYunRedis;
        } catch (Exception e) {
            System.out.println("e:" + e.getMessage());
        }
        return null;
    }

    @Override
    public Wrapper<ZhiYunIdAuth> idCardLicense(String frontPath, String reversePath) throws Exception {
        Map<String, String> map = getBaseParam();
        map.put("data", Base64.byteArrayToBase64(FileUtils.getByteArray(frontPath)));
        map.put("data2", Base64.byteArrayToBase64(FileUtils.getByteArray(reversePath)));
        map.put("fname",frontPath.substring(frontPath.lastIndexOf("/")+1));
        map.put("fname2",reversePath.substring(reversePath.lastIndexOf("/")+1));
        String url = zhiyunBaseUrl+"/save/apis/idCardLicense";
        DataExchangeService des = new DataExchangeService( 5000,8000);
        // 通过 https 方式调用，此方法内部会使用私钥生成签名参数 sign,私钥不会发送
        String result= des.postHttps(url,map);
        log.info("返回："+result);
        ZhiYunResult<ZhiYunIdAuth> res= JSONObject.parseObject(result,new ZhiYunResult<ZhiYunIdAuth>().getClass());
        if(res.getStatus().equals(Integer.valueOf("1001"))){
            return WrapMapper.ok(res.getResult());
        }else if(res.getStatus().equals(Integer.valueOf("1016"))){
            login();
            return idCardLicense_1(frontPath, reversePath);
        }else {
            return WrapMapper.error("第三方接口异常");
        }
    }

    private Wrapper<ZhiYunIdAuth> idCardLicense_1(String frontPath, String reversePath) throws Exception {
        Map<String, String> map = getBaseParam();
        map.put("data", Base64.byteArrayToBase64(FileUtils.getByteArray(frontPath)));
        map.put("data2", Base64.byteArrayToBase64(FileUtils.getByteArray(reversePath)));
        map.put("fname",frontPath.substring(frontPath.lastIndexOf("/")+1));
        map.put("fname2",reversePath.substring(reversePath.lastIndexOf("/")+1));
        String url = zhiyunBaseUrl+"/save/apis/idCardLicense";
        DataExchangeService des = new DataExchangeService( 5000,8000);
        // 通过 https 方式调用，此方法内部会使用私钥生成签名参数 sign,私钥不会发送
        String result= des.postHttps(url,map);
        ZhiYunResult<ZhiYunIdAuth> res= JSONObject.parseObject(result,new ZhiYunResult<ZhiYunIdAuth>().getClass());
        if(res.getStatus().equals(Integer.valueOf("1001"))){
            return WrapMapper.ok(res.getResult());
        }else {
            return WrapMapper.error("第三方接口异常");
        }
    }
    @Override
    public TruckLocation vLastLocationV3(String truckNum) throws Exception {
        Map<String, String> map = getBaseParam();
        map.put("vclN", truckNum);
        map.put("timeNearby","1");
        String url = zhiyunBaseUrl+"/save/apis/vLastLocationV3";
        DataExchangeService des = new DataExchangeService( 5000,8000);
        // 通过 https 方式调用，此方法内部会使用私钥生成签名参数 sign,私钥不会发送
        String result= des.postHttps(url,map);
        ZhiYunResult<TruckLocation> res= JSONObject.parseObject(result,new ZhiYunResult<TruckLocation>().getClass());
        if(res.getStatus().equals(Integer.valueOf("1016"))){
            login();
            return vLastLocationV3_1(truckNum);
        }
        return res.getResult();
    }

    /**
     * 获取基础参数
     * @return
     */
    private Map<String,String> getBaseParam(){
        ZhiYunRedis zhiyun=getZhiYunAuth();
        Map<String, String> map = new HashMap<>();
        map.put("srt",zhiyunSrt);
        map.put("token", zhiyun.getToken());
        map.put("cid", zhiyunCid);
        return map;
    }

    @Override
    public Wrapper<ZhiYunDrivingLicence> drivingLicense(String drivingPath) throws Exception {
        Map<String, String> map = getBaseParam();
        map.put("data", Base64.byteArrayToBase64(FileUtils.getByteArray(drivingPath)));
        map.put("fname",drivingPath.substring(drivingPath.lastIndexOf("/")+1));
        String url = zhiyunBaseUrl+"/save/apis/idCardLicense";
        DataExchangeService des = new DataExchangeService( 5000,8000);
        // 通过 https 方式调用，此方法内部会使用私钥生成签名参数 sign,私钥不会发送
        String result= des.postHttps(url,map);
        log.info("返回："+result);
        ZhiYunResult<ZhiYunDrivingLicence> res= JSONObject.parseObject(result,new ZhiYunResult<ZhiYunIdAuth>().getClass());
        if(res.getStatus().equals(Integer.valueOf("1001"))){
            return WrapMapper.ok(res.getResult());
        }else if(res.getStatus().equals(Integer.valueOf("1016"))){
            login();
            return drivingLicense_1(drivingPath);
        }else {
            return WrapMapper.error("第三方接口异常");
        }
    }

    @Override
    public ZhiYunBreakRules getBreakRules(Truck truck) throws Exception {
        Map<String, String> map = getBaseParam();
        String url = zhiyunBaseUrl+"/save/apis/queryIllegal";
        map.put("vclN",truck.getTruckNum());
        map.put("carType",truck.getCarType());
        map.put("vin",truck.getSemitrailerShelfNum());
        map.put("engine",truck.getEngineNum());
        DataExchangeService des = new DataExchangeService( 5000,8000);
        // 通过 https 方式调用，此方法内部会使用私钥生成签名参数 sign,私钥不会发送
        String result= des.postHttps(url,map);
        log.info("返回："+result);
        ZhiYunResult<ZhiYunBreakRules> res= JSONObject.parseObject(result,new ZhiYunResult<ZhiYunBreakRules>().getClass());
        if(res.getStatus().equals(Integer.valueOf("10000"))){
            return res.getResult();
        }else {
            return null;
        }
    }

    @Override
    public ZhiYunMileageStatistics getMileageStatistics(Truck truck,String startDate,String endDate) throws Exception {
            Map<String, String> map = getBaseParam();
            map.put("vclN", truck.getTruckNum());
            map.put("vco", truck.getTruckNumColor().toString());
            map.put("qryBtm", startDate);
            map.put("qryEtm", endDate);
            String url = zhiyunBaseUrl+"/save/apis/vQueryMileage";
            DataExchangeService des = new DataExchangeService( 5000,8000);
            // 通过 https 方式调用，此方法内部会使用私钥生成签名参数 sign,私钥不会发送
            String result= des.postHttps(url,map);
            log.info("返回："+result);
            ZhiYunResult<ZhiYunMileageStatistics> res= JSONObject.parseObject(result,new ZhiYunResult<ZhiYunMileageStatistics>().getClass());
            if(res.getStatus().equals(Integer.valueOf("1001"))){
                return res.getResult();
            }else if(res.getStatus().equals(Integer.valueOf("1016"))){
                login();
                return getMileageStatistics_1(truck,startDate,endDate);
            }else {
                return null;
            }
    }

    private ZhiYunMileageStatistics getMileageStatistics_1(Truck truck,String startDate,String endDate) throws Exception {
        Map<String, String> map = getBaseParam();
        map.put("vclN", truck.getTruckNum());
        map.put("vco", truck.getTruckNumColor().toString());
        map.put("qryBtm", startDate);
        map.put("qryEtm", endDate);
        String url = zhiyunBaseUrl+"/save/apis/vQueryMileage";
        DataExchangeService des = new DataExchangeService( 5000,8000);
        // 通过 https 方式调用，此方法内部会使用私钥生成签名参数 sign,私钥不会发送
        String result= des.postHttps(url,map);
        log.info("返回："+result);
        ZhiYunResult<ZhiYunMileageStatistics> res= JSONObject.parseObject(result,new ZhiYunResult<ZhiYunMileageStatistics>().getClass());
        if(res.getStatus().equals(Integer.valueOf("1001"))){
            return res.getResult();
        }else {
            return null;
        }
    }


    public Wrapper<ZhiYunDrivingLicence> drivingLicense_1(String drivingPath) throws Exception {
        Map<String, String> map = getBaseParam();
        map.put("data", Base64.byteArrayToBase64(FileUtils.getByteArray(drivingPath)));
        map.put("fname",drivingPath.substring(drivingPath.lastIndexOf("/")+1));
        String url = zhiyunBaseUrl+"/save/apis/idCardLicense";
        DataExchangeService des = new DataExchangeService( 5000,8000);
        // 通过 https 方式调用，此方法内部会使用私钥生成签名参数 sign,私钥不会发送
        String result= des.postHttps(url,map);
        log.info("返回："+result);
        ZhiYunResult<ZhiYunDrivingLicence> res= JSONObject.parseObject(result,new ZhiYunResult<ZhiYunIdAuth>().getClass());
        if(res.getStatus().equals(Integer.valueOf("1001"))){
            return WrapMapper.ok(res.getResult());
        }else {
            return WrapMapper.error("第三方接口异常");
        }
    }



    private TruckLocation vLastLocationV3_1(String truckNum) throws Exception {
        Map<String, String> map = getBaseParam();
        map.put("vclN", truckNum);
        map.put("timeNearby","1");
        String url = zhiyunBaseUrl+"/save/apis/vLastLocationV3";
        DataExchangeService des = new DataExchangeService( 5000,8000);
        // 通过 https 方式调用，此方法内部会使用私钥生成签名参数 sign,私钥不会发送
        String result= des.postHttps(url,map);
        ZhiYunResult<TruckLocation> res= JSONObject.parseObject(result,new ZhiYunResult<TruckLocation>().getClass());
        return res.getResult();
    }


}
