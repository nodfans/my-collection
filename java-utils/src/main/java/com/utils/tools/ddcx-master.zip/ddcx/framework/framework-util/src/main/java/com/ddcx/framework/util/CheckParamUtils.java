package com.ddcx.framework.util;


import io.swagger.annotations.ApiModelProperty;

import java.lang.reflect.Field;

/**
 * 该工具类配合swagger属性注解进行参数必填校验
 */
public class CheckParamUtils {

    public static <T> String checkParam(T t, Class clazz) {
        if (t == null) {
            return "参数不能为空";
        }
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            ApiModelProperty apiModelProperty = field.getAnnotation(ApiModelProperty.class);
            if (apiModelProperty == null || !apiModelProperty.required()) {
                continue;
            }
            field.setAccessible(true);
            if (field.getType().equals(String.class)) {
                try {
                    if (StringUtils.isBlank((String) field.get(t))) {
                        return apiModelProperty.value() + "不能为空";
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    if (field.get(t) == null) {
                        return apiModelProperty.value() + "不能为空";
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
        return "success";
    }
}
